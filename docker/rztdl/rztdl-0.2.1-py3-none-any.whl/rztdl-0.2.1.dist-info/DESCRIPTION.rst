![build failing](https://img.shields.io/badge/build-failing-red.svg) ![build failing]( https://img.shields.io/badge/coverage-83%25-yellow.svg) ![docs failing](https://img.shields.io/badge/docs-failing-red.svg) ![dev dependencies](https://img.shields.io/badge/devDependencies-out--of--date-red.svg) 
# Quickstart 

#### Requirements  
1. **OS:** macOS Maverics+ or Ubuntu 14.04+  
2. **Python:** v3.6.0+ 
3. **Tensorflow:** v1.4.0+ 

#### What is rztdl?
Razorthink's Deeplearning Library (rztdl) is a wrapper on top of
Tensorflow (current framework) which is designed with basic 4 entities  
1. Layer - The entity provides Neural Layers which can be embedded inside the model   
2. Operator - Operators which takes in one or more layers and
gives N number of layers based on the operation  
3. Model - Container for Layers - A Neural Network Model  
4. Network - Container for Model with respective Hyperparameters  

#### Design Principles of RZTDL:  
1. Simple and Clean API
2. Lightweight Library [--mem -a]
3. Zero Memory Leaks [--mem]
4. Easy Installation [--install <env>]
5. Proper Documentation [--docs -r]


#### Why rztdl?  

#### Native Tensorflow MNIST Network:<br>
```python
'''
A Convolutional Network implementation example using TensorFlow library.
This example is using the MNIST database of handwritten digits
(http://yann.lecun.com/exdb/mnist/)

Author: Aymeric Damien
Project: https://github.com/aymericdamien/TensorFlow-Examples/
'''

from __future__ import print_function

import tensorflow as tf

# Import MNIST data
from tensorflow.examples.tutorials.mnist import input_data
mnist = input_data.read_data_sets("/tmp/data/", one_hot=True)

# Parameters
learning_rate = 0.001
training_iters = 200000
batch_size = 128
display_step = 10

# Network Parameters
n_input = 784 # MNIST data input (img shape: 28*28)
n_classes = 10 # MNIST total classes (0-9 digits)
dropout = 0.75 # Dropout, probability to keep units

# tf Graph input
x = tf.placeholder(tf.float32, [None, n_input])
y = tf.placeholder(tf.float32, [None, n_classes])
keep_prob = tf.placeholder(tf.float32) #dropout (keep probability)


# Create some wrappers for simplicity
def conv2d(x, W, b, strides=1):
    # Conv2D wrapper, with bias and relu activation
    x = tf.nn.conv2d(x, W, strides=[1, strides, strides, 1], padding='SAME')
    x = tf.nn.bias_add(x, b)
    return tf.nn.relu(x)


def maxpool2d(x, k=2):
    # MaxPool2D wrapper
    return tf.nn.max_pool(x, ksize=[1, k, k, 1], strides=[1, k, k, 1],
                          padding='SAME')


# Create model
def conv_net(x, weights, biases, dropout):
    # Reshape input picture
    x = tf.reshape(x, shape=[-1, 28, 28, 1])

    # Convolution Layer
    conv1 = conv2d(x, weights['wc1'], biases['bc1'])
    # Max Pooling (down-sampling)
    conv1 = maxpool2d(conv1, k=2)

    # Convolution Layer
    conv2 = conv2d(conv1, weights['wc2'], biases['bc2'])
    # Max Pooling (down-sampling)
    conv2 = maxpool2d(conv2, k=2)

    dl_layer
    dl_layer
    fc1 = tf.reshape(conv2, [-1, weights['wd1'].get_shape().as_list()[0]])
    fc1 = tf.add(tf.matmul(fc1, weights['wd1']), biases['bd1'])
    fc1 = tf.nn.relu(fc1)
    # Apply Dropout
    fc1 = tf.nn.dropout(fc1, dropout)

    # Output, class prediction
    out = tf.add(tf.matmul(fc1, weights['out']), biases['out'])
    return out

# Store layers weight & bias
weights = {
    # 5x5 conv, 1 input, 32 outputs
    'wc1': tf.Variable(tf.random_normal([5, 5, 1, 32])),
    # 5x5 conv, 32 inputs, 64 outputs
    'wc2': tf.Variable(tf.random_normal([5, 5, 32, 64])),
    # fully connected, 7*7*64 inputs, 1024 outputs
    'wd1': tf.Variable(tf.random_normal([7*7*64, 1024])),
    # 1024 inputs, 10 outputs (class prediction)
    'out': tf.Variable(tf.random_normal([1024, n_classes]))
}

biases = {
    'bc1': tf.Variable(tf.random_normal([32])),
    'bc2': tf.Variable(tf.random_normal([64])),
    'bd1': tf.Variable(tf.random_normal([1024])),
    'out': tf.Variable(tf.random_normal([n_classes]))
}

# Construct model
pred = conv_net(x, weights, biases, keep_prob)

# Define loss and optimizer
cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=pred, labels=y))
optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(cost)

# Evaluate model
correct_pred = tf.equal(tf.argmax(pred, 1), tf.argmax(y, 1))
accuracy = tf.reduce_mean(tf.cast(correct_pred, tf.float32))

# Initializing the variables
init = tf.global_variables_initializer()

# Launch the graph
with tf.Session() as sess:
    sess.run(init)
    step = 1
    # Keep training until reach max iterations
    while step * batch_size < training_iters:
        batch_x, batch_y = mnist.train.next_batch(batch_size)
        # Run optimization op (backprop)
        sess.run(optimizer, feed_dict={x: batch_x, y: batch_y,
                                       keep_prob: dropout})
        if step % display_step == 0:
            # Calculate batch loss and accuracy
            loss, acc = sess.run([cost, accuracy], feed_dict={x: batch_x,
                                                              y: batch_y,
                                                              keep_prob: 1.})
            print("Iter " + str(step*batch_size) + ", Minibatch Loss= " + \
                  "{:.6f}".format(loss) + ", Training Accuracy= " + \
                  "{:.5f}".format(acc))
        step += 1
    print("Optimization Finished!")

    # Calculate accuracy for 256 mnist test images
    print("Testing Accuracy:", \
        sess.run(accuracy, feed_dict={x: mnist.test.images[:256],
                                      y: mnist.test.labels[:256],
                                      keep_prob: 1.}))

```



#### rztdl MNIST Network:<br>
```python
'''
A Convolutional Network implementation example using RZTDL library.
This example is using the MNIST database of handwritten digits
(http://yann.lecun.com/exdb/mnist/)

Author: Prathyush SP
'''

# Import rztdl
import rztdl.dl
from rztdl.utils.file import read_csv

# Load the Data
data_path = "data/mnist_dataset.csv"
train_data, train_label, valid_data, valid_label, test_data, test_label = read_csv(data_path, split_ratio=[10, 20, 70], delimiter=";" randomize=True, label_vector=True)

# Build the model
model = rztdl.dl.Model('cnn')
model.add_layer(rztdl.dl.layer.InputLayer("input_layer", layer_nodes=len(train_data[0])))
model.add_layer(rztdl.dl.layer.ConvolutionLayer('con1', layer_activation=rztdl.dl.constants.ACTIVATION.RELU,
                                                filter_dimensions=[5, 5, 1, 32], filter_strides=[1, 1, 1, 1],
                                                filter_padding=rztdl.dl.constants.PADDING.SAME))
model.add_layer(rztdl.dl.layer.PoolLayer('pool1', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                         pool_padding=rztdl.dl.constants.PADDING.SAME,
                                         pool_type=rztdl.dl.constants.POOL.MAX_POOL, layer_input='cnn.con1'))
model.add_layer(rztdl.dl.layer.ConvolutionLayer('con2', layer_activation=rztdl.dl.constants.ACTIVATION.RELU,
                                                filter_dimensions=[5, 5, 32, 64], filter_strides=[1, 1, 1, 1],
                                                filter_padding=rztdl.dl.constants.PADDING.SAME))
model.add_layer(rztdl.dl.layer.PoolLayer('pool2', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                         pool_padding=rztdl.dl.constants.PADDING.SAME,
                                         pool_type=rztdl.dl.constants.POOL.MAX_POOL))
model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1", layer_activation=rztdl.dl.constants.ACTIVATION.RELU, layer_nodes=10))
model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_2", layer_activation=rztdl.dl.constants.ACTIVATION.RELU, layer_nodes=10))
model.add_layer(rztdl.dl.layer.OutputLayer(name="output_layer", layer_activation=rztdl.dl.constants.ACTIVATION.IDENTITY, layer_nodes=len(train_label[0])))
model.close()

# Run the Model
network = rztdl.dl.Network('mnist_data')
network.train(epoch=5, learning_rate=0.01, model=model, cost=rztdl.dl.constants.COST.SOFTMAX_CROSS_ENTROPY,
              optimizer=rztdl.dl.constants.OPTIMIZER.ADAM,
              train_data={'input_layer': train_data, 'output_layer': train_label},
              valid_data={'input_layer': valid_data, 'output_layer': valid_label},
              test_data={'input_layer': test_data, 'output_layer': test_label},
              display_step=1, train_batches=1)

```






#### Installation
```bash
# Install Prerequisites - Mac
brew install cloc pandoc graphviz figlet

# Install Prerequisites - Linux
sudo apt-get install cloc pandoc graphviz figlet

# Setup rztdl_manager.sh variables
DEBUG=<Bool>
python_command=<Python 3.5 command>
python_pip=<Python 3.5 pip>

# Clone without dependencies
git clone https://github.com/razorthinksoftware/rztdl

# Clone with dependencies
git clone --recursive https://github.com/razorthinksoftware/rztdl

# Common
cd rztdl
pip3 install -r requirements.txt
sh rztdl_manager.sh --install dev
```

#### Generate Documentation
```bash
git clone https://github.com/razorthinksoftware/rztdl
cd rztdl
sh rztdl_manager.sh --docs -r
```
open [RZTDL-Documentation](http://localhost:8121)

#### Script Utils
```bash
# Run Tests
sh rztdl_manager.sh --tests

# Run Coverage
sh rztdl_manager.sh --coverage

# Run Code Stats
sh rztdl_manager.sh --stats

# Test Memory Leak
# For more details: https://pythonhosted.org/Pympler/tutorials/muppy_tutorial.html
sh rztdl_manager.sh --mem -t

# Test Addon Memory
sh rztdl_manager.sh --mem -a
```


#### Navigation
1. [Installation Documentation](https://github.com/razorthinksoftware/rztdl/blob/master/INSTALL.md)
2. [Todo List](https://github.com/razorthinksoftware/rztdl/issues?q=is%3Aopen+is%3Aissue+label%3Aenhancement)
3. [Simple Issue Tracker](https://github.com/razorthinksoftware/rztdl/issues?q=is%3Aopen+is%3Aissue+label%3Abug)
4. [RZTDL Configuration Documentation](https://github.com/razorthinksoftware/rztdl/blob/master/CONFIG.md)
5. [Metadata Documentation](https://github.com/razorthinksoftware/rztdl/blob/master/METADATA_DOC.md)
6. [Pycharm RZTDL Model Template](https://github.com/razorthinksoftware/rztdl/blob/master/PYTHON_RZTDL_TEMPLATE.py)

#### Contributing Guidelines
1. Commit format - [COMMIT_TYPE] - COMMIT_MESSAGE
2. Commit Types:
```Bash
  1. Critical / Major Bug Fix - [BF]
  2. Typos - [TY]
  3. Enhancement / Major Refactor - [EN]
  4. New Feature - [FE]
  5. Deprecated - [DP]
```


