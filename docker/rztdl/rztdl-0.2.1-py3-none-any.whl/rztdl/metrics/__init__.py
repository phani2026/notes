# -*- coding: utf-8 -*-
"""
| **@created on:** 29/09/17,
| **@author:** Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
| Metrics Module used to define Evaluation Metrics. It consists of
| 1. Accuracy Metric
| 2. Gini Metric
| 3. Cost Metric
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

from rztdl.metrics.evaluation_metrics import EvaluationMetric
