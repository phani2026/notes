# -*- coding: utf-8 -*-
"""
| **@created on:** 23/01/18,
| **@author:** Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
| Metrics Module used to define Evaluation Metrics. It consists of
| 1. Accuracy Metric
| 2. Gini Metric
| 3. Cost Metric
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

from rztdl.metrics.dl.primitive import *
