# -*- coding: utf-8 -*-
"""
| **@created on:** 04/10/2017,
| **@author:** Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
| Softmax Accuracy Evaluation Metrics Class
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import logging
import numpy as np
from numpy import ndarray
from typeguard import typechecked

logger = logging.getLogger(__name__)

from rztdl.metrics.evaluation_metrics import EvaluationMetric


class SoftmaxAccuracyMetric(EvaluationMetric):
    """
       | **@author:** Umesh Kumar
       |
       | Softmax Accuracy Metric class
    """

    def __init__(self):
        """

        """
        super().__init__(name="softmax_accuracy")
        self.validate()

    @typechecked
    def evaluate(self, actual_output: ndarray, predicted_output: ndarray = None):
        """

        :param actual_output: Actual output
        :param predicted_output: Predicted Output
        :return:
        """
        accurate_count = 0.0
        if np.isnan(predicted_output).any() is None:
            raise Exception("Predicted data is None")
        if np.isnan(actual_output).any() is None:
            raise Exception("Labelled data is None")
        if not isinstance(predicted_output, np.ndarray):
            raise Exception("Predicted Data is not an Numpy Array object")
        if not isinstance(actual_output, np.ndarray):
            raise Exception("Labelled Data is not an Numpy Array object")
        if not len(predicted_output) == len(actual_output):
            raise Exception("Exception: length of predicted_data and labelled_data are not similar")
        for p, l in list(zip(predicted_output, actual_output)):
            if np.argmax(p) == np.argmax(l):
                accurate_count += 1
        accuracy = float(accurate_count / float(len(predicted_output)) * 100)
        return "{0:.2f}".format(accuracy)

    def validate(self):
        """

        :return:
        """
        pass


SoftmaxAccuracyMetric = SoftmaxAccuracyMetric()
