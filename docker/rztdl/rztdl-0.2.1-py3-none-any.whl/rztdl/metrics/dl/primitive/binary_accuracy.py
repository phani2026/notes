# -*- coding: utf-8 -*-
"""
| **@created on:** 04/10/2017,
| **@author:** Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
| Binary Evaluation Metrics Class
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import logging

from numpy import ndarray
from typeguard import typechecked

logger = logging.getLogger(__name__)

from rztdl.metrics.evaluation_metrics import EvaluationMetric


class BinaryAccuracyMetric(EvaluationMetric):
    """
       | **@author:** Umesh Kumar
       |
       | Binary Accuracy Metric class
    """

    def __init__(self):
        """

        """
        super().__init__(name="binary_accuracy")
        self.validate()
        self.value = 0.0
        self.threshold = 0.5

    @typechecked
    def evaluate(self, actual_output: ndarray, predicted_output: ndarray = None):
        """

        :param actual_output: Actual output
        :param predicted_output: Predicted Output
        :return:
        """
        if not isinstance(self.value, float):
            raise Exception("Binary value should be an instance of float. Found:", type(self.value))
        accurate_count = 0.0
        if not len(predicted_output) == len(actual_output):
            raise Exception("Exception: length of predicted_data and labelled_data are not similar")
        data_count = 0
        for p, l in zip(predicted_output, actual_output):
            ret_value = [1] if p > [self.threshold] else [0]
            if ret_value == [self.value]:
                data_count += 1
                if ret_value == ([1] if l > [self.threshold] else [0]):
                    accurate_count += 1
        accuracy = float(accurate_count / float(data_count) * 100) if not float(data_count) == 0 else 0
        return "{0:.2f}".format(accuracy)

    def validate(self):
        """

        :return:
        """
        pass


BinaryAccuracyMetric = BinaryAccuracyMetric()
