# -*- coding: utf-8 -*-
"""
| **@created on:** 04/10/2017,
| **@author:** Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
| Regression Evaluation Metrics Class
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import logging
from typing import Union

import tensorflow as tf
import numpy as np
from numpy import ndarray
from typeguard import typechecked

logger = logging.getLogger(__name__)

from rztdl.metrics.evaluation_metrics import EvaluationMetric


class RegressionAccuracyMetric(EvaluationMetric):
    """
       | **@author:** Umesh Kumar
       |
       | Regression Accuracy Metric class
    """

    def __init__(self):
        """

        """
        super().__init__(name="regression_accuracy")
        self.validate()
        self.threshold = 0.5

    @typechecked
    def evaluate(self, actual_output: Union[ndarray, tf.Tensor], predicted_output: Union[ndarray, tf.Tensor] = None):
        """

        :param actual_output: Actual output
        :param predicted_output: Predicted Output
        :return:
        """
        predicted_output = np.reshape(predicted_output, newshape=[-1, ]).tolist()
        actual_output = np.reshape(actual_output, newshape=[-1, ]).tolist()
        accurate_count = sum([1 if int(i) in range(int(j - self.threshold), int(j + self.threshold)) else 0 for i, j in
                              (zip(predicted_output, actual_output))])
        accuracy = float(accurate_count / float(len(predicted_output)) * 100)
        return "{0:.2f}".format(accuracy)

    def validate(self):
        """

        :return:
        """
        pass


RegressionAccuracyMetric = RegressionAccuracyMetric()
