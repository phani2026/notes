# -*- coding: utf-8 -*-
"""
| **@created on:** 29/09/17,
| **@author:** Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
| Metrics Module used to define Evaluation Metrics. It consists of
| 1. Accuracy Metric
| 2. Gini Metric
| 3. Cost Metric
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

from rztdl.metrics.dl.primitive.accuracy_metric import AccuracyMetric
from rztdl.metrics.dl.primitive.accuracy_simple import SimpleAccuracyMetric
from rztdl.metrics.dl.primitive.regression_accuracy import RegressionAccuracyMetric
from rztdl.metrics.dl.primitive.binary_accuracy import BinaryAccuracyMetric
from rztdl.metrics.dl.primitive.softmax_accuracy import SoftmaxAccuracyMetric
from rztdl.metrics.dl.primitive.cost_metric import CostMetric
from rztdl.metrics.dl.primitive.gini_metric import GiniMetric
