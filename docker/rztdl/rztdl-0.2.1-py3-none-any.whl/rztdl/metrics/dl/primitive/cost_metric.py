# -*- coding: utf-8 -*-
"""
| **@created on:** 26/09/2017,
| **@author:** Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
| Evaluation Metrics Class
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import logging
from typing import Union

import tensorflow as tf
from numpy import ndarray
from rztdl.dl.helpers.tfhelpers import Cost, Regularisation
from rztdl.metrics.evaluation_metrics import EvaluationMetric
from rztdl.utils.string_constants import CostType, PARAMETERS
from typeguard import typechecked
from rztdl.dl.dl_dict_parsers import parse_cost_dict

logger = logging.getLogger(__name__)


class CostMetric(EvaluationMetric):
    """
    | **@author:** Umesh Kumar
    |
    | Cost Metric
    """

    def __init__(self, cost_type: str, regularisation: bool = False, regularisation_params: dict = None,
                 model_name: str = None):
        """

        """
        super().__init__(name="cost")
        self.cost = cost_type
        self.regularisation = regularisation
        self.regularisation_params = regularisation_params
        self.model_name = model_name
        self.validate()

    @typechecked
    def evaluate(self, actual_output: Union[ndarray, tf.Tensor], predicted_output: Union[ndarray, tf.Tensor]):
        """

        :param actual_output: Actual output
        :param predicted_output: Predicted Output
        :return:
        """
        if isinstance(self.cost, dict):
            cost = parse_cost_dict(actual_output=actual_output, predicted_output=predicted_output,
                                                cost_dict=self.cost)
        else:
            cost = Cost(actual_output=actual_output, predicted_output=predicted_output).switch(cost=self.cost)
        if self.regularisation:
            cost = Regularisation(input_tensor=cost, model_name=self.model_name,
                                  regularisation_params=self.regularisation_params).select_regulariser(
                self.regularisation_params[PARAMETERS.REGULARISATION_TYPE])
        tf.add_to_collection(cost.name, cost)
        return cost

    def validate(self):
        """

        :return:
        """
        if isinstance(self.cost, str):
            if self.cost not in CostType.__dict__.values():
                raise Exception("Not a valid Cost. Usage: COST.<>")
        if self.regularisation:
            logger.info(
                'Regularisation Function: {}'.format(self.regularisation_params[PARAMETERS.REGULARISATION_TYPE]))
