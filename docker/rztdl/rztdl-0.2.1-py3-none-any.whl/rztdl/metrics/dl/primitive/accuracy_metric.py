# -*- coding: utf-8 -*-
"""
| **@created on:** 26/09/2017,
| **@author:** Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
| Evaluation Metrics Class
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import logging
from typing import Union

import tensorflow as tf
from numpy import ndarray
from typeguard import typechecked

logger = logging.getLogger(__name__)

from rztdl.metrics.evaluation_metrics import EvaluationMetric


class AccuracyMetric(EvaluationMetric):
    """
    | **@author:** Umesh Kumar
    |
    | Accuracy Metric
    """

    def __init__(self):
        """

        """
        super().__init__(name="accuracy")
        self.validate()

    @typechecked
    def evaluate(self, actual_output: Union[ndarray, tf.Tensor], predicted_output: Union[ndarray, tf.Tensor] = None):
        """

        :param actual_output: Actual output
        :param predicted_output: Predicted Output
        :return:
        """
        correct_pred = tf.equal(tf.greater(predicted_output, 0.5), tf.greater(actual_output, 0.5))
        return tf.reduce_mean(tf.cast(correct_pred, tf.float32))

    def validate(self):
        """

        :return:
        """
        pass


AccuracyMetric = AccuracyMetric()
