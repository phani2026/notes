# -*- coding: utf-8 -*-
"""
| **@created on:** 08/09/2017,
| **@author:** Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
| Evaluation Metrics Runner Class
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
from collections import OrderedDict
from typing import Union

import numpy as np
import rztdl.utils.string_constants as constant
import tensorflow as tf
from numpy import ndarray
from rztdl import RZTDL_CONFIG
from rztdl import RZTDL_STORE
from rztdl.dl import tf_summary
from rztdl.metrics.evaluation_metrics import EvaluationMetric
from rztdl.statistic.algorithms import calculate_mean
from rztdl.utils.pyutils import DLTimer
from rztdl.utils.singleton import Singleton
from tensorflow import Tensor
from typeguard import typechecked


class EvaluationMetricRunner(metaclass=Singleton):
    """
    | **@author:** Umesh Kumar
    |
    | Evaluation Metric Runner
    """

    def __init__(self):
        """
        | **@author:** Umesh Kumar
        |
        | Evaluation Metric Runner init method
        """

        self.evaluation_metrics, self.cost = None, None
        self.regularisation, self.regularisation_params = None, None
        self.actual_output, self.predicted_output = None, None
        self.init = False
        self.metadata, self.model_name, self.result_object = None, None, None
        self.evaluation_metrics_switch, self.evaluation_metrics_batch_tensors = {}, {}
        self.evaluation_metrics_batch_algorithms, self.uninitialised_vars = [], []
        self.evaluation_metrics_placeholder, self.evaluation_metrics_variable = None, None
        self.evaluation_metrics_tensor, self.metric_dict = None, None
        self.batch_display_step, self.epoch_display_step = 0, 0

    @typechecked
    def initialise_variables(self, actual_output: Union[Tensor, ndarray], cost: Union[str, dict, Tensor],
                             batch_display_step: int, display_step: int, predicted_output: Union[Tensor, ndarray],
                             model_name: str, evaluation_metrics: list, result=None, regularisation: bool = False,
                             regularisation_params: dict = None, init: bool = True, metadata=None):
        """
       :param actual_output: actual output data
       :param cost: type of cost
       :param batch_display_step: batch display step
       :param display_step: epoch display step
       :param predicted_output: predicted output data
       :param model_name: model name
       :param evaluation_metrics: what are the metrics to calculate
       :param result: result object
       :param regularisation: regularisation True or False
       :param regularisation_params: parameters of regularisation
       :param init: whether to initialise tensor variables or not
       :param metadata: metadata of previous run or given run id
               """
        self.evaluation_metrics = evaluation_metrics
        self.cost = cost
        self.regularisation = regularisation
        self.regularisation_params = regularisation_params
        self.actual_output = actual_output
        self.predicted_output = predicted_output
        self.init = init
        self.result_object = result
        self.metadata = metadata
        self.model_name = model_name
        self.evaluation_metrics_switch = {}
        self.evaluation_metrics_batch_tensors = {}
        self.evaluation_metrics_batch_algorithms = []
        self.create_evaluation_metrics_switch(actual_output=ndarray(shape=[1], dtype=np.float32),
                                              predicted_output=ndarray(shape=[1], dtype=np.float32))
        self.evaluation_metrics_placeholder = OrderedDict()
        self.evaluation_metrics_variable = OrderedDict()
        self.evaluation_metrics_tensor = OrderedDict()
        self.metric_dict = OrderedDict()
        self.batch_display_step = batch_display_step
        self.epoch_display_step = display_step
        self.uninitialised_vars = []
        self.create_summaries()
        return self

    @typechecked
    def calculate_batch_result(self, batch_data: dict, output_layer_name: Tensor, layer_output: Union[ndarray],
                               batch_id, batches, train_time, json_type, session, feed_dict: dict, mode: str):
        """

        :param batch_data: Batch data dictionary with input values and output values
        :param output_layer_name: output layer name
        :param layer_output: Output from output_layer
        :param batch_id: batch ID
        :param batches: no of batches
        :param train_time: time taken to train
        :param json_type: whether to print json format or not
        :param session: tensorflow Session
        :param feed_dict: feed dictionary for session
        :param mode: whether it is Train, Valid or Test mode
        :return:
        """
        batch_result = session.run(self.evaluation_metrics_batch_tensors, feed_dict=feed_dict)
        for key, value in batch_result.items():
            if np.isnan(value):
                for k, val in batch_data.items():
                    if np.isnan(val).any():
                        raise ValueError('Dataset contains Nan. Use pd.fillna() or pd.dropna() . . .')
            if mode == constant.ModelMetaConstant.TRAIN_META:
                self.evaluation_metrics_switch[key].batch_result_value.append(float(value))
            elif mode == mode == constant.ModelMetaConstant.VALID_META:
                self.evaluation_metrics_switch[key].valid_batch_result_value.append(float(value))
            else:
                self.evaluation_metrics_switch[key].test_batch_result_value.append(float(value))
        for metric in self.evaluation_metrics_batch_algorithms:
            value = self.evaluation_metrics_switch[metric.name].evaluate(actual_output=batch_data[output_layer_name],
                                                                         predicted_output=layer_output)
            if mode == constant.ModelMetaConstant.TRAIN_META:
                self.evaluation_metrics_switch[metric.name].batch_result_value.append(float(value))
            elif mode == constant.ModelMetaConstant.VALID_META:
                self.evaluation_metrics_switch[metric.name].valid_batch_result_value.append(float(value))
            else:
                self.evaluation_metrics_switch[metric.name].test_batch_result_value.append(float(value))
        if mode == constant.ModelMetaConstant.TEST_META:
            RZTDL_STORE.add_metrics_to_meta_data(model_name=self.model_name, mode=constant.ModelMetaConstant.TEST_META,
                                                 key="batch_metrics", value=[k.name for k in self.evaluation_metrics],
                                                 metric_constant="batch_")
        if self.batch_display_step > 0 and batch_id % self.batch_display_step == 0:
            self.result_object.get_batch_result(batch_id=batch_id,
                                                train_batches=batches, train_time=train_time,
                                                json_type=json_type, log=True,
                                                evaluation_metrics_switch=self.evaluation_metrics_switch, mode=mode)
        else:
            self.result_object.get_batch_result(batch_id=batch_id,
                                                train_batches=batches, train_time=train_time,
                                                json_type=json_type, log=False,
                                                evaluation_metrics_switch=self.evaluation_metrics_switch, mode=mode)

    @typechecked
    def calculate_epoch_result(self, each_epoch: int, train_time: DLTimer, epoch: int, json_type: bool, log: bool):
        """

        :param each_epoch: current epoch
        :param train_time: training time
        :param epoch: total epochs
        :param json_type: whether result should be printed in json format or not
        :param log: whether to log the result or not
        :return:
        """
        self.result_object.get_epoch_result(each_epoch=each_epoch, train_time=train_time, epoch=epoch, log=log,
                                            json_type=json_type,
                                            evaluation_metrics_switch=self.evaluation_metrics_switch)

    @typechecked
    def calculate_test_result(self, session, test_time: DLTimer, json_type: bool, log: bool):
        """

        :param session: tensorflow Session
        :param test_time: testing time
        :param json_type: whether result should be printed in json format or not
        :param log: whether to log the result or not
        :return:
        """
        test_result_assign_tensors = {}
        test_result_placeholder_dict = {}
        for metric in self.evaluation_metrics:
            metric = metric.name
            test_result_assign_tensors[metric] = self.evaluation_metrics_tensor[metric]
            value = self.evaluation_metrics_switch[metric].test_batch_result_value
            test_result_placeholder_dict[self.evaluation_metrics_placeholder[metric]] = calculate_mean(value)
        test_result = session.run(test_result_assign_tensors, feed_dict=test_result_placeholder_dict)
        for key, value in test_result.items():
            self.evaluation_metrics_switch[key].test_result_value.append(float(value))
        self.result_object.get_test_result(test_time=test_time, log=log, json_type=json_type,
                                           evaluation_metrics_switch=self.evaluation_metrics_switch)

    def create_summaries(self):
        """

        :return:
        """
        with tf.name_scope("metrics"):
            for metric in self.evaluation_metrics:
                metric = metric.name
                if self.init:
                    self.evaluation_metrics_placeholder[metric] = tf.placeholder(
                        dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE, shape=[], name=metric + '_placeholder')
                    self.evaluation_metrics_variable[metric] = tf.Variable(dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE,
                                                                           initial_value=0, name=metric + '_variable')
                    self.evaluation_metrics_tensor[metric] = tf.assign(ref=self.evaluation_metrics_variable[metric],
                                                                       value=self.evaluation_metrics_placeholder[
                                                                           metric], name=metric + "_assign")
                    tf_summary.add_scalar_summary(name=metric + '_scalar',
                                                  tensor=self.evaluation_metrics_variable[metric])
                else:
                    if metric in self.metadata[constant.ModelMetaConstant.EVALUATION_METRICS]:
                        self.evaluation_metrics_placeholder[metric] = tf.get_collection(
                            self.metadata[constant.ModelMetaConstant.EVALUATION_METRICS_DICT][metric + '_placeholder'])[
                            0]
                        self.evaluation_metrics_variable[metric] = tf.get_collection(
                            self.metadata[constant.ModelMetaConstant.EVALUATION_METRICS_DICT][metric + '_variable'])[0]
                        self.evaluation_metrics_tensor[metric] = tf.get_collection(
                            self.metadata[constant.ModelMetaConstant.EVALUATION_METRICS_DICT][metric + '_tensor'])[0]
                    else:
                        self.evaluation_metrics_placeholder[metric] = tf.placeholder(
                            dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE, shape=[], name=metric + '_placeholder')
                        self.evaluation_metrics_variable[metric] = tf.Variable(
                            dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE, initial_value=0, name=metric + '_variable')
                        self.uninitialised_vars.append(self.evaluation_metrics_variable[metric])
                        self.evaluation_metrics_tensor[metric] = tf.assign(ref=self.evaluation_metrics_variable[metric],
                                                                           value=self.evaluation_metrics_placeholder[
                                                                               metric], name=metric + "_assign")
                        tf_summary.add_scalar_summary(name=metric + '_scalar',
                                                      tensor=self.evaluation_metrics_variable[metric])

                tf.add_to_collection(self.evaluation_metrics_tensor[metric].name,
                                     self.evaluation_metrics_tensor[metric])
                tf.add_to_collection(self.evaluation_metrics_variable[metric].name,
                                     self.evaluation_metrics_variable[metric])
                tf.add_to_collection(self.evaluation_metrics_placeholder[metric].name,
                                     self.evaluation_metrics_placeholder[metric])

                self.metric_dict[metric + '_placeholder'] = self.evaluation_metrics_placeholder[metric].name
                self.metric_dict[metric + '_tensor'] = self.evaluation_metrics_tensor[metric].name
                self.metric_dict[metric + '_variable'] = self.evaluation_metrics_variable[metric].name
            RZTDL_STORE.add_meta_data(model_name=self.model_name,
                                      key=constant.ModelMetaConstant.EVALUATION_METRICS_DICT, value=self.metric_dict)

    @typechecked
    def run_metrics_for_epoch(self, session, mode: str, batches: int):
        """

        :param batches: no of batches
        :param mode: whether it is Train, Valid or Test mode
        :param session: tensorflow session
        :return:
        """
        epoch_result_assign_tensors = {}
        epoch_result_placeholder_dict = {}
        for metric in self.evaluation_metrics:
            metric = metric.name
            epoch_result_assign_tensors[metric] = self.evaluation_metrics_tensor[metric]
            value = self.evaluation_metrics_switch[
                        metric].batch_result_value[-batches:] if mode == constant.NETWORK_MODE.TRAIN else \
                self.evaluation_metrics_switch[metric].valid_batch_result_value[-batches:]
            epoch_result_placeholder_dict[self.evaluation_metrics_placeholder[metric]] = calculate_mean(value)
        epoch_result = session.run(epoch_result_assign_tensors, feed_dict=epoch_result_placeholder_dict)
        for key, value in epoch_result.items():
            self.evaluation_metrics_switch[key].epoch_result_value.append(float(
                value)) if mode == constant.NETWORK_MODE.TRAIN else self.evaluation_metrics_switch[
                key].valid_result_value.append(float(value))

    @typechecked
    def create_evaluation_metrics_switch(self, actual_output: ndarray, predicted_output: ndarray):
        """

        :param actual_output: actual output data
        :param predicted_output: predicted output data
        :return:
        """
        batch_metrics = {}
        for metric in self.evaluation_metrics:
            if isinstance(metric, EvaluationMetric):
                self.evaluation_metrics_switch[metric.name] = metric
                if isinstance(metric.evaluate(actual_output=actual_output, predicted_output=predicted_output), Tensor):
                    if self.init:
                        batch_metric = metric.evaluate(
                            actual_output=self.actual_output, predicted_output=self.predicted_output)
                    else:
                        if metric.name in self.metadata[constant.ModelMetaConstant.EVALUATION_METRICS]:
                            batch_metric = tf.get_collection(
                                self.metadata[constant.ModelMetaConstant.BATCH_METRICS_FOR_TRAIN][
                                    metric.name + '_batch_metric'])[0]
                        else:
                            batch_metric = metric.evaluate(
                                actual_output=self.actual_output, predicted_output=self.predicted_output)
                    self.evaluation_metrics_batch_tensors[metric.name] = batch_metric
                    batch_metrics[metric.name + "_batch_metric"] = batch_metric.name
                    tf.add_to_collection(batch_metric.name, batch_metric)
                else:
                    self.evaluation_metrics_batch_algorithms.append(metric)
            else:
                # todo:: Throw exception when metric is not type of Evaluation Metric
                print("throw exception")
        RZTDL_STORE.add_meta_data(model_name=self.model_name, key=constant.ModelMetaConstant.BATCH_METRICS_FOR_TRAIN,
                                  value=batch_metrics)

    @staticmethod
    def set_evaluation_metrics(evaluation_metrics):
        """

        :param evaluation_metrics: what are the metrics to calculate
        :return:
        """
        result = []
        for metric in evaluation_metrics:
            result.append(metric.name)
        return result
