# -*- coding: utf-8 -*-
"""
| **@created on:** 23/01/2018,
| **@author:** Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
| ML Module Evaluation Metrics Runner Class
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import numpy as np
from numpy import ndarray
from tensorflow import Tensor
from typeguard import typechecked

from rztdl.metrics.evaluation_metrics import EvaluationMetric
from rztdl.utils.pyutils import DLTimer
from rztdl.utils.singleton import Singleton


class MLEvaluationMetricRunner(metaclass=Singleton):
    """
    | **@author:** Umesh Kumar
    |
    | Evaluation Metric Runner
    """

    def __init__(self):
        """
        | **@author:** Umesh Kumar
        |
        | Evaluation Metric Runner init method
        """
        self.evaluation_metrics = None
        self.evaluation_metrics_switch = {}
        self.evaluation_metrics_algorithms = []
        self.result_object = None

    def initialise_variables(self, evaluation_metrics, result):
        """

        :param evaluation_metrics: Metrics which need to calculate
        :param result: Result object
        :return:
        """
        self.evaluation_metrics = evaluation_metrics
        self.evaluation_metrics_switch = {}
        self.evaluation_metrics_algorithms = []
        self.result_object = result
        self.create_evaluation_metrics_switch(actual_output=ndarray(shape=[1], dtype=np.float32),
                                              predicted_output=ndarray(shape=[1], dtype=np.float32))

    @typechecked
    def calculate_epoch_result(self, actual_labels, predicted_labels, accuracy: float,
                               train_time: DLTimer, json_type: bool):
        """

        :param actual_labels: Actual Labels
        :param predicted_labels: Predicted Labels
        :param cost: loss calculated
        :param accuracy: accuracy calculated
        :param train_time: Time at when training has started
        :param json_type: print json_type or normal
        :return:
        """
        for metric in self.evaluation_metrics:
            metric = metric.name
            value = self.evaluation_metrics_switch[metric].evaluate(actual_output=actual_labels,
                                                                    predicted_output=predicted_labels)
            self.evaluation_metrics_switch[metric].epoch_result_value.append(float(value))
        self.result_object.get_train_result(accuracy=accuracy,
                                            evaluation_metrics_switch=self.evaluation_metrics_switch,
                                            train_time=train_time, json_type=json_type)

    @typechecked
    def calculate_test_result(self, actual_labels, predicted_labels, accuracy: float,
                              test_time: DLTimer, json_type: bool):
        """

        :param actual_labels: Actual Labels
        :param predicted_labels: Predicted Labels
        :param cost: loss calculated
        :param accuracy: accuracy calculated
        :param test_time: Time at when testing has started
        :param json_type: print json_type or normal
        :return:
        """
        for metric in self.evaluation_metrics:
            metric = metric.name
            value = self.evaluation_metrics_switch[metric].evaluate(actual_output=actual_labels,
                                                                    predicted_output=predicted_labels)
            self.evaluation_metrics_switch[metric].test_result_value.append(float(value))
        self.result_object.get_test_result(accuracy=accuracy,
                                           evaluation_metrics_switch=self.evaluation_metrics_switch,
                                           test_time=test_time, json_type=json_type)

    @typechecked
    def create_evaluation_metrics_switch(self, actual_output: ndarray, predicted_output: ndarray):
        """

        :param actual_output: actual output data
        :param predicted_output: predicted output data
        :return:
        """
        for metric in self.evaluation_metrics:
            if isinstance(metric, EvaluationMetric):
                self.evaluation_metrics_switch[metric.name] = metric
                if isinstance(metric.evaluate(actual_output=actual_output, predicted_output=predicted_output), Tensor):
                    raise Exception("Metric should not be of Tensor type")
                else:
                    self.evaluation_metrics_algorithms.append(metric)
            else:
                raise Exception("Metric should be inherited from Evaluation Metric")

    @staticmethod
    def set_evaluation_metrics(evaluation_metrics):
        """

        :param evaluation_metrics: what are the metrics to calculate
        :return:
        """
        result = []
        for metric in evaluation_metrics:
            result.append(metric.name)
        return result
