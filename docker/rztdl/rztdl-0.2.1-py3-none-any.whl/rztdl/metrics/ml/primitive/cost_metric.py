# -*- coding: utf-8 -*-
"""
| **@created on:** 26/09/2017,
| **@author:** Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
| Evaluation Metrics Class
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import logging
from typing import Union

import tensorflow as tf
from numpy import ndarray
from rztdl.ml.helpers.mlhelpers import Cost
from rztdl.metrics.evaluation_metrics import EvaluationMetric
from rztdl.utils.string_constants import CostType
from typeguard import typechecked

logger = logging.getLogger(__name__)


class CostMetric(EvaluationMetric):
    """
    | **@author:** Umesh Kumar
    |
    | Cost Metric
    """

    def __init__(self, cost_type: str):
        """

        """
        super().__init__(name="cost", write_epoch_meta=True)
        self.cost = cost_type
        self.validate()

    @typechecked
    def evaluate(self, actual_output: Union[ndarray, tf.Tensor], predicted_output: Union[ndarray, tf.Tensor]):
        """

        :param actual_output: Actual output
        :param predicted_output: Predicted Output
        :return:
        """
        cost = Cost(actual_output=actual_output, predicted_output=predicted_output).select_cost(cost=self.cost)
        return cost

    def validate(self):
        """

        :return:
        """
        if isinstance(self.cost, str):
            if self.cost not in CostType.__dict__.values():
                raise Exception("Not a valid Cost. Usage: COST.<>")
