# -*- coding: utf-8 -*-
"""
| **@created on:** 26/09/2017,
| **@author:** Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
| Evaluation Metrics Class
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import logging
from typing import Union

import tensorflow as tf
from numpy import ndarray
from rztdl.statistic.algorithms import calculate_gini_score
from typeguard import typechecked

logger = logging.getLogger(__name__)

from rztdl.metrics.evaluation_metrics import EvaluationMetric


class GiniMetric(EvaluationMetric):
    """
    | **@author:** Umesh Kumar
    |
    | Gini Metric
    """

    def __init__(self):
        """

        """
        super().__init__(name="gini")
        self.validate()

    @typechecked
    def evaluate(self, actual_output: Union[ndarray, tf.Tensor], predicted_output: Union[ndarray, tf.Tensor]):
        """

        :param actual_output: Actual output
        :param predicted_output: Predicted Output
        :return:
        """
        return calculate_gini_score(y_pred=predicted_output, y_true=actual_output)

    def validate(self):
        """

        :return:
        """
        pass


GiniMetric = GiniMetric()
