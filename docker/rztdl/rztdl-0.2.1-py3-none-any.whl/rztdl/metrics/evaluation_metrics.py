# -*- coding: utf-8 -*-
"""
| **@created on:** 08/09/2017,
| **@author:** Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
| Evaluation Metrics Class
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import logging
from abc import ABCMeta, abstractmethod
from typing import Union

import rztdl.utils.string_constants as constants
import tensorflow as tf
from numpy import ndarray
from typeguard import typechecked

logger = logging.getLogger(__name__)


class EvaluationMetric(metaclass=ABCMeta):
    """
    | **@author:** Umesh Kumar
    |
    | Used to evaluate various metrics
    """

    @abstractmethod
    def __init__(self, name: str, write_epoch_meta=True, write_batch_meta=True):
        """
        | **@author:** Umesh Kumar
        |
        """
        self.name = name
        self.write_epoch_meta = write_epoch_meta
        self.write_batch_meta = write_batch_meta
        self.batch_result_value = []
        self.epoch_result_value = []
        self.valid_result_value = []
        self.valid_batch_result_value = []
        self.test_result_value = []
        self.test_batch_result_value = []
        self.metric_value = {
            constants.ModelMetaConstant.TRAIN_META: {constants.ModelMetaConstant.EPOCH_METRICS: self.epoch_result_value,
                                                     constants.ModelMetaConstant.BATCH_METRICS: self.batch_result_value},
            constants.ModelMetaConstant.VALID_META: {constants.ModelMetaConstant.EPOCH_METRICS: self.valid_result_value,
                                                     constants.ModelMetaConstant.BATCH_METRICS: self.valid_batch_result_value},
            constants.ModelMetaConstant.TEST_META: {constants.ModelMetaConstant.TEST_METRICS: self.test_result_value,
                                                    constants.ModelMetaConstant.BATCH_METRICS: self.test_batch_result_value},
            constants.ML_MODELS.ML_TRAIN_META: {constants.ML_MODELS.TRAIN_METRICS: self.epoch_result_value},
            constants.ML_MODELS.ML_TEST_META: {constants.ML_MODELS.TEST_METRICS: self.test_result_value}

        }

    @abstractmethod
    @typechecked
    def evaluate(self, actual_output: Union[ndarray, tf.Tensor], predicted_output: Union[ndarray, tf.Tensor]):
        """

        :param actual_output: Actual output
        :param predicted_output: Predicted Output
        :return:
        """
        pass

    @abstractmethod
    def validate(self):
        """
        | **@author:** Umesh Kumar
        |
        | Metrics Validation
        """
        pass
