# -*- coding: utf-8 -*-
"""
| **@created on:** 09/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
|
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
from rztdl.utils.singleton import Singleton
from typeguard import typechecked
from rztdl.utils.dl_exception import keyexception, DatasetException, RztdlException, raises_exception
from collections import OrderedDict
from .config_manager import RZTDL_CONFIG
import numpy as np
from rztdl.utils.string_constants import ModelMetaConstant
import yaml
import logging
import os
from rztdl.utils.pyutils import ROrderedDict, File, RWeakValueDictionary
import rztdl.utils.string_constants as constants
import json
import typing

logger = logging.getLogger(__name__)


class _RztdlStore(metaclass=Singleton):
    """
    | **@author:** Prathyush SP
    |
    | RZTDL DAG
    """

    def __init__(self):
        self.store = OrderedDict()
        self.data_store = RWeakValueDictionary()
        self.meta_data = OrderedDict()

    def initialize(self):
        """
        | **@author:** Prathyush SP
        | Initialize RZTDL DAG
        """
        self.__init__()

    @typechecked
    def add_dataset(self, dataset_name: str, dataset):
        """
        | **@author:** Prathyush SP
        | Add Dataset
        :param dataset_name: Dataset Name
        :param dataset: Dataset Object
        """
        self.data_store[dataset_name] = dataset

    @typechecked
    @raises_exception(exceptions=(KeyError))
    def get_dataset(self, dataset_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Add Model
        :param dataset_name: Dataset Name
        :return Dataset Object
        """
        return self.data_store[dataset_name]

    @typechecked
    def add_to_scopes(self, model_name: str, scopes: typing.Set[str], tensor_name: str):
        try:
            # todo: Prathyush SP -  Do Variable only validation
            self.store[model_name][ModelMetaConstant.GRAPH].get_tensor_by_name(tensor_name)
        except Exception as e:
            raise Exception('Tensor [{}] not found in the model [{}] graph'.format(tensor_name, model_name))
        scopes = scopes.union(self.get_scopes_of_model(model_name))
        for scope in scopes:
            if scope in self.store[model_name][ModelMetaConstant.SCOPES]:
                self.store[model_name][ModelMetaConstant.SCOPES][scope].append(tensor_name)
            else:
                self.store[model_name][ModelMetaConstant.SCOPES][scope] = []
                self.store[model_name][ModelMetaConstant.SCOPES][scope].append(tensor_name)

    @typechecked
    def get_tensors_from_scopes(self, model_name: str, scopes: typing.Set[str]):
        """
        | **@author:** Prathyush SP
        |
        | Get tensors from scopes
        :param model_name: Model Name
        :param scopes: Scopes
        :return: Tensor List belonging to the given scopes
        """
        tensor_list = []
        for scope in scopes:
            if scope not in self.store[model_name][ModelMetaConstant.SCOPES]:
                raise Exception('{} scope Not Found!'.format(scope))
            tensor_list += self.store[model_name][ModelMetaConstant.SCOPES][scope]
        return tensor_list

    @typechecked
    def add_model_scopes(self, model_name: str, scopes: typing.Set[str]):
        self.store[model_name][ModelMetaConstant.MODEL_SCOPES] = scopes

    @typechecked
    def get_scopes_of_model(self, model_name: str):
        return self.store[model_name][ModelMetaConstant.MODEL_SCOPES]

    @typechecked
    def get_scopes_of_model_components(self, model_name: str):
        return self.store[model_name][ModelMetaConstant.SCOPES]

    @typechecked
    def add_model(self, model_name: str):
        """
        | **@author:** Prathyush SP
        | Add Model
        :param model_name: Model Name
        """
        if model_name in self.store.keys():
            raise Exception('Model Name must be unique: ' + model_name)
        self.store[model_name] = OrderedDict(
            [(ModelMetaConstant.MODEL_ARCHITECTURE, ROrderedDict()),
             (ModelMetaConstant.COMPONENT_OUTPUT, ROrderedDict()),
             (ModelMetaConstant.REQUIRED_INPUT_FOR_METRICS, ROrderedDict()),
             (ModelMetaConstant.NODE, ROrderedDict()),
             (ModelMetaConstant.COMPONENTS, RWeakValueDictionary()),
             (ModelMetaConstant.LOG_COMPONENTS, ROrderedDict()),
             (ModelMetaConstant.DATASETS, ROrderedDict()),
             (ModelMetaConstant.TRAINABLE_VARIABLES, ROrderedDict()),
             (ModelMetaConstant.MODEL_SCOPES, []),
             (ModelMetaConstant.SCOPES, OrderedDict()),
             (ModelMetaConstant.RNN_STATES, ROrderedDict()),
             (ModelMetaConstant.GRAPH, None), (ModelMetaConstant.PLACEHOLDERS, ROrderedDict()),
             (ModelMetaConstant.DROPOUT_PLACEHOLDERS, ROrderedDict()),
             (ModelMetaConstant.PREDICTION_PLACEHOLDERS, ROrderedDict()),
             (ModelMetaConstant.LR_PLACEHOLDERS, ROrderedDict()),
             (ModelMetaConstant.METADATA, OrderedDict()), (ModelMetaConstant.WEIGHTS, ROrderedDict()),
             (ModelMetaConstant.BIAS, ROrderedDict()), (ModelMetaConstant.TRAIN_OP, ROrderedDict())])

    @typechecked
    def remove_model(self, model_name: str):
        """
        | **@author:** Prathyush SP
        | Remove Model
        :param model_name: Model Name
        """
        if model_name not in self.store.keys():
            raise Exception('Model Name does not exist: {}'.format(model_name))
        del self.store[model_name]

    @typechecked
    @keyexception
    def add_and_validate_model_datasets(self, model_name: str, dataset_dict: OrderedDict):
        # todo: Prathyush SP - Optimize this method
        train_dataset_values = list(dataset_dict.values())
        train_dataset_keys = list(dataset_dict.keys())

        # Check if a train template exists:
        if constants.DatasetTemplate._TRAIN_TEMPLATE not in train_dataset_values:
            raise DatasetException('Train Flow requires at least one dataset of train template')

        # Check for multiple train templates:
        train_temp = None
        for e, v in enumerate(train_dataset_values):
            if v == constants.DatasetTemplate._TRAIN_TEMPLATE:
                if train_temp is not None:
                    raise DatasetException(
                        'There already exists a dataset ({}) of train template. Change the dataset ({}) '
                        'to either valid / test template'.format(train_dataset_keys[train_temp], train_dataset_keys[e]))
                train_temp = e
        self.store[model_name][ModelMetaConstant.DATASETS] = dataset_dict

    @typechecked
    @keyexception
    def add_meta_data(self, model_name: str, key: str, value: typing.Union[list, dict, OrderedDict, str, int, float]):
        """
        | **@author:** Prathyush SP
        | Add Meta Data
        :param model_name: Model Name
        :param key: Meta Key
        :param value: Meta Data
        """
        self.store[model_name][ModelMetaConstant.METADATA][key] = value

    @typechecked
    @keyexception
    def add_meta_data_dict(self, model_name: str, items: typing.Union[dict, OrderedDict]):
        """
        | **@author:** Prathyush SP
        | Add Meta Data
        :param model_name: Model Name
        :param items: Dictionary
        """
        for k, v in items.items():
            self.store[model_name][ModelMetaConstant.METADATA][k] = v

    @typechecked
    @keyexception
    def add_result_meta_data_dict(self, model_name: str, mode: str, item: typing.Union[dict, OrderedDict]):
        """
        | **@author:** Prathyush SP
        | Add Result Metadata Dictionary
        :param model_name: Model Name
        :param mode: Model <Train/Valid/Test>
        :param item: Dictionary Object
        """
        for k, v in item.items():
            self.store[model_name][ModelMetaConstant.METADATA][mode][k] = v

    @typechecked
    @keyexception
    def add_metrics_to_meta_data(self, model_name: str, mode: str, key: str, value: list, metric_constant: str):
        """
        | **@author:** Umesh Kumar
        | Add Metrics Metadata Dictionary
        :param model_name: Model Name
        :param mode:  <Train/Valid/Test>
        :param key: dictionary key
        :param value: dictionary value
        :param metric_constant: <epoch/valid/test/batch>
        :return:
        """
        self.store[model_name][ModelMetaConstant.METADATA][mode][key] = OrderedDict()
        for metric in value:
            self.store[model_name][ModelMetaConstant.METADATA][mode][key][metric_constant + metric] = []

    @typechecked
    @keyexception
    def append_value_to_key(self, model_name: str, key: str, value: typing.Union[int, list, float, str, np.float32]):
        """
        | **@author:** Umesh Kumar
        | Append new value to existing key in meta_data
        :param model_name:
        :param key: meta_data key
        :param value: meta_data value
        """
        if value:
            self.store[model_name][ModelMetaConstant.METADATA][key].append(value)

    @typechecked
    @keyexception
    def append_value_to_key_dict(self, model_name: str, item: dict):
        """
        | **@author:** Umesh Kumar
        | Append new value to existing key in meta_data
        :param model_name:
        :param item: Dictionary Object
        """
        for k, v in item.items():
            self.store[model_name][ModelMetaConstant.METADATA][k].append(v)

    @typechecked
    @keyexception
    def append_value_to_result_key(self, model_name: str, mode: str, key: str, value: str):
        """
        | **@author:** Prathyush SP
        | Append value to result as key
        :param model_name: Model Name
        :param mode: Model <Train/Valid/Test>
        :param key: Key
        :param value: Value
        """
        self.store[model_name][ModelMetaConstant.METADATA][mode][key].append(value)

    @typechecked
    def update_value_of_result_key(self, model_name: str, key: str, value: typing.Union[str, int]):
        """
        | **@author:** Umesh Kumar
        | Update value to result as key
        :param model_name: Model Name
        :param key: Key
        :param value: Value
        """
        try:
            self.store[model_name][ModelMetaConstant.METADATA][key] = value
        except KeyError as ke:
            raise Exception('key not found', ke)

    @typechecked
    @keyexception
    def append_value_to_result_dict(self, model_name: str, mode: str, item: dict):
        """
        | **@author:** Prathyush SP
        | Append value to result as dictionary
        :param model_name: Model Name
        :param mode: Model <Train/Valid/Test>
        :param item: Dictionary Object
        """
        for k, v in item.items():
            if v is not None:
                if k in ["epoch_metrics", "batch_metrics", "test_metrics", "train_metrics"]:
                    for key, value in item[k].items():
                        self.store[model_name][ModelMetaConstant.METADATA][mode][k][key] = value
                else:
                    self.store[model_name][ModelMetaConstant.METADATA][mode][k].append(v)

    @typechecked
    @keyexception
    def set_value_to_result_dict(self, model_name: str, mode: str, item: dict):
        """
        | **@author:** Prathyush SP
        | Set value to result as dictionary
        :param model_name: Model Name
        :param mode: Mode <Train/Valid/Test>
        :param item: Dictionary Object
        """
        for k, v in item.items():
            if v is not None:
                self.store[model_name][ModelMetaConstant.METADATA][mode][k] = v

    @typechecked
    @keyexception
    def update_model_architecture(self, model_name: str, layer_name: str, layer_details: OrderedDict):
        self.store[model_name][ModelMetaConstant.MODEL_ARCHITECTURE][layer_name] = layer_details

    @typechecked
    @keyexception
    def update_model_operator_architecture(self, model_name: str, operator_name: str, operator_details: OrderedDict):
        self.store[model_name][ModelMetaConstant.MODEL_ARCHITECTURE][operator_name] = operator_details

    @typechecked
    @keyexception
    def get_meta_data(self, model_name: str) -> dict:
        """
        | **@author:** Prathyush SP
        | Get Meta Data
        :param model_name: Model Name
        :return: Model Metadata
        """
        return self.store[model_name][ModelMetaConstant.METADATA]

    @typechecked
    @keyexception
    def get_meta_data_by_key(self, model_name: str, key: str) -> str:
        """
        | **@author:** Umesh Kumar
        | Get Meta Data by key
        :param model_name: Model Name
        :param key : meta_data key
        :return: Model Metadata value of given key
        """
        return self.store[model_name][ModelMetaConstant.METADATA][key]

    @typechecked
    @keyexception
    def get_meta_data_by_mode_and_key(self, model_name: str, mode: str, key: str):
        """
        | **@author:** Umesh Kumar
        | Get Meta Data by mode and key
        :param mode: mode
        :param model_name: Model Name
        :param key : meta_data key
        :return: Model Metadata value of given key
        """
        return self.store[model_name][ModelMetaConstant.METADATA][mode][key]

    @typechecked
    @keyexception
    def get_key_of_model_operator_architecture(self, model_name: str, key: str):
        """

        :param model_name: Model Name
        :param key:meta_data key
        :return:Model dl_operator architecture Metadata value of given key
        """
        return self.store[model_name][ModelMetaConstant.MODEL_ARCHITECTURE][key]

    @typechecked
    def add_logs_to_tmp(self, path: str):
        """
        | **@author:** Umesh Kumar
        | Adding logs to the PATH_LOG folder
        :param path: Path where logs has to store
        """
        # default_path = os.path.join("/".join(__file__.split('/')[:-1]), 'config', 'rztdl_logging.yaml')
        # noinspection PyProtectedMember
        with open(RZTDL_CONFIG.CommonConfig._GLOBAL_LOGGING_CONFIG_FILE_PATH, 'rt') as f:
            config = yaml.safe_load(f.read())
            keys = [key for key in config['handlers'].keys()]
            for key in keys:
                if 'filename' in config['handlers'][key].keys():
                    log_path = config['handlers'][key]['filename']
                    log_path = log_path.split('/')
                    try:
                        log_file_path = open(path + '/' + log_path[-1], 'w')
                        file_path = open(config['handlers'][key]['filename'])
                        [log_file_path.write(line) for line in file_path.readlines()]
                        os.remove(config['handlers'][key]['filename'])
                    except FileNotFoundError or Exception as e:
                        logging.warning('Logging Files not found!!')
                    config['handlers'][key]['filename'] = path + '/' + log_path[-1]
            logging.config.dictConfig(config)
            # todo: Prathyush SP - Enable when coloredlogs package supports filters (https://github.com/xolox/python-coloredlogs/issues/32)
            # coloredlogs.install(fmt=config['formatters']['standard']['format'], stream=sys.stdout,
            #                     level=logging.INFO)

    @typechecked
    @keyexception
    def add_graph(self, model_name: str, graph):
        """
        | **@author:** Prathyush SP
        | Add Tensorflow Graph
        :param model_name: Model Name
        :param graph: Tensorflow Graph
        """
        if self.store[model_name][ModelMetaConstant.GRAPH] is None:
            self.store[model_name][ModelMetaConstant.GRAPH] = graph
        else:
            raise Exception('Model Graph is already initialized')

    @typechecked
    @keyexception
    def remove_graph(self, model_name: str):
        """
        | **@author:** Prathyush SP
        | Add Tensorflow Graph
        :param model_name: Model Name
        """
        if self.store[model_name][ModelMetaConstant.GRAPH]:
            del self.store[model_name][ModelMetaConstant.GRAPH]
        else:
            raise Exception('Model Graph does not exist!')

    @typechecked
    @keyexception
    def get_graph(self, model_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Get Tensorflow Graph
        :param model_name: Model Name
        :return: Tensorflow Graph
        """
        return self.store[model_name][ModelMetaConstant.GRAPH]

    @typechecked
    @keyexception
    def update_graph(self, model_name: str, graph):
        """
        | **@author:** Prathyush SP
        |
        | Update Model Graph
        :param model_name: Model Name
        :param graph: Tensorflow Graph
        :return:
        """
        self.store[model_name][ModelMetaConstant.GRAPH] = graph

    @typechecked
    @keyexception
    def add_component_output_as_tensor(self, model_name: str, component_name: any, tensor_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Add Component output as a tensor
        :param model_name: Model Name
        :param component_name: Component Name
        :param tensor_name: Tensor Name
        """
        self.store[model_name][ModelMetaConstant.COMPONENT_OUTPUT][component_name] = tensor_name

        # todo: Prathyush SP - Refactor {tensorname: component name} to support multiple components referring to same tensor. Ex: Output Buffer
        if component_name in self.store[model_name][ModelMetaConstant.COMPONENTS]:
            if tensor_name not in self.store[model_name][ModelMetaConstant.NODE]:
                self.store[model_name][ModelMetaConstant.NODE][tensor_name] = component_name

    @typechecked
    @keyexception
    def add_required_input_for_metrics_as_tensor(self, model_name: str, metric_component_name: any, tensor_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Add Component output as a tensor
        :param model_name: Model Name
        :param metric_component_name: Metric Component Name
        :param tensor_name: Tensor Name
        """
        self.store[model_name][ModelMetaConstant.REQUIRED_INPUT_FOR_METRICS][metric_component_name] = tensor_name

    @typechecked
    @keyexception
    def get_required_input_for_metrics_as_tensor(self, model_name: str, metric_component_name: any):
        """
        | **@author:** Prathyush SP
        |
        | Get Component output as a tensor
        :param model_name: Model Name
        :param metric_component_name: Metric Component Name
        """
        return self.store[model_name][ModelMetaConstant.REQUIRED_INPUT_FOR_METRICS][metric_component_name]

    @typechecked
    def get_node_from_graph(self, model_name: str, node_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Get node from Graph
        :param model_name: Model Name
        :param node_name: Node Name
        :return: Node from Tensorflow Graph
        """
        if node_name in self.store[model_name][ModelMetaConstant.COMPONENT_OUTPUT]:
            node_name = self.store[model_name][ModelMetaConstant.COMPONENT_OUTPUT][node_name]
        try:
            return self.get_tensor_from_graph(model_name=model_name, tensor_name=node_name)
        except (KeyError, ValueError):
            pass

        try:
            return self.get_operation_from_graph(model_name=model_name, operation_name=node_name)
        except (KeyError, ValueError):
            raise Exception('{} Node not found in the graph'.format(node_name))

    @raises_exception(exceptions=(KeyError, ValueError), log_exception=False)
    @typechecked
    def get_tensor_from_graph(self, model_name: str, tensor_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Get Tensor from graph
        :param model_name: Model Name
        :param tensor_name: Tensor Name
        :return: Tensorflow Tensor
        """
        return self.store[model_name][ModelMetaConstant.GRAPH].get_tensor_by_name(tensor_name)

    @raises_exception(exceptions=(KeyError, ValueError), log_exception=False)
    @typechecked
    def get_operation_from_graph(self, model_name: str, operation_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Get Operation from graph
        :param model_name:
        :param operation_name:
        :return:
        """
        return self.store[model_name][ModelMetaConstant.GRAPH].get_operation_by_name(operation_name)

    @raises_exception(exceptions=(KeyError, ValueError, IndexError), log_exception=False)
    @typechecked
    def get_variable_from_graph(self, model_name: str, variable_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Get Variable from graph
        :param model_name:
        :param variable_name:
        :return:
        """
        return self.store[model_name][ModelMetaConstant.GRAPH].get_collection('variables', scope=variable_name)[0]

    @typechecked
    def get_component_output_as_tensor(self, model_name: str, component_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Get Component Output as a tensor
        :param model_name: Model Name
        :param component_name: Component Name
        :return Tensor
        """
        if '.' in component_name:
            if len(component_name.split('.')) == 2:
                model_name, component_name = component_name.split('.')
            else:
                raise Exception('Layer Input supports: model_name.layer_name. Given: {}'.format(component_name))
        try:
            return self.store[model_name][ModelMetaConstant.GRAPH].get_tensor_by_name(
                self.store[model_name][ModelMetaConstant.COMPONENT_OUTPUT][component_name])
        except KeyError as ke:
            print('Model Layers: \n{}'.format(self.store[model_name][ModelMetaConstant.COMPONENT_OUTPUT]))
            logger.error('model_name: {}, layer_name: {}'.format(model_name, component_name))
            raise Exception('key error, ', ke)

    @keyexception
    @typechecked
    def get_component_output_from_tensor_name(self, model_name: str, tensor_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Get Component Output as a tensor
        :param model_name: Model Name
        :param tensor_name: Component Name
        :return Component Name
        """
        return self.store[model_name][ModelMetaConstant.NODE][tensor_name]

    @typechecked
    @keyexception
    def register_component(self, model_name: str, component_name: any, component):
        """
        | **@author:** Prathyush SP
        |
        | Add Component
        :param model_name: Model Name
        :param component_name: Component Name
        :param component: Component
        """
        self.store[model_name][ModelMetaConstant.COMPONENTS][component_name] = component

    @typechecked
    @keyexception
    def get_component(self, model_name: str, component_name: any):
        """
        | **@author:** Prathyush SP
        |
        | Get Component
        :param model_name: Model Name
        :param component_name: Component Name
        :return Component Object
        """
        return self.store[model_name][ModelMetaConstant.COMPONENTS][component_name]

    @typechecked
    @keyexception
    def add_rnn_state(self, model_name: str, state_name: any, tensor_name: str):
        """
        | **@author:** Umesh Kumar
        |
        | Add Layer
        :param model_name: Model Name
        :param state_name: Layer Name
        :param tensor_name: Tensor Name
        """
        self.store[model_name][ModelMetaConstant.RNN_STATES][state_name] = tensor_name

    @typechecked
    @keyexception
    def get_rnn_state(self, model_name: str, state_name: str):
        """
        | **@author:** Umesh Kumar
        |
        | Get Layer
        :param model_name: Model Name
        :param state_name: Layer Name
        :return Tensor
        """
        if '.' in state_name:
            if len(state_name.split('.')) == 2:
                model_name, layer_name = state_name.split('.')
            else:
                raise Exception('State Input supports: model_name.layer_name. Given: {}'.format(state_name))
        return self.store[model_name][ModelMetaConstant.GRAPH].get_tensor_by_name(
            self.store[model_name][ModelMetaConstant.RNN_STATES][state_name])

    @typechecked
    @keyexception
    def add_components_to_log(self, model_name: str, component_name: str, tensor_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Add components to log in runner
        :param model_name: Model Name
        :param component_name: Component Name
        :param tensor_name: Tensor Name
        """
        self.store[model_name][ModelMetaConstant.LOG_COMPONENTS][component_name] = tensor_name

    @typechecked
    @keyexception
    def get_components_to_log(self, model_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Get components to log in runner
        :param model_name: Model Name
        """
        return self.store[model_name][ModelMetaConstant.LOG_COMPONENTS]

    @typechecked
    @keyexception
    def add_unstack_operator(self, model_name: str, layer_name: any, tensors: list):
        """
        | **@author:** Umesh Kumar
        |
        | Add Unstack Operator
        :param model_name: Model Name
        :param layer_name: Layer Name
        :param tensors: Tensor Name
        """
        for i, tensor in enumerate(tensors):
            self.store[model_name][ModelMetaConstant.LAYERS][layer_name + "_" + str(i)] = tensor

    @typechecked
    @keyexception
    def get_unstack_operator(self, model_name: str, layer_name: any, start_index, end_index):
        """

        :param model_name: Model Name
        :param layer_name:  Layer Name
        :param start_index: start index to slice
        :param end_index: end index to slice
        :return:
        """
        operator_list = []
        operator_names = []
        for i in range(start_index, end_index, 1):
            operator_list.append(self.store[model_name][ModelMetaConstant.GRAPH].get_tensor_by_name(
                self.store[model_name][ModelMetaConstant.LAYERS][layer_name + "_" + str(i)]))
            operator_names.append(self.store[model_name][ModelMetaConstant.LAYERS][layer_name + "_" + str(i)])
        return operator_list, operator_names

    @typechecked
    @keyexception
    def get_placeholder(self, model_name: str, layer_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Get Placeholder
        :param model_name: Model Name
        :param layer_name: Layer Name
        :return: Placeholder
        """
        return self.store[model_name][ModelMetaConstant.GRAPH].get_tensor_by_name(
            self.store[model_name][ModelMetaConstant.PLACEHOLDERS][layer_name])

    @typechecked
    @keyexception
    def add_placeholder(self, model_name: str, layer_name: str, placeholder_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Add Placeholder
        :param model_name: Model Name
        :param layer_name: Layer Name
        :param placeholder_name: Placeholder Name
        """
        self.store[model_name][ModelMetaConstant.PLACEHOLDERS][layer_name] = placeholder_name

    @typechecked
    @keyexception
    def add_lr_placeholder(self, model_name: str, optimiser_name: str, placeholder_name: str):
        """
        | **@author:** Umesh Kumar
        |
        | Add Placeholder
        :param model_name: Model Name
        :param optimiser_name: Layer Name
        :param placeholder_name: Placeholder Name
        """
        self.store[model_name][ModelMetaConstant.LR_PLACEHOLDERS][optimiser_name] = placeholder_name

    @typechecked
    @keyexception
    def get_all_lr_placeholders(self, model_name: str):
        """
        | **@author:** Umesh Kumar
        |
        | Add Prediction Placeholder
        :param model_name: Model Name
        """
        return {name: lr_placeholder for name, lr_placeholder in
                self.store[model_name][ModelMetaConstant.LR_PLACEHOLDERS].items()}

    @typechecked
    @keyexception
    def add_prediction_placeholder(self, model_name: str, layer_name: str, placeholder_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Add Prediction Placeholder
        :param model_name: Model Name
        :param layer_name: Layer Name
        :param placeholder_name: Placeholder Name
        """
        self.store[model_name][ModelMetaConstant.PREDICTION_PLACEHOLDERS][layer_name] = placeholder_name

    @typechecked
    @keyexception
    def add_dropout_placeholder(self, model_name: str, placeholder_name: str, value: float):
        """
        | **@author:** Prathyush SP
        |
        | Add Dropout Placeholder
        :param model_name: Model Name
        :param placeholder_name: Layer Name
        :param value: Placeholder Value
        """
        self.store[model_name][ModelMetaConstant.DROPOUT_PLACEHOLDERS][placeholder_name] = value

    @typechecked
    @keyexception
    def get_all_dropout_placeholders(self, model_name: str, mode: str):
        """
        | **@author:** Prathyush SP
        |
        | Get Dropout Placeholders for Prediction
        :param model_name: Model Name
        """
        if model_name in self.store:
            dropout_placeholder_dict = {}
            for dropout_placeholder_name, dropout_placeholder_value in self.store[model_name][
                ModelMetaConstant.DROPOUT_PLACEHOLDERS].items():
                dropout_placeholder_dict[self.store[model_name][ModelMetaConstant.GRAPH].get_tensor_by_name(
                    dropout_placeholder_name)] = dropout_placeholder_value if mode == constants.NETWORK_MODE.TRAIN else 1.0
            return dropout_placeholder_dict
        else:
            raise Exception('Model does not Exist: {}'.format(model_name))

    @typechecked
    @keyexception
    def get_all_placeholders(self, model_name: str, fetch_tensors: bool = False):
        """
        | **@author:** Prathyush SP
        |
        | Get All placeholders
        :param model_name: Model Name
        :param fetch_tensors: Fetch tensors instead of tensor names
        :return: List of Placeholder
        """

        return {name: self.store[model_name][ModelMetaConstant.GRAPH].get_tensor_by_name(
            placeholder) if fetch_tensors else placeholder for name, placeholder in
                self.store[model_name][ModelMetaConstant.PLACEHOLDERS].items()}
        # placeholder_dict = OrderedDict()
        # for name, placeholder in self.store[model_name][ModelMetaConstant.PLACEHOLDERS].items():
        #     placeholder_dict[name] = self.store[model_name][ModelMetaConstant.GRAPH].get_tensor_by_name(placeholder)
        # return placeholder_dict

    @typechecked
    def get_all_weights(self, model_name: str):
        """
        | **@author:** Umesh Kumar
        |
        | Get All weights
        |
        | Refactor 1:
        | **@author:** Prathyush SP
        | Changed return type from list of tuples to Ordered Dictionaries
        :param model_name: Model Name
        :return: Dictionary of Weights, k:name, v: tensor
        """
        if model_name in self.store:
            weight_dict = OrderedDict()
            for name, weight in self.store[model_name][ModelMetaConstant.WEIGHTS].items():
                weight_dict[name] = self.store[model_name][ModelMetaConstant.GRAPH].get_tensor_by_name(weight)
            return weight_dict
        else:
            raise Exception('Model does not Exist: {}'.format(model_name))

    @typechecked
    @keyexception
    def get_weights(self, model_name: str, layer_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Get Weights
        :param model_name: Model Name
        :param layer_name: Layer Name
        :return: Tensor
        """
        return self.store[model_name][ModelMetaConstant.GRAPH].get_tensor_by_name(
            self.store[model_name][ModelMetaConstant.WEIGHTS][layer_name])

    @typechecked
    @keyexception
    def add_weights(self, model_name: str, layer_name: str, layer_weights: str):
        """
        | **@author:** Prathyush SP
        |
        | Add Weights
        :param model_name: Model Name
        :param layer_name: Layer Name
        :param layer_weights: Layer Weights
        """
        self.store[model_name][ModelMetaConstant.WEIGHTS][layer_name] = layer_weights

    @typechecked
    def get_bias(self, model_name: str, layer_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Get Bias
        :param model_name: Model Name
        :param layer_name: Layer Name
        :return: Layer Bias - Tensor
        """
        try:
            return self.store[model_name][ModelMetaConstant.GRAPH].get_tensor_by_name(
                self.store[model_name][ModelMetaConstant.BIAS][layer_name])
        except KeyError as ke:
            raise Exception('Key Error', ke)

    @typechecked
    def add_bias(self, model_name: str, layer_name: str, layer_bias: str):
        """
        | **@author:** Prathyush SP
        |
        | Add Bias
        :param model_name: Model Name
        :param layer_name: Layer Name
        :param layer_bias: Layer Bias
        """
        try:
            self.store[model_name][ModelMetaConstant.BIAS][layer_name] = layer_bias
        except KeyError as ke:
            raise Exception('Key Error', ke)

    @typechecked
    def validate_metadata(self, metadata: typing.Union[dict, OrderedDict]):
        """
        | **@author:** Prathyush SP
        |
        | Validate Metadata
        :param metadata: Metadata Dictionary Object
        """
        val_metadata = OrderedDict()
        for k, v in metadata.items():
            if RZTDL_CONFIG.MetadataConfig.METADATA[k]:
                if isinstance(v, dict) or isinstance(v, OrderedDict):
                    if k in [constants.ModelMetaConstant.TRAIN_META, constants.ModelMetaConstant.TEST_META,
                             constants.ModelMetaConstant.VALID_META]:
                        val_metadata[k] = OrderedDict()
                        for key, value in v.items():
                            if key in [constants.ModelMetaConstant.EPOCH_METRICS,
                                       constants.ModelMetaConstant.BATCH_METRICS,
                                       constants.ModelMetaConstant.TEST_METRICS]:
                                if RZTDL_CONFIG.MetadataConfig.METADATA[k + '_options'][key]:
                                    val_metadata[k][key] = OrderedDict()
                                    for each_key in v[key].keys():
                                        write_to_meta = True if (key == constants.ModelMetaConstant.BATCH_METRICS and
                                                                 v[key][each_key].write_batch_meta) or \
                                                                (key == constants.ModelMetaConstant.EPOCH_METRICS and
                                                                 v[key][each_key].write_epoch_meta) or (
                                                                        key == constants.ModelMetaConstant.TEST_METRICS and
                                                                        v[key][each_key].write_epoch_meta) else False
                                        if write_to_meta:
                                            val_metadata[k][key][each_key] = v[key][each_key].metric_value[k][key]
                            elif RZTDL_CONFIG.MetadataConfig.METADATA[k + '_options'][key]:
                                val_metadata[k][key] = value
                    elif k in [constants.ML_MODELS.ML_TRAIN_META, constants.ML_MODELS.ML_TEST_META]:
                        val_metadata[k] = OrderedDict()
                        for key, value in v.items():
                            if key in [constants.ML_MODELS.TRAIN_METRICS, constants.ML_MODELS.TEST_METRICS]:
                                if RZTDL_CONFIG.MetadataConfig.METADATA[k][key]:
                                    val_metadata[k][key] = OrderedDict()
                                    for each_key in v[key].keys():
                                        write_to_meta = True if (key == constants.ML_MODELS.TRAIN_METRICS and
                                                                 v[key][each_key].write_epoch_meta) or (
                                                                        key == constants.ML_MODELS.TEST_METRICS and
                                                                        v[key][each_key].write_epoch_meta) else False
                                        if write_to_meta:
                                            val_metadata[k][key][each_key] = v[key][each_key].metric_value[k][key][-1]
                            elif RZTDL_CONFIG.MetadataConfig.METADATA[k][key]:
                                val_metadata[k][key] = value
                    else:
                        val_metadata[k] = v
                else:
                    val_metadata[k] = v
        return val_metadata

    @typechecked
    def load_metadata(self, path: str, name: str, model_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Load Metadata
        :param path: Metadata Path
        :param name: Network Name
        :param model_name: Model Name
        :return:
        """
        if self.meta_data:
            if RZTDL_CONFIG.CommonConfig.PARALLEL_MODELS:
                self.meta_data = self.validate_metadata(self.store[model_name][ModelMetaConstant.METADATA])
            else:
                keys = [int(k) for k in self.meta_data.keys()]
                self.meta_data[int(max(keys))] = self.validate_metadata(
                    self.store[model_name][ModelMetaConstant.METADATA])
        else:
            if File.is_exist(path + name + '/model.meta'):
                try:
                    self.meta_data = File.read_json(path + name + '/model.meta', object_pairs_hook=OrderedDict)
                    if RZTDL_CONFIG.CommonConfig.PARALLEL_MODELS:
                        self.meta_data = self.validate_metadata(self.store[model_name][ModelMetaConstant.METADATA])
                    else:
                        keys = [int(k) for k in self.meta_data.keys()]
                        self.meta_data[int(max(keys)) + 1] = self.validate_metadata(
                            self.store[model_name][ModelMetaConstant.METADATA])
                except Exception as e:
                    logger.warning('Unable to fetch Model Metadata. Creating a new Metadata')
                    if RZTDL_CONFIG.CommonConfig.PARALLEL_MODELS:
                        self.meta_data = self.validate_metadata(self.store[model_name][ModelMetaConstant.METADATA])
                    else:
                        self.meta_data = OrderedDict()
                        self.meta_data[0] = self.validate_metadata(self.store[model_name][ModelMetaConstant.METADATA])
            else:
                logger.warning('Metadata does not exist. Creating new Metadata . . .')
                if RZTDL_CONFIG.CommonConfig.PARALLEL_MODELS:
                    self.meta_data = self.validate_metadata(self.store[model_name][ModelMetaConstant.METADATA])
                else:
                    self.meta_data[0] = self.validate_metadata(self.store[model_name][ModelMetaConstant.METADATA])

    @typechecked
    def save_metadata(self, path: str, name: str, model_name: str):
        """
        | **@author:** Write Metadata to a file
        :param path: Save Path
        :param name: Network Name
        :param model_name: Model Name
        """
        self.load_metadata(path, name, model_name)
        if RZTDL_CONFIG.CommonConfig.PARALLEL_MODELS:
            File.write_json(data=self.meta_data, save_path=path + '/' + name, file_name='model.meta', reverse=False)
        else:
            File.write_json(data=self.meta_data, save_path=path + '/' + name, file_name='model.meta', reverse=True)

    def __repr__(self):
        """
        | **@author:** Prathyush SP
        |
        | Return RZTDL_DAG dict
        :return:
        """
        repr_dict = OrderedDict()
        for model_name, model_items in self.store.items():
            repr_dict[model_name] = OrderedDict(
                [(ModelMetaConstant.LAYERS, OrderedDict()), (ModelMetaConstant.PLACEHOLDERS, OrderedDict())])
            for layers, tensors in model_items[ModelMetaConstant.LAYERS].items():
                repr_dict[model_name][ModelMetaConstant.LAYERS][layers] = tensors.name
            for placeholder_name, placeholder_val in model_items[ModelMetaConstant.PLACEHOLDERS].items():
                repr_dict[model_name][ModelMetaConstant.PLACEHOLDERS][placeholder_name] = placeholder_val.name
        return json.dumps(repr_dict, indent=2).__str__()


RZTDL_STORE = _RztdlStore()
