# -*- coding: utf-8 -*-
"""
| *@created on:* 21/05/18,
| *@author:* Umesh Kumar,
| *@version:* v0.0.1
|
| *Description:*
|
| *Sphinx Documentation Status:* Complete
|
"""

import typing

import networkx as nx
from typeguard import typechecked


class Parser(object):
    """
    | **@author:** Umesh Kumar
    |
    | DL model Parser
    """

    @typechecked
    def __init__(self, parser_config_json: dict):
        """
        | **@author:** Umesh Kumar
        |
        :param parser_config_json: DL Model Parser Config JSON
        """
        self.parser_config_json = parser_config_json

    @typechecked
    def get_model_code(self, model_config_json: dict):
        """

        :param model_config_json: Model Designer generated JSON
        :return:
        """
        component_blocks = self.get_block_order(model_config_json=model_config_json)
        code = "import rztdl.dl\nimport rztdl.utils\nimport logging\nimport traceback\n" \
               "from rztdl.utils.dl_exception import RztdlException\r\nfrom functools " \
               "import wraps\r\n\r\nlogger = logging.getLogger(__name__)\n"
        code += "def check_exception(f):\r\n    @wraps(f)\r\n    def wrapped(*args, **kwargs):\r\n        " \
                "try:\r\n           ""return f(*args, **kwargs)\r\n        except RztdlException as e:\r\n            " \
                "e.traceback = traceback.format_exc()\r\n            logger.error(e.__repr__())\r\n            " \
                "exit(1)\r\n\r\n    return wrapped\n\n"
        code += "@check_exception\ndef model_fn():\n\tmodel = rztdl.dl.Model('{}')\n".format(model_config_json["name"])
        model_code = "model = rztdl.dl.Model('{}')\n".format(
            model_config_json["name"])
        component_blocks_code = ''
        for block in component_blocks:
            component_parameters = ""
            block_id = list(block.keys())[0]
            block_inputs = self.get_block_inputs(block_inputs=block[block_id])
            component_parameters += block_inputs
            block_parameters = self.get_block_parameters(
                block_parameters=model_config_json["blocks"][block_id]["parameters"],
                component_block=model_config_json["blocks"][block_id])
            component_parameters += block_parameters
            block_outputs = self.get_block_outputs(block_outputs=model_config_json["blocks"][block_id]["outputs"],
                                                   component_block=model_config_json["blocks"][block_id])
            component_parameters += block_outputs
            component_parameters += "{}='{}',".format("name", model_config_json["blocks"][block_id]["name"])
            component_blocks_code += "\tmodel.add_component(" + \
                                     self.parser_config_json[model_config_json["blocks"][block_id]["component_id"]][
                                         "class_name"] + "(" + component_parameters[:-1] + "))\n"
        code += component_blocks_code
        model_code += component_blocks_code.replace("\t", "")
        model_code += "\nmodel.close()"
        code += "\tmodel.close()\n\nmodel = model_fn()"
        return model_code, code

    @staticmethod
    @typechecked
    def get_block_order(model_config_json: dict):
        """

        :param model_config_json: Model Designer generated JSON
        :return:
        """
        graph = nx.MultiDiGraph()
        for i in model_config_json["blocks"]:
            graph.add_node(i)

        if model_config_json["connections"]:
            for i, conn in model_config_json["connections"].items():
                source = conn["source"]["id"]
                target = conn["target"]["id"]
                if model_config_json["blocks"][source["block_id"]]["outputs"][source["slot_id"]]["parameters"]:
                    out = model_config_json["blocks"][source["block_id"]]["outputs"][source["slot_id"]]["parameters"][
                        "name"]
                else:
                    out = model_config_json["blocks"][source["block_id"]]["outputs"][source["slot_id"]]["name"]
                inp = model_config_json["blocks"][target["block_id"]]["inputs"][target["slot_id"]]["internal_name"]
                graph.add_edge(source["block_id"], target["block_id"], **{inp: out})

        k = []
        for node in nx.topological_sort(graph):
            t = {node: {}}
            if len(list(graph.predecessors(node))) > 1:
                component_inputs = ComponentInputs()
                for m in graph.predecessors(node):
                    for each_input in graph.get_edge_data(m, node).values():
                        component_inputs.update(each_input)
                t[node].update(component_inputs.component_input)
            else:
                for m in graph.predecessors(node):
                    t[node].update(graph.get_edge_data(m, node)[0])
            k.append(t)
        return k

    @staticmethod
    @typechecked
    def get_block_inputs(block_inputs: typing.Union[dict, None]):
        """

        :param block_inputs: Inputs for the block
        :return:
        """
        block_inputs_parameters = ""
        if block_inputs:
            for block_input_key, block_input_value in block_inputs.items():
                block_inputs_parameters += "{}='{}',".format(block_input_key, str(block_input_value)) if isinstance(
                    block_input_value, str) else "{}={},".format(block_input_key, block_input_value)
        return block_inputs_parameters

    def get_block_parameters(self, block_parameters: typing.Union[dict, None], component_block: dict):
        """

        :param block_parameters: Parameter for the block
        :param component_block: DL Model Designer generated JSON
        :return:
        """
        block_parameter_attributes = ""
        if block_parameters:
            for attribute, value in block_parameters.items():
                if isinstance(value, dict):
                    all_attributes = self.get_all_attributes(block_attribute=attribute, block_property=value,
                                                             component_block=
                                                             self.parser_config_json[component_block["component_id"]][
                                                                 "parameters"])
                    block_parameter_attributes += "{}={},".format(attribute, all_attributes)
                elif isinstance(value, list) and isinstance(value[0], dict):
                    list_attributes = ""
                    for each_value in value:
                        list_attributes += self.get_all_attributes(block_attribute=attribute, block_property=each_value,
                                                                   component_block=
                                                                   self.parser_config_json[
                                                                       component_block["component_id"]][
                                                                       "parameters"]) + ","
                    block_parameter_attributes += "{}=[{}],".format(attribute, list_attributes[:-1])

                else:
                    if attribute != "name":
                        block_parameter_attributes += "{}='{}',".format(attribute, str(value)) \
                            if isinstance(value, str) else "{}={},".format(attribute, value)
        return block_parameter_attributes

    @typechecked
    def get_all_attributes(self, block_attribute: str, block_property: dict, component_block: list):
        """

        :param block_property:
        :param block_attribute:
        :param component_block:
        :return:
        """
        if "properties" in block_property.keys() and block_property["properties"]:
            for component_parameter in component_block:
                if block_attribute == component_parameter["internal_name"]:
                    property_values = component_parameter["class_name"] + "." + block_property["internal_name"]
                    parameter = ""
                    for block_property_key, block_property_value in block_property["properties"].items():
                        if isinstance(block_property_value, dict):
                            if component_parameter["render_type"] == "DropDown":
                                key = "possible_values"
                            else:
                                key = "properties"
                            for value in component_parameter[key]:
                                if value["internal_name"] == block_property["internal_name"]:
                                    block_property_attributes = self.get_all_attributes(
                                        block_attribute=block_property_key,
                                        block_property=block_property_value,
                                        component_block=value["properties"])
                                    parameter += "{}={},".format(block_property_key, block_property_attributes)
                        else:
                            parameter += "{}='{}',".format(block_property_key, str(block_property_value)) if isinstance(
                                block_property_value, str) else "{}={},".format(block_property_key,
                                                                                block_property_value)
                    property_values = property_values + "(" + parameter[:-1] + ")"
                    return property_values
                else:
                    pass
        elif "properties" in block_property.keys() and not block_property["properties"]:
            for component_parameter in component_block:
                if block_attribute == component_parameter["internal_name"]:
                    property_values = component_parameter["class_name"] + "." + block_property["internal_name"]
                    return property_values
        elif "properties" not in block_property.keys():
            for component_parameter in component_block:
                if block_attribute == component_parameter["internal_name"]:
                    property_values = component_parameter["class_name"] + "." + block_property["internal_name"]
                    return property_values

    @typechecked
    def get_block_outputs(self, block_outputs: typing.Union[dict, None], component_block: dict):
        """

        :param block_outputs:
        :param component_block:
        :return:
        """
        block_output_parameters = ""
        if block_outputs:
            component_outputs = ComponentOutputs()
            for block_output_key, block_output_value in block_outputs.items():
                if "parameters" in block_output_value.keys() and block_output_value["parameters"]:
                    for each_output in self.parser_config_json[component_block["component_id"]]["outputs"]:
                        if each_output["internal_name"] == block_output_value["internal_name"]:
                            component_outputs.update(each_output=block_output_value["parameters"],
                                                     component_properties=each_output["properties"])
                else:
                    block_output_parameters += "{}='{}',".format(block_output_value["internal_name"],
                                                                 block_output_value["name"])
            if component_outputs.component_output:
                for attribute, value in component_outputs.component_output.items():
                    block_output_parameters += "{}={},".format(attribute, value)
        return block_output_parameters


class ComponentInputs(dict):
    """
        | **@author:** Umesh Kumar
        |
        """

    def __init__(self):
        """
        | **@author:** Umesh Kumar
        |
        """
        super().__init__()
        self.component_input = {}

    def update(self, each_input, **kwargs):
        """

        :param each_input:
        :return:
        """
        for key, value in each_input.items():
            if key not in self.component_input.keys():
                self.component_input[key] = value
            elif isinstance(self.component_input[key], list):

                self.component_input[key].append(value)
            else:
                self.component_input[key] = [self.component_input[key], value]


class ComponentOutputs(dict):
    """
        | **@author:** Umesh Kumar
        |
        """

    def __init__(self):
        """
        | **@author:** Umesh Kumar
        |
        """
        super().__init__()
        self.component_output = {}

    def update(self, each_output: dict, **kwargs):
        """

        :param each_output:
        :return:
        """
        for key, value in each_output.items():
            for each_property in kwargs["component_properties"]:
                if each_property["internal_name"] == key:
                    key = each_property["link_to_attribute"] if "link_to_attribute" in each_property.keys() else key
                    if key not in self.component_output.keys():
                        self.component_output[key] = value
                    elif isinstance(self.component_output[key], list):
                        self.component_output[key].append(value)
                    else:
                        self.component_output[key] = [self.component_output[key], value]
