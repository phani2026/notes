"""
@created on: 18/01/17,
@author: Prathyush SP,
@version: v0.0.1

Description:

Sphinx Documentation Status:

..todo::

"""
from rztdl import Singleton
from rztdl.utils.string_constants import JSON_PARSER
import json
from collections import OrderedDict
from jinja2 import Template
import requests
import rztdl.dl

operator_dict = {}
layer_dict = {}


class Model:
    @staticmethod
    def create_model(name: str):
        DLParser.model_list.append('model = contrib.dl.Model(\'{}\')'.format(name))

    @staticmethod
    def add_layer(layer):
        add_layer_template = Template('model.add_layer({{layer}})')
        DLParser.model_list.append(add_layer_template.render(layer=layer))

    @staticmethod
    def add_operator(operator):
        add_operator_template = Template('model.add_operator({{operator}})')
        DLParser.model_list.append(add_operator_template.render(operator=operator))

    @staticmethod
    def close_model():
        DLParser.model_list.append('model.close()')


class Util:
    @staticmethod
    def initializer_switch(init_dict):
        try:
            init_type = init_dict[JSON_PARSER.INITIALIZER.INITIALIZER_TYPE][JSON_PARSER.INITIALIZER.INITIALIZER_VALUE]
        except Exception as e:
            init_type = init_dict[JSON_PARSER.INITIALIZER.INITIALIZER_TYPE]
        if init_type == JSON_PARSER.INITIALIZER.RANDOM_NORMAL:
            init_props = init_dict[JSON_PARSER.INITIALIZER.INITIALIZER_TYPE][
                JSON_PARSER.INITIALIZER.INITIALIZER_PROPERTIES]
            mean, std_dev, seed = init_props[JSON_PARSER.INITIALIZER.INITIALIZER_MEAN] or 0.0, init_props[
                JSON_PARSER.INITIALIZER.INITIALIZER_STDDEV] or 1.0, init_props[
                                      JSON_PARSER.INITIALIZER.INITIALIZER_SEED] or 0
            return "contrib.dl.constants.INITIALIZER.random_normal(mean={}, std_dev={}, seed={})".format(mean, std_dev,
                                                                                                         seed)
        elif init_type == JSON_PARSER.INITIALIZER.RANDOM_UNIFORM:
            init_props = init_dict[JSON_PARSER.INITIALIZER.INITIALIZER_TYPE][
                JSON_PARSER.INITIALIZER.INITIALIZER_PROPERTIES]
            minval, maxval, seed = init_props[JSON_PARSER.INITIALIZER.INITIALIZER_MIN] or 0.0, init_props[
                JSON_PARSER.INITIALIZER.aINITIALIZER_MAX] or 1.0, init_props[
                                       JSON_PARSER.INITIALIZER.INITIALIZER_SEED] or 0
            return "contrib.dl.constants.INITIALIZER.random_uniform(min_val={}, max_val={}, seed={})".format(minval,
                                                                                                             maxval,
                                                                                                             seed)
        elif init_type == JSON_PARSER.INITIALIZER.ONES:
            return "contrib.dl.constants.INITIALIZER.ONES"
        elif init_type == JSON_PARSER.INITIALIZER.ZEROS:
            return "contrib.dl.constants.INITIALIZER.ZEROS"

    @staticmethod
    def activation_switch(act_type):
        if act_type == JSON_PARSER.ACTIVATION.SIGMOID:
            return "contrib.dl.constants.ACTIVATION.SIGMOID"
        elif act_type == JSON_PARSER.ACTIVATION.RELU:
            return "contrib.dl.constants.ACTIVATION.RELU"
        elif act_type == JSON_PARSER.ACTIVATION.TANH:
            return "contrib.dl.constants.ACTIVATION.TANH"
        elif act_type == JSON_PARSER.ACTIVATION.SOFTMAX:
            return "contrib.dl.constants.ACTIVATION.SOFTMAX"
        elif act_type == JSON_PARSER.ACTIVATION.IDENTITY:
            return "contrib.dl.constants.ACTIVATION.IDENTITY"
        elif act_type == JSON_PARSER.ACTIVATION.NONE:
            return "contrib.dl.constants.ACTIVATION.NONE"

    @staticmethod
    def padding_switch(pad_type):
        if pad_type == JSON_PARSER.PADDING.SAME:
            return "contrib.dl.constants.PADDING.SAME"
        elif pad_type == JSON_PARSER.PADDING.VALID:
            return "contrib.dl.constants.PADDING.VALID"

    @staticmethod
    def pool_switch(pool_type):
        if pool_type == JSON_PARSER.POOL.MAX_POOL:
            return "contrib.dl.constants.POOL.MAX_POOL"
        elif pool_type == JSON_PARSER.POOL.AVG_POOL:
            return "contrib.dl.constants.POOL.AVG_POOL"


class Layer(object):
    @staticmethod
    def input_layer(layer_name, layer_nodes):
        return Template(
            "contrib.dl.layer.InputLayer(name='{{layer_name}}', layer_nodes={{layer_nodes}})").render(
            layer_name=layer_name, layer_nodes=layer_nodes)

    @staticmethod
    def fully_connected_layer(layer_name, layer_activation, layer_nodes, layer_weights, layer_bias, layer_input):
        layer_weights = Util.initializer_switch(layer_weights)
        layer_bias = Util.initializer_switch(layer_bias)
        if layer_input:
            return Template(
                "contrib.dl.layer.FullyConnectedLayer(name='{{layer_name}}', layer_activation={{layer_activation}}, "
                "layer_nodes={{layer_nodes}}, layer_weights={{layer_weights}}, layer_bias={{layer_bias}}, layer_input='{{layer_input}}')").render(
                layer_name=layer_name, layer_activation=Util.activation_switch(layer_activation),
                layer_nodes=layer_nodes,
                layer_weights=layer_weights, layer_bias=layer_bias,
                layer_input=layer_input)
        else:
            return Template(
                "contrib.dl.layer.FullyConnectedLayer(name='{{layer_name}}', layer_activation={{layer_activation}}, "
                "layer_nodes={{layer_nodes}}, layer_weights={{layer_weights}}, layer_bias={{layer_bias}})").render(
                layer_name=layer_name, layer_activation=Util.activation_switch(layer_activation),
                layer_nodes=layer_nodes,
                layer_weights=layer_weights, layer_bias=layer_bias)

    @staticmethod
    def convolution_layer(layer_name, layer_activation, filter_dimensions, filter_strides,
                          filter_padding, layer_filter, layer_bias, layer_input):
        layer_filter = Util.initializer_switch(layer_filter)
        layer_bias = Util.initializer_switch(layer_bias)
        if layer_input:
            return Template(
                "contrib.dl.layer.ConvolutionLayer(name='{{layer_name}}', layer_activation={{layer_activation}}, "
                "filter_dimensions={{filter_dimensions}}, filter_strides={{filter_strides}}, filter_padding={{filter_padding}},"
                "layer_bias={{layer_bias}}, layer_filter={{layer_filter}}, layer_input='{{layer_input}}')").render(
                layer_name=layer_name, layer_activation=Util.activation_switch(layer_activation),
                layer_filter=layer_filter, layer_bias=layer_bias, filter_strides=filter_strides,
                filter_padding=Util.padding_switch(filter_padding), filter_dimensions=filter_dimensions,
                layer_input=layer_input)
        else:
            return Template(
                "contrib.dl.layer.ConvolutionLayer(name='{{layer_name}}', layer_activation={{layer_activation}}, "
                "filter_dimensions={{filter_dimensions}}, filter_strides={{filter_strides}}, filter_padding={{filter_padding}},"
                "layer_bias={{layer_bias}}, layer_filter={{layer_filter}})").render(
                layer_name=layer_name, layer_activation=Util.activation_switch(layer_activation),
                layer_filter=layer_filter, layer_bias=layer_bias, filter_strides=filter_strides,
                filter_padding=Util.padding_switch(filter_padding), filter_dimensions=filter_dimensions)


    @staticmethod
    def pool_layer(layer_name, pool_dimensions, pool_strides, pool_padding, pool_type, layer_input):
        if layer_input:
            return Template(
                "contrib.dl.layer.PoolLayer(name='{{layer_name}}', pool_dimensions={{pool_dimensions}}, pool_strides={{pool_strides}}, pool_padding={{pool_padding}}, pool_type={{pool_type}}, layer_input='{{layer_input}}')").render(
                layer_name=layer_name, pool_dimensions=pool_dimensions, pool_strides=pool_strides,
                pool_padding=Util.padding_switch(pool_padding), pool_type=Util.pool_switch(pool_type), layer_input=layer_input)
        else:
            return Template(
                "contrib.dl.layer.PoolLayer(name='{{layer_name}}', pool_dimensions={{pool_dimensions}}, pool_strides={{pool_strides}}, pool_padding={{pool_padding}}, pool_type={{pool_type}})").render(
                layer_name=layer_name, pool_dimensions=pool_dimensions, pool_strides=pool_strides,
                pool_padding=Util.padding_switch(pool_padding), pool_type=Util.pool_switch(pool_type))

    @staticmethod
    def output_layer(layer_name, layer_nodes, layer_activation, layer_weights, layer_bias, layer_input):
        layer_weights = Util.initializer_switch(layer_weights)
        layer_bias = Util.initializer_switch(layer_bias)
        if layer_input:
            return Template(
                "contrib.dl.layer.OutputLayer(name='{{layer_name}}', layer_nodes={{layer_nodes}}, layer_activation={{layer_activation}}, "
                "layer_weights={{layer_weights}}, layer_bias={{layer_bias}}, layer_input='{{layer_input}}')").render(
                layer_name=layer_name, layer_activation=Util.activation_switch(layer_activation),
                layer_weights=layer_weights, layer_bias=layer_bias, layer_nodes=layer_nodes, layer_input=layer_input)
        else:
            return Template(
                "contrib.dl.layer.OutputLayer(name='{{layer_name}}', layer_nodes={{layer_nodes}}, layer_activation={{layer_activation}}, "
                "layer_weights={{layer_weights}}, layer_bias={{layer_bias}})").render(
                layer_name=layer_name, layer_activation=Util.activation_switch(layer_activation),
                layer_weights=layer_weights, layer_bias=layer_bias, layer_nodes=layer_nodes)


class Operator(object):
    @staticmethod
    def split_operator(operator_name, operator_dimension, input_tensor, output_tensors):
        global operator_dict
        op_temp_tensors = {v: 'split_{}'.format(len(operator_dict) + i) for i, v in enumerate(output_tensors)}
        operator_dict = {**operator_dict, **op_temp_tensors}
        return Template(
            "contrib.dl.operator.SplitOperator(name='{{operator_name}}', operator_input='{{input_tensor}}', operator_output={{output_tensor}}, dimension={{operator_dimension}})"
        ).render(operator_name=operator_name, input_tensor=input_tensor, output_tensor=list(op_temp_tensors.values()),
                 operator_dimension=operator_dimension)

    @staticmethod
    def concat_operator(operator_name, operator_dimension, input_tensors, output_tensor):
        global operator_dict
        operator_dict[output_tensor] = 'concat_{}'.format(len(operator_dict) + 1)
        return Template(
            "contrib.dl.operator.ConcatOperator(name='{{operator_name}}', operator_input={{input_tensors}}, operator_output = '{{output_tensor}}', dimension = {{operator_dimension}})"
        ).render(operator_name=operator_name, input_tensors=input_tensors, output_tensor=operator_dict[output_tensor],
                 operator_dimension=operator_dimension)

    @staticmethod
    def reshape_operator(operator_name, input_tensor, output_tensor, shape):
        global operator_dict
        operator_dict[output_tensor] = 'reshape_{}'.format(len(operator_dict) + 1)
        return Template(
            "contrib.dl.operator.ReshapeOperator(name='{{operator_name}}', operator_input='{{input_tensor}}', operator_output='{{output_tensor}}', shape={{shape}})"
        ).render(operator_name=operator_name, input_tensor=input_tensor, output_tensor=operator_dict[output_tensor],
                 shape=shape)


class DLParser(metaclass=Singleton):
    model_list, model = [], Model

    def __init__(self, model_config, save_path, local: bool = True):
        self.template = ['import contrib.dl']
        self.tf_file_path = save_path
        self.model_name = ''
        if local:
            try:
                self.model_data = json.loads(model_config)
                print(self.model_data)
            except json.decoder.JSONDecodeError:
                self.read_json(model_config)
                print(self.model_data)
        else:
            self.model_name = model_config
            self.model_data = self.fetch_json(model_name=model_config)
            print(self.model_data)
        self.generate_model()
        self.get_template()
        self.write_template()

    def generate_model(self):
        components = self.model_data
        global layer_dict

        # [v[JSON_PARSER.PARAMETERS.COMPONENT] for k, v in self.model_data.items() if
        #       v[JSON_PARSER.LAYERS.TYPE] == JSON_PARSER.PARAMETERS.LAYER]
        self.model.create_model(self.model_name)
        for id, component in components.items():
            if component[JSON_PARSER.LAYERS.TYPE] == JSON_PARSER.PARAMETERS.LAYER:
                layer = component[JSON_PARSER.PARAMETERS.COMPONENT]
                if layer[JSON_PARSER.LAYERS.TYPE] == JSON_PARSER.LAYERS.INPUT_LAYER:
                    layer = layer[JSON_PARSER.LAYERS.LAYERPARAMETERS]
                    self.model.add_layer(
                        Layer().input_layer(
                            layer_name=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_NAME],
                            layer_nodes=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_NODES]))
                elif layer[JSON_PARSER.LAYERS.TYPE] == JSON_PARSER.LAYERS.FULLY_CONNECTED_LAYER:
                    layer = layer[JSON_PARSER.LAYERS.LAYERPARAMETERS]
                    layer_input = operator_dict[
                        layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][
                            JSON_PARSER.LAYERS.LAYER_NAME]] if \
                        layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][
                            JSON_PARSER.LAYERS.LAYER_NAME] in operator_dict else None
                    self.model.add_layer(Layer.fully_connected_layer(
                        layer_name=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_NAME],
                        layer_activation=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][
                            JSON_PARSER.LAYERS.LAYER_ACTIVATION],
                        layer_nodes=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_NODES],
                        layer_weights=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_WEIGHTS],
                        layer_bias=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_BIAS],
                        layer_input=layer_input))
                elif layer[JSON_PARSER.LAYERS.TYPE] == JSON_PARSER.LAYERS.OUTPUT_LAYER:
                    layer = layer[JSON_PARSER.LAYERS.LAYERPARAMETERS]
                    layer_input = operator_dict[
                        layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][
                            JSON_PARSER.LAYERS.LAYER_NAME]] if \
                        layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][
                            JSON_PARSER.LAYERS.LAYER_NAME] in operator_dict else None
                    self.model.add_layer(Layer.output_layer(
                        layer_name=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_NAME],
                        layer_activation=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][
                            JSON_PARSER.LAYERS.LAYER_ACTIVATION],
                        layer_weights=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][
                            JSON_PARSER.LAYERS.LAYER_WEIGHTS],
                        layer_bias=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][
                            JSON_PARSER.LAYERS.LAYER_BIAS],
                        layer_nodes=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][
                            JSON_PARSER.LAYERS.LAYER_NODES], layer_input=layer_input))
                    # elif target[PARAMETERS.LAYER_TYPE] == LAYERS.CONVOLUTION_LAYER:
                    #     self.model.add_layer(Layer.convolution_layer(layer_name=target[PARAMETERS.LAYER_NAME],
                    #                                                  layer_activation=target[PARAMETERS.PARAMETERS][
                    #                                                      PARAMETERS.LAYER_ACTIVATION],
                    #                                                  filter_dimensions=target[PARAMETERS.PARAMETERS][
                    #                                                      PARAMETERS.FILTER_DIMENSIONS],
                    #                                                  filter_strides=target[PARAMETERS.PARAMETERS][
                    #                                                      PARAMETERS.FILTER_STRIDES],
                    #                                                  filter_padding=target[PARAMETERS.PARAMETERS][
                    #                                                      PARAMETERS.FILTER_PADDNING],
                    #                                                  layer_filter=target[PARAMETERS.PARAMETERS][
                    #                                                      PARAMETERS.LAYER_FILTER],
                    #                                                  layer_nodes=target[PARAMETERS.PARAMETERS][
                    #                                                      PARAMETERS.LAYER_NODES],
                    #                                                  layer_bias=target[PARAMETERS.PARAMETERS][
                    #                                                      PARAMETERS.LAYER_BIAS]))
                    #
                    # elif target[PARAMETERS.LAYER_TYPE] == LAYERS.POOL_LAYER:
                    #     self.model.add_layer(Layer.pool_layer(layer_name=target[PARAMETERS.LAYER_NAME],
                    #                                           pool_dimensions=target[PARAMETERS.PARAMETERS][
                    #                                               PARAMETERS.POOL_DIMENSIONS],
                    #                                           pool_strides=target[PARAMETERS.PARAMETERS][
                    #                                               PARAMETERS.POOL_STRIDES],
                    #                                           pool_padding=target[PARAMETERS.PARAMETERS][
                    #                                               PARAMETERS.POOL_PADDING],
                    #                                           pool_type=target[PARAMETERS.PARAMETERS][PARAMETERS.POOL_TYPE]))
                elif layer[JSON_PARSER.LAYERS.TYPE] == JSON_PARSER.LAYERS.CONVOLUTION_LAYER:
                    layer = layer[JSON_PARSER.LAYERS.LAYERPARAMETERS]
                    layer_input = operator_dict[
                        layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][
                            JSON_PARSER.LAYERS.LAYER_NAME]] if \
                        layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][
                            JSON_PARSER.LAYERS.LAYER_NAME] in operator_dict else None
                    self.model.add_layer(Layer.convolution_layer(
                        layer_name=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_NAME],
                        layer_activation=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][
                            JSON_PARSER.LAYERS.LAYER_ACTIVATION],
                        filter_dimensions=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_FILTER],
                        filter_strides=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_STRIDES],
                        filter_padding=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_PADDING],
                        layer_filter=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_WEIGHTS],
                        layer_bias=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_BIAS],
                        layer_input=layer_input))
                elif layer[JSON_PARSER.LAYERS.TYPE] == JSON_PARSER.LAYERS.POOL_LAYER:
                    layer = layer[JSON_PARSER.LAYERS.LAYERPARAMETERS]
                    layer_input = operator_dict[
                        layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][
                            JSON_PARSER.LAYERS.LAYER_NAME]] if \
                        layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][
                            JSON_PARSER.LAYERS.LAYER_NAME] in operator_dict else None
                    self.model.add_layer(Layer.pool_layer(
                        layer_name=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_NAME],
                        pool_dimensions=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.POOL_DIMENSIONS],
                        pool_strides=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_STRIDES],
                        pool_padding=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_PADDING],
                        pool_type=layer[JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.POOL_TYPE],
                        layer_input=layer_input))

            elif component[JSON_PARSER.LAYERS.TYPE] == JSON_PARSER.PARAMETERS.CONNECTOR and \
                    component[JSON_PARSER.PARAMETERS.COMPONENT][JSON_PARSER.OPERATOR.OPERATOR]:
                operator = component[JSON_PARSER.PARAMETERS.COMPONENT][JSON_PARSER.OPERATOR.OPERATOR]
                source = component[JSON_PARSER.PARAMETERS.COMPONENT][JSON_PARSER.PARAMETERS.SOURCE]
                # source = [components[str(s_id)][JSON_PARSER.PARAMETERS.INPUTLAYER][0] for s_id in
                #           component[JSON_PARSER.PARAMETERS.COMPONENT][JSON_PARSER.PARAMETERS.SOURCE]]
                target = [components[str(t_id)][JSON_PARSER.PARAMETERS.OUTPUTLAYER][0] for t_id in
                          component[JSON_PARSER.PARAMETERS.COMPONENT][JSON_PARSER.PARAMETERS.TARGET]]
                if operator[JSON_PARSER.OPERATOR.TYPE] == JSON_PARSER.OPERATOR.SPLIT:
                    source = \
                        components[str(source[0])][JSON_PARSER.PARAMETERS.COMPONENT][
                            JSON_PARSER.LAYERS.LAYERPARAMETERS][
                            JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_NAME]
                    for t_id in target:
                        layer_dict[t_id] = \
                            components[str(t_id)][JSON_PARSER.PARAMETERS.COMPONENT][JSON_PARSER.LAYERS.LAYERPARAMETERS][
                                JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_NAME]
                    target = [
                        components[str(t_id)][JSON_PARSER.PARAMETERS.COMPONENT][JSON_PARSER.LAYERS.LAYERPARAMETERS][
                            JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_NAME] for t_id in target]
                    self.model.add_operator(Operator.split_operator(
                        operator_name=operator[JSON_PARSER.OPERATOR.PARAMETERS][JSON_PARSER.OPERATOR.PARAMETERS][
                            JSON_PARSER.OPERATOR.NAME],
                        operator_dimension=operator[JSON_PARSER.OPERATOR.PARAMETERS][JSON_PARSER.OPERATOR.PARAMETERS][
                            JSON_PARSER.OPERATOR.SPLIT_DIMENSION],
                        input_tensor=source, output_tensors=target))
                elif operator[JSON_PARSER.OPERATOR.TYPE] == JSON_PARSER.OPERATOR.CONCAT:
                    source = [components[str(s_id)][JSON_PARSER.PARAMETERS.COMPONENT][
                                  JSON_PARSER.LAYERS.LAYERPARAMETERS][
                                  JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_NAME] for s_id in
                              source]
                    for t_id in target:
                        layer_dict[t_id] = \
                            components[str(t_id)][JSON_PARSER.PARAMETERS.COMPONENT][JSON_PARSER.LAYERS.LAYERPARAMETERS][
                                JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_NAME]
                    target = components[str(target[0])][JSON_PARSER.PARAMETERS.COMPONENT][
                        JSON_PARSER.LAYERS.LAYERPARAMETERS][
                        JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_NAME]
                    self.model.add_operator(Operator.concat_operator(
                        operator_name=operator[JSON_PARSER.OPERATOR.PARAMETERS][JSON_PARSER.OPERATOR.PARAMETERS][
                            JSON_PARSER.OPERATOR.NAME],
                        operator_dimension=operator[JSON_PARSER.OPERATOR.PARAMETERS][JSON_PARSER.OPERATOR.PARAMETERS][
                            JSON_PARSER.OPERATOR.CONCAT_DIMENSION],
                        input_tensors=source, output_tensor=target))
            elif component[JSON_PARSER.LAYERS.TYPE] == JSON_PARSER.PARAMETERS.CONNECTOR and \
                            component[JSON_PARSER.PARAMETERS.COMPONENT][
                                JSON_PARSER.LAYERS.TYPE] == JSON_PARSER.OPERATOR.RESHAPE:
                source = component[JSON_PARSER.PARAMETERS.COMPONENT][JSON_PARSER.PARAMETERS.SOURCE][0]
                target = component[JSON_PARSER.PARAMETERS.COMPONENT][JSON_PARSER.PARAMETERS.TARGET][0]
                source = components[str(source)][JSON_PARSER.PARAMETERS.COMPONENT][
                    JSON_PARSER.LAYERS.LAYERPARAMETERS][
                    JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_NAME]
                target = components[str(target)][JSON_PARSER.PARAMETERS.COMPONENT][
                    JSON_PARSER.LAYERS.LAYERPARAMETERS][
                    JSON_PARSER.LAYERS.LAYER_PARAMETERS][JSON_PARSER.LAYERS.LAYER_NAME]
                self.model.add_operator(
                    Operator.reshape_operator(operator_name=component[JSON_PARSER.PARAMETERS.COMPONENT][
                        JSON_PARSER.PARAMETERS.PARAMETERS][JSON_PARSER.PARAMETERS.PARAMETERS][
                        JSON_PARSER.OPERATOR.NAME],
                                              input_tensor=source, output_tensor=target,
                                              shape=component[JSON_PARSER.PARAMETERS.COMPONENT][
                                                  JSON_PARSER.PARAMETERS.PARAMETERS][JSON_PARSER.PARAMETERS.PARAMETERS][
                                                  JSON_PARSER.OPERATOR.SHAPE]))

        self.model.close_model()

    def get_template(self):
        self.template += DLParser.model_list
        return self.template

    def get_template_as_str(self):
        return '\n'.join(self.template)

    def read_json(self, json_input):
        with open(json_input) as data_file:
            self.model_data = json.load(data_file, object_pairs_hook=OrderedDict)

    def write_template(self):
        with open(self.tf_file_path, 'w') as f:
            for line in self.template:
                f.write(line + "\n")

    def fetch_json(self, model_name):
        login_url = 'http://192.168.49.224:9999/rest/v1/auth/login'
        fetch_model_id_url = 'http://192.168.49.224:9999/rest/v1/designer/model/get-all-models'
        fetch_model_json_url = 'http://192.168.49.224:9999/rest/v1/ensemble_mgmt/model_graph_json/'
        token = json.loads(
            str(requests.post(login_url, headers={"X-Auth-Username": "admin", "X-Auth-Password": "admin"}).content,
                encoding="utf-8"))['result']['token']
        print('token: ', token)
        model_id = json.loads(str(
            requests.post(fetch_model_id_url, headers={"X-Auth-Token": token, 'Content-Type': 'application/json'},
                          data="{  \"index\": 0, \"searchValue\": \"" + model_name + "\", \"size\": 10}").content,
            encoding="utf-8"))['result']['modelInfos'][0]['id']
        print('ID: ', model_id)
        model_json = json.loads(str(
            requests.get(fetch_model_json_url + str(model_id),
                         headers={"X-Auth-Token": token, "Accept": "*/*"}).content,
            encoding="utf-8"), object_pairs_hook=OrderedDict)['result'][
            'orderedComponents']
        print('Model Config:\n ', json.dumps(model_json))
        return model_json


if __name__ == '__main__':
    # model_name = 'RZTDLTEST4'
    model_name = '/Users/prathyushsp/Git/python-resources/resources/dlparser/json/cnn_updated.json'
    model_save_path = '/tmp/model.py'
    print(DLParser(model_config=model_name, save_path=model_save_path, local=True).get_template_as_str())
    # exec(open(model_save_path).read())