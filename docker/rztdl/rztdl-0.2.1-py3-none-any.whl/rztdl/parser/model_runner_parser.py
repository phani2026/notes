# -*- coding: utf-8 -*-
"""
| *@created on:* 14/06/18,
| *@author:* Umesh Kumar,
| *@version:* v0.0.1
|
| *Description:*
| 
| *Sphinx Documentation Status:* Complete
|
"""
import networkx as nx
from typeguard import typechecked
from rztdl.parser import Parser


class ModelRunnerParser(object):
    """
    | **@author:** Umesh Kumar
    |
    | DL Model Runner Parser
    """

    def __init__(self, parser_config_json: dict):
        """
        | **@author:** Umesh Kumar
        |
        """
        self.parser_config_json = parser_config_json

    @typechecked
    def get_model_runner_code(self, model_runner_config_json: dict):
        """

        :param model_runner_config_json:
        :return:
        """
        runner_code = "import rztdl.dl\nfrom rztdl.dl.dataset.dataset_v1 import *\n\n"
        model_code, code = Parser(parser_config_json=self.parser_config_json).get_model_code(
            model_config_json=model_runner_config_json["model_json"])
        runner_code += model_code
        flow_blocks = self.get_flow_order(model_runner_config_json=model_runner_config_json)
        for each_flow in flow_blocks:
            dataset_generation = self.generate_dataset_for_flow(
                input_json=model_runner_config_json["blocks"][each_flow]["inputs"])
            runner_code += dataset_generation[0]
            runner_code += self.generate_datasplit_for_flow(data_splits=model_runner_config_json["blocks"][each_flow][
                "data_splits"])
            runner_code += self.generate_flow_code(name=model_runner_config_json["name"],
                                                   buffers=dataset_generation[1],
                                                   flow_json=model_runner_config_json["blocks"][each_flow])

        return runner_code

    @staticmethod
    @typechecked
    def generate_dataset_for_flow(input_json: dict):
        """

        :param input_json:
        :return:
        """
        dataset_code = "\n\ndataset = DatasetHandle(name='model_runner_dataset', dataset_elements=buffer_elements)"
        buffers = []
        for each_input in input_json:
            if input_json[each_input]["type"] == "data_input":
                dataset_columns = {}
                for each_buffer in input_json[each_input]["value"]["buffers"]:
                    dataset_columns[each_buffer["name"]] = each_buffer["columns"]
                    buffers.append(each_buffer["name"])
                dataset_code += "\ndataset.add_dataset(KafkaDataset(name='{}',server='""', topic_name= '""'," \
                                " column_names={}))".format(input_json[each_input]["value"]["name"], dataset_columns)
        dataset_code = dataset_code.replace("buffer_elements", str(buffers))
        dataset_code += "\ndataset.close()"
        return [dataset_code, buffers]

    @staticmethod
    @typechecked
    def generate_datasplit_for_flow(data_splits: list):
        """

        :param data_splits:
        :return:
        """
        data_split_code = "\n\ndata_split = DatasetSplit(name='model_runner_data_split', split_ratio = {})"
        split_ratio = []
        for split in data_splits:
            split_ratio.append(split["split_ratio"])
            data_split_code += "\ndata_split.add_split(Split(name='{}', " \
                               "template=constants.DatasetTemplate.{}()))".format(split["name"], split["template"])
        data_split_code = data_split_code.format(split_ratio)
        data_split_code += "\ndata_split.close()"
        return data_split_code

    @staticmethod
    @typechecked
    def generate_flow_code(name: str, buffers: list, flow_json: dict):
        """

        :param name:
        :param buffers:
        :param flow_json:
        :return:
        """
        flow_code = "\n\nwith rztdl.dl.ModelRunnerV1(name='{}', model=model) as model_runner:".format(name)
        model_parameters = ""
        run_parameters = {}
        for each_input in flow_json["inputs"]:
            if flow_json["inputs"][each_input]["type"] == "block_input":
                if flow_json["inputs"][each_input]["internal_name"] == "run_parameters":
                    run_parameters = flow_json["inputs"][each_input]["value"]
        model_parameters += "name='{}', ".format(flow_json["name"])
        for k, v in run_parameters.items():
            model_parameters += " {}={},".format(k, str(k) if isinstance(v, str) else v)
        model_parameters += " optimizers = {}, dataset_handle = dataset, dataset_split = data_split,".format(
            flow_json["optimizers"])
        buffer_parameters = {}
        for buffer in buffers:
            buffer_parameters[buffer] = buffer
        model_parameters += " dataset_mapping = {}".format(buffer_parameters)
        flow_code += "\n\tmodel_runner.run_flow(rztdl.dl.flow.TrainFlowV1({}))".format(model_parameters)
        return flow_code

    @staticmethod
    @typechecked
    def get_flow_order(model_runner_config_json: dict):
        """

        :param model_runner_config_json: Model Designer generated JSON
        :return:
        """
        graph = nx.MultiDiGraph()
        for i in model_runner_config_json["blocks"]:
            graph.add_node(i)

        if model_runner_config_json["connections"]:
            for i, conn in model_runner_config_json["connections"].items():
                source = conn["source"]["id"]
                target = conn["target"]["id"]
                graph.add_edge(source["block_id"], target["block_id"])

        return [node for node in nx.topological_sort(graph)]
