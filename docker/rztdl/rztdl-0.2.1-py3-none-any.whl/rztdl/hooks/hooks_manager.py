# -*- coding: utf-8 -*-
"""
| **@created on:** 30/10/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

from rztdl.utils.singleton import Singleton
from rztdl.utils.string_constants import Hook
from typing import Callable
import logging
from rztdl.utils.dl_exception import HookException

logger = logging.getLogger(__name__)


class HooksManager(metaclass=Singleton):
    """
    | **author:** Prathyush SP
    |
    | Hooks Manager
    """

    def __init__(self):
        """
        | Initializes Global Hook Store
        """
        self.hook_store = {i: {h: [] for h in Hook.HookPosition} for i in Hook.HookType}

    def add_hook(self, hook: Callable, hook_args: dict,  hook_type: Hook.HookType, hook_pos: Hook.HookPosition, kwargs:dict=None,):
        """
        | **author:** Prathyush SP
        |
        | Adds hook to the hook store
        :param hook: Hook (Callable Function)
        :param hook_args: Arguments for Hook
        :param hook_type: Hook Type
        :param hook_pos: Hook Position
        """
        self.hook_store[hook_type][hook_pos].append((hook, hook_args, kwargs))

    def fetch_hook(self, hook_type: Hook.HookType, hook_pos: Hook.HookPosition, index: int = None):
        """
        | **author:** Prathyush SP
        |
        | Fetch Hook from the hook store
        :param hook_type: Hook Type
        :param hook_pos: Hook Position
        :param index: Hook Index
        :return: Tuple of Hook, Argument
        """
        if index is None:
            try:
                return self.hook_store[hook_type][hook_pos]
            except Exception as e:
                raise HookException(
                    'Exception while fetching hooks \nType:{}, Position:{}, \nException:{}'.format(hook_type,
                                                                                                   hook_pos, e))
        else:
            try:
                return self.hook_store[hook_type][hook_pos][index]
            except Exception as e:
                raise HookException(
                    'Exception while fetching hook \nType:{}, Position:{}, Index:{} \nException:{}'.format(hook_type,
                                                                                                           hook_pos,
                                                                                                           index, e))

    def initialize_hook_store(self):
        """
        | **author:** Prathyush SP
        |
        | Initialize Hook Store
        :return: 
        """
        self.__init__()

    def remove_hook(self, hook_type: Hook.HookType, hook_pos: Hook.HookPosition, index: int = None):
        """
        | **author:** Prathyush SP
        |
        | Remove hook from hook store
        :param hook_type: Hook Type
        :param hook_pos: Hook Position
        :param index: Index (Insertion order)        
        """
        if index is None:
            try:
                self.hook_store[hook_type][hook_pos] = []
            except Exception as e:
                raise HookException(
                    'Exception while clearing hooks \nType:{}, Position:{}, \nException:{}'.format(hook_type,
                                                                                                   hook_pos, e))
        else:
            try:
                del self.hook_store[hook_type][hook_pos][index]
            except Exception as e:
                raise HookException(
                    'Exception while deleting hook \nType:{}, Position:{}, Index:{} \nException:{}'.format(hook_type,
                                                                                                           hook_pos,
                                                                                                           index, e))


def hook_controller(hook_type: Hook.HookType, hook_pos: Hook.HookPosition, wrap_fn: Callable):
    """
    | **author:** Prathyush SP
    |
    | Hook Controller - Used to map hook into respective place in hook store
    | Note: This follows Decorator pattern
    :param hook_type: Hook Type
    :param hook_pos: Hook Position
    :param wrap_fn: Decorator wrapped function
    """

    def wrapped_function(hook_decorator):
        """
        | **author:** Prathyush SP
        |
        | Outer decorator function comprises of Hook decorator
        :param hook_decorator: Hook Decorator
        """

        def wrapped_function_arguments(**kwargs):
            """
            | **author:** Prathyush SP
            |
            | Wrapped function which provides arguments for the decorator defined above
            :param kwargs:
            :return:
            """

            def wrapped_inner_function(f):
                """
                | **author:** Prathyush SP
                |
                | Wrapped Inner function which consists of logic of the controller
                :param f: Function supplied by the decorator (Real User Defined function)
                """
                hooks_manager.add_hook(hook=wrap_fn(hook_decorator(f))(), hook_type=hook_type, hook_pos=hook_pos,
                                       hook_args=kwargs, kwargs=None)

            return wrapped_inner_function

        return wrapped_function_arguments

    return wrapped_function


def wrap(f):
    """
    | **author:** Prathyush SP
    |
    | Wrapping mechanism for chaining decorators
    :param f: Function to be wrapped
    :return: Inner Wrapper
    """

    def wrapper():
        """
        | **author:** Prathyush SP
        |
        | Used to call the wrapped function
        :return: Wrap Function call
        """
        return f()

    return wrapper


hooks_manager = HooksManager()
