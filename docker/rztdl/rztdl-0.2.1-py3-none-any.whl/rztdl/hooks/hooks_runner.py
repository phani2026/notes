# -*- coding: utf-8 -*-
"""
| **@created on:** 31/10/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
from abc import ABCMeta, abstractmethod
from rztdl import RZTDL_CONFIG
from rztdl.utils.string_constants import Hook
from rztdl.utils.dl_exception import HookException
import traceback
from rztdl.utils.singleton import Singleton


class HooksRunner(metaclass=Singleton):
    """
    | **author:** Prathyush SP
    |
    | Hooks Runner - Abstract Class
    """

    def __init__(self, name: str, hook_type: Hook.HookRunnerTypes):
        """
        
        :param name: Hook Runner Name 
        :param hook_type: Hook Runner Type
        """
        self.name = name
        self.hook_type = hook_type
        pass

    @abstractmethod
    def validate_rules(self, hook_argument, conditions: dict):
        """
        | **author:** Prathyush SP
        |
        | Validate rules before running hook
        :param hook_argument: Hook Argument
        :param conditions: Hook Conditions
        :return: Boolean value
        """
        pass

    def run(self, hook_with_conditions: list, hook_argument):
        """        
        | **author:** Prathyush SP
        |
        | Run method for running hooks. Hooks are called with their respective arguments in this runner
        :param hook_with_conditions: Hook with execution conditions 
        :param hook_argument: Arguments for Hook        
        """
        for hook, conditions, pre_def_args in hook_with_conditions:
            if self.validate_rules(conditions=conditions,
                                   hook_argument=hook_argument) and RZTDL_CONFIG.CommonConfig.HOOKS_ENABLED:
                try:
                    if pre_def_args:
                        hook(hook_argument, pre_def_args)
                    else:
                        hook(hook_argument)
                except Exception as e:
                    raise HookException('Hook Function threw exception. \nFunction:{} \nArguments:{} \nConditions:{}'
                                        ' \nException:{}\n Traceback:\n{}'.format(hook, hook_argument,
                                                                                  hook_with_conditions, e,
                                                                                  traceback.format_exc()))
