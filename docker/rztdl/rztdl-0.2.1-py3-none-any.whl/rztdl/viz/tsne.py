# -*- coding: utf-8 -*-
"""
| **@created on:** 16/05/17,
| **@author:** Thebzeera V,
| **@version:** v0.0.1
|
| **Description:**
| PCA Class
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from typeguard import typechecked
from numpy import ndarray


class Tsne(object):
    """
    | **@author:** Thebzeera V
    |
    | TSNE Visualizer
    """

    @typechecked
    def __init__(self, n_iter: int, n_learning_rate: float, data: ndarray, label: ndarray):
        """
        :param n_iter: Number of Iterations
        :param n_learning_rate: learning_rate
        :param data: Train Data
        :param label: Train Label
        """
        self.data = data
        self.label = label
        self.n_iter = n_iter
        self.learning_rate = n_learning_rate
        self.X_tsne = TSNE(n_iter=self.n_iter, learning_rate=self.learning_rate).fit_transform(self.data)

    @typechecked
    def plot(self, name: str = 'tsne.png', xlabel: str = '', ylabel: str = '', save_path: str = None,
             show: bool = True):
        """
        :param name: name of the graph
        :param xlabel: xlabel
        :param ylabel: ylabel
        :param save_path: save path - Save Image in save path
        :param show: Display the Image
        :return: TSNE Object
        """
        plt.scatter(self.X_tsne[:, 0], self.X_tsne[:, 1], c=self.label)
        plt.title(name)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)

        if save_path:
            plt.savefig(save_path)
        if show:
            plt.show()
        return self
