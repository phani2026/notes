# -*- coding: utf-8 -*-
"""
| **@created on:** 16/05/17,
| **@author:** Thebzeera V,
| **@version:** v0.0.1
|
| **Description:**
| PCA Class
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from typeguard import typechecked
from numpy import ndarray


class Pca(object):
    """
    | **@author:** Thebzeera V
    |
    | Principle Component Analysis
    """

    @typechecked
    def __init__(self, n_component: int, data: ndarray, label: ndarray):
        """
        :param n_component: number of dimensions
        :param data: Train Data
        :param label: Train Label
        """
        self.label = label
        self.X_pca = PCA(n_components=n_component).fit_transform(data)

    @typechecked
    def plot(self, name: str = 'pca.png', xlabel: str = '', ylabel: str = '', save_path: str = None,
             show: bool = False):
        """
        | **@author:** Thebzeera V
        |
        | Plot Function
        :param name: name of the graph
        :param xlabel: xlabel
        :param ylabel: ylabel
        :param save_path: save path - Save Image in save Path
        :param show: Show the figure
        :return: Pca Object
        """
        plt.scatter(self.X_pca[:, 0], self.X_pca[:, 1], c=self.label)
        plt.title(name)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)

        if save_path:
            plt.savefig(save_path)
        if show:
            plt.show()
        return self
