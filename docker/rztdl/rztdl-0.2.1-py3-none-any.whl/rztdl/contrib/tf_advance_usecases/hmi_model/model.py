# -*- coding: utf-8 -*-
"""
| **@created on:** 07/04/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| HMI Tensorflow Model
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import tensorflow as tf
from rztdl.utils.file import read_csv

data_path = '/'.join(str(__file__).split('/')[:-1]) + "/data.csv"
customer_id, train_data, train_label, valid_data, valid_label, test_data, test_label = read_csv(data_path,
                                                                                                split_ratio=[50, 20,
                                                                                                             30],
                                                                                                header=True, skiprows=1,
                                                                                                index_col=0
                                                                                                )
epoch = 10
batch_size = 100
display_step = 1

input_placeholder = tf.placeholder(shape=[None, len(train_data[0])], dtype=tf.float32, name='input')
label_placeholder = tf.placeholder(shape=[None, len(train_label[0])], dtype=tf.float32, name='label')
learning_rate_placeholder_m = tf.placeholder(dtype=tf.float32, name='lr_m')
learning_rate_placeholder_h = tf.placeholder(dtype=tf.float32, name='lr_h')


def hmi_model(input_p, label_p, learning_rate_m, learning_rate_h):
    m_block_dict, h_block_dict = {}, {}
    with tf.name_scope('macine_block'):
        # Reshape input data into 8 attributes x 12 months
        with tf.name_scope('reshape_input_op'):
            m_block_dict["input_reshape_out"] = tf.reshape(input_p, shape=[-1, 8, 12, 1])

        # Convolution Layer 1
        with tf.name_scope('conv_layer_1'):
            with tf.name_scope('filter'):
                # Filter for each attribute and 3 months with 4 features
                m_block_dict["conv_layer_1_filter"] = tf.Variable(
                    tf.initializers.random_normal().__call__(shape=[1, 3, 1, 4]))
            with tf.name_scope('bias'):
                m_block_dict["conv_layer_1_bias"] = tf.Variable(tf.initializers.random_normal().__call__(shape=[4]))
                # Outputs a tensor of shape (?, 8, 6, 4) on a 1x2 stride
                m_block_dict["conv_layer_1_out"] = tf.nn.relu(
                    tf.nn.bias_add(
                        tf.nn.conv2d(m_block_dict["input_reshape_out"], m_block_dict["conv_layer_1_filter"],
                                     strides=[1, 1, 2, 1], padding='SAME'),
                        m_block_dict["conv_layer_1_bias"]))

        # Convolution Layer 2
        with tf.name_scope('conv_layer_2'):
            with tf.name_scope('filter'):
                # Filter for each attribute and 3 patterns with 8 features
                m_block_dict["conv_layer_2_filter"] = tf.Variable(
                    tf.initializers.random_normal().__call__(shape=[1, 3, 4, 8]))
            with tf.name_scope('bias'):
                m_block_dict["conv_layer_2_bias"] = tf.Variable(tf.initializers.random_normal().__call__(shape=[8]))
                # Outputs a tensor of shape (?, 8, 3, 8) on a 1x2 stride
                m_block_dict["conv_layer_2_out"] = tf.nn.relu(
                    tf.nn.bias_add(
                        tf.nn.conv2d(m_block_dict["conv_layer_1_out"], m_block_dict["conv_layer_2_filter"],
                                     strides=[1, 1, 2, 1],
                                     padding='SAME'),
                        m_block_dict["conv_layer_2_bias"]))

        # Reshape of conv layer to 2dims (8 attributes, 3-width patterns * 8 features) which is fed to hidden layer
        with tf.name_scope('reshape_conv_layer_2_op'):
            m_block_dict["conv_layer_2_reshape_out"] = tf.reshape(m_block_dict["conv_layer_2_out"],
                                                                  shape=[-1, 8 * 3 * 8])

        with tf.name_scope('hidden_layer'):
            with tf.name_scope('weights'):
                # Weights for 50 nodes
                m_block_dict["hidden_layer_weights"] = tf.Variable(
                    tf.initializers.random_normal().__call__(shape=[8 * 3 * 8, 50]))
            with tf.name_scope('bias'):
                m_block_dict["hidden_layer_bias"] = tf.Variable(tf.initializers.random_normal().__call__(shape=[50]))
                # Outputs a tensor of shape (?, 50)
                m_block_dict["hidden_layer_out"] = tf.nn.sigmoid(
                    tf.nn.bias_add(
                        tf.matmul(m_block_dict["conv_layer_2_reshape_out"], m_block_dict["hidden_layer_weights"]),
                        m_block_dict["hidden_layer_bias"]))

        with tf.name_scope('output_layer'):
            with tf.name_scope('weights'):
                # Weights for 1 nodes
                m_block_dict["output_layer_weights"] = tf.Variable(
                    tf.initializers.random_normal().__call__(shape=[50, 1]))
            with tf.name_scope('bias'):
                m_block_dict["output_layer_bias"] = tf.Variable(tf.initializers.random_normal().__call__(shape=[1]))
                # Outputs a tensor of shape (?, 1)
                m_block_dict["output_layer_out"] = tf.nn.bias_add(
                    tf.matmul(m_block_dict["hidden_layer_out"], m_block_dict["output_layer_weights"]),
                    m_block_dict["output_layer_bias"])

        with tf.name_scope('objective_function_classification'):
            # Cross Entropy as objective function as the problem is binary classification
            m_block_dict["objective_function"] = tf.reduce_mean(
                tf.nn.sigmoid_cross_entropy_with_logits(labels=label_p, logits=m_block_dict["output_layer_out"]))

        with tf.name_scope('optimizer'):
            # Adam Optimizer
            m_block_dict["optimizer"] = tf.train.AdamOptimizer(learning_rate=learning_rate_m).minimize(
                m_block_dict["objective_function"])

        with tf.name_scope('accuracy_classification'):
            correct_pred = tf.equal(tf.greater(m_block_dict["output_layer_out"], 0.5), tf.greater(label_p, 0.5))
            m_block_dict['accuracy'] = tf.reduce_mean(tf.cast(correct_pred, 'float'))

    with tf.name_scope('human_block'):
        # Convolution Layer 1
        with tf.name_scope('conv_layer_1'):
            with tf.name_scope('filter'):
                # Filter for each attribute and 3 months with 4 features
                h_block_dict["conv_layer_1_filter"] = tf.Variable(
                    tf.initializers.random_normal().__call__(shape=[1, 3, 4, 1]))
            with tf.name_scope('bias'):
                h_block_dict["conv_layer_1_bias"] = tf.Variable(tf.initializers.random_normal().__call__(shape=[1]))
                # Outputs a tensor of shape (?, 8, 3, 1) on a 1x2 stride
                h_block_dict["conv_layer_1_out"] = tf.nn.relu(
                    tf.nn.bias_add(
                        tf.nn.conv2d(m_block_dict["conv_layer_1_out"], h_block_dict["conv_layer_1_filter"],
                                     strides=[1, 1, 2, 1], padding='SAME'),
                        h_block_dict["conv_layer_1_bias"]))

        # Convolution Layer 2
        with tf.name_scope('conv_layer_2'):
            with tf.name_scope('filter'):
                # Filter for each attribute and 3 patterns with 8 features
                h_block_dict["conv_layer_2_filter"] = tf.Variable(
                    tf.initializers.random_normal().__call__(shape=[1, 3, 8, 1]))
            with tf.name_scope('bias'):
                h_block_dict["conv_layer_2_bias"] = tf.Variable(tf.initializers.random_normal().__call__(shape=[1]))
                # Outputs a tensor of shape (?, 8, 2, 1) on a 1x2 stride
                h_block_dict["conv_layer_2_out"] = tf.nn.relu(
                    tf.nn.bias_add(
                        tf.nn.conv2d(m_block_dict["conv_layer_2_out"], h_block_dict["conv_layer_2_filter"],
                                     strides=[1, 1, 2, 1],
                                     padding='SAME'),
                        h_block_dict["conv_layer_2_bias"]))

        # Reshape of conv layer 1 to 2dims (8 attributes, 3-width patterns * 1 features) which is fed to hidden layer
        with tf.name_scope('reshape_conv_layer_1_op'):
            h_block_dict["conv_layer_1_reshape_out"] = tf.reshape(h_block_dict["conv_layer_1_out"],
                                                                  shape=[-1, 8 * 3 * 1])

        # Reshape of conv layer 2 to 2dims (8 attributes, 2-width patterns * 1 features) which is fed to hidden layer
        with tf.name_scope('reshape_conv_layer_2_op'):
            h_block_dict["conv_layer_2_reshape_out"] = tf.reshape(h_block_dict["conv_layer_2_out"],
                                                                  shape=[-1, 8 * 2 * 1])

        # Concate Conv_layer 1 and Conv layer 2 outputs:
        with tf.name_scope('concate_op'):
            h_block_dict['concat_op'] = tf.concat(
                [h_block_dict["conv_layer_1_reshape_out"], h_block_dict["conv_layer_2_reshape_out"]], axis=1)

        with tf.name_scope('hidden_layer'):
            with tf.name_scope('weights'):
                # Weights for 50 nodes
                h_block_dict["hidden_layer_weights"] = tf.Variable(
                    tf.initializers.random_normal().__call__(shape=[40, 20]))
            with tf.name_scope('bias'):
                h_block_dict["hidden_layer_bias"] = tf.Variable(tf.initializers.random_normal().__call__(shape=[20]))
                # Outputs a tensor of shape (?, 50)
                h_block_dict["hidden_layer_out"] = tf.nn.sigmoid(
                    tf.nn.bias_add(
                        tf.matmul(h_block_dict["concat_op"], h_block_dict["hidden_layer_weights"]),
                        h_block_dict["hidden_layer_bias"]))

        with tf.name_scope('output_layer'):
            with tf.name_scope('weights'):
                # Weights for 1 nodes
                h_block_dict["output_layer_weights"] = tf.Variable(
                    tf.initializers.random_normal().__call__(shape=[20, 1]))
            with tf.name_scope('bias'):
                h_block_dict["output_layer_bias"] = tf.Variable(tf.initializers.random_normal().__call__(shape=[1]))
                # Outputs a tensor of shape (?, 1)
                h_block_dict["output_layer_out"] = tf.nn.sigmoid(tf.nn.bias_add(
                    tf.matmul(h_block_dict["hidden_layer_out"], h_block_dict["output_layer_weights"]),
                    h_block_dict["output_layer_bias"]))

        with tf.name_scope('objective_function_regression'):
            # MSE as objective function as the problem is regression
            h_block_dict["objective_function"] = tf.reduce_mean(
                tf.square(m_block_dict["output_layer_out"] - h_block_dict["output_layer_out"]))

        with tf.name_scope('optimizer'):
            # Adam Optimizer
            h_block_dict["optimizer"] = tf.train.AdamOptimizer(learning_rate=learning_rate_h).minimize(
                h_block_dict["objective_function"])

        with tf.name_scope('accuracy_regression'):
            h_block_dict['accuracy'] = tf.reduce_mean(tf.cast(tf.equal(
                tf.logical_and(tf.less(h_block_dict["output_layer_out"], tf.add(m_block_dict["output_layer_out"], 1)),
                               tf.greater(h_block_dict["output_layer_out"],
                                          tf.subtract(m_block_dict["output_layer_out"], 1))),
                tf.cast(h_block_dict["output_layer_out"], 'bool')), 'float'))

    return m_block_dict, h_block_dict


mblock_dict, hblock_dict = hmi_model(input_p=input_placeholder, label_p=label_placeholder,
                                     learning_rate_m=learning_rate_placeholder_m,
                                     learning_rate_h=learning_rate_placeholder_h)

# Create Global initializer operation
init_global = tf.global_variables_initializer()

# Generate Tensorflow Graph
# from rztdl.dl.helpers.tfhelpers import GraphUtils
# GraphUtils().save_graph('/tmp').run_tensorboard()


# Launch the graph
with tf.Session() as sess:
    # Run initialization operation
    sess.run(init_global)
    sess.run(tf.initialize_all_variables())
    sess.run(tf.initialize_local_variables())

    # Generate Train and Label Batches
    train_data_batches = [train_data[k:k + batch_size] for k in range(0, len(train_data), batch_size)]
    train_label_batches = [train_label[k:k + batch_size] for k in range(0, len(train_label), batch_size)]

    # Start Training
    for e in range(epoch):
        for b, data in enumerate(zip(train_data_batches, train_label_batches)):
            sess.run([hblock_dict['optimizer'], mblock_dict['optimizer']],
                     feed_dict={input_placeholder: data[0],
                                label_placeholder: data[1],
                                learning_rate_placeholder_h: 0.001,
                                learning_rate_placeholder_m: 0.01})
            if epoch % display_step == 0 and b == 0:
                # Calculate batch loss and accuracy
                mloss, hloss, macc, hacc = sess.run(
                    [mblock_dict['objective_function'], hblock_dict['objective_function'], mblock_dict["accuracy"],
                     hblock_dict["accuracy"]],
                    feed_dict={input_placeholder: data[0],
                               label_placeholder: data[1],
                               learning_rate_placeholder_h: 0.001,
                               learning_rate_placeholder_m: 0.01})
                print(
                    "Iter {}, Minibatch HBlock Loss={}, MBlock Loss={}, Minibatch MBlock Accuracy={}, HBlock Accuracy={}".format(
                        e, round(
                            float(hloss), 2), round(float(mloss), 2), round(float(macc), 2), round(float(hacc), 2)))

    print("Optimization Finished!")

    # Calculate accuracy for test data
    macc, hacc = sess.run([mblock_dict['accuracy'], hblock_dict['accuracy']],
                          feed_dict={input_placeholder: test_data,
                                     label_placeholder: test_label
                                     })
    print("Testing Accuracy: Mblock= {}, HBlock= {}".format(round(float(macc), 2), round(float(hacc), 2)))