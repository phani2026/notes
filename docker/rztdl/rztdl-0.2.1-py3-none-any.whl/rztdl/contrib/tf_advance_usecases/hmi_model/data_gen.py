# -*- coding: utf-8 -*-
"""
| **@created on:** 07/04/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Datagen Utility for HMI Model
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import numpy as np
from random import randrange
import pandas as pd
from collections import OrderedDict

SAMPLES = 1000
attributes = ['Attribute_{}_Month_{}'.format(k, i) for k in range(8) for i in range(12)]
data = np.random.random([SAMPLES, len(attributes)], )
label = [randrange(0, 2) for i in range(SAMPLES)]
df = pd.DataFrame(OrderedDict(
    {**OrderedDict([(i, np.round(data[:, e], decimals=2)) for e, i in enumerate(attributes)]), **{'label': label}}))
df.to_csv('data.csv', index=True, header=True)