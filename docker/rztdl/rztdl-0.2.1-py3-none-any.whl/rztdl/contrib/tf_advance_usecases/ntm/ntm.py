##Date: 23/4/2018, Author: Sagnik Bhattacharya, encoding: UTF-8

##The following is the code for a Neural Turing Machine (NTM),
##a kind of memory-augmented neural net.
##The NTM consists of a controller and a memory module. With every step of forward propagation,
##the controller reads from the memory module and writes to it, like what a Turing machine does
##on a tape. At each forward propagation, the controller reads from the memory,
##generates an output from forward propagation based on that input, encodes that into a key.
##It then passes the key to the memory module, by virtue of which the module updates itself
## i.e does read and write operations on the module.

import tensorflow as tf
import numpy as np
import pandas as pd
from sklearn.utils import shuffle

memory_size = 24


##I'm building a 24x24 memory matrix, keeping it square for simplicity.
##You can choose your own dimensions.

def initialize_weight(shape, name, scope):
    with tf.variable_scope(scope, reuse=tf.AUTO_REUSE):
        init = tf.truncated_normal(shape=shape, mean=0, stddev=0.01)
        a = tf.get_variable(name=name, initializer=init, dtype=tf.float32)
        return a


def convolution(X, W, strides, padding):
    return tf.nn.conv2d(input=X, filter=W, strides=strides, padding=padding)


def generate_data(split_ratio=0.3):
    df = pd.read_csv("binary_strings_order.csv")
    df = df.drop(columns="Unnamed: 0")
    # df = shuffle(df)

    X = df.iloc[:, :11]
    Y = df.iloc[:, 13:]
    index = int(split_ratio * len(df))
    Xtrain = X[:index]
    Ytrain = Y[:index]
    Xtest = X[index:]
    Ytest = Y[index:]

    data_dictionary = {"x_train": Xtrain, "x_test": Xtest, "y_train": Ytrain, "y_test": Ytest}
    return data_dictionary


class network:
    def __init__(self, input_xshape=[None, 11], input_yshape=[None, 12]):
        self.X_data = tf.placeholder(dtype=tf.float32, shape=input_xshape)
        self.Y_data = tf.placeholder(dtype=tf.float32, shape=input_yshape)

        ##We have initialized the placeholders, now let's initialize all the
        ##trainable variables in the system.

        self.memory_matrix = initialize_weight(shape=[int(self.X_data.get_shape()[1]), memory_size],
                                               name="memory_matrix",
                                               scope="Memory_module")
        self.attention_vector = initialize_weight(shape=[int(self.X_data.get_shape()[1])], name="attention_vector",
                                                  scope="Memory_module")

        self.read_vector = tf.multiply(self.attention_vector, self.X_data)
        self.write_vector = initialize_weight(shape=[memory_size], name="write_vector", scope="Memory_module")
        self.erase_vector = initialize_weight(shape=[memory_size], name="erase_vector", scope="Memory_module")

        self.beta = tf.Variable(tf.constant(1.5, dtype=tf.float32), import_scope="Memory_module")
        self.interpol_g = tf.Variable(tf.constant(0.5, dtype=tf.float32), import_scope="Memory_module")
        self.gamma = tf.Variable(tf.constant(0.13, dtype=tf.float32), import_scope="Memory_module")

    def forward_prop(self):
        ##The controller generates a key per each instance of forward propagation.
        ##It the feeds this key to the memory module.

        LSTM_input = tf.reshape(self.read_vector, shape=[-1, 11, 1])
        cell = tf.nn.rnn_cell.LSTMCell(num_units=memory_size, use_peepholes=True, state_is_tuple=True)
        value, state = tf.nn.dynamic_rnn(cell=cell, inputs=LSTM_input, dtype=tf.float32)

        value = tf.transpose(value, perm=[1, 0, 2])
        key = tf.gather(params=value, indices=int(value.shape[0]) - 1)
        last = tf.gather(params=value, indices=int(value.shape[0]) - 1)

        target_size = int(self.Y_data.get_shape()[1])
        final_weights = initialize_weight(shape=[memory_size, target_size], name="final_weights", scope="controller")
        final_bias = initialize_weight(shape=[target_size], name="final_bias", scope="controller")

        hypothesis = tf.matmul(last, final_weights) + final_bias
        return tf.reshape(key, shape=[-1]), hypothesis

        ##Now we are finished with the graph of the controller,
        ##we now need to build the memory module.

    def update_memory(self, key):
        ##Updates the memory matrix once it receives a key after one instance of
        ##forward propagation

        norm_mem = tf.nn.l2_normalize(self.memory_matrix, axis=1)
        norm_key = tf.nn.l2_normalize(key)
        cosine_sim = tf.nn.softmax(tf.multiply(tf.reduce_sum(tf.multiply(norm_key, norm_mem), axis=1), self.beta))

        interpolated_gate = tf.add(tf.multiply(self.interpol_g, cosine_sim), tf.multiply(
            tf.subtract(tf.constant(1.0, dtype=tf.float32), self.interpol_g), self.attention_vector))

        flatten_interpol = tf.reshape(interpolated_gate, shape=[-1, int(interpolated_gate.get_shape()[0]), 1, 1])
        shifter = initialize_weight(shape=[1, memory_size, 1, 1], name="shifter", scope="Memory_module")
        shifted = convolution(flatten_interpol, shifter, strides=[1, 1, 1, 1], padding="SAME")

        flatten_shifted = tf.reshape(shifted, shape=[-1])

        sharpened = tf.nn.l2_normalize(tf.pow(flatten_shifted, self.gamma))

        new_attention_vector = sharpened
        self.attention_vector = new_attention_vector

        ##We now have our new attention vector from the key given by the controller.
        ##Let's update the memory matrix now.

        erase = tf.reshape(self.erase_vector, shape=[-1, 1])
        new_attention = tf.reshape(new_attention_vector, shape=[-1, 1])

        erase_matrix = tf.transpose(tf.matmul(erase, tf.transpose(new_attention)))

        write = tf.reshape(self.write_vector, shape=[-1, 1])
        write_matrix = tf.transpose(tf.matmul(write, tf.transpose(new_attention)))

        self.memory_matrix = tf.add(
            tf.multiply(self.memory_matrix, tf.subtract(tf.ones(shape=self.memory_matrix.shape), erase_matrix)),
            write_matrix)
        # Memory matrix has been updated.
        ##Now, to update the read vector.

        new_read_vector = tf.multiply(tf.matmul(tf.transpose(self.memory_matrix), new_attention), self.X_data)
        self.read_vector = new_read_vector

    def train(self, epochs=12000, write_log=True):
        ##Generate data dictionary for tensorflow session.
        dict = generate_data()
        feed_train = {self.X_data: dict["x_train"], self.Y_data: dict["y_train"]}
        feed_test = {self.X_data: dict["x_test"], self.Y_data: dict["y_test"]}

        ##Generate key and scores with each step of forward propagation.
        key, scores = self.forward_prop()

        ##Cost and accuracy metrics
        cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(labels=self.Y_data, logits=scores))
        correct_hits = tf.equal(tf.argmax(self.Y_data, 1), tf.argmax(scores, 1))
        accuracy = tf.reduce_mean(tf.cast(correct_hits, tf.float32))

        ##Train the model using gradient descent.
        optimizer = tf.train.GradientDescentOptimizer(learning_rate=0.33)
        update_variables = optimizer.minimize(cost)
        self.update_memory(key)

        if write_log:
            summary_log = tf.summary.scalar("Cost", cost)


        ##Run the training session.
        with tf.Session() as sess:
            sess.run(tf.global_variables_initializer())
            for i in range(epochs):
                sess.run(update_variables, feed_dict=feed_train)
                print("Trained till epoch", i, " ...")
                print("Cost is ", sess.run(cost, feed_dict=feed_test))
                print("Accuracy is ", sess.run(accuracy, feed_dict=feed_test))

                if write_log:
                    writer = tf.summary.FileWriter("/home/sagnikb/PycharmProjects/logs",
                                                   graph=tf.get_default_graph())
                    writer.add_summary(sess.run(summary_log, feed_dict=feed_test), global_step=i)



n = network()
n.train()
