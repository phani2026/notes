# -*- coding: utf-8 -*-
"""
| **@created on:** 07/04/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| HMI Tensorflow Model
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import tensorflow as tf
from bunch import Bunch
from rztdl.utils.file import read_csv
import numpy as np

data_path = 'mnist_dataset.csv'
train_data, train_label, valid_data, valid_label, test_data, test_label = read_csv(data_path, split_ratio=[50, 20, 30],
                                                                                   delimiter=";", strict_type=False,
                                                                                   randomize=False, label_vector=True)
epoch = 10
batch_size = 1
display_step = 1

input_placeholder = tf.placeholder(shape=[None, len(train_data[0])], dtype=tf.float32, name='input')
label_placeholder = tf.placeholder(shape=[None, len(train_label[0])], dtype=tf.float32, name='label')
cond_placeholder = tf.placeholder(dtype=tf.float32)
model_dict = Bunch()


def generate_data(name, shape):
    return tf.get_variable(name, shape=shape,
                           initializer=tf.truncated_normal_initializer(stddev=0.1))


def model(ip, cond, label):
    global model_dict
    # model_dict.reshape_op = tf.reshape(ip, shape=[-1, 28, 28, 1])

    model_dict.layer_1_weights = generate_data('w1', [784, 10])
    model_dict.layer_1_bias = generate_data('b1', [10])
    model_dict.layer_1 = tf.nn.bias_add(tf.matmul(ip, model_dict.layer_1_weights), model_dict.layer_1_bias)

    model_dict.lout = tf.cond(tf.equal(tf.mod(cond, 2), 0), lambda: true_network(model_dict.layer_1),
                              lambda: false_network(model_dict.layer_1))

    model_dict.output_layer_weight = generate_data('wo', [10, 10])
    model_dict.output_layer_bias = generate_data('bo', [10])
    model_dict.output_layer_out = tf.nn.bias_add(tf.matmul(model_dict.lout, model_dict.output_layer_weight),
                                                 model_dict.output_layer_bias)

    model_dict.loss = tf.reduce_mean(
        tf.nn.softmax_cross_entropy_with_logits_v2(labels=label, logits=model_dict.output_layer_out))
    model_dict.optimizer = tf.train.AdamOptimizer(learning_rate=0.01, beta1=0.9, beta2=0.9)

    model_dict.true_vars = [model_dict.layer_1_weights, model_dict.layer_1_bias,
                            model_dict.layer_2_weights, model_dict.layer_2_bias,
                            model_dict.output_layer_weight, model_dict.output_layer_bias]

    model_dict.false_vars = [model_dict.layer_1_weights, model_dict.layer_1_bias,
                             model_dict.layer_3_weights, model_dict.layer_3_bias,
                             model_dict.output_layer_weight, model_dict.output_layer_bias]

    model_dict.tgrads, _ = zip(*model_dict.optimizer.compute_gradients(loss=model_dict.loss, var_list=model_dict.true_vars))
    model_dict.t_apply_op = model_dict.optimizer.apply_gradients(
        grads_and_vars={*zip(model_dict.tgrads, model_dict.true_vars)})

    model_dict.fgrads, _ = zip(*model_dict.optimizer.compute_gradients(loss=model_dict.loss, var_list=model_dict.false_vars))
    model_dict.f_apply_op = model_dict.optimizer.apply_gradients(
        grads_and_vars={*zip(model_dict.fgrads, model_dict.false_vars)})

    correct_pred = tf.equal(tf.argmax(model_dict.output_layer_out, 1), tf.argmax(label, 1))
    model_dict.accuracy = tf.reduce_mean(tf.cast(correct_pred, 'float'))

    return model_dict


def true_network(ip_tensor):
    global model_dict
    model_dict.layer_2_weights = generate_data('tw', [10, 10])
    model_dict.layer_2_bias = generate_data('tb', [10])
    model_dict.lout = tf.nn.sigmoid(
        tf.nn.bias_add(tf.matmul(ip_tensor, model_dict.layer_2_weights), model_dict.layer_2_bias))
    return model_dict.lout


def false_network(ip_tensor):
    global model_dict
    model_dict.layer_3_weights = generate_data('fw', [10, 10])
    model_dict.layer_3_bias = generate_data('fb', [10])
    model_dict.lout = tf.nn.relu(tf.nn.bias_add(tf.matmul(ip_tensor, model_dict.layer_3_weights),
                                                model_dict.layer_3_bias))
    return model_dict.lout


modelop = model(input_placeholder, cond_placeholder, label_placeholder)

from rztdl.dl.helpers.tfhelpers.graph_utils import GraphUtils
GraphUtils().save_graph('/tmp/tw').run_tensorboard()
exit()

# Launch the graph
with tf.Session() as sess:
    # Run initialization operation

    sess.run(tf.initialize_all_variables())
    sess.run(tf.initialize_local_variables())

    # Generate Train and Label Batches
    train_data_batches = [train_data[k:k + batch_size] for k in range(0, len(train_data), batch_size)]
    train_label_batches = [train_label[k:k + batch_size] for k in range(0, len(train_label), batch_size)]

    # Start Training
    for e in range(epoch):
        initial_tw = sess.run(modelop.layer_2_weights)
        initial_fw = sess.run(modelop.layer_3_weights)
        for b, data in enumerate(zip(train_data_batches, train_label_batches)):
            if e % 2 == 0:
                sess.run(modelop.t_apply_op,
                         feed_dict={input_placeholder: data[0],
                                    label_placeholder: data[1],
                                    cond_placeholder: e})
            else:
                sess.run(modelop.f_apply_op,
                         feed_dict={input_placeholder: data[0],
                                    label_placeholder: data[1],
                                    cond_placeholder: e})

            print('Epoch: {} Going through {}'.format(e, 'True Network' if e % 2 == 0 else 'False Network'))
            current_tw = sess.run(modelop.layer_2_weights)
            current_fw = sess.run(modelop.layer_3_weights)

            print('TW Changed: {}'.format('Not Changed' if np.sum(initial_tw - current_tw) == 0 else 'Changed'))
            print('FW Changed: {}'.format('Not Changed' if np.sum(initial_fw - current_fw) == 0 else 'Changed'))

            initial_fw = current_fw
            initial_tw = current_tw

            if epoch % display_step == 0 and b == 0:
                # Calculate batch loss and accuracy

                loss, acc = sess.run([modelop.loss, modelop.accuracy],
                                     feed_dict={input_placeholder: data[0],
                                                label_placeholder: data[1],
                                                cond_placeholder: e})
                print(
                    "Iter {}, Minibatch Loss={}, Accuracy={}".format(e, round(float(loss), 2), round(float(acc), 2)))
            break
    print("Optimization Finished!")

    # Calculate accuracy for test data
    acc = sess.run(modelop.accuracy,
                   feed_dict={input_placeholder: test_data,
                              label_placeholder: test_label,
                              cond_placeholder: 0})
    print("Testing Accuracy: {}".format(round(float(acc), 2)))
