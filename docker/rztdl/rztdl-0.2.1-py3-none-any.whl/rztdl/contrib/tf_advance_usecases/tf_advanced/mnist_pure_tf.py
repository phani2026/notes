# -*- coding: utf-8 -*-
"""
| **@created on:** 07/04/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| HMI Tensorflow Model
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import tensorflow as tf
from rztdl.utils.file import read_csv
import bunch
from rztdl import RZTDL_CONFIG
import numpy as np

RZTDL_CONFIG.CommonConfig.STRICT_TYPE = False

# data_path = '/'.join(str(__file__).split('/')[:-1]) + "/data.csv"
data_path = 'mnist_dataset.csv'
train_data, train_label, valid_data, valid_label, test_data, test_label = read_csv(data_path, split_ratio=[50, 20, 30],
                                                                                   delimiter=";", strict_type=False,
                                                                                   randomize=False, label_vector=True)
epoch = 100
batch_size = 10
display_step = 1

input_placeholder = tf.placeholder(shape=[None, len(train_data[0])], dtype=tf.float32, name='input')
label_placeholder = tf.placeholder(shape=[None, len(train_label[0])], dtype=tf.float32, name='label')
learning_rate_placeholder = tf.placeholder(dtype=tf.float32, name='lr_m')


def mnist_model(input_p, label_p, learning_rate):
    model_dict = bunch.Bunch()

    with tf.name_scope('mnist_model'):
        # Reshape input data into 8 attributes x 12 months
        with tf.name_scope('reshape_input_op'):
            model_dict.input_reshape_out = tf.reshape(input_p, shape=[-1, 28, 28, 1])

        # Convolution Layer 1
        with tf.name_scope('conv_layer_1'):
            with tf.name_scope('filter'):
                # Filter for each attribute and 3 months with 4 features
                model_dict.conv_layer_1_filter = tf.Variable(
                    tf.initializers.random_normal().__call__(shape=[5, 5, 1, 32]))
            with tf.name_scope('bias'):
                model_dict.conv_layer_1_bias = tf.Variable(tf.initializers.random_normal().__call__(shape=[32]))
                # Outputs a tensor of shape (?, 8, 6, 4) on a 1x2 stride
                model_dict.conv_layer_1_out = tf.nn.relu(
                    tf.nn.bias_add(
                        tf.nn.conv2d(model_dict.input_reshape_out, model_dict.conv_layer_1_filter,
                                     strides=[1, 1, 1, 1], padding='SAME'),
                        model_dict.conv_layer_1_bias))

        # Pool Layer 1
        with tf.name_scope('pool_layer_1'):
            model_dict.pool_layer_1 = tf.nn.max_pool(model_dict.conv_layer_1_out, ksize=[1, 2, 2, 1],
                                                     strides=[1, 2, 2, 1], padding='SAME')

        # Convolution Layer 2
        with tf.name_scope('conv_layer_2'):
            with tf.name_scope('filter'):
                # Filter for each attribute and 3 patterns with 8 features
                model_dict.conv_layer_2_filter = tf.Variable(
                    tf.initializers.random_normal().__call__(shape=[5, 5, 32, 64]))
            with tf.name_scope('bias'):
                model_dict.conv_layer_2_bias = tf.Variable(tf.initializers.random_normal().__call__(shape=[64]))
                # Outputs a tensor of shape (?, 8, 3, 8) on a 1x2 stride
                model_dict.conv_layer_2_out = tf.nn.relu(
                    tf.nn.bias_add(
                        tf.nn.conv2d(model_dict.conv_layer_1_out, model_dict.conv_layer_2_filter,
                                     strides=[1, 1, 1, 1],
                                     padding='SAME'),
                        model_dict.conv_layer_2_bias))

                # Pool Layer 2
        with tf.name_scope('pool_layer_2'):
            model_dict.pool_layer_2 = tf.nn.max_pool(model_dict.conv_layer_2_out, ksize=[1, 2, 2, 1],
                                                     strides=[1, 2, 2, 1],
                                                     padding='SAME')

        # Reshape of conv layer to 2dims (8 attributes, 3-width patterns * 8 features) which is fed to hidden layer
        with tf.name_scope('reshape_conv_layer_2_op'):
            model_dict.pool_layer_2_reshape_out = tf.reshape(model_dict.pool_layer_2, shape=[-1, np.prod(
                model_dict.pool_layer_2.shape.as_list()[1:])])

        with tf.name_scope('hidden_layer'):
            with tf.name_scope('weights'):
                # Weights for 50 nodes
                model_dict.hidden_layer_weights = tf.Variable(
                    tf.initializers.random_normal().__call__(
                        shape=[np.prod(model_dict.pool_layer_2.shape.as_list()[1:]), 50]))
            with tf.name_scope('bias'):
                model_dict.hidden_layer_bias = tf.Variable(tf.initializers.random_normal().__call__(shape=[50]))
                # Outputs a tensor of shape (?, 50)
                model_dict.hidden_layer_out = tf.nn.sigmoid(
                    tf.nn.bias_add(
                        tf.matmul(model_dict.pool_layer_2_reshape_out, model_dict.hidden_layer_weights),
                        model_dict.hidden_layer_bias))

        with tf.name_scope('output_layer'):
            with tf.name_scope('weights'):
                # Weights for 1 nodes
                model_dict.output_layer_weights = tf.Variable(
                    tf.initializers.random_normal().__call__(shape=[50, 10]))
            with tf.name_scope('bias'):
                model_dict.output_layer_bias = tf.Variable(tf.initializers.random_normal().__call__(shape=[10]))
                # Outputs a tensor of shape (?, 1)
                model_dict.output_layer_out = tf.nn.bias_add(
                    tf.matmul(model_dict.hidden_layer_out, model_dict.output_layer_weights),
                    model_dict.output_layer_bias)

        with tf.name_scope('objective_function_classification'):
            # Cross Entropy as objective function as the problem is binary classification
            model_dict.objective_function = tf.reduce_mean(
                tf.nn.softmax_cross_entropy_with_logits_v2(labels=label_p, logits=model_dict.output_layer_out))

        with tf.name_scope('optimizer'):
            # Adam Optimizer
            model_dict.optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(
                model_dict.objective_function)

        with tf.name_scope('accuracy_classification'):
            correct_pred = tf.equal(tf.argmax(model_dict.output_layer_out, 1), tf.argmax(label_p, 1))
            model_dict.accuracy = tf.reduce_mean(tf.cast(correct_pred, 'float'))

    return model_dict


model_dict = mnist_model(input_p=input_placeholder, label_p=label_placeholder, learning_rate=learning_rate_placeholder)

# Generate Tensorflow Graph
# from rztdl.dl.helpers.tfhelpers import GraphUtils
# GraphUtils().save_graph('/tmp').run_tensorboard()


# Launch the graph
with tf.Session() as sess:
    # Run initialization operation
    sess.run(tf.initialize_all_variables())
    sess.run(tf.initialize_local_variables())

    # Generate Train and Label Batches
    train_data_batches = [train_data[k:k + batch_size] for k in range(0, len(train_data), batch_size)]
    train_label_batches = [train_label[k:k + batch_size] for k in range(0, len(train_label), batch_size)]

    # Start Training
    for e in range(epoch):
        for b, data in enumerate(zip(train_data_batches, train_label_batches)):
            sess.run(model_dict.optimizer,
                     feed_dict={input_placeholder: data[0],
                                label_placeholder: data[1],
                                learning_rate_placeholder: 0.1})
            if epoch % display_step == 0 and b == 0:
                # Calculate batch loss and accuracy

                loss, acc = sess.run([model_dict.objective_function, model_dict.accuracy],
                                     feed_dict={input_placeholder: data[0],
                                                label_placeholder: data[1],
                                                learning_rate_placeholder: 0.001})
                print(
                    "Iter {}, Minibatch Loss={}, Accuracy={}".format(e, round(float(loss), 2), round(float(acc), 2)))

    print("Optimization Finished!")

    # Calculate accuracy for test data
    acc = sess.run(model_dict.accuracy,
                   feed_dict={input_placeholder: test_data,
                              label_placeholder: test_label})
    print("Testing Accuracy: {}".format(round(float(acc), 2)))
