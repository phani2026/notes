import tensorflow as tf
from bunch import Bunch
from rztdl.utils.file import read_csv
import numpy as np

data_path = 'mnist_dataset.csv'
train_data, train_label, valid_data, valid_label, test_data, test_label = read_csv(data_path, split_ratio=[50, 20, 30],
                                                                                   delimiter=";", strict_type=False,
                                                                                   randomize=False, label_vector=True)
epoch = 10
batch_size = len(train_data)
display_step = 1

input_placeholder = tf.placeholder(shape=[None, len(train_data[0])], dtype=tf.float32, name='input')
label_placeholder = tf.placeholder(shape=[None, len(train_label[0])], dtype=tf.float32, name='label')
cond_placeholder = tf.placeholder(dtype=tf.float32)

model_dict = Bunch()


def generate_data(name, shape):
    return tf.get_variable(name, shape=shape,
                           initializer=tf.truncated_normal_initializer(stddev=0.1))


def normal_model(ip, label):
    global model_dict
    model_dict.layer_1 = Bunch()
    model_dict.layer_1.weights = generate_data('w1', [784, 10])
    model_dict.layer_1.bias = generate_data('b1', [10])
    model_dict.layer_1.out = tf.nn.bias_add(tf.matmul(ip, model_dict.layer_1.weights), model_dict.layer_1.bias)

    model_dict.output_layer = Bunch()
    model_dict.output_layer.weights = generate_data('wo', [10, 10])
    model_dict.output_layer.bias = generate_data('bo', [10])
    model_dict.output_layer.out = tf.nn.bias_add(tf.matmul(model_dict.layer_1.out, model_dict.output_layer.weights),
                                                 model_dict.output_layer.bias)

    model_dict.loss = tf.reduce_mean(
        tf.nn.softmax_cross_entropy_with_logits_v2(labels=label, logits=model_dict.output_layer.out))

    model_dict.vars = [model_dict.layer_1.weights, model_dict.layer_1.bias,
                       model_dict.output_layer.weights, model_dict.output_layer.bias]

    correct_pred = tf.equal(tf.argmax(model_dict.output_layer.out, 1), tf.argmax(label, 1))
    model_dict.accuracy = tf.reduce_mean(tf.cast(correct_pred, 'float'))

    return model_dict


def cond_model(ip, cond, label):
    global model_dict

    def true_network(ip_tensor):
        global model_dict
        model_dict.layer_2 = Bunch()

        model_dict.layer_2.weights = generate_data('tw', [10, 10])
        model_dict.layer_2.bias = generate_data('tb', [10])
        model_dict.layer_2.out = tf.nn.sigmoid(
            tf.nn.bias_add(tf.matmul(ip_tensor, model_dict.layer_2.weights), model_dict.layer_2.bias))
        return model_dict.layer_2.out

    def false_network(ip_tensor):
        global model_dict
        model_dict.layer_3 = Bunch()
        model_dict.layer_3.weights = generate_data('fw', [10, 10])
        model_dict.layer_3.bias = generate_data('fb', [10])
        model_dict.layer_3.out = tf.nn.sigmoid(tf.nn.bias_add(tf.matmul(ip_tensor, model_dict.layer_3.weights),
                                                              model_dict.layer_3.bias))
        return model_dict.layer_3.out

    model_dict.layer_1 = Bunch()
    model_dict.layer_1.weights = generate_data('w1', [784, 10])
    model_dict.layer_1.bias = generate_data('b1', [10])
    model_dict.layer_1.out = tf.nn.bias_add(tf.matmul(ip, model_dict.layer_1.weights), model_dict.layer_1.bias)

    model_dict.cond_op = tf.cond(tf.equal(tf.mod(cond, 2), 0), lambda: true_network(model_dict.layer_1.out),
                                 lambda: false_network(model_dict.layer_1.out))

    model_dict.output_layer = Bunch()
    model_dict.output_layer.weights = generate_data('wo', [10, 10])
    model_dict.output_layer.bias = generate_data('bo', [10])
    model_dict.output_layer.out = tf.nn.bias_add(tf.matmul(model_dict.cond_op, model_dict.output_layer.weights),
                                                 model_dict.output_layer.bias)

    model_dict.loss = tf.reduce_mean(
        tf.nn.softmax_cross_entropy_with_logits_v2(labels=label, logits=model_dict.output_layer.out))

    model_dict.true_vars = [model_dict.layer_1.weights, model_dict.layer_1.bias,
                            model_dict.layer_2.weights, model_dict.layer_2.bias,
                            model_dict.output_layer.weights, model_dict.output_layer.bias]

    model_dict.false_vars = [model_dict.layer_1.weights, model_dict.layer_1.bias,
                             model_dict.layer_3.weights, model_dict.layer_3.bias,
                             model_dict.output_layer.weights, model_dict.output_layer.bias]

    model_dict.global_vars = [*model_dict.true_vars, *model_dict.false_vars]

    correct_pred = tf.equal(tf.argmax(model_dict.output_layer.out, 1), tf.argmax(label, 1))
    model_dict.accuracy = tf.reduce_mean(tf.cast(correct_pred, 'float'))

    return model_dict


def g_sgd(gradients, state, learning_rate=0.001):
    return -learning_rate * gradients, state


def g_rms(gradients, state, learning_rate=0.001, decay_rate=0.99):
    if state is None:
        state = tf.zeros(gradients.shape)
    state = decay_rate * state + (1 - decay_rate) * tf.pow(gradients, 2)
    update = -learning_rate * gradients / (tf.sqrt(state) + 1e-5)
    return update, state


# from rztdl.dl.helpers.tfhelpers.graph_utils import GraphUtils
# GraphUtils().save_graph('/tmp/tw').run_tensorboard()
# exit()


def learn(modelop, layer, optimizer, state):
    g_w = tf.gradients(modelop.loss, modelop[layer].weights)[0]
    g_b = tf.gradients(modelop.loss, modelop[layer].bias)[0]
    update_w, state_w = optimizer(g_w, state[layer].weights)
    update_b, state_b = optimizer(g_b, state[layer].bias)
    state[layer].weights = state_w
    state[layer].bias = state_b
    return state, [modelop[layer].weights.assign(tf.add(modelop[layer].weights, update_w)), modelop[layer].bias.assign(
        tf.add(modelop[layer].bias, update_b))]


def normal_training(optimizer_type):
    modelop = normal_model(input_placeholder, label_placeholder)
    # Launch the graph
    with tf.Session() as sess:
        # Run initialization operation

        sess.run(tf.initialize_all_variables())
        sess.run(tf.initialize_local_variables())

        # Generate Train and Label Batches
        train_data_batches = [train_data[k:k + batch_size] for k in range(0, len(train_data), batch_size)]
        train_label_batches = [train_label[k:k + batch_size] for k in range(0, len(train_label), batch_size)]

        state_dict = Bunch(
            {'layer_1': Bunch({'weights': None, 'bias': None}), 'output_layer': Bunch({'weights': None, 'bias': None})})

        # Start Training
        for e in range(epoch):
            for b, data in enumerate(zip(train_data_batches, train_label_batches)):
                state_dict, layer1_update_op = learn(modelop, 'layer_1', optimizer_type, state_dict)
                state_dict, output_layer_update_op = learn(modelop, 'output_layer', optimizer_type, state_dict)
                sess.run([*layer1_update_op, *output_layer_update_op], feed_dict={input_placeholder: data[0],
                                                                                  label_placeholder: data[1],
                                                                                  cond_placeholder: 0})

                loss = sess.run(modelop.loss,
                                feed_dict={input_placeholder: data[0],
                                           label_placeholder: data[1],
                                           cond_placeholder: 0})

                print('Epoch: {}, Loss: {}'.format(e, loss))
                if epoch % display_step == 0 and b == 0:
                    # Calculate batch loss and accuracy

                    loss, acc = sess.run([modelop.loss, modelop.accuracy],
                                         feed_dict={input_placeholder: data[0],
                                                    label_placeholder: data[1],
                                                    cond_placeholder: 0})
                    print(
                        "Iter {}, Minibatch Loss={}, Accuracy={}".format(e, round(float(loss), 2),
                                                                         round(float(acc), 2)))
        print("Optimization Finished!")

        # Calculate accuracy for test data
        acc = sess.run(modelop.accuracy,
                       feed_dict={input_placeholder: test_data,
                                  label_placeholder: test_label,
                                  cond_placeholder: 0})
        print("Testing Accuracy: {}".format(round(float(acc), 2)))


def mix_training():
    modelop = normal_model(input_placeholder, label_placeholder)
    with tf.Session() as sess:
        # Run initialization operation

        sess.run(tf.initialize_all_variables())
        sess.run(tf.initialize_local_variables())

        # Generate Train and Label Batches
        train_data_batches = [train_data[k:k + batch_size] for k in range(0, len(train_data), batch_size)]
        train_label_batches = [train_label[k:k + batch_size] for k in range(0, len(train_label), batch_size)]

        state_dict = Bunch(
            {'layer_1': Bunch({'weights': None, 'bias': None}),
             'output_layer': Bunch({'weights': None, 'bias': None})})

        # Start Training
        for e in range(epoch):
            for b, data in enumerate(zip(train_data_batches, train_label_batches)):
                if e % 2 == 0:
                    print('Running SGD Optimizer optimizer')
                    optimizer_type = g_sgd
                else:
                    print('Running RMS Optimizer optimizer')
                    optimizer_type = g_rms
                state_dict, layer1_update_op = learn(modelop, 'layer_1', optimizer_type, state_dict)
                state_dict, output_layer_update_op = learn(modelop, 'output_layer', optimizer_type, state_dict)
                sess.run([*layer1_update_op, *output_layer_update_op],
                         feed_dict={input_placeholder: data[0],
                                    label_placeholder: data[1],
                                    cond_placeholder: 0})

                loss = sess.run(modelop.loss,
                                feed_dict={input_placeholder: data[0],
                                           label_placeholder: data[1],
                                           cond_placeholder: 0})

                print('Epoch: {}, Loss: {}'.format(e, loss))
                if epoch % display_step == 0 and b == 0:
                    # Calculate batch loss and accuracy

                    loss, acc = sess.run([modelop.loss, modelop.accuracy],
                                         feed_dict={input_placeholder: data[0],
                                                    label_placeholder: data[1],
                                                    cond_placeholder: 0})
                    print(
                        "Iter {}, Minibatch Loss={}, Accuracy={}".format(e, round(float(loss), 2),
                                                                         round(float(acc), 2)))
                break
        print("Optimization Finished!")

        # Calculate accuracy for test data
        acc = sess.run(modelop.accuracy,
                       feed_dict={input_placeholder: test_data,
                                  label_placeholder: test_label,
                                  cond_placeholder: 0})
        print("Testing Accuracy: {}".format(round(float(acc), 2)))


def custom_training():
    modelop = cond_model(input_placeholder, cond_placeholder, label_placeholder)
    with tf.Session() as sess:
        # Run initialization operation
        sess.run(tf.initialize_all_variables())
        sess.run(tf.initialize_local_variables())

        # Generate Train and Label Batches
        train_data_batches = [train_data[k:k + batch_size] for k in range(0, len(train_data), batch_size)]
        train_label_batches = [train_label[k:k + batch_size] for k in range(0, len(train_label), batch_size)]

        state_dict = Bunch(
            {'layer_1': Bunch({'weights': None, 'bias': None}),
             'layer_2': Bunch({'weights': None, 'bias': None}),
             'layer_3': Bunch({'weights': None, 'bias': None}),
             'output_layer': Bunch({'weights': None, 'bias': None})})

        # Start Training
        for e in range(epoch):
            initial_tw = sess.run(modelop.layer_2.weights)
            initial_fw = sess.run(modelop.layer_3.weights)
            for b, data in enumerate(zip(train_data_batches, train_label_batches)):
                if e % 2 == 0:
                    state_dict, layer1_update_op = learn(modelop, 'layer_1', g_sgd, state_dict)
                    state_dict, layer2_update_op = learn(modelop, 'layer_2', g_sgd, state_dict)
                    state_dict, output_layer_update_op = learn(modelop, 'output_layer', g_sgd, state_dict)
                    sess.run([*layer1_update_op, *layer2_update_op, *output_layer_update_op],
                             feed_dict={input_placeholder: data[0],
                                        label_placeholder: data[1],
                                        cond_placeholder: e})
                else:
                    state_dict, layer1_update_op = learn(modelop, 'layer_1', g_rms, state_dict)
                    state_dict, layer3_update_op = learn(modelop, 'layer_3', g_rms, state_dict)
                    state_dict, output_layer_update_op = learn(modelop, 'output_layer', g_rms, state_dict)
                    sess.run([*layer1_update_op, *layer3_update_op, *output_layer_update_op],
                             feed_dict={input_placeholder: data[0],
                                        label_placeholder: data[1],
                                        cond_placeholder: e})

                print('Epoch: {} Going through {} with {} optimizer'.format(e,
                                                                            'True Network' if e % 2 == 0 else 'False Network',
                                                                            'Custom SGD' if e % 2 == 0 else 'Custom RMS Prop'))
                current_tw = sess.run(modelop.layer_2.weights)
                current_fw = sess.run(modelop.layer_3.weights)

                print('TW Changed: {}, Diff: {}'.format(
                    'Not Changed' if np.sum(initial_tw - current_tw) == 0 else 'Changed',
                    np.sum(initial_tw - current_tw)))
                print('FW Changed: {}, Diff: {}'.format(
                    'Not Changed' if np.sum(initial_fw - current_fw) == 0 else 'Changed',
                    np.sum(initial_fw - current_fw)))

                initial_fw = current_fw
                initial_tw = current_tw

                if epoch % display_step == 0 and b == 0:
                    # Calculate batch loss and accuracy

                    loss, acc = sess.run([modelop.loss, modelop.accuracy],
                                         feed_dict={input_placeholder: data[0],
                                                    label_placeholder: data[1],
                                                    cond_placeholder: e})
                    print(
                        "Iter {}, Minibatch Loss={}, Accuracy={}".format(e, round(float(loss), 2),
                                                                         round(float(acc), 2)))
                break
        print("Optimization Finished!")

        # Calculate accuracy for test data
        acc = sess.run(modelop.accuracy,
                       feed_dict={input_placeholder: test_data,
                                  label_placeholder: test_label,
                                  cond_placeholder: 0})
        print("Testing Accuracy: {}".format(round(float(acc), 2)))


if __name__ == '__main__':
    # normal_training(g_sgd)
    # mix_training()
    # custom_training()
    pass
