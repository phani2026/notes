# -*- coding: utf-8 -*-
"""
| **@created on:** 07/04/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| HMI Tensorflow Model
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import tensorflow as tf
from rztdl.utils.file import read_csv
from bunch import Bunch
import numpy as np
from tensorflow.python import debug as tf_debug

tf.logging.set_verbosity(tf.logging.INFO)

data_path = 'mnist_dataset.csv'
train_data, train_label, valid_data, valid_label, test_data, test_label = read_csv(data_path, split_ratio=[50, 20, 30],
                                                                                   delimiter=";",
                                                                                   randomize=False, label_vector=True)


def cnn_model_fn(features, labels, mode):
    model_dict = Bunch()
    """Model function for CNN."""
    with tf.name_scope('mnist_model'):
        # Reshape input data into 8 attributes x 12 months
        with tf.name_scope('reshape_input_op'):
            model_dict.input_reshape_out = tf.reshape(features['x'], shape=[-1, 28, 28, 1])

        # Convolution Layer 1
        with tf.name_scope('conv_layer_1'):
            with tf.name_scope('filter'):
                # Filter for each attribute and 3 months with 4 features
                model_dict.conv_layer_1_filter = tf.Variable(
                    tf.initializers.random_normal().__call__(shape=[5, 5, 1, 32]))
            with tf.name_scope('bias'):
                model_dict.conv_layer_1_bias = tf.Variable(tf.initializers.random_normal().__call__(shape=[32]))
                # Outputs a tensor of shape (?, 8, 6, 4) on a 1x2 stride
                model_dict.conv_layer_1_out = tf.nn.relu(
                    tf.nn.bias_add(
                        tf.nn.conv2d(model_dict.input_reshape_out, model_dict.conv_layer_1_filter,
                                     strides=[1, 1, 1, 1], padding='SAME'),
                        model_dict.conv_layer_1_bias))

        # Pool Layer 1
        with tf.name_scope('pool_layer_1'):
            model_dict.pool_layer_1 = tf.nn.max_pool(model_dict.conv_layer_1_out, ksize=[1, 2, 2, 1],
                                                     strides=[1, 2, 2, 1], padding='SAME')

        # Convolution Layer 2
        with tf.name_scope('conv_layer_2'):
            with tf.name_scope('filter'):
                # Filter for each attribute and 3 patterns with 8 features
                model_dict.conv_layer_2_filter = tf.Variable(
                    tf.initializers.random_normal().__call__(shape=[5, 5, 32, 64]))
            with tf.name_scope('bias'):
                model_dict.conv_layer_2_bias = tf.Variable(tf.initializers.random_normal().__call__(shape=[64]))
                # Outputs a tensor of shape (?, 8, 3, 8) on a 1x2 stride
                model_dict.conv_layer_2_out = tf.nn.relu(
                    tf.nn.bias_add(
                        tf.nn.conv2d(model_dict.conv_layer_1_out, model_dict.conv_layer_2_filter,
                                     strides=[1, 1, 1, 1],
                                     padding='SAME'),
                        model_dict.conv_layer_2_bias))

                # Pool Layer 2
        with tf.name_scope('pool_layer_2'):
            model_dict.pool_layer_2 = tf.nn.max_pool(model_dict.conv_layer_2_out, ksize=[1, 2, 2, 1],
                                                     strides=[1, 2, 2, 1],
                                                     padding='SAME')

        # Reshape of conv layer to 2dims (8 attributes, 3-width patterns * 8 features) which is fed to hidden layer
        with tf.name_scope('reshape_conv_layer_2_op'):
            model_dict.pool_layer_2_reshape_out = tf.reshape(model_dict.pool_layer_2, shape=[-1, np.prod(
                model_dict.pool_layer_2.shape.as_list()[1:])])

        with tf.name_scope('hidden_layer'):
            with tf.name_scope('weights'):
                # Weights for 50 nodes
                model_dict.hidden_layer_weights = tf.Variable(
                    tf.initializers.random_normal().__call__(
                        shape=[np.prod(model_dict.pool_layer_2.shape.as_list()[1:]), 50]))
            with tf.name_scope('bias'):
                model_dict.hidden_layer_bias = tf.Variable(tf.initializers.random_normal().__call__(shape=[50]))
                # Outputs a tensor of shape (?, 50)
                model_dict.hidden_layer_out = tf.nn.sigmoid(
                    tf.nn.bias_add(
                        tf.matmul(model_dict.pool_layer_2_reshape_out, model_dict.hidden_layer_weights),
                        model_dict.hidden_layer_bias))

        with tf.name_scope('output_layer'):
            with tf.name_scope('weights'):
                # Weights for 1 nodes
                model_dict.output_layer_weights = tf.Variable(
                    tf.initializers.random_normal().__call__(shape=[50, 10]))
            with tf.name_scope('bias'):
                model_dict.output_layer_bias = tf.Variable(tf.initializers.random_normal().__call__(shape=[10]))
                # Outputs a tensor of shape (?, 1)
                model_dict.logits = tf.nn.bias_add(
                    tf.matmul(model_dict.hidden_layer_out, model_dict.output_layer_weights),
                    model_dict.output_layer_bias)
                model_dict.pred = tf.nn.softmax(tf.nn.bias_add(
                    tf.matmul(model_dict.hidden_layer_out, model_dict.output_layer_weights),
                    model_dict.output_layer_bias))

        with tf.name_scope('objective_function_classification'):
            # Cross Entropy as objective function as the problem is binary classification
            model_dict.objective_function = tf.reduce_mean(
                tf.nn.softmax_cross_entropy_with_logits_v2(labels=labels, logits=model_dict.logits))
            global_step = tf.train.get_or_create_global_step()
            # # Create an ExponentialMovingAverage object
            ema = tf.train.ExponentialMovingAverage(decay=0.99, num_updates=global_step, zero_debias=True)
            # Create the shadow variables, and add op to maintain moving averages
            maintain_averages_op = ema.apply([model_dict.objective_function])
            loss_ema = ema.average(model_dict.objective_function)
            tf.summary.scalar('loss/ema', loss_ema)
            # loss_ema = tf.Print(loss_ema, [loss_ema], 'EMA Loss: ')
            tf.add_to_collection('ema_loss', loss_ema)

        with tf.name_scope('optimizer'):
            # Adam Optimizer
            model_dict.optimizer = tf.train.AdamOptimizer(learning_rate=0.1).minimize(
                model_dict.objective_function, global_step=global_step)
            update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
            with tf.control_dependencies(update_ops + [model_dict.optimizer]):
                train_op = tf.group(maintain_averages_op)

        with tf.name_scope('accuracy_classification'):
            correct_pred = tf.equal(tf.argmax(model_dict.pred, 1), tf.argmax(labels, 1))
            model_dict.accuracy = tf.reduce_mean(tf.cast(correct_pred, 'float'))
            model_dict.accuracy = tf.Print(model_dict.accuracy, [model_dict.accuracy], 'Accuracy: ')

    predictions = {
        # Generate predictions (for PREDICT and EVAL mode)
        "classes": tf.argmax(input=model_dict.logits, axis=1),
        # Add `softmax_tensor` to the graph. It is used for PREDICT and by the
        # `logging_hook`.
        "probabilities": tf.nn.softmax(model_dict.logits, name="softmax_tensor"),
        'global_step': global_step
    }

    if mode == tf.estimator.ModeKeys.EVAL:

        # Add evaluation metrics (for EVAL mode)
        eval_metric_ops = {
            "accuracy": tf.metrics.accuracy(
                labels=labels, predictions=predictions["classes"])}
    else:
        eval_metric_ops = None

    train_hooks = []
    eval_hooks = []
    persist_train = False

    predictions_dict = {'prob': model_dict.pred,
                        'raw_predictions': model_dict.logits
                        }

    export_outputs = {'predictions': tf.estimator.export.PredictOutput(predictions_dict)}

    return tf.estimator.EstimatorSpec(
        training_hooks=train_hooks,
        evaluation_hooks=eval_hooks,
        mode=mode,
        predictions=predictions_dict,
        loss=model_dict.objective_function,
        train_op=train_op,
        eval_metric_ops=eval_metric_ops,
        export_outputs=export_outputs,
        scaffold=tf.train.Scaffold(init_fn=None) if persist_train else tf.train.Scaffold()

    )


class CustomEvalSessionHook(tf.train.SessionRunHook):
    def __init__(self, tensors_to_monitor, *kwargs):
        super().__init__()
        self.tensors_to_monitor = tensors_to_monitor

    def begin(self):
        print('Eval Session Started')
        # You can add ops to the graph here.
        pass

    def after_create_session(self, session, coord):
        # When this is called, the graph is finalized and
        # ops can no longer be added to the graph.
        pass

    def before_run(self, run_context):
        return tf.train.SessionRunArgs(self.your_tensor)

    def after_run(self, run_context, run_values):
        tensor_outs = run_context.session.run([self.ema_cost, tf.train.get_global_step()])
        # epoch = (gs * self.parameters.train_batch_size) / self.parameters.n_samples_train
        # if ct < 1 and self.least_cost > ct:
        #     self.least_cost = ct
        #     file_list = os.listdir(self.parameters.output_model_dir)
        #     event_file = sorted([e for e in file_list if 'events' in e])[-1]
        #     model_files = [m for m in file_list if
        #                    'model' in m and self.estimator.latest_checkpoint().split('-')[-1] in m]
        #     model_parm_file = sorted([e for e in file_list if 'params' in e])[-1]
        #     files_to_transfer = [event_file] + model_files + [model_parm_file]
        #     dir_name = self.parameters.output_model_dir + '/../timeline/' + generate_timestamp() + '_E' + str(
        #         int(epoch)) + '_C' + str(
        #         round(ct, 2)) + '_G' + str(gs) + '/'
        #     os.system('mkdir -p {}'.format(dir_name))
        #     [os.system('cp -R {} {}'.format(self.parameters.output_model_dir + '/' + filet, dir_name)) for filet in
        #      files_to_transfer]
        #     self.estimator.export_savedmodel(os.path.join(dir_name, 'export'),
        #                                      self.preprocess_image_for_prediction_fn(min_width=10))
        #     print('Exported model to {}'.format(os.path.join(self.parameters.output_model_dir, 'export')))

        # if you-need-to-stop-loop:
        #   run_context.request_stop()

    def end(self, session):
        print('Done with Eval Session.')


class CustomTrainSessionHook(tf.train.SessionRunHook):
    def __init__(self, tensors_to_monitor, *kwargs):
        super().__init__()
        self.tensors_to_monitor = tensors_to_monitor
        # self.notify = Notify(parameters)

    def begin(self):
        pass

    def after_create_session(self, session, coord):
        # When this is called, the graph is finalized and
        # ops can no longer be added to the graph.
        pass

    def before_run(self, run_context):
        return tf.train.SessionRunArgs(self.tensors_to_monitor)

    def after_run(self, run_context, run_values):
        # if run_values.results['step'] % self.parameters.notify_every_n_steps == 0:
        #     self.notify.train_interval(run_values.results, mode='step')

        # if time.time() > self.last_call + self.parameters.notify_every_n_secs:
        #     self.last_call += self.parameters.notify_every_n_secs
        #     self.notify.train_interval(run_values.results, mode='time')

        pass

    def end(self, session):
        # self.notify.train_completed()
        pass


def get_tf_session_config(parameters):
    config = tf.ConfigProto()
    # if parameters.use_horovod:
    #     import horovod.tensorflow as hvd
    #     hvd.init()
    #     config.gpu_options.visible_device_list = str(hvd.local_rank())
    #     parameters.output_model_dir = parameters.output_model_dir if hvd.rank() == 0 else None
    #     parameters.train_steps = ((
    #                                       parameters.n_epochs * parameters.n_samples_train) / parameters.train_batch_size) // hvd.size()
    #     parameters.eval_steps = (np.floor(parameters.n_samples_eval / parameters.eval_batch_size)) // hvd.size()
    #     if hvd.rank() == 0:
    #         parameters.export_experiment_params()
    # else:
    #     parameters.output_model_dir = parameters.output_model_dir
    #     parameters.train_steps = (parameters.n_epochs * parameters.n_samples_train) / parameters.train_batch_size
    #     parameters.eval_steps = np.floor(parameters.n_samples_eval / parameters.eval_batch_size)
    #     parameters.export_experiment_params()
    # if parameters.allow_gpu_growth:
    #     config.gpu_options.allow_growth = True
    return config


def get_estimator_config(parameters, config):
    est_config = tf.estimator.RunConfig()
    # est_config = est_config.replace(keep_checkpoint_max=parameters.max_checkpoints_to_keep,
    #                                 save_checkpoints_steps=parameters.save_interval_steps,
    #                                 session_config=config,
    #                                 save_checkpoints_secs=parameters.save_checkpoints_secs,
    #                                 save_summary_steps=parameters.save_summary_steps,
    #                                 model_dir=parameters.output_model_dir)
    return est_config


def get_hooks(tensors_to_log):
    # Logging Hook
    logging_hook = tf.train.LoggingTensorHook(
        tensors=tensors_to_log, every_n_iter=50)

    # Profiler Hook
    profile_hook = tf.train.ProfilerHook(save_secs=10000, output_dir='/tmp/tfprofile/')

    # Custom Training Hook
    custom_train_hook = CustomTrainSessionHook(tensors_to_monitor={})

    # CLI Debug Hook
    debug_hook = tf_debug.LocalCLIDebugHook(ui_type='curses')

    # Tensorboard Debugger
    # debug_hook = tf_debug.TensorBoardDebugHook(grpc_debug_server_addresses='localhost:6064')

    # Custom Eval Hook
    custom_eval_hook = CustomEvalSessionHook(tensors_to_monitor={})

    return [logging_hook, profile_hook, custom_train_hook, debug_hook], [logging_hook, profile_hook, custom_eval_hook]


def main(unused_argv):
    # Create Tensorflow Config
    config_sess = get_tf_session_config(parameters={})

    # Configure Estimator
    estimator_config = get_estimator_config(parameters={}, config=config_sess)

    # Create the Estimator
    mnist_classifier = tf.estimator.Estimator(
        model_fn=cnn_model_fn, model_dir="/tmp/mnist_convnet_model", config=estimator_config)

    # Create train data loader function
    train_input_fn = tf.estimator.inputs.numpy_input_fn(
        x={"x": train_data},
        y=train_label,
        batch_size=10,
        num_epochs=None,
        shuffle=True)

    # Create eval data loader function
    eval_input_fn = tf.estimator.inputs.numpy_input_fn(
        x={"x": test_data},
        y=test_label,
        num_epochs=1,
        shuffle=False)

    # Log the values in the "Softmax" tensor with label "probabilities"
    tensors_to_log = {}  # {"probabilities": "softmax_tensor"}

    train_hooks, eval_hooks = get_hooks(tensors_to_log)

    # Train and Evaluation
    # tf.estimator.train_and_evaluate(
    #     estimator=mnist_classifier,
    #     train_spec=tf.estimator.TrainSpec(input_fn=train_input_fn, max_steps=2000,
    #                                       hooks=train_hooks if train_hooks else None),
    #     eval_spec=tf.estimator.EvalSpec(input_fn=eval_input_fn, steps=1000,
    #                                     start_delay_secs=10,
    #                                     throttle_secs=120,
    #                                     hooks=eval_hooks if eval_hooks else None))

    # Only Train
    mnist_classifier.train(input_fn=train_input_fn, steps=2000, hooks=train_hooks)

    # Only Evaluation / Infer
    # mnist_classifier.evaluate(input_fn=eval_input_fn, hooks=eval_hooks)


if __name__ == "__main__":
    tf.app.run()
