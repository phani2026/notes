# -*- coding: utf-8 -*-
"""
| **@created on:** 03/05/17,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::
"""
import pandas as pd
import logging

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


def sort_dataframes(file_path_list: list, id_col: int, randomize: bool = False, save_path=None, verify=True):
    """
    | **@author:** Prathyush SP
    |
    | Sort Dataframes
    :param file_path_list: Files to be read
    :param id_col: id column
    :param randomize: Randomize
    :param save_path: Save
    :param verify: Print first 10 rows for verification
    :return: List of Dataframes
    """

    # Reading Data
    logger.info('Reading Data . . .')
    dataframe_list = [pd.read_csv(filep, header=None, skiprows=1) for filep in file_path_list]
    file_name_list = [f.split('/')[-1] for f in file_path_list]
    original_samples_count = [len(df.index) for df in dataframe_list]

    # Remove NA
    logger.info('Removing NA . . . ')
    dataframe_list = [df.dropna(axis=1) for df in dataframe_list]

    # Generate Curated ID
    logger.info('Generating Curated ID (inner join id) . . . ')
    merge_df = dataframe_list[0][id_col].to_frame(name=None)
    for df in dataframe_list[1:]:
        merge_df = pd.merge(merge_df, df[id_col].to_frame(name=None), on=id_col, how='inner')
    curated_id_list = merge_df[id_col].as_matrix().tolist()

    # Select Curated ID
    logger.info('Selecting id based on curated id . . . ')
    curated_df = pd.DataFrame({id_col: curated_id_list})
    if randomize:
        logger.info("Randomizing ID's . . .")
        curated_df = curated_df.sample(frac=1)

    dataframe_list = [pd.merge(curated_df, df, how='inner', on=id_col) for df in dataframe_list]
    if save_path:
        logger.info("Saving to CSV files . . .")
        for df, fname in zip(dataframe_list, file_name_list):
            df.to_csv(save_path + '/' + fname, index=False)
    if verify:
        for df in dataframe_list:
            print(df.head(10))
    final_samples_count = [len(df.index) for df in dataframe_list]
    [logger.info('Error Samples Count {}: {}'.format(n, o - c)) for o, c, n in
     zip(original_samples_count, final_samples_count, file_name_list)]
    return dataframe_list
