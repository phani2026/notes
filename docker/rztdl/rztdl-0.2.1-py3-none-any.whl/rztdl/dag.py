# -*- coding: utf-8 -*-
"""
| *@created on:* 08/06/18,
| *@author:* Umesh Kumar,
| *@version:* v0.0.1
|
| *Description:*
| 
| *Sphinx Documentation Status:* Complete
|
..todo::
"""

import enum
import logging

import networkx as nx
from typeguard import typechecked

from rztdl.utils.singleton import Singleton
import rztdl.utils.string_constants as constants

logger = logging.getLogger(__name__)


class _RztdlDag(metaclass=Singleton):
    """
    | **@author:** Umesh Kumar
    |
    | RZTDL DAG
    """

    def __init__(self):
        """
        | **@author:** Umesh Kumar
        |
        """
        self.dag = nx.MultiDiGraph()

    @typechecked
    def add_node_to_dag(self, node: str, component_type: enum):
        """

        :param node:
        :param component_type:
        :return:
        """
        self.dag.add_node(node_for_adding=node, component_type=component_type)
        pass

    def get_all_nodes(self, data=False):
        """

        :param data:
        :return:
        """
        return self.dag.nodes(data=data)

    @typechecked
    def add_edge_to_node(self, from_node: str, to_node: str):
        """

        :param from_node:
        :param to_node:
        :return:
        """
        self.dag.add_edge(u_for_edge=from_node, v_for_edge=to_node)

    def get_all_edges(self):
        """

        :return:
        """
        return self.dag.edges()

    @typechecked
    def get_all_predecessors(self, node: str):
        """

        :param node:
        :return:
        """
        return list(self.dag.predecessors(n=node))

    @typechecked
    def get_all_successors(self, node: str):
        """

        :param node:
        :return:
        """
        return list(self.dag.successors(n=node))

    @typechecked
    def get_ancestors(self, node: str):
        """

        :param node:
        :return:
        """
        return list(nx.ancestors(self.dag, node))

    @typechecked
    def get_descendants(self, node: str):
        """

        :param node:
        :return:
        """
        return list(nx.descendants(self.dag, node))

    # noinspection PyUnresolvedReferences
    @typechecked
    def get_ancestors_by_type(self, node: str, component_type: enum):
        """

        :param node:
        :param component_type:
        :return:
        """
        ancestors = list(nx.ancestors(self.dag, node))
        ancestors_with_specify_component_type = []
        for ancestor in ancestors:
            if self.dag.node[ancestor]["component_type"] == component_type:
                ancestors_with_specify_component_type.append(ancestor)
        return ancestors_with_specify_component_type

    # noinspection PyUnresolvedReferences
    @typechecked
    def get_descendants_by_type(self, node: str, component_type: enum):
        """

        :param node:
        :param component_type:
        :return:
        """
        descendants = list(nx.descendants(self.dag, node))
        descendants_with_specify_component_type = []
        for descendant in descendants:
            if self.dag.node[descendant]["component_type"] == component_type:
                descendants_with_specify_component_type.append(descendant)
        return descendants_with_specify_component_type

    # noinspection PyUnresolvedReferences
    @typechecked
    def get_metrics_of_node(self, node: str):
        """

        :param node:
        :return:
        """
        ancestors = nx.ancestors(self.dag, node)
        metrics_of_specify_node = []
        for ancestor in ancestors:
            if self.dag.node[ancestor]["component_type"] == constants.MetricType:
                metrics_of_specify_node.append(ancestor)
            else:
                for successor in self.dag.successors(n=ancestor):
                    if self.dag.node[successor]["component_type"] == constants.MetricType:
                        metrics_of_specify_node.append(successor)
        return list(set(metrics_of_specify_node))


RZTDL_DAG = _RztdlDag()
