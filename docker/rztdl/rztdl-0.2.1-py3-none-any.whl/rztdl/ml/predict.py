# -*- coding: utf-8 -*-
"""
| **@created on**: 26/12/2017,
| **@author**: Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
|   1. Prediction class for ML models
|
| **Sphinx Documentation Status:** Complete
|
| ..todo::
    --
"""
import os
import pickle

import numpy
from typeguard import typechecked

from rztdl import RZTDL_CONFIG
from rztdl.utils.pyutils import File
from rztdl.utils.string_constants import ModelMetaConstant


class Prediction(object):
    """
    | **@author:** Umesh Kumar
    |
    | Prediction Class

    """

    @typechecked
    def __init__(self, name: str, model_save_path: str = None, run_id=-1):
        """

        :param name: Name
        :param model_save_path: Save model in save_path
        :param run_id : Run Id of the model
        """
        self.name = name
        self.id = run_id
        self.metadata = None
        self.model_save_path = model_save_path if model_save_path else RZTDL_CONFIG.CommonConfig.PATH_RZTDL
        self._validate()

    @typechecked
    def predict(self, data: numpy.ndarray):
        """
        | **@author:** Umesh Kumar
        |
        | Predict the label of given data

        :param data: Data
        """
        model = pickle.load(open(self.model_save_path, 'rb'))
        return model.predict(data)

    def _validate(self):
        """
        | **@author:** Umesh Kumar
        |
        | Prediction Validation
        """
        if os.path.exists(path=self.model_save_path + '/' + self.name + '/model.meta'):
            self.metadata = File.read_json(path=self.model_save_path + '/' + self.name + '/model.meta')
            try:
                self.model_save_path += '/' + self.metadata[ModelMetaConstant.NETWORK_NAME] + '/' + \
                                        self.metadata[
                                            ModelMetaConstant.TIMESTAMP] + '/' + \
                                        self.metadata[ModelMetaConstant.PATH][
                                            ModelMetaConstant.PATH_OPTIONS.ML_SAVE_PATH]
                self.model_save_path += self.name + '.model'
            except KeyError:
                self.model_save_path = self.model_save_path if self.model_save_path else RZTDL_CONFIG.CommonConfig.PATH_RZTDL
                keys = [int(k) for k in self.metadata.keys()]
                self.metadata = self.metadata[str(self.id)] if self.id in keys else self.metadata[str(max(keys))]
                self.model_save_path += '/' + self.metadata[ModelMetaConstant.NETWORK_NAME] + '/' + self.metadata[
                    ModelMetaConstant.TIMESTAMP] + '/' + self.metadata[ModelMetaConstant.PATH][
                                            ModelMetaConstant.PATH_OPTIONS.ML_SAVE_PATH] + self.name + '.model'
            self.model_name = self.metadata[ModelMetaConstant.MODEL_NAME]
        else:
            raise FileExistsError('Model meta file / Network not found')
