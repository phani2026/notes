# -*- coding: utf-8 -*-
"""
| **@created on:** 09/05/2017,
| **@author:** Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
|
| **Sphinx Documentation Status:**
|

"""
import logging
import pickle
from collections import OrderedDict
from typing import Union

import numpy
from typeguard import typechecked

from rztdl import RZTDL_CONFIG, RZTDL_STORE
from rztdl.meta.network_meta import NetworkMeta
from rztdl.ml.helpers.mlhelpers import Cost
from rztdl.ml.model import Model
from rztdl.ml.result import Result
from rztdl.utils.pyutils import Directories
from rztdl.utils.pyutils import generate_timestamp, DLTimer
from rztdl.utils.string_constants import NetworkMetaConstant, CostType
from rztdl.utils.validations import validate_name
from rztdl.metrics.ml import CostMetric
from rztdl.metrics.ml.ml_evaluation_metric_runner import MLEvaluationMetricRunner

logger = logging.getLogger(__name__)


class Network(object):
    """
    | **@author:** Umesh Kumar
    |
    | Network Class
    """

    @typechecked
    def __init__(self, name: str):
        """
        :param name: Network name
        """
        self.name = validate_name(name)
        self.model = None
        self.cost = None
        self.gini = None
        self.model_name = None
        self.save_path = None
        self.network_meta = None
        self.evaluation_metric_runner = None
        self.timestamp = generate_timestamp()

    @typechecked
    def _create_directories(self, save_path: str = RZTDL_CONFIG.CommonConfig.PATH_RZTDL):
        """
        | **@author:** Umesh Kumar
        |
        | Create required directories for the Network
        :param save_path: Save Path [Default: '/tmp/rztdl_logs/' ]
        """
        init_path = save_path + '/' + self.name + '/' + self.timestamp + '/'
        if not RZTDL_CONFIG.CommonConfig.DRY_RUN:
            [Directories.mkdir(init_path + path, force=True) for path in
             [RZTDL_CONFIG.CommonConfig.PATH_LOG, RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_DL,
              RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_ML, RZTDL_CONFIG.CommonConfig.PATH_GRAPH,
              RZTDL_CONFIG.CommonConfig.PATH_DATA]]
            RZTDL_STORE.add_logs_to_tmp(path=init_path + RZTDL_CONFIG.CommonConfig.PATH_LOG)

    @typechecked
    def train(self, model: Union[Model, str], train_data: dict, test_data: dict = None, cost: str = None,
              evaluation_metrics: list = [], print_json=False, save_path: str = None):

        """
        | **@author:** Umesh Kumar
        |
        | Train the Network
        :param evaluation_metrics: Evaluation Metrics
        :param model: Model
        :param cost: Loss Function
        :param train_data: Train data
        :param test_data: Test data
        :param print_json: Print in JSON format
        :param save_path: Model save path

        """
        self.model = model
        self.model_name = model.name
        self.cost = cost
        meta_data_save_path = save_path if save_path else RZTDL_CONFIG.CommonConfig.PATH_RZTDL
        self.save_path = save_path if save_path else RZTDL_CONFIG.CommonConfig.PATH_RZTDL
        cost_metric = CostMetric(cost_type=self.cost)
        evaluation_metrics += [cost_metric]
        result = Result(model_name=self.model_name, network_name=self.name, cost=cost, timestamp=self.timestamp,
                        evaluation_metrics=evaluation_metrics)
        self.evaluation_metric_runner = MLEvaluationMetricRunner()
        self.evaluation_metric_runner.initialise_variables(evaluation_metrics=evaluation_metrics, result=result)

        # Validate
        self._train_validation(save_path=self.save_path)
        train_time = DLTimer().set_time()
        self.save_path += '/' + self.name + '/' + self.timestamp + '/'
        self.model.train(train_data['data'], train_data['label'])
        accuracy = self.model.accuracy(train_data['data'], train_data['label'])
        pred_labels = self.model.predict(train_data['data'])
        self.evaluation_metric_runner.calculate_epoch_result(actual_labels=train_data["label"],
                                                             predicted_labels=pred_labels, accuracy=accuracy,
                                                             train_time=train_time, json_type=print_json)

        # Test Data
        if test_data:
            test_time = DLTimer().set_time()
            test_accuracy = self.model.accuracy(test_data['data'], test_data['label'])
            pred_labels = self.model.predict(test_data['data'])
            self.evaluation_metric_runner.calculate_test_result(actual_labels=test_data["label"],
                                                                predicted_labels=pred_labels,
                                                                accuracy=test_accuracy,
                                                                test_time=test_time, json_type=print_json)

        RZTDL_STORE.add_meta_data_dict(model_name=self.model_name, items={
            'model_factors': {k: v.tolist() for k, v in self.model.model.__dict__.items() if
                              isinstance(v, numpy.ndarray)}})
        # Saving the model

        if not RZTDL_CONFIG.CommonConfig.DRY_RUN:
            pickle.dump(self.model,
                        open(self.save_path + RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_ML + self.name + ".model",
                             'wb'))
            self.network_meta = NetworkMeta().load_meta(network_name=self.name,
                                                        load_path=meta_data_save_path,
                                                        ntype=NetworkMetaConstant.TYPE_OPTION.ML)
            RZTDL_STORE.save_metadata(path=meta_data_save_path, name=self.name, model_name=self.model_name)

            self.network_meta.update_meta(name=self.name, save_path=meta_data_save_path,
                                          ntype=NetworkMetaConstant.TYPE_OPTION.ML)
            self.network_meta.save_meta(save_path=meta_data_save_path)
            RZTDL_STORE.meta_data = OrderedDict()

    def _train_validation(self, save_path):
        """
        | **@author:** Umesh Kumar
        |
        | Network Train Validation
        :param save_path: Save Path
        :return:
        """
        self._create_directories(save_path=save_path)
        if isinstance(self.cost, str):
            if self.cost not in CostType.__dict__.values():
                raise Exception("Not a valid Cost. Usage: COST.<>")
        logger.info('Cost Function: {}'.format(self.cost))
