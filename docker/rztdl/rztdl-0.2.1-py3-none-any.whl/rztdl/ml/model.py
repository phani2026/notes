"""
| **@created on:** 19/04/17,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::
"""
from abc import ABCMeta, abstractmethod
from typing import Union

import numpy
from numpy import array
from sklearn import linear_model, ensemble
from typeguard import typechecked

from rztdl import RZTDL_STORE
from rztdl.utils.string_constants import ML_MODELS
from rztdl.utils.validations import validate_name, validate_ml_model_type


class Model(metaclass=ABCMeta):
    """
    | **@author:** Prathyush SP
    |
    | Base class, which defines abstract methods for ML Models

    """

    @typechecked
    def __init__(self, name: str, model_type: str):
        """

        :param name: Model name
        :param model_type: Model type
        """
        self.name = validate_name(name)
        self.type = validate_ml_model_type(model_type)
        self.validate()

    @abstractmethod
    def train(self, data, label):
        """
        | **@author:** Prathyush SP
        |
        | Training method

        :param data: Train data
        :param label: Train label
        :return:
        """
        pass  # pragma: no cover

    @abstractmethod
    def validate_train(self, data, label):
        """
        | **@author:** Prathyush SP
        |
        | Validation Method

        :param data : Data
        :param label : Label
        """
        pass  # pragma: no cover

    @abstractmethod
    def predict(self, data):
        """
        | **@author:** Prathyush SP
        |
        | Prediction Method

        :param data: Data
        :return:
        """
        pass  # pragma: no cover

    @abstractmethod
    def validate_predict(self):
        """
        | **@author:** Prathyush SP
        |
        | Validation Method
        """
        pass  # pragma: no cover

    @abstractmethod
    def accuracy(self, data, label):
        """
        | **@author:** Umesh Kumar
        |
        | Accuracy Method

        :param data: Data
        :param label: Label
        """
        pass  # pragma: no cover

    def validate(self):
        RZTDL_STORE.add_model(self.name)


class LogisticRegression(Model):
    """
        | **@author:** Umesh Kumar
        |
        | Logistic Regression MLModel

    """

    @typechecked
    def __init__(self, name: str, penalty: str = 'l2', dual: bool = False, tol: float = 1e-4, C: float = 1.0,
                 fit_intercept: bool = True, intercept_scaling: float = 1,
                 class_weight: dict = None, random_state: int = None, solver: str = 'liblinear', max_iter: int = 100,
                 multi_class: str = 'ovr', verbose: int = 0,
                 warm_start: bool = False, n_jobs: int = 1):
        """

        :param name: Model name
        :param penalty: Norm used in the penalization
        :param dual: Only implemented for 'l2' penalty, dual = False when n_sample>n_features
        :param tol: Tolerance
        :param C: Inverse of regularization function
        :param fit_intercept: Intercept
        :param intercept_scaling: Used only when the solver liblinear and self.fit_intercept is set to true
        :param class_weight: Class weight
        :param random_state: Random number generator to use when shuffling the data
        :param solver: Algorithm to use optimization problem
        :param max_iter: Maximum iteration
        :param multi_class: Multiclass
        :param verbose: Verbosity
        :param warm_start: If  warm start is True, reuse the solution of the previous call to fit as initialization,
                           otherwise, just erase the previous solution
        :param n_jobs: Number of CPU cores 
        """
        self.model_type = ML_MODELS.LOGISTIC_REGRESSION
        super().__init__(name=name, model_type=self.model_type)
        self.model = linear_model.LogisticRegression(penalty=penalty, dual=dual, tol=tol, C=C,
                                                     fit_intercept=fit_intercept,
                                                     intercept_scaling=intercept_scaling, class_weight=class_weight,
                                                     random_state=random_state, solver=solver, max_iter=max_iter,
                                                     multi_class=multi_class, verbose=verbose, warm_start=warm_start,
                                                     n_jobs=n_jobs)

    @typechecked
    def train(self, data: numpy.ndarray, label: numpy.ndarray):
        """
        | **@author:** Umesh Kumar
        |
        | **Description:**
        | Train the model
        | Fit the model according to the given training data and label

        :param data: Train data
        :param label: Train label
        :return: self
        """
        self.validate_train(data, label)
        return self.model.fit(X=data, y=label.ravel())

    def validate_predict(self):
        """

        :return:self
        """
        pass  # pragma: no cover

    @typechecked
    def predict(self, data: numpy.ndarray) -> numpy.ndarray:
        """
        | **@author:** Umesh Kumar
        |
        | **Description:**
        |  Predict the class label per sample

        :param data: Data
        :return: predict class label
        """
        return self.model.predict(X=data)

    @typechecked
    def validate_train(self, data: numpy.ndarray, label: numpy.ndarray):
        """
        | **@author:** Umesh Kumar
        |
        |  Validates the training data and label

        :param data: data
        :param label: label 
        """
        array_data = array(data)
        array_label = array(label)
        if not array_data.shape[0] == array_label.shape[0]:
            raise Exception('shape of sample_data and sample_label is not equal')

    @typechecked
    def accuracy(self, data: numpy.ndarray, label: numpy.ndarray) -> float:
        """
        | **@author:** Umesh Kumar
        |
        | **Description:**
        | Score function returns mean accuracy of data and label

        :param data: Data
        :param label: Label
        :return: Mean accuracy - float value - ranges from 0 to 1
        """
        return self.model.score(X=data, y=label)


class LinearRegression(Model):
    """
    | **@author:** Umesh Kumar
    |
    | Linear Regression MLModel
    """

    @typechecked
    def __init__(self, name: str, fit_intercept: bool = True, normalize: bool = False, copy_X: bool = True,
                 n_jobs: int = 1):
        """

        :param name: Model name
        :param fit_intercept: Intercept
        :param normalize:Normalize
        :param copy_X: If True, X will be copied; else, it may be overwritten.
        :param n_jobs: Number of jobs
        """
        self.model_type = ML_MODELS.LINEAR_REGRESSION
        super().__init__(name=name, model_type=self.model_type)
        self.model = linear_model.LinearRegression(fit_intercept=fit_intercept, normalize=normalize, copy_X=copy_X,
                                                   n_jobs=n_jobs)

    @typechecked
    def train(self, data: numpy.ndarray, label: numpy.ndarray):
        """
        | **@author:** Umesh Kumar
        |
        | **Description:**
        | Train the model
        | Fit the model according to the given training data and label

        :param data: Train data
        :param label: Train label
        :return:
        """
        self.validate_train(data, label)
        return self.model.fit(X=data, y=label)

    def validate_predict(self):
        """

        :return:
        """
        pass  # pragma: no cover

    @typechecked
    def predict(self, data: numpy.ndarray) -> numpy.ndarray:
        """
        | **@author:** Umesh Kumar
        |
        | **Description:**
        |  Predict the class label per sample

        :param data: Data
        :return: Predict label
        """
        return self.model.predict(X=data)

    def validate_train(self, data, label):
        """
        | **@author:** Umesh Kumar
        |
        |  Validates the training data and label

        :param data: data
        :param label:label 
        """
        array_data = array(data)
        array_label = array(label)
        if not array_data.shape[0] == array_label.shape[0]:
            raise Exception('shape of sample_data and sample_label is not equal')

    @typechecked
    def accuracy(self, data: numpy.ndarray, label: numpy.ndarray) -> float:
        """
        | **@author:** Umesh Kumar
        |
        | **Description:**
        | Score function returns mean accuracy on data and label

        :param data: Data
        :param label: Label
        :return: float value - ranges from 0 to 1
        """
        return self.model.score(X=data, y=label)


class RandomForest(Model):
    """
    | **@author:** Umesh Kumar
    |
    | RandomForest Regression MLModel
    """

    def __init__(self, name: str, n_estimators: int = 10, criterion: str = "gini",
                 max_depth: Union[int, float, str, None] = None, min_samples_split: Union[float, int] = 2,
                 min_samples_leaf: Union[int, float] = 1, min_weight_fraction_leaf: float = 0.,
                 max_features: Union[int, float, str, None] = "auto", max_leaf_nodes: Union[int, None] = None,
                 min_impurity_decrease: float = 1e-7, bootstrap: bool = True, oob_score: bool = False, n_jobs: int = 1,
                 random_state: Union[int, None] = None, verbose: int = 0,
                 warm_start: bool = False, class_weight: Union[dict] = None):
        """

        :param name: Model name.
        :param n_estimators: Number of trees in the forest.
        :param criterion: Measure the quality of split.
        :param max_depth: Maximum depth of tree.
        :param min_samples_split: Minimum number of sample to split internal node.
        :param min_samples_leaf: Minimum number of samples required to be at a leaf node.
        :param min_weight_fraction_leaf: Minimum weighted fraction of the sum total of weights required to be at a leaf node.
        :param max_features: Maximum  number of split.
        :param max_leaf_nodes: Maximun number of leaf nodes.
        :param min_impurity_decrease: Minimum number of impurity split
        :param bootstrap: Bootstrap sample
        :param oob_score:Out-of-bag score
        :param n_jobs:Number of jobs to run parallel 
        :param random_state: Random state
        :param verbose: Verbosity
        :param warm_start: If  warm start is True, reuse the solution of the previous call to fit as initialization,
                           otherwise, just erase the previous solution
        :param class_weight: Class weight
        """
        self.model_type = ML_MODELS.RANDOM_FOREST
        super().__init__(name=name, model_type=self.model_type, )
        self.model = ensemble.RandomForestClassifier(n_estimators=n_estimators,
                                                     criterion=criterion,
                                                     max_depth=max_depth,
                                                     min_samples_split=min_samples_split,
                                                     min_samples_leaf=min_samples_leaf,
                                                     min_weight_fraction_leaf=min_weight_fraction_leaf,
                                                     max_features=max_features,
                                                     max_leaf_nodes=max_leaf_nodes,
                                                     min_impurity_decrease=min_impurity_decrease,
                                                     bootstrap=bootstrap,
                                                     oob_score=oob_score,
                                                     n_jobs=n_jobs,
                                                     random_state=random_state,
                                                     verbose=verbose,
                                                     warm_start=warm_start,
                                                     class_weight=class_weight)

    @typechecked
    def train(self, data: numpy.ndarray, label: numpy.ndarray):
        """
        | **@author:** Umesh Kumar
        |
        | **Description:**
        | Train the model
        | Fit the model according to the given training data and label

        :param data: Train data
        :param label: Train label
        :return: self
        """
        self.validate_train(data, label)
        return self.model.fit(X=data, y=label.ravel())

    def validate_predict(self):
        """

        :return:self
        """
        pass  # pragma: no cover

    @typechecked
    def predict(self, data: numpy.ndarray) -> numpy.ndarray:
        """
        | **@author:** Umesh Kumar
        |
        | **Description:**
        |  Predict the class label per sample

        :param data: Data
        :return: predict class label
        """
        return self.model.predict(X=data)

    def validate_train(self, data: numpy.ndarray, label: numpy.ndarray):
        """
        | **@author:** Umesh Kumar
        |
        |  Validates the training data and label

        :param data: data
        :param label: label
        :return: 
        """
        array_data = array(data)
        array_label = array(label)
        if not array_data.shape[0] == array_label.shape[0]:
            raise Exception('shape of sample_data and sample_label is not equal')

    @typechecked
    def accuracy(self, data: numpy.ndarray, label: numpy.ndarray) -> float:
        """
        | **@author:** Umesh Kumar
        |
        | **Description:**
        | Score function returns mean accuracy on data and label

        :param data: Data
        :param label: Label
        :return: Mean accuracy
        """
        return self.model.score(X=data, y=label)
