# -*- coding: utf-8 -*-
"""
| **@created on:** 22/05/2017,
| **@author:** Thebzeera V,
| **@version:** v0.0.2
|
| Refactored on 23/01/18
| **@author:** Umesh Kumar,
|
| Description: Result Helpers
|
| Sphinx Documentation Status: Complete
|
..todo::

"""

import json
import logging
from collections import OrderedDict
from typing import Union
import numpy
from typeguard import typechecked
from rztdl import RZTDL_STORE
from rztdl.utils.pyutils import DLTimer
from rztdl import RZTDL_CONFIG
from rztdl.utils.string_constants import ML_MODELS

logger = logging.getLogger(__name__)


class Result(object):
    """
    | **@author:** Thebzeera V
    |
    | Result Helper Class
    """

    @typechecked
    def __init__(self, model_name, cost: Union[str, None], network_name, timestamp: str, evaluation_metrics: list):
        """
        :param cost
        :param model_name:  Model Name
        :param network_name: Network Name
        :param timestamp: Timestamp YYYYMMDD_HHmmss
        :param evaluation_metrics: Evaluation Metrics
        """
        self.evaluation_metrics = evaluation_metrics
        self.eta = 0
        self.batch_eta = 0
        self.time_for_one_batch = 0
        self.model_name = model_name

        # Initialize Model parameters
        RZTDL_STORE.add_meta_data_dict(self.model_name,
                                       OrderedDict([('network_name', network_name), ('model_name', self.model_name),
                                                  ('timestamp', timestamp),
                                                  ('cost', cost),
                                                  ('path',
                                                   OrderedDict([('dl_save_path',
                                                                 RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_DL),
                                                                ('ml_save_path',
                                                                 RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_ML),
                                                                ('data_save_path',
                                                                 RZTDL_CONFIG.CommonConfig.PATH_DATA),
                                                                ('graph_save_path',
                                                                 RZTDL_CONFIG.CommonConfig.PATH_GRAPH)]))]))

        # Initialize Metas
        RZTDL_STORE.add_meta_data_dict(self.model_name,
                                       OrderedDict([(ML_MODELS.ML_TRAIN_META, OrderedDict()),
                                                  (ML_MODELS.ML_TEST_META, OrderedDict())]))

        # Initialize metrics
        RZTDL_STORE.add_metrics_to_meta_data(model_name=self.model_name, mode=ML_MODELS.ML_TRAIN_META,
                                             key="train_metrics", metric_constant="train_",
                                             value=[metric.name for metric in self.evaluation_metrics])

        # Initialize Train meta
        RZTDL_STORE.add_result_meta_data_dict(model_name=self.model_name, mode=ML_MODELS.ML_TRAIN_META,
                                              item=OrderedDict([(i, "") for i in (['accuracy', 'time_elapsed'])]))

    @typechecked
    def get_test_result(self, accuracy: float, evaluation_metrics_switch,
                        test_time: DLTimer, json_type: bool = False):
        """
        | **@author:** Thebzeera V
        |
        | Used to fetch test result

        :param evaluation_metrics_switch: Evaluation Metrics Switch
        :param accuracy: Test Accuracy
        :param test_time: Test Time (DLTimer Object)
        :param json_type: Format output as JSON String (Boolean)
        :return:
        """

        RZTDL_STORE.add_metrics_to_meta_data(model_name=self.model_name, mode=ML_MODELS.ML_TEST_META,
                                             key="test_metrics", metric_constant="test_",
                                             value=[metric.name for metric in self.evaluation_metrics])
        # Initialize Test meta
        RZTDL_STORE.add_result_meta_data_dict(model_name=self.model_name, mode=ML_MODELS.ML_TEST_META,
                                              item=OrderedDict([(i, '') for i in (
                                                ['test_accuracy', 'test_time_elapsed'])]))
        test_dictionary = {"test_metrics": {}}

        for metric in self.evaluation_metrics:
            metric = metric.name
            test_dictionary['test_metrics']['test_' + metric] = evaluation_metrics_switch[metric].test_result_value[-1]

        test_item = OrderedDict(
            [('test_accuracy', accuracy)] +
            [(k, v) for k, v in test_dictionary['test_metrics'].items()]
            + [('test_time_elapsed', str(test_time.get_elapsed_time()))])

        print_item = ['Accuracy'] + [x for x, v in test_dictionary['test_metrics'].items()] + ['Time Elapsed']
        if json_type:
            logger.info(
                "Test Data - " + json.dumps(OrderedDict([(k, v) for k, v in test_item.items() if v is not None])))
        else:
            logger.info('Test Data - ' + ', '.join(
                [": ".join([print_item[e], '{0:.2f}'.format(i[1]) if isinstance(i[1], float) else str(i[1])]) for
                 e, i in enumerate(test_item.items()) if i[1] is not None]))
        for metric in self.evaluation_metrics:
            metric = metric.name
            test_dictionary['test_metrics']['test_' + metric] = evaluation_metrics_switch[metric]
        test_item = OrderedDict(
            [('test_accuracy', accuracy)] +
            [(k, v) for k, v in test_dictionary.items()]
            + [('test_time_elapsed', str(test_time.get_elapsed_time()))])
        RZTDL_STORE.set_value_to_result_dict(model_name=self.model_name, mode=ML_MODELS.ML_TEST_META, item=test_item)

    @typechecked
    def get_train_result(self, accuracy: float, evaluation_metrics_switch,
                         train_time: DLTimer, json_type: bool = False):
        """
        | **@author:** Thebzeera V
        |
        | Used to fetch train result

        :param evaluation_metrics_switch: Evaluation Metrics Switch
        :param accuracy: Accuracy list of train data
        :param train_time: Train Time (DLTimer Object)
        :param json_type: Format output as JSON String (Boolean)
        :return:
        """
        train_dictionary = {"train_metrics": {}}
        for metric in self.evaluation_metrics:
            metric = metric.name
            train_dictionary['train_metrics']['train_' + metric] = evaluation_metrics_switch[metric].epoch_result_value[
                -1]
        train_item = OrderedDict(
            [('accuracy', accuracy)] +
            [(k, v) for k, v in train_dictionary['train_metrics'].items()] + [
                ('time_elapsed', str(train_time.get_elapsed_time()))])
        print_item = ['Accuracy'] + [x for x, v in train_dictionary['train_metrics'].items()] + ['Time Elapsed']
        if json_type:
            logger.info(
                'Train Data - ' + json.dumps(OrderedDict([(k, v) for k, v in train_item.items() if v is not None])))
        else:
            logger.info('Train Data - ' + ', '.join(
                [": ".join([print_item[e], '{0:.2f}'.format(i[1]) if isinstance(i[1], float) else str(i[1])]) for
                 e, i in enumerate(train_item.items()) if i[1] is not None]))
        for metric in self.evaluation_metrics:
            metric = metric.name
            train_dictionary['train_metrics']['train_' + metric] = evaluation_metrics_switch[metric]
        train_item = OrderedDict(
            [('accuracy', accuracy)] +
            [(k, v) for k, v in train_dictionary.items()] + [
                ('time_elapsed', str(train_time.get_elapsed_time()))])
        RZTDL_STORE.set_value_to_result_dict(model_name=self.model_name, mode=ML_MODELS.ML_TRAIN_META, item=train_item)
