# -*- coding: utf-8 -*-
"""
@created on: 5/29/18,
@author: Himaprasoon,
@version: v0.0.1

Description:

Sphinx Documentation Status:

..todo::

"""

from typeguard import typechecked, Union, List
import hashlib


class BluePrintProperties(object):
    @typechecked
    def __init__(self, name: str, data_type: Union[str, None], status: str, optional: bool = False,
                 repeatable: bool = False, link_to_attribute: str = None, minimum_inputs: int = None,
                 description: str = "", default_value=None, possible_values=None, minimum_outputs: int = None,
                 properties: List['BluePrintProperties'] = None, class_name=None):
        """

        :param name: Name of the property
        :param data_type: Datatype of the property see
        :param status:
        :param optional:
        :param repeatable:
        :param description:
        :param default_value:
        :param possible_values:
        :param link_to_attribute:
        :param minimum_inputs:
        :param minimum_outputs:
        :param properties: List of BlueprintProperties
        :param class_name:
        """
        self.link_to_attribute = link_to_attribute
        self.name = name
        self.status = status
        self.description = description
        self.repeatable = repeatable
        self.optional = optional
        self.minimum_inputs = minimum_inputs
        self.minimum_outputs = minimum_outputs
        self.data_type = data_type
        self.default_value = default_value
        self.properties = properties if properties is None else [i.json() for i in properties]
        self.possible_values = possible_values
        self.class_name = class_name

        self.validate()

    def validate(self):
        import rztdl.utils.string_constants as constants
        if self.data_type == constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX:
            if self.properties is None or not self.properties:
                raise KeyError(
                    "Properties missing:  Complex type Property {} requires a list of properties".format(self.name))
        elif self.data_type == constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST:
            if self.class_name is None:
                raise KeyError(
                    "Properties missing:  List type Property {} requires a class_name_property".format(self.name))
            if self.possible_values is None:
                raise KeyError(
                    "Properties missing:  List type Property {} requires a possible_values_property".format(self.name))
        else:
            if self.possible_values is not None or self.class_name is not None:
                raise KeyError(
                    "Property {} is not of data type LIST but has values for possible_value and class_name".format(
                        self.name))
            elif self.properties is not None:
                raise KeyError(
                    "Property {} is not of data type Complex but has values for properties".format(
                        self.name))

    def json(self):
        import rztdl.utils.string_constants as constants
        json = self.__dict__
        if self.data_type != constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX:
            json.pop("properties", None)
        if self.data_type != constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST:
            json.pop("possible_values", None)
            json.pop("class_name", None)
        if "link_to_attribute" in self.__dict__ and not self.link_to_attribute:
            json.pop("link_to_attribute", None)
        if "minimum_inputs" in self.__dict__ and not self.minimum_inputs:
            json.pop("minimum_inputs", None)
        if "minimum_outputs" in self.__dict__ and not self.minimum_outputs:
            json.pop("minimum_outputs", None)
        return json


class Blueprint(object):
    @typechecked
    def __init__(self, cls: type, version: str = "0.0.1", status: str = "ACTIVE"):
        from rztdl.dl.components.component import Component
        self.version = version
        self.class_name = cls.__module__ + "." + cls.__qualname__ if Component in cls.mro() else cls.__module__
        self.status = status
        self.type = cls.__bases__[0].__name__
        self.description = ""
        self.name = cls.__name__
        self.component_id = hashlib.md5('_'.join([self.name, self.version]).encode('utf-8')).hexdigest()
        self.inputs = []
        self.outputs = []
        self.parameters = []

    @typechecked
    def add_parameter(self, name: str, data_type: Union[str, None], status: str, minimum_inputs: int = None,
                      minimum_outputs: int = None, optional: bool = True, repeatable: bool = False,
                      link_to_attribute: str = None, description: str = "",
                      properties: List[BluePrintProperties] = None, default_value=None, class_name=None,
                      possible_values=None):
        self.parameters.append(
            BluePrintProperties(name=name, data_type=data_type, status=status, optional=optional, repeatable=repeatable,
                                description=description, properties=properties, possible_values=possible_values,
                                link_to_attribute=link_to_attribute, default_value=default_value,
                                minimum_inputs=minimum_inputs, minimum_outputs=minimum_outputs,
                                class_name=class_name).json())

    @typechecked
    def add_inputs(self, name: str, data_type: Union[str, None], status: str, minimum_inputs: int = None,
                   optional: bool = True, repeatable: bool = False, link_to_attribute: str = None,
                   description: str = "", properties: List[BluePrintProperties] = None, default_value=None,
                   class_name=None, minimum_outputs: int = None, ):
        self.inputs.append(
            BluePrintProperties(name=name, data_type=data_type, status=status, optional=optional, repeatable=repeatable,
                                description=description, properties=properties, default_value=default_value,
                                minimum_inputs=minimum_inputs, minimum_outputs=minimum_outputs,
                                link_to_attribute=link_to_attribute, class_name=class_name).json())

    @typechecked
    def add_outputs(self, name: str, data_type: Union[str, None], status: str, minimum_inputs: int = None,
                    optional: bool = True, repeatable: bool = False, link_to_attribute: str = None,
                    description: str = "", properties: List[BluePrintProperties] = None, default_value=None,
                    class_name=None, minimum_outputs: int = None, ):
        self.outputs.append(
            BluePrintProperties(name=name, data_type=data_type, status=status, optional=optional, repeatable=repeatable,
                                description=description, properties=properties, default_value=default_value,
                                minimum_inputs=minimum_inputs, minimum_outputs=minimum_outputs,
                                link_to_attribute=link_to_attribute, class_name=class_name).json())

    def to_json(self):
        return self.__dict__
