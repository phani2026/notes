# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
|
| **Sphinx Documentation Status:**
|
.. todo::
    Prathyush SP: Convert keys to string constants
"""
# todo: Prathyush SP -  Convert keys to string constants
# todo: Prathyush SP -  Implement Log Handlers


import os
from rztdl.logging_config_manager import setup_logging

# todo: Prathyush SP: Move logging config to logging manager

RZTDL_MODULE_PATH = os.path.dirname(os.path.abspath(__file__))
setup_logging(default_path=os.path.join(RZTDL_MODULE_PATH, 'config', 'rztdl_logging.yaml'))

import logging
import traceback

logger = logging.getLogger(__name__)
try:
    import tensorflow as tf
    from tensorflow.python.client import device_lib
    from rztdl.utils.pyutils import run_system_command

    if run_system_command('nvidia-smi')[1] == 0:
        import pip

        if len([str(i) for i in pip.get_installed_distributions() if 'tensorflow-gpu' in str(i)]) == 0:
            logger.warning('Found GPU device. But Tensorflow GPU version is not found!! GPU\'s will not be used')
except ImportError:
    logger.error('Unable to import tensorflow. Please install tensorflow depending on cpu / gpu')
except Exception:
    logger.error('Exception Traceback:\n{}'.format(traceback.format_exc()))

# todo: Prathyush SP - Debug code breakages due to changing start method
# import multiprocessing
# multiprocessing.context._force_start_method('spawn')

from rztdl.store import RZTDL_STORE
from rztdl.dag import RZTDL_DAG
from rztdl.config_manager import RZTDL_CONFIG, RZTDL_CONFIG_DATA
from rztdl.metadata import metadata as md

__version__ = md.__version__

if __name__ == '__main__':
    print('rztdl.__init__ success . . .')
