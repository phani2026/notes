# -*- coding: utf-8 -*-
"""
| **@created on:** 11/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

# Dummy file for cython to copy configs
