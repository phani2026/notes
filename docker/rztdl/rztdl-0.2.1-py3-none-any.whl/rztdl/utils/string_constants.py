# -*- coding: utf-8 -*-
"""
| **@created on:** 20/05/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Library Constants
|
| Sphinx Documentation Status:** Complete
|
..todo::
"""

import enum
from munch import Munch
from typeguard import typechecked
from typing import Union

from rztdl.blueprint import Blueprint, BluePrintProperties


class DatasetIntervalType(enum.Enum):
    """
    |
    |**@author**: Prathyush SP
    |
    | Dataset Interval Types
    |**DO NOT MODIFY**
    |
    """
    EPOCH = enum.auto()
    BATCH = enum.auto()
    # todo: Prathyush SP - Enable time based dataset interval


class DatasetMetricIntervalType(enum.Enum):
    """
    |
    |**@author**: Prathyush SP
    |
    | Dataset Metric Interval Types
    |**DO NOT MODIFY**
    |
    """
    EPOCH = enum.auto()
    BATCH = enum.auto()
    # todo: Prathyush SP - Enable time based dataset interval


class DatasetType(enum.Enum):
    """
    |
    |**@author**: Prathyush SP
    |
    | Dataset Types
    |**DO NOT MODIFY**
    |
    """
    NUMPY = enum.auto()


class DatasetTemplate(Munch):
    class _Parameters(enum.Enum):
        TRAIN_TEMPLATE = enum.auto()
        VALID_TEMPLATE = enum.auto()
        TEST_TEMPLATE = enum.auto()
        DATASET_TEMPLATE = enum.auto()
        INTERVAL_TYPE = enum.auto()
        INTERVAL = enum.auto()

    @classmethod
    def train(cls):
        dt_obj = DatasetTemplate()
        dt_obj[cls._Parameters.DATASET_TEMPLATE] = cls._Parameters.TRAIN_TEMPLATE
        return dt_obj

    @classmethod
    def valid(cls, interval: int = 1, interval_type: DatasetIntervalType = DatasetIntervalType.EPOCH):
        dt_obj = DatasetTemplate()
        dt_obj[cls._Parameters.DATASET_TEMPLATE] = cls._Parameters.VALID_TEMPLATE
        dt_obj[cls._Parameters.INTERVAL_TYPE] = interval_type
        dt_obj[cls._Parameters.INTERVAL] = interval
        return dt_obj

    @classmethod
    def test(cls):
        dt_obj = DatasetTemplate()
        dt_obj[cls._Parameters.DATASET_TEMPLATE] = cls._Parameters.TEST_TEMPLATE
        return dt_obj


class ComponentType(enum.Enum):
    """
    |
    |**@author**: Prathyush SP
    |
    | Component Types
    |**DO NOT MODIFY**
    |
    """
    LAYER = enum.auto()
    OPERATOR = enum.auto()
    COST = enum.auto()
    OPTIMIZER = enum.auto()
    BUFFER = enum.auto()
    METRIC = enum.auto()


class FlowType(enum.Enum):
    """
    |
    |**@author**: Prathyush SP
    |
    | Flow Types
    |**DO NOT MODIFY**
    |
    """
    TRAIN = enum.auto()
    INFER = enum.auto()


class BufferType(enum.Enum):
    """
   | *@author*: Prathyush SP
   |
   | Buffer Types
   **DO NOT MODIFY**
   """
    IN_BUFFER = enum.auto()


class MorphType(enum.Enum):
    """
    |
    |**@author**: Prathyush SP
    |
    | Morph Types
    |**DO NOT MODIFY**
    |
    """
    ONES_LIKE = enum.auto()
    ZEROS_LIKE = enum.auto()
    RANDOMIZE = enum.auto()

    __meta2__ = None

    @classmethod
    def blueprint(cls):
        if cls.__meta2__ is not None:
            return cls.__meta2__

        bp = Blueprint(cls, version="0.0.1", status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "ONES_LIKE",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "ZEROS_LIKE",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "RANDOMIZE",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        cls.__meta2__ = bp
        return cls.__meta2__


class STATUS:
    """
    @author: Umesh Kumar
    Status Class
    **DO NOT MODIFY**
    """
    ACTIVE = "ACTIVE"
    DEPRECATED = "DEPRECATED"


class BLUEPRINT_PARAMETERS:
    """
    @author: Umesh Kumar
    BLUEPRINT_PARAMETERS Class
    **DO NOT MODIFY**
    """

    DataType = "data_type"

    class DataTypeOptions:
        INTEGER = "Integer"
        FLOAT = "Float"
        BOOLEAN = "Boolean"
        STRING = "String"
        COMPLEX = "Complex"
        LIST = "List"
        ARRAYOFINT = "ArrayofINT"
        ARRAYOFSTRING = "ArrayofString"
        ENUM = "Enum"
        NONE = None


class PARAMETERS:
    UNIFORM = 'uniform'
    GAIN = 'gain'
    DTYPE = 'dtype'
    COST = 'cost'
    COST_TYPE = 'cost_type'
    POS_WEIGHT = 'pos_weight'
    EPOCH = 'epoch'
    OPTIMIZER = 'optimizer'
    LEARNING_RATE = 'learning_rate'
    LAYER_NAME = 'layer_name'
    LAYER_NODES = 'layer_nodes'
    LAYER_ACTIVATION = 'layer_activation'
    LAYER_TYPE = 'layer_type'
    LAYER_WEIGHTS = 'layer_weights'
    LAYER_BIAS = 'layer_bias'
    TEST = 'test'
    PARAMETERS = 'parameters'
    SOURCE = 'source'
    TARGET = 'target'
    TRAINING_MODE = 'training_mode'
    BATCH_SIZE = 'batch_size'
    INPUT_STRUCTURE = 'input_structure'
    LAYERS = 'layers'
    FILTER_DIMENSIONS = 'filter_dimensions'
    FILTER_STRIDES = 'filter_strides'
    FILTER_PADDNING = 'filter_padding'
    LAYER_FILTER = 'layer_filter'
    POOL_DIMENSIONS = 'pool_dimensions'
    POOL_STRIDES = 'pool_strides'
    POOL_PADDING = 'pool_padding'
    POOL_TYPE = 'pool_type'
    INITIALIZER_TYPE = 'initializer_type'
    MIN_VAL = 'min_val'
    MAX_VAL = 'max_val'
    STD_DEV = 'std_dev'
    MEAN = 'mean'
    SEED = 'seed'
    NORM_DIM = 'dim'
    NORM_EPSILON = 'epsilon'
    DEPTH_RADIUS = 'depth_radius'
    NORM_BIAS = 'bias'
    NORM_ALPHA = 'alpha'
    NORM_BETA = 'beta'
    THRESHOLD = 'threshold'
    ACCURACY_TYPE = 'accuracy_type'
    REGULARISATION_TYPE = 'regularisation_type'
    REGULARISATION_BETA = 'regularisation_beta'
    REGULARISATION_WEIGHTS = 'regularisation_weights'
    NUM_UNITS = 'num_units'
    FORGET_BIAS = 'forget_bias'
    USE_PEEPHOLES = 'use_peepholes'
    CELL_CLIP = 'cell_clip'
    NUM_PROJ = 'num_proj'
    PROJ_CLIP = 'proj_clip'
    NUM_UNIT_SHARDS = 'num_unit_shards'
    NUM_PROJ_SHARDS = 'num_proj_shards'
    ACTIVATION = 'activation'
    KERNEL_INITIALIZER = 'kernel_initializer'
    BIAS_INITIALIZER = 'bias_initializer'
    REUSE = 'reuse'
    INITIALIZER = 'initializer'
    CONSTANT = 'constant'
    START_INDEX = "start_index"
    END_INDEX = "end_index"
    INPUT_NAME = "input_name"
    MORPHER_TYPE = 'morpher'
    NORM_TYPE = 'norm_type'


class MODEL_ARCHITECTURE:
    BIAS_SHAPE = 'bias_shape'
    KEEP_DIMENSION = 'keep_dimension'
    REDUCE_OPERATOR_DIMENSION = 'reduce_operator_dimension'
    UNSTACK_DIMENSION = 'unstack_dimension'
    UNSTACK_SIZE = 'unstack_size'
    SLICE_BEGIN = 'slice_begin'
    SLICE_SIZE = 'slice_size'
    OPERATOR_SHAPE = 'operator_shape'
    SPLIT_DIMENSION = 'split_dimension'
    SPLIT_SIZE = 'split_size'
    OPERATOR_OUTPUT = 'operator_output'
    CONCAT_DIMENSION = 'concat_dimension'
    OPERATOR_INPUT = 'operator_input'
    OPERATOR_TYPE = 'operator_type'
    LAYER_TYPE = 'layer_type'
    LAYER_WEIGHTS = 'layer_weights'
    LAYER_BIAS = 'layer_bias'
    LAYER_ACTIVATION = 'layer_activation'
    LAYER_DROPOUT = 'layer_dropout'
    LAYER_NORMALIZATION = 'layer_normalization'
    LAYER_OUTPUT = 'layer_output'
    LAYER_FILTER = 'layer_filter'
    LAYER_DIMENSIONS = 'layer_dimensions'
    LAYER_STRIDES = 'layer_strides'
    LAYER_CELLS = 'layer_cells'
    COST_TYPE = 'cost_type'
    COST_OUTPUT = 'cost_output'
    MORPH_TYPE = 'morph_type'


class ExceptionMode:
    CRITICAL = 'critical'
    ERROR = 'error'


class PaddingType(enum.Enum):
    """
    | **@author:** Prathyush SP
    |
    | Padding Class
    | **DO NOT MODIFY**
    """

    SAME = enum.auto()
    VALID = enum.auto()
    __meta2__ = None

    @classmethod
    def blueprint(cls):
        if cls.__meta2__ is not None:
            return cls.__meta2__

        bp = Blueprint(cls, version="0.0.1", status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "SAME",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "VALID",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        cls.__meta2__ = bp
        return cls.__meta2__


class PoolType(enum.Enum):
    """
    |
    |**@author**: Prathyush SP
    |
    | Pool Class
    |**DO NOT MODIFY**
    |
    """
    MAX_POOL = enum.auto()
    AVG_POOL = enum.auto()
    MAX_POOL_3D = enum.auto()
    AVG_POOL_3D = enum.auto()

    __meta2__ = None

    @classmethod
    def blueprint(cls):
        if cls.__meta2__ is not None:
            return cls.__meta2__

        bp = Blueprint(cls, version="0.0.1", status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "MAX_POOL",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "AVG_POOL",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "MAX_POOL_3D",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "AVG_POOL_3D",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        cls.__meta2__ = bp
        return cls.__meta2__


class OptimizerTypes(enum.Enum):
    """
    @author: Prathyush SP
    Optimizer Types
    ** DO NOT MODIFY**
    """
    ADAM = enum.auto()
    MOMENTUM = enum.auto()
    GRADIENT_DESCENT = enum.auto()
    ADA_GRADIENT = enum.auto()
    FTRL = enum.auto()
    PROXIMAL_ADAGRAD = enum.auto()
    PROXIMAL_GRADIENT_DESCENT = enum.auto()
    ADA_DELTA = enum.auto()


class ActivationType(enum.Enum):
    """
    @author: Prathyush SP
    Activation Class
    **DO NOT MODIFY**
    """

    SIGMOID = enum.auto()
    TANH = enum.auto()
    RELU = enum.auto()
    RELU6 = enum.auto()
    CRELU = enum.auto()
    ELU = enum.auto()
    SOFTMAX = enum.auto()
    SOFT_PLUS = enum.auto()
    SOFT_SIGN = enum.auto()
    IDENTITY = enum.auto()
    NONE = enum.auto()

    __meta2__ = None

    @classmethod
    def blueprint(cls):
        if cls.__meta2__ is not None:
            return cls.__meta2__

        bp = Blueprint(cls, version="0.0.1", status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "SIGMOID",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "TANH",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "RELU",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "RELU6",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "CRELU",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "ELU",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "SOFTMAX",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "SOFT_PLUS",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "SOFT_SIGN",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "IDENTITY",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "NONE",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        cls.__meta2__ = bp
        return cls.__meta2__


class MetricType(enum.Enum):
    """
    | *@author*: Prathyush SP
    |
    | Metric Type Class
    **DO NOT MODIFY**
    """
    GINI_METRIC = enum.auto()


class CostType(enum.Enum):
    """
    | *@author*: Prathyush SP
    |
    | Cost Class
    **DO NOT MODIFY**
    """
    MEAN_SQUARE_ERROR = enum.auto()
    # todo Prathyush SP - Cross entropy deprecated in favour of SigmoidCrossEntropy and SoftmaxCrossEntropy
    # CROSS_ENTROPY = enum.auto()
    SIMPLE_CROSS_ENTROPY = enum.auto()
    SOFTMAX_CROSS_ENTROPY = enum.auto()
    SIGMOID_CROSS_ENTROPY = enum.auto()
    WEIGHTED_CROSS_ENTOPY = enum.auto()
    CUSTOM_COST = enum.auto()

    # todo Prathyush SP - weighted entropy deprecated here in favour of Cost construct
    # @staticmethod
    # def weighted_cross_entropy(pos_weight: float):
    #     return {PARAMETERS.POS_WEIGHT: pos_weight, PARAMETERS.COST_TYPE: CostType._WEIGHTED_CROSS_ENTOPY}


class REGULARISATION:
    """
    | *@author*: Umesh Kumar
    |
    | Regularisation Class
    **DO NOT MODIFY**
    """
    L2_REGULARISATION = "l2_regularisation"
    L1_REGULARISATION = "l1_regularisation"

    @staticmethod
    def regularisation(regularisation_type: str = L2_REGULARISATION, regularisation_weights: list = None,
                       beta: float = 0.01) -> dict:
        return {PARAMETERS.REGULARISATION_WEIGHTS: regularisation_weights, PARAMETERS.REGULARISATION_BETA: beta,
                PARAMETERS.REGULARISATION_TYPE: regularisation_type}


class ACCURACY:
    """
    | *@author*: Prathyush SP
    |
    | Cost Class
    **DO NOT MODIFY**
    """

    SIMPLE = "simple"
    BINARY = 'binary'
    SOFTMAX = 'softmax'
    REGRESSION = 'regression'

    @staticmethod
    def regression(threshold: int = 5):
        return {PARAMETERS.THRESHOLD: threshold, PARAMETERS.ACCURACY_TYPE: ACCURACY.REGRESSION}


class ModelHandler(Munch):
    class _Parameters(enum.Enum):
        IntervalType = enum.auto()
        Interval = enum.auto()
        MaxCheckpointsToKeep = enum.auto()
        Name = enum.auto()
        ModelName = enum.auto()
        ModelRunnerName = enum.auto()
        FlowName = enum.auto()
        CheckpointStep = enum.auto()
        RunId = enum.auto()
        SavePath = enum.auto()

    @staticmethod
    def save_model(save_path: str = None, max_checkpoints_to_keep: int = 5,
                   interval_type: DatasetIntervalType = DatasetIntervalType.EPOCH,
                   interval: int = 1) -> 'ModelHandler':
        model_h = ModelHandler()
        model_h[ModelHandler._Parameters.IntervalType] = interval_type
        model_h[ModelHandler._Parameters.Interval] = interval
        model_h[ModelHandler._Parameters.SavePath] = save_path
        model_h[ModelHandler._Parameters.MaxCheckpointsToKeep] = max_checkpoints_to_keep
        return model_h

    @staticmethod
    def load_model(model_name: str = None, model_runner_name: str = None, flow_name: str = None,
                   checkpoint_step: int = -1, run_id: int = -1, save_path: str = None) -> 'ModelHandler':
        model_h = ModelHandler()
        model_h[ModelHandler._Parameters.ModelName] = model_name
        model_h[ModelHandler._Parameters.ModelRunnerName] = model_runner_name
        model_h[ModelHandler._Parameters.FlowName] = flow_name
        model_h[ModelHandler._Parameters.CheckpointStep] = checkpoint_step
        model_h[ModelHandler._Parameters.RunId] = run_id
        model_h[ModelHandler._Parameters.SavePath] = save_path
        return model_h


class DisplayHandler(Munch):
    class _Parameters(enum.Enum):
        INTERVAL_TYPE = enum.auto()
        INTERVAL = enum.auto()

    @staticmethod
    def display_config(interval_type: DatasetIntervalType = DatasetIntervalType.EPOCH,
                       interval: int = 1) -> 'DisplayHandler':
        disp_h = DisplayHandler()
        disp_h[DisplayHandler._Parameters.INTERVAL_TYPE.name] = interval_type.name
        disp_h[DisplayHandler._Parameters.INTERVAL.name] = interval
        return disp_h


class NormalizationType(Munch):
    """
    | *@author*: Umesh Kumar
    |
    | Normalization Type
    **DO NOT MODIFY**
    """

    class _Parameters(enum.Enum):
        """
        | *@author*: Umesh Kumar
        |
        | Parameter Class
        """
        L2_NORM = enum.auto()
        LRN_NORM = enum.auto()
        NORM_TYPE = enum.auto()
        DIM = enum.auto()
        EPSILON = enum.auto()
        DEPTH_RADIUS = enum.auto()
        BIAS = enum.auto()
        ALPHA = enum.auto()
        BETA = enum.auto()

    __meta2__ = None

    @classmethod
    @typechecked
    def blueprint(cls: 'NormalizationType.__class__'):
        if cls.__meta2__ is not None:
            return cls.__meta2__
        bp = Blueprint(cls, version="0.0.1", status=STATUS.ACTIVE)

        p1 = BluePrintProperties(name=cls._Parameters.DIM.name.lower(),
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=STATUS.ACTIVE, default_value=0)
        p2 = BluePrintProperties(name=cls._Parameters.EPSILON.name.lower(),
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                                 status=STATUS.ACTIVE, default_value=1e-12)
        bp.add_parameter(name=cls.__name__ + "." + "l2_norm",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                         properties=[p1, p2], status=STATUS.ACTIVE)

        p1 = BluePrintProperties(name=cls._Parameters.BIAS.name.lower(),
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                                 status=STATUS.ACTIVE, default_value=1)
        p2 = BluePrintProperties(name=cls._Parameters.DEPTH_RADIUS.name.lower(),
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=STATUS.ACTIVE, default_value=5)
        p3 = BluePrintProperties(name=cls._Parameters.BETA.name.lower(),
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                                 status=STATUS.ACTIVE, default_value=0.5)
        p4 = BluePrintProperties(name=cls._Parameters.ALPHA.name.lower(),
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                                 status=STATUS.ACTIVE, default_value=1)
        bp.add_parameter(name=cls.__name__ + "." + "lrn_norm",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                         properties=[p1, p2, p3, p4], status=STATUS.ACTIVE)

        cls.__meta2__ = bp
        return cls.__meta2__

    @staticmethod
    def l2_norm(dim: int = 0, epsilon: float = 1e-12) -> 'NormalizationType':
        """
        | *@author*: Umesh Kumar
        |
        | L2 Normalization
        :param dim: Dimension
        :param epsilon: Epsilon Value
        :return: Normalization Object
        """
        norm_obj = NormalizationType()
        norm_obj[NormalizationType._Parameters.NORM_TYPE.name] = NormalizationType._Parameters.L2_NORM
        norm_obj[NormalizationType._Parameters.DIM.name] = dim
        norm_obj[NormalizationType._Parameters.EPSILON.name] = epsilon
        return norm_obj

    @staticmethod
    def lrn_norm(depth_radius: int = 5, bias: float = 1, alpha: float = 1,
                 beta: float = 0.5) -> 'NormalizationType':
        """
        | *@author*: Umesh Kumar
        |
        | LRN Normalization
        :param depth_radius: Depth Radius
        :param bias: Bias
        :param alpha: Aplha
        :param beta: Beta
        :return: Normalization Object
        """
        norm_obj = NormalizationType()
        norm_obj[NormalizationType._Parameters.NORM_TYPE.name] = NormalizationType._Parameters.LRN_NORM
        norm_obj[NormalizationType._Parameters.DEPTH_RADIUS.name] = depth_radius
        norm_obj[NormalizationType._Parameters.BIAS.name] = bias
        norm_obj[NormalizationType._Parameters.ALPHA.name] = alpha
        norm_obj[NormalizationType._Parameters.BETA.name] = beta
        return norm_obj


class InitializerType(Munch):
    """
    | *@author*: Prathyush SP
    |
    | Initializer Types
    |
    | todo: Umesh - Refactor InitializerType class. Follow NormalizationType Class for more details
    """

    class _Parameters(enum.Enum):
        RANDOM_UNIFORM = enum.auto()
        RANDOM_NORMAL = enum.auto()
        ZEROS = enum.auto()
        ONES = enum.auto()
        CONSTANT = enum.auto()
        ORTHOGONAL = enum.auto()
        XAVIER = enum.auto()
        TRUNCATED_NORMAL = enum.auto()
        MIN_VAL = enum.auto()
        MAX_VAL = enum.auto()
        SEED = enum.auto()
        MEAN = enum.auto()
        STD_DEV = enum.auto()
        UNIFORM = enum.auto()
        GAIN = enum.auto()
        INITIALIZER_TYPE = enum.auto()
        DTYPE = enum.auto()

    __meta2__ = None

    @classmethod
    @typechecked
    def blueprint(cls: 'InitializerType.__class__'):
        if cls.__meta2__ is not None:
            return cls.__meta2__

        bp = Blueprint(cls, version="0.0.1", status=STATUS.ACTIVE)
        p1 = BluePrintProperties(name=cls._Parameters.MIN_VAL.name.lower(),
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                                 status=STATUS.ACTIVE, default_value=0.0)
        p2 = BluePrintProperties(name=cls._Parameters.MAX_VAL.name.lower(),
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                                 status=STATUS.ACTIVE, default_value=1.0)
        p3 = BluePrintProperties(name=cls._Parameters.SEED.name.lower(),
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "random_uniform",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                         properties=[p1, p2, p3], status=STATUS.ACTIVE)

        p1 = BluePrintProperties(name=cls._Parameters.STD_DEV.name.lower(), default_value=0.0,
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                                 status=STATUS.ACTIVE)
        p2 = BluePrintProperties(name=cls._Parameters.MEAN.name.lower(), default_value=1.0,
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                                 status=STATUS.ACTIVE)
        p3 = BluePrintProperties(name=cls._Parameters.SEED.name.lower(),
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "random_normal",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                         properties=[p1, p2, p3], status=STATUS.ACTIVE)

        p1 = BluePrintProperties(name=cls._Parameters.CONSTANT.name.lower(), default_value=1.0,
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                                 status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "constant",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                         properties=[p1], status=STATUS.ACTIVE)

        p1 = BluePrintProperties(name=cls._Parameters.UNIFORM.name.lower(), default_value=True,
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                                 status=STATUS.ACTIVE)
        p2 = BluePrintProperties(name=cls._Parameters.SEED.name.lower(),
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "xavier",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                         properties=[p1, p2], status=STATUS.ACTIVE)

        p1 = BluePrintProperties(name=cls._Parameters.STD_DEV.name.lower(), default_value=0.0,
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                                 status=STATUS.ACTIVE)
        p2 = BluePrintProperties(name=cls._Parameters.MEAN.name.lower(), default_value=1.0,
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                                 status=STATUS.ACTIVE)
        p3 = BluePrintProperties(name=cls._Parameters.SEED.name.lower(),
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "truncated_normal",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                         properties=[p1, p2, p3], status=STATUS.ACTIVE)

        p1 = BluePrintProperties(name=cls._Parameters.GAIN.name.lower(), default_value=1.0,
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                                 status=STATUS.ACTIVE)
        p2 = BluePrintProperties(name=cls._Parameters.SEED.name.lower(),
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "orthogonal",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                         properties=[p1, p2], status=STATUS.ACTIVE)

        bp.add_parameter(name=cls.__name__ + "." + "zeros",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)

        bp.add_parameter(name=cls.__name__ + "." + "ones",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.NONE, status=STATUS.ACTIVE)
        cls.__meta2__ = bp
        return cls.__meta2__

    @staticmethod
    def random_uniform(min_val=0.0, max_val=1.0, seed=None, dtype=None):
        return {InitializerType._Parameters.INITIALIZER_TYPE.name: InitializerType._Parameters.RANDOM_UNIFORM.name,
                InitializerType._Parameters.MIN_VAL.name: min_val,
                InitializerType._Parameters.MAX_VAL.name: max_val, InitializerType._Parameters.SEED.name: seed,
                InitializerType._Parameters.DTYPE.name: dtype}

    @staticmethod
    def random_normal(std_dev=0.0, mean=1.0, seed=None, dtype=None):
        return {InitializerType._Parameters.INITIALIZER_TYPE.name: InitializerType._Parameters.RANDOM_NORMAL.name,
                InitializerType._Parameters.STD_DEV.name: std_dev,
                InitializerType._Parameters.MEAN.name: mean, InitializerType._Parameters.SEED.name: seed,
                InitializerType._Parameters.DTYPE.name: dtype}

    @staticmethod
    def zeros(dtype=None):
        return {InitializerType._Parameters.INITIALIZER_TYPE.name: InitializerType._Parameters.ZEROS.name,
                InitializerType._Parameters.DTYPE.name: dtype,
                InitializerType._Parameters.SEED.name: None}

    @staticmethod
    def ones(dtype=None):
        return {InitializerType._Parameters.INITIALIZER_TYPE.name: InitializerType._Parameters.ONES.name,
                InitializerType._Parameters.DTYPE.name: dtype,
                InitializerType._Parameters.SEED.name: None}

    @staticmethod
    def constant(constant: float = 1.0, dtype=None):
        return {InitializerType._Parameters.INITIALIZER_TYPE.name: InitializerType._Parameters.CONSTANT.name,
                InitializerType._Parameters.CONSTANT.name: constant,
                InitializerType._Parameters.DTYPE.name: dtype}

    @staticmethod
    def orthogonal(gain: float = 1.0, seed=None, dtype=None):
        return {InitializerType._Parameters.INITIALIZER_TYPE.name: InitializerType._Parameters.ORTHOGONAL.name,
                InitializerType._Parameters.GAIN.name: gain,
                InitializerType._Parameters.SEED.name: seed,
                InitializerType._Parameters.DTYPE.name: dtype}

    @staticmethod
    def xavier(uniform: bool = True, seed=None, dtype=None):
        return {InitializerType._Parameters.INITIALIZER_TYPE.name: InitializerType._Parameters.XAVIER.name,
                InitializerType._Parameters.UNIFORM.name: uniform,
                InitializerType._Parameters.SEED.name: seed,
                InitializerType._Parameters.DTYPE.name: dtype}

    @staticmethod
    def truncated_normal(std_dev=0.0, mean=1.0, seed=None, dtype=None):
        return {InitializerType._Parameters.INITIALIZER_TYPE.name: InitializerType._Parameters.TRUNCATED_NORMAL.name,
                InitializerType._Parameters.STD_DEV.name: std_dev,
                InitializerType._Parameters.MEAN.name: mean, InitializerType._Parameters.SEED.name: seed,
                InitializerType._Parameters.DTYPE.name: dtype}


class RNNCell(Munch):
    class _Parameters(enum.Enum):
        CELL = enum.auto()
        BASIC_LSTM_CELL = enum.auto()
        LSTMCELL = enum.auto()
        BASIC_RNN_CELL = enum.auto()
        GRUCELL = enum.auto()
        NUM_PROJ = enum.auto()
        PROJ_CLIP = enum.auto()
        NUM_PROJ_SHARDS = enum.auto()
        NUM_UNIT_SHARDS = enum.auto()
        NUM_UNITS = enum.auto()
        KERNEL_INITIALIZER = enum.auto()
        CELL_CLIP = enum.auto()
        FORGET_BIAS = enum.auto()
        BIAS_INITIALIZER = enum.auto()
        USE_PEEPHOLES = enum.auto()
        INITIALIZER = enum.auto()
        ACTIVATION = enum.auto

    __meta2__ = None

    # noinspection PyProtectedMember
    @classmethod
    def blueprint(cls):
        if cls.__meta2__ is not None:
            return cls.__meta2__
        bp = Blueprint(cls, version="0.0.1", status=STATUS.ACTIVE)
        p1 = BluePrintProperties(name="num_units",
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=STATUS.ACTIVE)
        p2 = BluePrintProperties(name="cell_clip",
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                                 status=STATUS.ACTIVE)
        p3 = BluePrintProperties(name="num_proj",
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=STATUS.ACTIVE)
        p4 = BluePrintProperties(name="proj_clip",
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                                 status=STATUS.ACTIVE)
        p5 = BluePrintProperties(name="num_unit_shards",
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=STATUS.ACTIVE)
        p6 = BluePrintProperties(name="num_proj_shards",
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=STATUS.ACTIVE)
        p7 = BluePrintProperties(name="activation",
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                                 default_value=ActivationType.RELU.name,
                                 status=ActivationType.blueprint().status,
                                 possible_values=ActivationType.blueprint().parameters,
                                 class_name=ActivationType.blueprint().class_name)

        p8 = BluePrintProperties(name="forget_bias", default_value=1.0,
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                                 status=STATUS.ACTIVE)
        p9 = BluePrintProperties(name="use_peepholes", default_value=False,
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                                 status=STATUS.ACTIVE)
        p10 = BluePrintProperties(name="initializer",
                                  data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                                  default_value=InitializerType._Parameters.RANDOM_NORMAL.name,
                                  status=InitializerType.blueprint().status,
                                  possible_values=InitializerType.blueprint().parameters,
                                  class_name=InitializerType.blueprint().class_name)
        bp.add_parameter(name=cls.__name__ + "." + "lstm_cell",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                         properties=[p1, p2, p3, p4, p5, p6, p7, p8, p9, p10], status=STATUS.ACTIVE)

        p1 = BluePrintProperties(name="activation",
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                                 default_value=ActivationType.RELU.name,
                                 status=ActivationType.blueprint().status,
                                 possible_values=ActivationType.blueprint().parameters,
                                 class_name=ActivationType.blueprint().class_name)
        p2 = BluePrintProperties(name="num_units",
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=STATUS.ACTIVE)

        bp.add_parameter(name=cls.__name__ + "." + "gru_cell",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                         properties=[p1, p2], status=STATUS.ACTIVE)

        p1 = BluePrintProperties(name="activation",
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                                 default_value=ActivationType.RELU.name,
                                 status=ActivationType.blueprint().status,
                                 possible_values=ActivationType.blueprint().parameters,
                                 class_name=ActivationType.blueprint().class_name)
        p2 = BluePrintProperties(name="num_units",
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=STATUS.ACTIVE)
        p3 = BluePrintProperties(name="forget_bias", default_value=1.0,
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                                 status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "basic_lstm_cell",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                         properties=[p1, p2, p3], status=STATUS.ACTIVE)

        p1 = BluePrintProperties(name="activation",
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                                 default_value=ActivationType.RELU.name,
                                 status=ActivationType.blueprint().status,
                                 possible_values=ActivationType.blueprint().parameters,
                                 class_name=ActivationType.blueprint().class_name)
        p2 = BluePrintProperties(name="num_units",
                                 data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=STATUS.ACTIVE)
        bp.add_parameter(name=cls.__name__ + "." + "basic_rnn_cell",
                         data_type=BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                         properties=[p1, p2], status=STATUS.ACTIVE)
        cls.__meta2__ = bp
        return cls.__meta2__

    @staticmethod
    def lstm_cell(num_units: int, cell_clip: float = None, num_proj: int = None, proj_clip: float = None,
                  num_unit_shards: int = None, num_proj_shards: int = None,
                  activation: ActivationType = ActivationType.TANH,
                  forget_bias: float = 1.0, use_peepholes: bool = False, initializer: object = None) -> dict:
        return {RNNCell._Parameters.CELL.name: RNNCell._Parameters.LSTMCELL.name,
                RNNCell._Parameters.NUM_UNITS.name: num_units, RNNCell._Parameters.CELL_CLIP.name: cell_clip,
                RNNCell._Parameters.NUM_PROJ.name: num_proj, RNNCell._Parameters.PROJ_CLIP.name: proj_clip,
                RNNCell._Parameters.NUM_UNIT_SHARDS.name: num_unit_shards,
                RNNCell._Parameters.NUM_PROJ_SHARDS.name: num_proj_shards,
                RNNCell._Parameters.ACTIVATION.name: activation, RNNCell._Parameters.FORGET_BIAS.name: forget_bias,
                RNNCell._Parameters.USE_PEEPHOLES.name: use_peepholes,
                RNNCell._Parameters.INITIALIZER.name: initializer}

    @staticmethod
    def gru_cell(num_units: int,
                 activation: ActivationType = ActivationType.TANH) -> dict:
        return {RNNCell._Parameters.CELL.name: RNNCell._Parameters.GRUCELL.name,
                RNNCell._Parameters.NUM_UNITS.name: num_units,
                RNNCell._Parameters.KERNEL_INITIALIZER.name: None,
                RNNCell._Parameters.BIAS_INITIALIZER.name: None,
                RNNCell._Parameters.ACTIVATION.name: activation}

    @staticmethod
    def basic_lstm_cell(num_units: int, activation: ActivationType = ActivationType.TANH,
                        forget_bias: float = 1.0) -> dict:
        return {RNNCell._Parameters.CELL.name: RNNCell._Parameters.BASIC_LSTM_CELL.name,
                RNNCell._Parameters.NUM_UNITS.name: num_units,
                RNNCell._Parameters.ACTIVATION.name: activation,
                RNNCell._Parameters.FORGET_BIAS.name: forget_bias}

    @staticmethod
    def basic_rnn_cell(num_units: int, activation: ActivationType = ActivationType.TANH):
        return {RNNCell._Parameters.CELL.name: RNNCell._Parameters.BASIC_RNN_CELL.name,
                RNNCell._Parameters.NUM_UNITS.name: num_units,
                RNNCell._Parameters.ACTIVATION.name: activation}


class MORPHER:
    """
    ..  todo::
        Prathyush SP: Discuss with Parser team and Subbu
    """
    ZEROS_LIKE = 'zeros_like'
    ONES_LIKE = 'ones_like'

    @staticmethod
    def zeros_like():
        return {PARAMETERS.MORPHER_TYPE: MORPHER.ZEROS_LIKE}

    @staticmethod
    def ones_like():
        return {PARAMETERS.MORPHER_TYPE: MORPHER.ONES_LIKE}


class OPERATOR_OUTPUT:
    @staticmethod
    def get_output(name: Union[str, list], start_index: int = 0, end_index: int = -1):
        return {PARAMETERS.INPUT_NAME: name, PARAMETERS.START_INDEX: start_index, PARAMETERS.END_INDEX: end_index}


class STOP_CRITERIA:
    GINI = "gini"
    COST = "cost"
    ACCURACY = "accuracy"


class TrainingMode:
    BATCH_TRAINING = "batch_training"
    STOCHASTIC_TRAIN = "stochastic_training"
    NORMAL = "normal"


class LAYERS:
    FULLY_CONNECTED_LAYER = 'fully_connected_layer'
    CONVOLUTION_LAYER = 'convolution_layer'
    CONVOLUTION_3D_LAYER = 'convolution_3D_layer'
    OUTPUT_LAYER = 'output_layer'
    INPUT_LAYER = 'input_layer'
    POOL_LAYER = 'pool_layer'
    BATCH_NORMALIZATION_LAYER = 'batch_normalization_layer'
    ACTIVATION_LAYER = 'activation_layer'
    OUTPUT_LAYER_PLACEHOLDER = 'output_layer_placeholder'


class LayerType(enum.Enum):
    """
   | *@author*: Prathyush SP
   |
   | Layer Types
   **DO NOT MODIFY**
   """
    FULLY_CONNECTED_LAYER = enum.auto()
    CONVOLUTION_LAYER = enum.auto()
    CONVOLUTION_3D_LAYER = enum.auto()
    # OUTPUT_LAYER = enum.auto()
    # INPUT_LAYER = enum.auto()
    POOL_LAYER = enum.auto()
    BATCH_NORMALIZATION_LAYER = enum.auto()
    ACTIVATION_LAYER = enum.auto()
    OUTPUT_LAYER_PLACEHOLDER = enum.auto()
    BI_DIRECTIONAL_RNN_LAYER = enum.auto()
    MORPH_LAYER = enum.auto()
    RNN_LAYER = enum.auto()


class OperatorTypes(enum.Enum):
    ADD_OPERATOR = enum.auto()
    CONCAT_OPERATOR = enum.auto()
    DIVIDE_OPERATOR = enum.auto()
    MUL_OPERATOR = enum.auto()
    RESHAPE_OPERATOR = enum.auto()
    SLICE_OPERATOR = enum.auto()
    SPLIT_OPERATOR = enum.auto()
    SUB_OPERATOR = enum.auto()
    UNSTACK_OPERATOR = enum.auto()
    APPLY_OPERATOR = enum.auto()
    BIAS_ADD_OPERATOR = enum.auto()
    REDUCE_OPERATOR = enum.auto()

    # CONVOLUTION_LAYER = 'convolution_layer'
    # OUTPUT_LAYER = 'output_layer'
    # INPUT_LAYER = 'input_layer'
    # POOL_LAYER = 'pool_layer'
    # BATCH_NORMALIZATION_LAYER = 'batch_normalization_layer'
    # ACTIVATION_LAYER = 'activation_layer'


class ML_MODELS:
    LOGISTIC_REGRESSION = 'logistic_regression'
    LINEAR_REGRESSION = 'linear_regression'
    RANDOM_FOREST = 'random_forest'
    KMEANS = 'kmeans'
    SUPPORTED_MODELS = [LOGISTIC_REGRESSION, LINEAR_REGRESSION, RANDOM_FOREST, KMEANS]

    ML_TRAIN_META = "ml_train_meta"

    TRAIN_METRICS = "train_metrics"
    TEST_METRICS = "test_metrics"

    class ML_TRAIN_META_OPTIONS:
        EPOCH_COST = "cost"
        EPOCH_ACCURACY = "accuracy"
        EPOCH_GINI = "gini"
        EPOCH_TIME_ELAPSED = "time_elapsed"

    ML_TEST_META = "ml_test_meta"

    class ML_TEST_META_OPTIONS:
        TEST_COST = "test_cost"
        TEST_ACCURACY = "test_accuracy"
        TEST_GINI = "test_gini"
        TEST_TIME_ELAPSED = "test_time_elapsed"


class LOGGING_LEVEL:
    INFO = 'INFO'
    WARN = 'WARN'
    DEBUG = 'DEBUG'
    FATAL = 'FATAL'
    CRITICAL = 'CRITICAL'
    ERROR = 'ERROR'
    SUPPORTED_LEVELS = [INFO, WARN, DEBUG, FATAL, CRITICAL, ERROR]


class NETWORK_MODE:
    TRAIN = 'train'
    PREDICTION = 'pred'


class NetworkMetaConstant:
    """
    """
    FILE_NAME = 'network.meta'
    NETWORK_META = 'network_meta'
    RUNS = 'runs'
    SIZE = 'size'
    TYPE = 'type'
    MODEL_META_PATH = 'model_meta_path'

    class TYPE_OPTION:
        DL = 'dl'
        ML = 'ml'


class EvaluationMetrics:
    ACCURACY = 'accuracy'
    GINI = 'gini'
    COST = 'cost'


class MONITORS:
    class TYPE:
        CPU_MONITOR = 'cpu_monitor'
        GPU_MONITOR = 'gpu_monitor'
        MEMORY_MONITOR = 'memory_monitor'

    class CODE:
        RUNNING = 'running'
        ERROR = 'error'
        INITIALIZING = 'initializing'
        DISABLED = 'disabled'
        COMPLETED = 'completed'


class ModelMetaConstant:
    """
    """
    METADATA = "metadata"
    NETWORK_NAME = "network_name"
    MODEL_NAME = "model_name"
    TIMESTAMP = "timestamp"
    MODEL_ARCHITECTURE = "model_architecture"
    EPOCHS = "epochs"
    EPOCH_STEP = "epoch_step"
    LEARNING_RATE = "learning_rate"
    COST = "cost"
    OPTIMIZER = "optimizer"
    ACCURACY = "accuracy"
    TRAIN_BATCH_SIZE = "train_batch_size"
    TRAIN_BATCHES = "train_batches"
    VALID_BATCH_SIZE = "valid_batch_size"
    VALID_BATCHES = "valid_batches"
    TEST_BATCH_SIZE = "valid_batch_size"
    TEST_BATCHES = "valid_batches"
    PATH = 'path'
    RNN_STATES = "rnn_states"
    MODEL_COMPLEXITY = 'model_complexity'
    EVALUATION_METRICS = 'evaluation_metrics'
    EPOCH_METRICS = 'epoch_metrics'
    BATCH_METRICS = 'batch_metrics'
    TEST_METRICS = 'test_metrics'
    BATCH_METRICS_FOR_TRAIN = 'batch_metrics_for_train'
    LOG_COMPONENTS = 'log_components'
    SCOPES = 'scopes'
    MODEL_SCOPES = 'model_scopes'
    TRAINABLE_VARIABLES = 'trainable_variables'
    DATASETS = 'datasets'

    class PATH_OPTIONS:
        DL_SAVE_PATH = 'dl_save_path'
        ML_SAVE_PATH = 'ml_save_path'
        DATA_SAVE_PATH = 'data_save_path'
        GRAPH_SAVE_PATH = 'graph_save_path'

    GRAPH = "graph"
    PLACEHOLDERS = "placeholders"
    DROPOUT_PLACEHOLDERS = "dropout_placeholders"
    PREDICTION_PLACEHOLDERS = "prediction_placeholders"
    LR_PLACEHOLDERS = "lr_placeholders"
    WEIGHTS = "weights"
    BIAS = "bias"
    LAYERS = "layers"
    TRAIN_OP = "train_op"

    class TRAIN_OP_OPTIONS:
        COST = 'cost'
        OPTIMIZER = 'optimizer'
        LR_PLACEHOLDER = 'lr_placeholder'

    TRAIN_METRICS = "train_metrics"

    class TRAIN_METRICS_OPTIONS:
        COST_PLACEHOLDER = 'cost_placeholder'
        COST_TENSOR = 'cost_tensor'

    EVALUATION_METRICS_DICT = 'evaluation_metrics_dict'

    class EVALUATION_METRICS_DICT_OPTIONS:
        ACCURACY_PLACEHOLDER = 'accuracy_placeholder'
        GINI_PLACEHOLDER = 'gini_placeholder'
        ACCURACY_TENSOR = 'accuracy_tensor'
        GINI_TENSOR = 'gini_tensor'

    TRAIN_META = "train_meta"

    class TRAIN_META_OPTIONS:
        EPOCHS = "epochs"
        EPOCH_COST = "epoch_cost"
        EPOCH_VALID_COST = "epoch_valid_cost"
        EPOCH_ACCURACY = "epoch_accuracy"
        EPOCH_VALID_ACCURACY = "epoch_valid_accuracy"
        EPOCH_GINI = "epoch_gini"
        EPOCH_VALID_GINI = "epoch_valid_gini"
        EPOCH_PROGRESS = "epoch_progress"
        EPOCH_ETA = "epoch_eta"
        EPOCH_TIME_ELAPSED = "epoch_time_elapsed"
        BATCH_ID = "batch_id"
        BATCH_COST = "batch_cost"
        BATCH_ACCURACY = "batch_accuracy"
        BATCH_GINI = "batch_gini"
        BATCH_ETA = "batch_eta"
        BATCH_PROGRESS = "batch_progress"
        BATCH_TIME_ELAPSED = "batch_time_elapsed"

    TEST_META = "test_meta"

    class TEST_META_OPTIONS:
        TEST_COST = "test_cost"
        TEST_ACCURACY = "test_accuracy"
        TEST_GINI = "test_gini"
        TEST_TIME_ELAPSED = "test_time_elapsed"

    VALID_META = "valid_meta"

    COMPONENTS = 'component'
    COMPONENT_OUTPUT = 'component_output'
    NODE = 'node'
    REQUIRED_INPUT_FOR_METRICS = 'required_inputs_for_metrics'


class REDUCE_OPERATOR:
    MAX = 'max'
    MIN = 'min'
    MEAN = 'mean'

    __version__ = "0.0.1"
    __status__ = STATUS.ACTIVE
    __meta__ = [
        {
            "name": MAX,
            "status": STATUS.ACTIVE,
            "description": "",
            "data_type": BLUEPRINT_PARAMETERS.DataTypeOptions.NONE
        },
        {
            "name": MIN,
            "status": STATUS.ACTIVE,
            "description": "",
            "data_type": BLUEPRINT_PARAMETERS.DataTypeOptions.NONE
        },
        {
            "name": MEAN,
            "status": STATUS.ACTIVE,
            "description": "",
            "data_type": BLUEPRINT_PARAMETERS.DataTypeOptions.NONE
        }]


class Hook:
    class HookType(enum.Enum):
        ComponentHook = enum.auto()
        ModelRunnerHook = enum.auto()
        FlowHook = enum.auto()
        ModelHook = enum.auto()

    class HookPosition(enum.Enum):
        BeginHook = enum.auto()
        EndHook = enum.auto()
        UpdateHook = enum.auto()
        CloseHook = enum.auto()
        TrainBeginHook = enum.auto()
        TrainEndHook = enum.auto()
        TrainUpdateHook = enum.auto()

    class HookRunnerTypes(enum.Enum):
        ComponentHookRunner = enum.auto()
        ModelHookRunner = enum.auto()
        ModelRunnerHookRunner = enum.auto()
        FlowHookRunner = enum.auto()

    class HookRules():
        # todo: Prathyush SP -  Do not change it to enum.auto as they are referenced by keys
        ModelName = 'model_name'
        ComponentType = 'component_type'
        ComponentSubType = 'component_sub_type'
        ComponentName = 'component_name'

        class FlowHookRules():
            FlowName = 'flow_name'
            ModelRunnerName = 'model_runner_name'
            IntervalType = 'interval_type'
            Interval = 'interval'
        # LayerType = 'layer_type'
        # LayerName = 'layer_name'
        # OperatorType = 'operator_type'
        # OperatorName = 'operator_name'
