"""
@created on: 16/12/16,
@author: Prathyush SP,
@version: v0.0.1

Description:

Sphinx Documentation Status:

..todo::

"""

import logging
logger = logging.getLogger(__name__)
from rztdl.utils import string_constants