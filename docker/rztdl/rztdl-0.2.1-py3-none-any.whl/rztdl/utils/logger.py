"""
@created on: 16/12/16,
@author: Prathyush SP,
@version: v0.0.1

Description:
Logger Class

Logger used to log. It has three Handlers,
1. File Handler 1: Logs Debug to File
2. File Handler 2: Logs Warn to File
3. Std Err Handler: Logs Info to Console

Sphinx Documentation Status:

..todo::
    --

"""

import datetime
import logging
from rztdl.utils.singleton import Singleton


class DLLogger(metaclass=Singleton):
    """
    Logger Class
    """

    def __init__(self, name=None, log_path=None):
        self.logger = logging.getLogger()
        self.timestamp = '{:%Y-%m-%d-%H_%M_%S}'.format(datetime.datetime.now())
        self.formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

        # Init Log Handlers
        self.debug_log_handler = logging.FileHandler(log_path + '/log_' + self.timestamp + '_' + name + '-DEBUG.log')
        self.summary_log_handler = logging.FileHandler(
            log_path + '/log_' + self.timestamp + '_' + name + '-SUMMARY.log')
        self.stderr_log_handler = logging.StreamHandler()

        # Add Handlers
        self.logger.addHandler(self.debug_log_handler)
        self.logger.addHandler(self.summary_log_handler)
        self.logger.addHandler(self.stderr_log_handler)

        # Set Handler Levels
        self.debug_log_handler.setLevel('DEBUG')
        self.summary_log_handler.setLevel('WARN')
        self.stderr_log_handler.setLevel('INFO')

        # Format Handlers
        self.debug_log_handler.setFormatter(self.formatter)
        self.stderr_log_handler.setFormatter(self.formatter)

    def summary(self, message):
        """
        @author: Prathyush SP

        Summary Logger
        :param message: Log Message
        :return: None
        """
        self.logger.warning(message)

    def get_dl_logger(self):
        """
        @author: Prathyush SP

        Get Logger
        :return: Logger Object
        """
        return self.logger

    def update_log_handler(self):
        # todo: Complete Implementation for Log Handler Update
        pass
