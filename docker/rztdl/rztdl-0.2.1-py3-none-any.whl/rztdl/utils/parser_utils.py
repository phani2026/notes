# -*- coding: utf-8 -*-
"""
| **@created on:** 22/04/16,
| **@author:** Himaprasoon PT,
| **@version:** v0.0.1
|
| **Description:**
|
| **Sphinx Documentation Status:**
|
|..todo::

"""
import requests
import json
import logging

logger = logging.getLogger(__name__)
from rztdl import RZTDL_CONFIG


def call_parser(json_path):
    """
    | **@author:** Himaprasoon PT
    |
    | Call Parser Utility
    :param json_path: JSON Path
    :return: json response
    """
    data = json.load(open(json_path))
    response = requests.post(RZTDL_CONFIG.ParserConfig.PARSER_CONFIG_URL, json=data)
    if response.status_code == 200:
        return response.json()["message"]
    else:
        logger.info(response.json()["message"])
        raise Exception(response.json()["message"])
