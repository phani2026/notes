# -*- coding: utf-8 -*-
"""
| **@created on:** 20/05/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Python Utilities
|
| Sphinx Documentation Status:** Complete
|
..todo::
"""
import collections
import datetime
import json
import logging
import os
import shutil
import subprocess
import uuid
from collections import Counter
from collections import OrderedDict
from typing import Dict
from typing import Union, List

from typeguard import typechecked
import glob
import subprocess
import typing
from rztdl.utils.dl_exception import value_exception
from weakref import WeakValueDictionary

logger = logging.getLogger(__name__)


def path_fixer(path: str) -> str:
    """
    | **@author:** Prathyush SP
    |
    | Fix redundant '/' in a given path
    :param path: Directory Path
    :return: Fixed Path
    """
    return '/' + '/'.join((p for p in path.split('/') if not p == ''))


@typechecked
@value_exception
def get_key_by_value(dict_: typing.Union[OrderedDict, dict], value: typing.Any):
    return list(dict_.keys())[list(dict_.values()).index(value)]


@typechecked
def mean(data: list, log_error=True) -> Union[None, float]:
    """
    | **@author:** Prathyush SP
    |
    | Get the mean of a list
    :param data: List Data
    :return: Mean of the List
    """
    try:
        return sum(data) / len(data)
    except Exception as e:
        if log_error:
            logger.error(e)
    return None


def append_to_lists(lists, values):
    """
    | **@author:** Prathyush SP
    |
    | Append values to multiple lists
    :param lists: List of Lists
    :param values: List of Values
    :return: Updated Lists
    """
    for l, v in list(zip(lists, values)):
        l.append(v)
    return lists


@typechecked
def generate_uuid(name: str = '') -> str:
    """
    | **@author:** Prathyush SP
    |
    | Generate Unique ID
    :param name: UID Name
    :return: Unique ID
    """
    return '_'.join([name, str(uuid.uuid4().hex)])


@typechecked
def raise_exception(msg: str, exception=None):
    """
    | **@author:** Prathyush SP
    |
    | Inline Exception Raiser
    :param msg: Message
    :param exception: Exception
    """
    raise Exception(msg, exception)


@typechecked
def run_system_command(command: str):
    sub_process = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, close_fds=True)
    process_info = sub_process.communicate()[0].strip()
    return process_info, sub_process.returncode


@typechecked
def generate_timestamp() -> str:
    """
    | **@author:** Prathyush SP
    |
    | Genetate Timestamp
    :return: Timestamp in String : Format(YYYY-MM-DD_HH:mm:SEC)
    .. todo::
        Prathyush SP:
            1. Support for custom formatting

    """
    # todo: Prathyush SP: Support for custom formatting
    return str(datetime.datetime.now().replace(microsecond=0)).replace(' ', '_').replace(':', '').replace('-', '')


class ROrderedDict(OrderedDict):
    """
    | **@author:** Prathyush SP
    |
    | Reject Ordered Dictionary - Raises Exception if key is found
    """

    def __init__(self, *args, **kwargs):
        super(ROrderedDict, self).__init__(*args, **kwargs)

    def __setitem__(self, key, value, dict_setitem=dict.__setitem__, proxy=collections._proxy, Link=collections._Link):
        if key in self:
            raise KeyError('Key: {} already Exists'.format(key))
        else:
            super().__setitem__(key, value)


class RWeakValueDictionary(WeakValueDictionary):
    """
    | **@author:** Prathyush SP
    |
    | Reject WeakrefValue Dictionary - Raises Exception if key is found
    """

    # todo: Prathyush SP - Support for args and kwargs in init function
    def __init__(self):
        super(RWeakValueDictionary, self).__init__()

    def __setitem__(self, key, value):
        if key in self:
            raise KeyError('Key: {} already Exists'.format(key))
        else:
            super().__setitem__(key, value)


# class FrozenDict(object):
#     def __init__(self, input: dict = {}):
#         self.__forzen_state = frozenset(input)
# 
#     def items(self):
#         return dict(self.__forzen_state).items()
# 
#     def keys(self):
#         return dict(self.__forzen_state).keys()
# 
#     def values(self):
#         return dict(self.__forzen_state).values()

class FrozenDict(dict):
    def __hash__(self):
        return id(self)

    def _immutable(self, *args, **kws):
        raise TypeError('object is immutable')

    __setitem__ = _immutable
    __delitem__ = _immutable
    clear = _immutable
    update = _immutable
    setdefault = _immutable
    pop = _immutable
    popitem = _immutable


class Directories:
    """
    | **@author:** Prathyush SP
    |
    | Directories Class
    """

    @staticmethod
    def is_exist(path: str) -> bool:
        """
        | **@author:** Prathyush SP
        |
        | Check if the directory Exists
        :param path: Directory path
        :return: Bool
        """
        return os.path.isdir(path)

    @staticmethod
    def is_empty(path: str) -> bool:
        """
        | **@author:** Prathyush SP
        |
        | Check if the directory is empty
        :param path: Directory path
        :return: Bool
        """
        if Directories.is_exist(path):
            if not os.listdir(path):
                return True
            else:
                return False
        else:
            logger.error('Directory does not Exist')
            return True

    @staticmethod
    def is_readable(path: str) -> bool:
        """
        | **@author:** Prathyush SP
        |
        | Check if the directory is readable
        :param path: Directory path
        :return: Bool
        """
        return os.access(path, os.R_OK)

    @staticmethod
    def is_writable(path) -> bool:
        """
        | **@author:** Prathyush SP
        |
        | Check if the directory is writable
        :param path: Directory path
        :return: Bool
        """
        return os.access(path, os.W_OK)

    @staticmethod
    def mkdir(path: str, force: bool = False):
        """
        | **@author:** Prathyush SP
        |
        | Create a directory
        :param path: Directory path
        :param force: Bool - Force Create a directory
        """
        if not Directories.is_exist(path):
            os.makedirs(path, exist_ok=True)
        elif (Directories.is_exist(path) and Directories.is_empty(path)) or force:
            Directories.rmdir(path, force=force)
            os.makedirs(path, exist_ok=True)
        else:
            logger.error('Directory already exists and is not Empty. Use force=True to force create')

    @staticmethod
    def rmdir(path: str, force: bool = False):
        """
        | **@author:** Prathyush SP
        |
        | Remove a Directory
        :param path: Directory path
        :param force: Bool - Force Remove a directory
        """
        if not Directories.is_exist(path):
            logger.error('Directory does not exist')
        elif Directories.is_exist(path) and force:
            shutil.rmtree(path)
        elif Directories.is_empty(path):
            shutil.rmtree(path)
        else:
            logger.error('Directory is not Empty. Use force=True to force remove')

    @staticmethod
    def size(path: str) -> str:
        """
        | **@author:** Prathyush SP
        |
        | Get the Size of the Directory
        :param path: Path
        :return: Size in str
        """

        if Directories.is_exist(path):
            return subprocess.check_output(['du', '-sh', path]).split()[0].decode('utf-8')
        else:
            logger.warning('Path does not exist')
            raise FileExistsError()

    @staticmethod
    def count_dirs(path: str, depth: int = None) -> List:
        """
        | **@author:** Prathyush SP
        |
        | Count Folders in the Directory
        :param path: Path
        :param depth: Depth
        :return: List of Directory paths
        """
        if Directories.is_exist(path):
            if depth:
                return str(subprocess.check_output(["find", path, "-type", "d", "-maxdepth", '1'])).split('\\n')[1:-1]
            else:
                return str(subprocess.check_output(["find", path, "-type", "d"])).split('\\n')[1:-1]
        else:
            logger.warning('Path does not exist')
            raise FileExistsError()


class File:
    """
    | **@author:** Prathyush SP
    |
    | File Utilities
    """

    @staticmethod
    def is_exist(path: str) -> bool:
        """
        | **@author:** Prathyush SP
        |
        | Check if a file exists
        :param path: File Path
        :return: Boolean
        """
        return os.path.exists(path)

    @staticmethod
    def is_writable(path) -> bool:
        """
        | **@author:** Prathyush SP
        |
        | Check if the directory is writable
        :param path: Directory path
        :return: Bool
        """
        return os.access(path, os.W_OK)

    @staticmethod
    def is_readable(path: str) -> bool:
        """
        | **@author:** Prathyush SP
        |
        | Check if the directory is readable
        :param path: Directory path
        :return: Bool
        """
        return os.access(path, os.R_OK)

    @staticmethod
    def word_count(path: str, encoding: str = None, only_count=True) -> Union[int, Counter]:
        """
        | **@author:** Prathyush SP
        |
        | Count the number of words in a File
        :param path: File Path
        :param encoding: File Encoding
        :param only_count: True/False [Count / {Word: Count}]
        :return: Union[int, Counter]
        """
        if File.is_exist(path=path):
            if only_count:
                return sum(v for k, v in Counter(open(r'' + path, 'r', encoding=encoding).read().split()).items())
            else:
                return Counter(open(r'' + path, 'r', encoding=encoding).read().split())
        else:
            logger.error('File does not exist')
            return -1

    @staticmethod
    def line_count(path: str, encoding: str = None) -> int:
        """
        | **@author:** Prathyush SP
        |
        | Count the number of lines in a File

        :param path: File Path
        :param encoding: File Encoding
        :return: Line Count in int
        """
        if File.is_exist(path=path):
            return len(open(r'' + path, encoding=encoding).read().splitlines())
        else:
            logger.error('File does not exist')
            return -1

    @staticmethod
    def read_json(path: str, encoding: str = None, object_pairs_hook: Union[dict, OrderedDict] = dict) -> Union[
        int, dict]:
        """
        | **@author:** Prathyush SP
        |
        | Load JSON (dict) from a file
        :param path: File Path
        :param encoding: File Encoding
        :return: Dictionary
        """
        if File.is_exist(path):
            try:
                return json.load(open(path, encoding=encoding), object_pairs_hook=object_pairs_hook)
            except Exception as e:
                raise Exception('Unable to load the JSON File')
        else:
            logger.error('File does not exist')
            return -1

    @staticmethod
    def size(path: str) -> int:
        """
        | **@author:** Prathyush SP
        |
        | Get File Size
        :param path: File Path
        :return: File Size
        """
        if File.is_exist(path=path):
            return os.path.getsize(path)
        else:
            logger.error('File does not exist')

    @staticmethod
    def load_json(load_path: str, file_name: str, encoding: str = None, mode: str = 'r', load_format=dict):
        """
        | **@author:** Prathyush SP
        |
        | Added Load JSON method
        :param load_path: Load Path
        :param file_name: File Name
        :param encoding: Encoding
        :param mode: Mode - 'r / rb'
        :param load_format: - Object Pair Hooks for JSON
        :return: load_format object
        """
        try:
            data = json.load(open(load_path + file_name, mode=mode, encoding=encoding), object_pairs_hook=load_format)
        except FileNotFoundError or FileExistsError:
            raise FileNotFoundError()
        return data

    @staticmethod
    def write_json(data: Union[OrderedDict, Dict], save_path: str, file_name: str, encoding: str = None, sort=False,
                   reverse=False, indent=2, parent_key: Union[str, None] = None):
        """
        | **@author:** Prathyush SP
        |
        | Write JSON to a File
        :param data: JSON Data
        :param save_path: Save Path
        :param file_name: File Name
        :param encoding: File Encoding
        :param sort: Sort JSON based on key in ascending order
        :param reverse: Sort JSON based on key in descending order
        :param indent: JSON Indentation
        :param parent_key: Parent Key
        """
        data = sorted(data.items(), key=lambda x: int(x[0]), reverse=reverse) if sort or reverse else data
        if parent_key:
            json.dump(OrderedDict([(parent_key, data)]),
                      open(r'' + save_path + '/' + file_name, 'w', encoding=encoding), indent=indent)
        else:
            json.dump(OrderedDict(data), open(r'' + save_path + '/' + file_name, 'w', encoding=encoding), indent=indent)


class TimeUtils(object):
    """
    | **@author:** Prathyush SP
    |
    | Time Utils
    """

    class DateTime(object):
        """
        | **@author:** Prathyush SP
        |
        | Time Utils for DateTime objects
        """

        @staticmethod
        def calculate_seconds(dt: datetime):
            """
            | **@author:** Prathyush SP
            |
            | Calculate Seconds
            :param dt: Datetime Object
            :return: seconds
            """
            return float(
                dt.year * 12 * 30 * 24 * 60 * 60 + dt.month * 30 * 24 * 60 * 60 + dt.day * 24 * 60 * 60 + dt.hour * 60 * 60 + dt.minute * 60 + dt.second + dt.microsecond / 10 ** 6)

        @staticmethod
        def calculate_minutes(dt: datetime):
            """
            | **@author:** Prathyush SP
            |
            | Calculate Minutes
            :param dt: Datetime Object
            :return: Minutes
            """
            return float(TimeUtils.DateTime.calculate_seconds(dt) / 60)

        @staticmethod
        def calculate_hours(dt: datetime):
            """
            | **@author:** Prathyush SP
            |
            | Calculate Hours
            :param dt: Datetime Object
            :return: Hours
            """
            return float(TimeUtils.DateTime.calculate_seconds(dt) / (60 * 60))

        @staticmethod
        def calculate_days(dt: datetime):
            """
            | **@author:** Prathyush SP
            |
            | Calculate Days
            :param dt: Datetime Object
            :return: Days
            """
            return float(TimeUtils.DateTime.calculate_seconds(dt) / (24 * 60 * 60))

        @staticmethod
        def calculate_months(dt: datetime):
            """
            | **@author:** Prathyush SP
            |
            | Calculate Months
            :param dt: Datetime Object
            :return: Months
            """
            return float(TimeUtils.DateTime.calculate_seconds(dt) / (30 * 24 * 60 * 60))

        @staticmethod
        def calculate_years(dt: datetime):
            """
            | **@author:** Prathyush SP
            |
            | Calculate Years
            :param dt: Datetime Object
            :return: Years
            """
            return float(TimeUtils.DateTime.calculate_seconds(dt) / (12 * 24 * 60 * 60))

    class TimeDelta(object):
        """
        | **@author:** Prathyush SP
        |
        | Time Utils for TimeDelta objects
        """

        @staticmethod
        def calculate_seconds(dt: datetime):
            """
            | **@author:** Prathyush SP
            |
            | Calculate Seconds
            :param dt: TimeDelta Object
            :return: Seconds
            """
            return float(dt.hour * 60 * 60 + dt.minute * 60 + dt.second + dt.microsecond / 10 ** 6)

        @staticmethod
        def calculate_minutes(dt: datetime):
            """
            | **@author:** Prathyush SP
            |
            | Calculate Minutes
            :param dt: TimeDelta Object
            :return: Minutes
            """
            return float(TimeUtils.TimeDelta.calculate_seconds(dt) / 60)

        @staticmethod
        def calculate_hours(dt: datetime):
            """
            | **@author:** Prathyush SP
            |
            | Calculate Hours
            :param dt: TimeDelta Object
            :return: Hours
            """
            return float(TimeUtils.TimeDelta.calculate_seconds(dt) / (60 * 60))


class DLTimer(object):
    """
    | **@author:** Prathyush SP
    |
    | DL Timer Class
    """

    def __init__(self):
        """
        | **@author:** Prathyush SP
        |
        | DL Timer Class Constructor
        """
        self.start_time = None
        pass

    def set_time(self):
        """
        | **@author:** Prathyush SP
        |
        |Set Time
        :return: DLTimer Object
        """
        self.start_time = datetime.datetime.now()
        return self

    def get_elapsed_time(self):
        """
        | **@author:** Prathyush SP
        |
        Get Elapsed Time
        :return: Time Elapsed in hh:mm:sec.milli_sec
        """
        return datetime.datetime.now() - self.start_time
