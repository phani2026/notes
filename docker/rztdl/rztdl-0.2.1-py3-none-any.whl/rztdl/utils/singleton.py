# -*- coding: utf-8 -*-
"""
| **@created on:** 20/05/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Singleton Class
|
| Sphinx Documentation Status:** Complete
|
..todo::
"""
from abc import ABCMeta

class Singleton(type, metaclass=ABCMeta):
    """
    Singleton Class
    """
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]
