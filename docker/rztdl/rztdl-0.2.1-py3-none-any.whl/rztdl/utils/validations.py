# -*- coding: utf-8 -*-
"""
| **@created on:** 19/04/17,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::
"""
import re
from typeguard import typechecked
from rztdl.utils.string_constants import ML_MODELS

NAME_REGEX = re.compile('^[A-Za-z0-9_]*$', )


@typechecked
def validate_name(name: str) -> str:
    """
    | **@author:** Prathyush SP
    |
    | Name Validation
    :param name: Name
    :return: String
    """
    if not name == '' and NAME_REGEX.match(name):
        return name
    else:
        raise NameError('Name Exception:  {}  - Supports Alphabets, Numbers and _'.format(name))


@typechecked
def validate_ml_model_type(model_type: str) -> str:
    """
    | **@author:** Prathyush SP
    |
    | ML Model Type Validation
    :param model_type: Model Type
    :return: String
    """
    if model_type in ML_MODELS.SUPPORTED_MODELS:
        return model_type
    else:
        raise NameError('Type Exception:  {}  - Supported Models:'.format(model_type, ML_MODELS.SUPPORTED_MODELS))