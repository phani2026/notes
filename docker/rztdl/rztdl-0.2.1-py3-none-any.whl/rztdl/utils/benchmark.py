# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Timer Class
|
| Sphinx Documentation Status:**
|
..todo::


Benchmark Statistics: 
1.	Total Elapsed Time	Timestamp	Total time taken by the runner  - DONE
2.	Epoch Time	List[Timestamp]	Time taken for every epoch - DONE
3.	Batch Time	List[Timestamp]	Time taken for each batch in an Epoch - DONE
4.	SFP Time	Timestamp	Time taken for Single Forward Pass - DONE
5.	SBP Time	Timestamp	Time taken for a Single Backward Pass - DONE
6.	Samples / Second	Int	Number of samples executed per second - DONE
7.	Data / Second	Int	Data crunched in a second in Kb/ Mb/ Gb - DONE
8.	Model Complexity	Int	Number of Weights associated for the given model - DONE
9.	Timeline	JSON	Used for Chrome Tracing: Useful to debug elapsed time for each operation.
10.	Physical Memory Consumption - RAM	List[Float]	Max Physical Memory (RAM) consumed by the run in Mb/ GB - DONE
11.	Physical Memory Consumption - GPU	List[Float]	Max Physical Memory (GPU) consumed by the run in Mb/ GB 
12.	Physical Processing Power Consumption	List[Float]	 Max Physical Power (CPU) consumed by the run in % - DONE
"""

from rztdl.dl.network import Network
from rztdl.dl.predict import Prediction
from rztdl import RZTDL_CONFIG, RZTDL_STORE
from rztdl.utils.pyutils import TimeUtils
import json
from collections import OrderedDict
import datetime
from multiprocessing import Process
from multiprocessing.managers import BaseManager
import time
import os
import logging
from rztdl.utils.pyutils import DLTimer, generate_timestamp
from typeguard import typechecked
import glob

logger = logging.getLogger(__name__)


# RZTDL_CONFIG.update_dl_config_manager(
#     config_file_path='/'.join(str(__file__).split('/')[:-1]) + "/../../rztdl/config/rztdl_benchmark_config.json")


# RZTDL_CONFIG.update_dl_logging_config_manager(
#     config_file_path='/'.join(str(__file__).split('/')[:-1]) + "/../../rztdl/config/rztdl_benchmark_logging.yaml")


# noinspection PyMissingOrEmptyDocstring
class BenchmarkStats(object):
    """
    | **@author:** Prathyush SP
    |
    | Benchmarking Statistics
    """

    def __init__(self, network_name):  # pragma: no cover
        self.network_name = network_name
        self.model_complexity = None
        self.single_forward_pass_time = None
        self.single_backward_pass_time = None
        self.samples_per_second = None
        self.total_elapsed_time = None
        self.single_epoch_time = None
        self.single_batch_time = None
        self.data_per_second = None
        self.batches = None
        self.batch_size = None
        self.single_sample_size = None
        self.total_samples = None
        self.synthetic_samples_per_second = None
        self.synthetic_data_per_second = None
        self.monitor_statistics = OrderedDict()

    def set_synthetic_samples_per_second(self, val):
        self.synthetic_samples_per_second = val

    def get_synthetic_samples_per_second(self):
        return self.synthetic_samples_per_second

    def set_synthetic_data_per_second(self, val):
        self.synthetic_data_per_second = val

    def set_batches(self, val):
        self.batches = val

    def get_batches(self):
        return self.batches

    def set_batch_size(self, val):
        self.batch_size = val

    def get_batch_size(self):
        return self.batch_size

    def set_total_samples(self, sample_size):
        self.total_samples = sample_size

    def get_total_samples(self):
        return self.total_samples

    def set_single_sample_size(self, val):
        self.single_sample_size = val

    def get_single_sample_size(self):
        return self.single_sample_size

    def get_monitor_statistics(self):
        return self.monitor_statistics

    def set_monitor_statistics(self, status: OrderedDict):
        self.monitor_statistics = status

    def set_data_per_second(self, data):
        self.data_per_second = data

    def get_samples_per_second(self):
        return self.samples_per_second

    def set_samples_per_second(self, samples):
        self.samples_per_second = samples

    def set_single_epoch_time(self, t):
        self.single_epoch_time = t

    def get_single_epoch_time(self):
        return self.single_epoch_time

    def set_single_batch_time(self, t):
        self.single_batch_time = t

    def get_single_batch_time(self):
        return self.single_batch_time

    def get_total_elapsed_time(self):
        return self.total_elapsed_time

    def set_total_elapsed_time(self, t):
        self.total_elapsed_time = t

    def get_single_forward_pass_time(self):
        return self.single_forward_pass_time

    def set_single_forward_pass_time(self, t):
        self.single_forward_pass_time = t

    def get_single_backward_pass_time(self):
        return self.single_backward_pass_time

    def set_single_backward_pass_time(self, t):
        self.single_backward_pass_time = t

    def set_model_complexity(self, complexity):
        self.model_complexity = complexity

    def info(self):  # pragma: no cover
        return OrderedDict([
            ('network_name', self.network_name),
            ('model_complexity', self.model_complexity),
            ('samples_per_second', self.samples_per_second),
            ('data_per_second (MBps)', self.data_per_second),
            ('total_samples', self.total_samples),
            ('batches', self.batches),
            ('batch_size', self.batch_size),
            ('single_forward_pass_time (HH:MM:SS.cs)', self.single_forward_pass_time),
            ('single_backward_pass_time (HH:MM:SS.cs)', self.single_backward_pass_time),
            ('total_elapsed_time (secs)', self.total_elapsed_time),
            ('single_epoch_time (secs)', self.single_epoch_time),
            ('single_batch_time (secs)', self.single_batch_time),
            ('single_sample_size (MB)', self.single_sample_size),
            ('monitor_statistics', self.monitor_statistics)
        ])


class BenchmarkUtil(object):
    """
    | **@author:** Prathyush SP
    |
    | Benchmark Util - 
    | Performs Training and Inference Benchmarks
    """

    @typechecked
    def __init__(self, network_name: str, network_path: str, stats_save_path: str = None,
                 monitors: list = None, benchmark_interval: int = 1):
        self.network_name = network_name
        self.network_path = network_path
        self.model_name = None
        self.deployed_monitors = monitors
        self.monitors = None
        self.timestamp = generate_timestamp()
        self.benchmark_interval = benchmark_interval
        self.pid = None
        self.stats_save_path = stats_save_path if stats_save_path \
            else RZTDL_CONFIG.CommonConfig.PATH_RZTDL + '/' + self.network_name + '/' + self.timestamp + '/' \
                 + RZTDL_CONFIG.CommonConfig.PATH_BENCHMARK + '/'
        os.system('mkdir -p ' + self.stats_save_path + '../graphs/')
        self.metadata = next(iter(json.load(open(self.network_path + '/' + self.network_name + '/model.meta'),
                                            object_pairs_hook=OrderedDict).values()))

    @staticmethod
    def _extract_data_from_timeline(trace_file_list):
        fp_dur, bp_dur, tot_time = 0, 0, 0
        for f in trace_file_list:
            timeline = json.load(open(f), object_pairs_hook=OrderedDict)['traceEvents']
            for e, d in enumerate(timeline):
                if 'args' in d and 'Apply' in d['args']['name']:
                    break_even, break_even_data = e, d
                    break
                fp_dur += d['dur'] if 'dur' in d else 0
                tot_time += d['dur'] if 'dur' in d else 0
            for e, d in enumerate(timeline[break_even:]):
                bp_dur += d['dur'] if 'dur' in d else 0
                tot_time += d['dur'] if 'dur' in d else 0
        fp_dur = (fp_dur / len(trace_file_list)) / 10 ** 6
        bp_dur = (bp_dur / len(trace_file_list)) / 10 ** 6
        return {
            'sfp_time': fp_dur,
            'sbp_time': bp_dur,
            'single_batch_time': (fp_dur + bp_dur) / 10 ** 6,
            'total_time_elapsed': tot_time / 10 ** 6
        }

    @typechecked
    def _attach_monitors(self, pid: int):
        """
        | **@author:** Prathyush SP
        |
        | Attach Various Monitors and waits
        :param pid: Process Id
        """

        if self.deployed_monitors:
            # Initialize Monitors
            self.monitors = [
                monitor(pid=pid, interval=self.benchmark_interval) if isinstance(monitor, type) else monitor
                for monitor in self.deployed_monitors]

            # Start Monitors
            for monitor in self.monitors:
                monitor.start()

            # Wait for Monitors
            for monitor in self.monitors:
                monitor.join()

    def _collect_monitor_stats(self):
        """
        | **@author:** Prathyush SP
        |
        | Collect Monitor Statistics
        """
        if self.monitors:
            return OrderedDict([(monitor.monitor_type, monitor.monitor_stats()) for monitor in self.monitors])
        return None

    @typechecked
    def run_synthetic_training(self, train_data: dict, valid_data: dict = None, test_data: dict = None,
                               display_step: int = 1, epoch: int = 10, learning_rate: int = 0.01,
                               train_batches: int = 1, train_batch_size: int = 0):
        """
       | **@author:** Prathyush SP
       |
       | Run Synthetic Training Benchmark
       |
       :param train_data: Train Data
       :param valid_data: Valid Data
       :param test_data: Test Data
       :param epoch: Epoch
       :param learning_rate: Learning Rate
       :param train_batches: Train Batches
       :param train_batch_size:  Train Batch Size
       """
        print('Running Synthetic Benchmark - Training . . .')
        BaseManager.register('BenchmarkStats', BenchmarkStats)
        manager = BaseManager()
        manager.start()
        b_stats_synthetic_train = manager.BenchmarkStats(self.network_name)
        arg = {'network_name': self.network_name, 'epoch': epoch, 'learning_rate': learning_rate,
               'train_batches': train_batches, 'train_batch_size': train_batch_size, 'network_path': self.network_path,
               'display_step': display_step, 'stats_save_path': self.stats_save_path,
               'timestamp': self.timestamp, 'tf_tracing': True}
        p = Process(target=self._training_process,
                    args=(arg, b_stats_synthetic_train, train_data, valid_data, test_data))
        p.start()
        self.pid = p.pid
        self._attach_monitors(pid=p.pid)
        p.join()
        timeline_times = self._extract_data_from_timeline(
            trace_file_list=glob.glob(self.stats_save_path + '../graphs/' + "*.json"))
        b_stats_synthetic_train.set_single_forward_pass_time(timeline_times['sfp_time'])
        b_stats_synthetic_train.set_single_backward_pass_time(timeline_times['sbp_time'])
        b_stats_synthetic_train.set_total_elapsed_time(timeline_times['total_time_elapsed'])
        b_stats_synthetic_train.set_single_batch_time(timeline_times['single_batch_time'])
        b_stats_synthetic_train.set_single_epoch_time(timeline_times['single_batch_time'] * train_batches)
        b_stats_synthetic_train.set_monitor_statistics(self._collect_monitor_stats())
        b_stats_synthetic_train.set_samples_per_second(
            b_stats_synthetic_train.get_batch_size() / float(timeline_times['sfp_time'] + timeline_times['sbp_time']))
        b_stats_synthetic_train.set_data_per_second(
            b_stats_synthetic_train.get_samples_per_second() * b_stats_synthetic_train.get_single_sample_size())
        json.dump(b_stats_synthetic_train.info(),
                  open(self.stats_save_path + '/benchmark_synthetic_training.json', 'w'),
                  indent=2)
        print('Benchmark Util - Synthetic Training completed successfully. Results stored at: {}'.format(
            self.stats_save_path + '/benchmark_synthetic_training.json'))

    @typechecked
    def run_training(self, train_data: dict, valid_data: dict = None, test_data: dict = None, display_step: int = 1,
                     epoch: int = 10, learning_rate: int = 0.01, train_batches: int = 1, train_batch_size: int = 0):
        """
        | **@author:** Prathyush SP
        |
        | Run Training Benchmark
        |
        :param train_data: Train Data 
        :param valid_data: Valid Data
        :param test_data: Test Data
        :param epoch: Epoch
        :param learning_rate: Learning Rate
        :param train_batches: Train Batches
        :param train_batch_size:  Train Batch Size
        """
        print('Running Benchmark - Training . . .')
        BaseManager.register('BenchmarkStats', BenchmarkStats)
        manager = BaseManager()
        manager.start()
        b_stats_train = manager.BenchmarkStats(self.network_name)
        arg = {'network_name': self.network_name, 'epoch': epoch, 'learning_rate': learning_rate,
               'train_batches': train_batches, 'train_batch_size': train_batch_size, 'network_path': self.network_path,
               'display_step': display_step, 'stats_save_path': self.stats_save_path,
               'timestamp': self.timestamp, 'tf_tracing': False}
        p = Process(target=self._training_process, args=(arg, b_stats_train, train_data, valid_data, test_data))
        p.start()
        self.pid = p.pid
        self._attach_monitors(pid=p.pid)
        p.join()
        b_stats_train.set_monitor_statistics(self._collect_monitor_stats())
        json.dump(b_stats_train.info(), open(self.stats_save_path + '/benchmark_training.json', 'w'), indent=2)
        print('Benchmark Util - Training completed successfully. Results stored at: {}'.format(
            self.stats_save_path + '/benchmark_training.json'))

    @staticmethod
    def _training_process(arg, b_stats_train, train_data, test_data, valid_data):
        """
        | **@author:** Prathyush SP
        |
        | Training Process for Multiprocessing
        :param arg: Arguments for Traing - Non-Iter Variables
        :param b_stats_train: BenchmarkStats Object
        :param train_data: Train Data
        :param test_data: Test Data
        :param valid_data: Valid Data
        """
        time.sleep(1)
        network = Network(arg['network_name'])
        network.timestamp = arg['timestamp']
        network.save_path = arg['stats_save_path'] + '/../../../'
        network.persist_training(epoch=arg['epoch'], learning_rate=arg['learning_rate'], train_data=train_data,
                                 valid_data=valid_data, test_data=test_data, load_path=arg['network_path'],
                                 display_step=arg['display_step'], train_batch_size=arg['train_batch_size'],
                                 train_batches=arg['train_batches'], tf_tracing=arg['tf_tracing'])
        model_name = network.model_name
        b_stats_train.set_total_samples(len(train_data[next(iter(train_data))]))
        b_stats_train.set_model_complexity(RZTDL_STORE.dag[model_name]['metadata']['model_complexity'])
        b_stats_train.set_total_elapsed_time(TimeUtils.TimeDelta.calculate_seconds(datetime.datetime.strptime(
            str(RZTDL_STORE.dag[model_name]['metadata']['train_meta']['epoch_time_elapsed'][-1]), "%H:%M:%S.%f")))
        b_stats_train.set_single_epoch_time(b_stats_train.get_total_elapsed_time() / arg['epoch'])
        b_stats_train.set_single_batch_time(b_stats_train.get_single_epoch_time() / network.train_batches)
        input_layer_list = list(RZTDL_STORE.dag[model_name]['prediction_placeholders'].keys())
        single_sample_size = 0
        for i in input_layer_list:
            single_sample_size += train_data[i][0].nbytes / 2 ** 20
        b_stats_train.set_single_sample_size(single_sample_size)
        b_stats_train.set_samples_per_second(
            float("{0:.2f}".format(network.train_batch_size / b_stats_train.get_single_batch_time())))
        b_stats_train.set_data_per_second(single_sample_size * b_stats_train.get_samples_per_second())
        b_stats_train.set_batches(network.train_batches)
        b_stats_train.set_batch_size(network.train_batch_size)

    @typechecked
    def run_inference(self, layer_name: str, data: dict, batches: int = 1, batch_size: int = 0):
        """
        | **@author:** Prathyush SP
        |
        | Run Inference Benchmarks
        :param layer_name: Layer Name
        :param data: Data
        :param batches: Batches
        :param batch_size: Batch Size
        """
        print('Running Benchmark - Inference . . .')
        BaseManager.register('BenchmarkStats', BenchmarkStats)
        manager = BaseManager()
        manager.start()
        b_stats_predict = manager.BenchmarkStats(self.network_name)
        arg = {'network_name': self.network_name, 'layer_name': layer_name,
               'batches': batches, 'batch_size': batch_size, 'network_path': self.network_path}
        p = Process(target=self._inference_process, args=(arg, b_stats_predict, data, self.metadata))
        p.start()
        self.pid = p.pid
        self._attach_monitors(pid=p.pid)
        p.join()
        b_stats_predict.set_monitor_statistics(self._collect_monitor_stats())
        json.dump(b_stats_predict.info(), open(self.stats_save_path + '/benchmark_inference.json', 'w'), indent=2)
        print('Benchmark Util - Inference completed successfully. Results stored at: {}'.format(
            self.stats_save_path + '/benchmark_inference.json'))

    @staticmethod
    def _inference_process(arg, b_stats_predict, data, metadata):
        """
        | **@author:** Prathyush SP
        |
        | Inference Processing for Multiprocessing
        |
        :param arg: Arguments for Traing - Non-Iter Variables
        :param b_stats_predict: BenchmarkStats
        :param data: Data
        :param metadata: Metadata
        """
        time.sleep(1)
        prediction = Prediction(arg['network_name'], model_save_path=arg['network_path'])
        timer = DLTimer().set_time()
        prediction.predict(layer_name=arg['layer_name'], data=data,
                           batch_size=arg['batch_size'], batches=arg['batches'])
        b_stats_predict.set_total_samples(len(data[next(iter(data))]))
        b_stats_predict.set_model_complexity(metadata['model_complexity'])
        b_stats_predict.set_total_elapsed_time(TimeUtils.TimeDelta.calculate_seconds(datetime.datetime.strptime(
            str(timer.get_elapsed_time()), "%H:%M:%S.%f")))
        b_stats_predict.set_single_batch_time(b_stats_predict.get_total_elapsed_time() / prediction.batches)
        input_layer_list = list(metadata['prediction_placeholders'].keys())
        single_sample_size = 0
        for i in input_layer_list:
            single_sample_size += data[i][0].nbytes / 2 ** 20
        b_stats_predict.set_single_sample_size(single_sample_size)
        b_stats_predict.set_samples_per_second(
            float("{0:.2f}".format(prediction.batch_size / b_stats_predict.get_single_batch_time())))
        b_stats_predict.set_data_per_second(single_sample_size * b_stats_predict.get_samples_per_second())
        b_stats_predict.set_batches(prediction.batches)
        b_stats_predict.set_batch_size(prediction.batch_size)

    def clean_up(self):
        """
        | **@author:** Prathyush SP
        |
        | Cleanup operations after benchmarking
        """
        pass  # pragma: no cover
