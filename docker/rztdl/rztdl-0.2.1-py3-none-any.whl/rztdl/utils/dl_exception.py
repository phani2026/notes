# -*- coding: utf-8 -*-
"""
| **@created on:** 30/03/17,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::
"""
import logging
from functools import wraps
import typing
import traceback
from functools import partial

logger = logging.getLogger(__name__)


class RztdlException(Exception):
    # todo: Prathyush SP -  Abstract exception based on flows, components and others
    def __init__(self, component_name: str, message: str, errors):
        self.exception = "Component Name: '{}', Message: '{}'".format(component_name, message)
        super(RztdlException, self).__init__(self.exception)
        self.message = message
        self.component_name = component_name
        self.errors = errors
        self.traceback = None

    def __repr__(self):
        return {'component_name': self.component_name, 'message': self.message, 'traceback': self.traceback}.__str__()


class ShapeError(RztdlException):
    """
    | **@author:** Prathyush SP
    |
    | Shape Validation.
    """

    def __init__(self, component_name: str, message: str, errors=None):
        """

        :param component_name: Component Name
        :param message: Error Message
        :param errors: Errors
        """
        super().__init__(component_name=component_name, message=message, errors=errors)


class PaddingError(RztdlException):
    """
    | **@author:** Prathyush SP
    |
    | Padding Validation.
    """

    def __init__(self, component_name: str, message: str, errors=None):
        """

        :param component_name: Component Name
        :param message: Error Message
        :param errors: Errors
        """
        super().__init__(component_name=component_name, message=message, errors=errors)


class ParameterError(RztdlException):
    """
    | **@author:** Umesh Kumar
    |
    | Parameter Validation.
    """

    def __init__(self, component_name: str, message: str, errors=None):
        """

        :param component_name: Component Name
        :param message: Error Message
        :param errors: Errors
        """
        super().__init__(component_name=component_name, message=message, errors=errors)


class SaveHandlerException(RztdlException):
    """
    | **@author:** Prathyush SP
    |
    | SaveHandler Exception
    """

    def __init__(self, component_name: str, message: str, errors=None):
        """

        :param component_name: Component Name
        :param message: Error Message
        :param errors: Errors
        """
        super().__init__(component_name=component_name, message=message, errors=errors)


class DTypeError(RztdlException):
    """
    | **@author:** Prathyush SP
    |
    | Datatype Validation.
    """

    def __init__(self, component_name: str, message: str, errors=None):
        """

        :param component_name: Component Name
        :param message: Error Message
        :param errors: Errors
        """
        super().__init__(component_name=component_name, message=message, errors=errors)


class ActivationError(RztdlException):
    """
    | **@author:** Prathyush SP
    |
    | Activation Error
    """

    def __init__(self, component_name: str, message: str, errors=None):
        """

        :param component_name: Component Name
        :param message: Error Message
        :param errors: Errors
        """
        super().__init__(component_name=component_name, message=message, errors=errors)


class NormalizationError(RztdlException):
    """
    | **@author:** Prathyush SP
    |
    | Normalization Error
    """

    def __init__(self, component_name: str, message: str, errors=None):
        """

        :param component_name: Component Name
        :param message: Error Message
        :param errors: Errors
        """
        super().__init__(component_name=component_name, message=message, errors=errors)


class RangeError(RztdlException):
    """
    | **@author:** Prathyush SP
    |
    | Range Error
    """

    def __init__(self, component_name: str, message: str, errors=None):
        """

        :param component_name: Component Name
        :param message: Message
        :param errors: Errors
        """
        super().__init__(component_name=component_name, message=message, errors=errors)


class DimensionError(RztdlException):
    """
    | **@author:** Prathyush SP
    |
    | Dimension Error
    """

    def __init__(self, component_name: str, message: str, errors=None):
        """

        :param component_name: Component Name
        :param message: Error Message
        :param errors: Errors
        """
        super().__init__(component_name=component_name, message=message, errors=errors)


class SizeError(RztdlException):
    """
    | **@author:** Prathyush SP
    |
    | Size Validation.
    """

    def __init__(self, component_name: str, message: str, errors=None):
        """

        :param component_name: Component Name
        :param message: Error Message
        :param errors: Errors
        """
        super().__init__(component_name=component_name, message=message, errors=errors)


class LayerException(RztdlException):
    """
    | **@author:** Prathyush SP
    |
    | Layer Exception.
    """

    def __init__(self, component_name: str, message: str, errors=None):
        """

        :param component_name: Component Name
        :param message: Error Message
        :param errors: Errors
        """
        super().__init__(component_name=component_name, message=message, errors=errors)


class ModelException(RztdlException):
    """
    | **@author:** Prathyush SP
    |
    | Model Exception.
    """

    def __init__(self, model_name: str, message: str, errors=None):
        """

        :param model_name: Model Name
        :param message: Error Message
        :param errors: Errors
        """
        super().__init__(component_name=model_name, message=message, errors=errors)


class ComponentException(RztdlException):
    """
    | **@author:** Prathyush SP
    |
    | Component Exception.
    """

    def __init__(self, component_name: str, message: str, errors=None):
        """

        :param component_name: Component Name
        :param message: Error Message
        :param errors: Errors
        """
        super().__init__(component_name=component_name, message=message, errors=errors)


class OperatorException(Exception):
    """
    | **@author:** Prathyush SP
    |
    | Operator Exception.
    """

    def __init__(self, message: str, errors=None):
        super(OperatorException, self).__init__(message)
        self.errors = errors


class DataFeedException(Exception):
    """
    | **@author:** Prathyush SP
    |
    | Exception caused due to mismatch of feed data and placeholders
    """

    def __init__(self, message: str, errors=None):
        super(DataFeedException, self).__init__(message)
        self.errors = errors


class InsufficientData(Exception):
    """
    | **@author:** Prathyush SP
    |
    | Exception caused due to Insufficient data fed to placeholders
    """

    def __init__(self, message: str, errors=None):
        super(InsufficientData, self).__init__(message)
        self.errors = errors


class DatasetException(RztdlException):
    """
    | **@author:** Prathyush SP
    |
    | Exception caused due to Insufficient data fed to placeholders
    """

    def __init__(self, component_name: str, message: str, errors=None):
        """

        :param component_name: Component Name
        :param message: Error Message
        :param errors: Errors
        """
        super().__init__(component_name=component_name, message=message, errors=errors)


class DatasetSplitException(RztdlException):
    """
    | **@author:** Prathyush SP
    |
    | Exception caused due to Insufficient data fed to placeholders
    """

    def __init__(self, component_name: str, message: str, errors=None):
        """

        :param component_name: Component Name
        :param message: Error Message
        :param errors: Errors
        """
        super().__init__(component_name=component_name, message=message, errors=errors)


class HookException(Exception):
    """
    | **@author:** Prathyush SP
    |
    | Hook Exception
    """

    def __init__(self, message: str, errors=None):
        super(HookException, self).__init__(message)
        self.errors = errors


class FlowException(RztdlException):
    """
    | **@author:** Prathyush SP
    |
    | Flow Exception
    """

    def __init__(self, component_name: str, message: str, errors=None):
        """

        :param component_name: Component Name
        :param message: Error Message
        :param errors: Errors
        """
        super().__init__(component_name=component_name, message=message, errors=errors)


def keyexception(f, always: bool = False):
    """
    | **@author:** Prathyush SP
    |
    | Key Exception Decorator.
    :param f: Function
    :return: Function Return Parameter
    """

    if f is None:
        return partial(raises_exception, always=always)

    @wraps(f)
    def wrapped(*args, **kwargs):
        try:
            r = f(*args, **kwargs)
            return r
        except KeyError as ke:
            # logger.error('Key Error - Attribute: {} Value:{}'.format(
            #     [k for k, v in kwargs.items() if v == ke.__str__().strip().replace('\'', '')], ke))
            raise KeyError('Key Error', ke)

    return wrapped


def value_exception(f, always: bool = False):
    """
    | **@author:** Prathyush SP
    |
    | Value Exception Decorator.
    :param f: Function
    :return: Function Return Parameter
    """

    if f is None:
        return partial(raises_exception, always=always)

    @wraps(f)
    def wrapped(*args, **kwargs):
        try:
            r = f(*args, **kwargs)
            return r
        except ValueError as ve:
            logger.error('Value Error - {}'.format(ve))
            raise Exception('Value Error', ve)

    return wrapped


def raises_exception(f=None, exceptions: typing.Tuple[BaseException] = None, always: bool = False,
                     log_exception: bool = True):
    """
    | **@author:** Prathyush SP
    |
    | Custom Exception Decorator.
    :param f:
    :param exceptions:
    :param always:
    :return:
    """
    if f is None:
        return partial(raises_exception, exceptions=exceptions, always=always, log_exception=log_exception)

    @wraps(f)
    def wrapped(*args, **kwargs):
        try:
            r = f(*args, **kwargs)
            return r
        except exceptions as e:
            if log_exception:
                logger.error('Exception: {}\nTraceback:\n{}'.format(e, traceback.format_exc()))
            raise type(e)(e)

    return wrapped


class SplitException(RztdlException):
    """
    | **@author:** Prathyush SP
    |
    | Component Exception.
    """

    def __init__(self, component_name: str, message: str, errors=None):
        """

        :param component_name: Component Name
        :param message: Error Message
        :param errors: Errors
        """
        super().__init__(component_name=component_name, message=message, errors=errors)
