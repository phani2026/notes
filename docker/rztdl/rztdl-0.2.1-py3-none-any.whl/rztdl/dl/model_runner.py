# -*- coding: utf-8 -*-
"""
| **@created on:** 17/05/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| Model Runner Module
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

__all__ = ['ModelRunner']

from rztdl.utils.validations import validate_name
from typeguard import typechecked
import logging
from rztdl.dl.dl_hooks.dl_hook_runners.model_runner_hooks_runner import model_runner_hooks_runner
from rztdl.dl.dl_hooks.dl_hook_runners.flow_hooks_runner import flow_hooks_runner
from rztdl.hooks.hooks_manager import hooks_manager
from rztdl.utils.string_constants import Hook
from collections import OrderedDict
from rztdl.dl.flows.flow import Flow
from rztdl.dl.model import Model
from rztdl.dl.stores import METRIC_STORE
from weakref import ref

logger = logging.getLogger(__name__)


class ModelRunner(object):
    """
    | **@author:** Prathyush SP
    |
    | Used to define a deeplearning Model
    """

    @typechecked
    def __init__(self, name: str, model: Model):
        """
        :param name: Model Name
        :param model: Model Object
        """
        # todo: Prathyush SP - Expose session: tf.Session = None, init: bool = True,init_operation: tf.Operation = None parameters, when tf.dataset API issues are resolved

        self.name = validate_name(name)
        self.model = model
        self.flow_id = 0
        self._flow = Flow
        self.flow_dict = OrderedDict()
        # self.init_op = init_operation.name if isinstance(init_operation, tf.Operation) else init_operation
        # self.init = init
        # self.session = session
        self.validate()
        self.metric_store = METRIC_STORE.add_model_runner(model_name=model.name, model_runner_name=self.name)

        # Model Runner begin hook runner
        model_runner_hooks_runner.run(
            hook_with_conditions=hooks_manager.fetch_hook(hook_type=Hook.HookType.ModelRunnerHook,
                                                          hook_pos=Hook.HookPosition.BeginHook), hook_argument=self)

    def __enter__(self):
        """
        | **@author:** Prathyush SP
        |
        | Default enter method used in conjunction with `with` block
        :return: Model Runner
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        | **@author:** Prathyush SP
        |
        | Default exit method used in conjunction with `with` block
        """
        self.close()

    def close(self):
        """
        | **@author:** Prathyush SP
        |
        | Model runer cleanup method
        """
        # self.session.close()
        # Model Runner end hook runner
        model_runner_hooks_runner.run(
            hook_with_conditions=hooks_manager.fetch_hook(hook_type=Hook.HookType.ModelRunnerHook,
                                                          hook_pos=Hook.HookPosition.EndHook), hook_argument=self)
        return self

    def run_flow(self, flow: Flow):
        """
        | **@author:** Prathyush SP
        |
        | Add Component
        :param flow: Operator
        :returns: Component Output
        """

        self.flow_id += 1

        # operator begin hook runner
        flow_hooks_runner.run(
            hook_with_conditions=hooks_manager.fetch_hook(hook_type=Hook.HookType.FlowHook,
                                                          hook_pos=Hook.HookPosition.BeginHook),
            hook_argument=self._flow)
        self._flow = flow.run_flow(model=self.model, previous_flow=self._flow,
                                   flow_id=self.flow_id, metric_store=self.metric_store, model_runner=ref(self))
        flow_hooks_runner.run(
            hook_with_conditions=hooks_manager.fetch_hook(hook_type=Hook.HookType.FlowHook,
                                                          hook_pos=Hook.HookPosition.EndHook),
            hook_argument=self._flow)
        self._flow.close()
        flow_hooks_runner.run(
            hook_with_conditions=hooks_manager.fetch_hook(hook_type=Hook.HookType.FlowHook,
                                                          hook_pos=Hook.HookPosition.CloseHook),
            hook_argument=self._flow)
        return {"status": "completed"}

    # todo: Prathyush SP - Model Runner global session deprecated unless tf.dataset API issues are resolved.
    # def get_or_create_session(self) -> tf.Session:
    #     """
    #     | **@author:** Prathyush SP
    #     |
    #     | Session Management
    #     :return: Tensorflow Session
    #     """
    #     # todo: Prathyush SP - Fix this function
    #     if self.init:
    #         if self.init_op is None:
    #             logger.debug('Initializing session with default init_op . . .')
    #             self.init_op = tf.group(tf.global_variables_initializer(), tf.local_variables_initializer()).name
    #         else:
    #             logger.debug('Initializing session with given init_op . . .')
    #
    #     if isinstance(self.session, tf.Session):
    #         logger.debug('Using external session . . .')
    #     else:
    #         logger.debug('Creating a new Session  . . .')
    #         self.session = tf.Session()
    #
    #     if self.init_op is not None:
    #         self.session.run(GraphUtils.get_operation(self.init_op))
    #
    #     return self.session

    def validate(self):
        """
        | **@author:** Prathyush SP
        |
        | Model Validation
        """
        # todo: Prathyush SP - Validate Model Runner
        # self.session = self.get_or_create_session()
        pass
