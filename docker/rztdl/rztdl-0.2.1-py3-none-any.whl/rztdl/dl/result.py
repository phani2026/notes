# -*- coding: utf-8 -*-
"""
| **@created on:** 12/03/17,
| **@author:** Prathyush SP,
| **@version:** v0.0.2
|
| Description: Result Helpers
|
| Sphinx Documentation Status: Complete
|
..todo::
    
"""

import json
import logging
from collections import OrderedDict
from typing import Union

from collections import defaultdict
from rztdl import RZTDL_CONFIG
from rztdl import RZTDL_STORE
from rztdl.utils.pyutils import DLTimer
from rztdl.utils.string_constants import ModelMetaConstant
from typeguard import typechecked

logger = logging.getLogger(__name__)


class Result(object):
    """
    | **@author:** Prathyush SP
    |
    | Result Helper Class
    """

    def __init__(self, model_name, network_name, epoch: int, model_complexity: int, epoch_step: int,
                 evaluation_metrics: Union[list, None], learning_rate: float, cost: str, optimizer: str,
                 train_batch_size: int, train_batches: int, valid_batches: Union[int, None],
                 valid_batch_size: Union[int, None], test_batches: [int, None],
                 test_batch_size: Union[int, None], timestamp: str):
        """
        :param model_name:  Model Name
        :param network_name: Network Name
        :param epoch: Epoch
        :param epoch_step: Display Step
        :param learning_rate: Learning Rate
        :param cost: Cost Function Used
        :param optimizer: Optimizer Used
        :param train_batch_size: Train Batch Size
        :param train_batches: Train Batches
        :param valid_batch_size : Valid Batch Size
        :param valid_batches : Valid Batches
        :param test_batch_size : Test Batch Size
        :param test_batches : Test Batches
        :param timestamp: Timestamp YYYYMMDD_HHmmss
        :param save_path: Save Path
        """
        self.eta = 0
        self.batch_eta = 0
        self.time_for_one_epoch = 0
        self.time_for_one_batch = 0
        self.model_name = model_name
        self.epoch = epoch
        self.evaluation_metrics = list(evaluation_metrics)

        # Initialize Model parameters
        RZTDL_STORE.add_meta_data_dict(self.model_name,
                                       OrderedDict([('network_name', network_name), ('model_name', self.model_name),
                                                  ('timestamp', timestamp),
                                                  ('model_complexity', model_complexity),
                                                  (ModelMetaConstant.MODEL_ARCHITECTURE,
                                                   RZTDL_STORE.dag[self.model_name][
                                                       ModelMetaConstant.MODEL_ARCHITECTURE]),
                                                  ('timestamp', timestamp),
                                                  (ModelMetaConstant.MODEL_ARCHITECTURE,
                                                   RZTDL_STORE.dag[self.model_name][
                                                       ModelMetaConstant.MODEL_ARCHITECTURE]),
                                                  ('epochs', epoch),
                                                  ('epoch_step', epoch_step),
                                                  ('learning_rate', learning_rate),
                                                  ('cost', cost if isinstance(cost, str) else '--persistence-training'),
                                                  ('optimizer', optimizer if isinstance(optimizer,
                                                                                        str) else '--persistence-training'),
                                                  ('train_batch_size', train_batch_size),
                                                  ('train_batches', train_batches),
                                                  ('valid_batch_size', valid_batch_size),
                                                  ('valid_batches', valid_batches),
                                                  ('test_batch_size', test_batch_size),
                                                  ('test_batches', test_batches),
                                                  ('path',
                                                   OrderedDict([('dl_save_path',
                                                                 RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_DL),
                                                                ('ml_save_path',
                                                                 RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_ML),
                                                                ('data_save_path',
                                                                 RZTDL_CONFIG.CommonConfig.PATH_DATA),
                                                                ('graph_save_path',
                                                                 RZTDL_CONFIG.CommonConfig.PATH_GRAPH)]))]))

        # Initialize Placeholders, Weights, Bias, Layers, TrainOP
        RZTDL_STORE.add_meta_data_dict(self.model_name, OrderedDict([(ModelMetaConstant.PLACEHOLDERS,
                                                                      RZTDL_STORE.dag[self.model_name][
                                                                        ModelMetaConstant.PLACEHOLDERS]),
                                                                     (ModelMetaConstant.DROPOUT_PLACEHOLDERS,
                                                                      RZTDL_STORE.dag[self.model_name][
                                                                        ModelMetaConstant.DROPOUT_PLACEHOLDERS]),
                                                                     (ModelMetaConstant.PREDICTION_PLACEHOLDERS,
                                                                      RZTDL_STORE.dag[self.model_name][
                                                                        ModelMetaConstant.PREDICTION_PLACEHOLDERS]),
                                                                     (ModelMetaConstant.WEIGHTS,
                                                                      RZTDL_STORE.dag[self.model_name][
                                                                        ModelMetaConstant.WEIGHTS]),
                                                                     (ModelMetaConstant.BIAS,
                                                                      RZTDL_STORE.dag[self.model_name][
                                                                        ModelMetaConstant.BIAS]),
                                                                     (ModelMetaConstant.LAYERS,
                                                                      RZTDL_STORE.dag[self.model_name][
                                                                        ModelMetaConstant.LAYERS]),
                                                                     (ModelMetaConstant.TRAIN_OP,
                                                                      RZTDL_STORE.dag[self.model_name][
                                                                        ModelMetaConstant.TRAIN_OP])]))
        # Initialize Metas
        RZTDL_STORE.add_meta_data_dict(self.model_name,
                                       OrderedDict(
                                         [(ModelMetaConstant.TRAIN_META, OrderedDict()),
                                          (ModelMetaConstant.TEST_META, OrderedDict()),
                                          (ModelMetaConstant.VALID_META, OrderedDict()),
                                          ]))

        RZTDL_STORE.add_result_meta_data_dict(model_name=self.model_name, mode=ModelMetaConstant.TRAIN_META,
                                              item=OrderedDict([(i, []) for i in (
                                                ['epochs', 'epoch_progress', 'epoch_eta', 'epoch_time_elapsed'])]))
        metrics = []
        for metric in self.evaluation_metrics:
            metrics.append(metric.name)

        RZTDL_STORE.add_metrics_to_meta_data(model_name=self.model_name, mode=ModelMetaConstant.TRAIN_META,
                                             key="epoch_metrics", value=metrics, metric_constant="epoch_")
        RZTDL_STORE.add_metrics_to_meta_data(model_name=self.model_name, mode=ModelMetaConstant.VALID_META,
                                             key="epoch_metrics", value=metrics, metric_constant="valid_")
        #
        RZTDL_STORE.add_result_meta_data_dict(model_name=self.model_name, mode=ModelMetaConstant.TEST_META,
                                              item=OrderedDict([(i, '') for i in (
                                                ['test_time_elapsed'])]))
        RZTDL_STORE.add_result_meta_data_dict(model_name=self.model_name, mode=ModelMetaConstant.TRAIN_META,
                                              item=OrderedDict([(i, []) for i in (
                                                ['batch_id', 'batch_eta', 'batch_progress', 'batch_time_elapsed'])]))
        RZTDL_STORE.add_result_meta_data_dict(model_name=self.model_name, mode=ModelMetaConstant.VALID_META,
                                              item=OrderedDict([(i, []) for i in (
                                                ['batch_id', 'batch_eta', 'batch_progress', 'batch_time_elapsed'])]))
        RZTDL_STORE.add_result_meta_data_dict(model_name=self.model_name, mode=ModelMetaConstant.TEST_META,
                                              item=OrderedDict([(i, []) for i in (
                                                ['batch_id', 'batch_eta', 'batch_progress', 'batch_time_elapsed'])]))
        RZTDL_STORE.add_metrics_to_meta_data(model_name=self.model_name, mode=ModelMetaConstant.TRAIN_META,
                                             key="batch_metrics", value=metrics, metric_constant="batch_")
        RZTDL_STORE.add_metrics_to_meta_data(model_name=self.model_name, mode=ModelMetaConstant.VALID_META,
                                             key="batch_metrics", value=metrics, metric_constant="batch_")

    def get_epoch_result(self, each_epoch: int, train_time: DLTimer, epoch: int, evaluation_metrics_switch,
                         json_type: bool = False, log=False):
        """
        | **@author:** Prathyush SP
        |
        | Used to fetch result of an epoch
        :param evaluation_metrics_switch: Evaluation metrics switch
        :param each_epoch: Epoch ID
        :param train_time: Train Time [DLTimer Class object]
        :param epoch: Total Epochs
        :param json_type: Format output as JSON String (Boolean)
        :param log: Log the results
        """
        if each_epoch == 0:
            self.time_for_one_epoch = train_time.get_elapsed_time()
            self.eta = train_time.get_elapsed_time() * epoch
        if self.eta < train_time.get_elapsed_time():
            self.eta += (self.time_for_one_epoch * (epoch - each_epoch))
        eta = str(self.eta - train_time.get_elapsed_time())
        epoch_dictionary = {'epoch_metrics': {}}
        valid_dictionary = {'epoch_metrics': {}}
        for metric in self.evaluation_metrics:
            metric = metric.name
            epoch_dictionary['epoch_metrics']['epoch_' + metric] = evaluation_metrics_switch[metric].epoch_result_value[
                -1]
            valid_dictionary['epoch_metrics']['valid_' + metric] = \
                evaluation_metrics_switch[metric].valid_result_value[-1] if len(
                    evaluation_metrics_switch[metric].valid_result_value) != 0 else None
        if log:
            epoch_item = OrderedDict(
                [('epochs', each_epoch)] + [(k, v) for k, v in epoch_dictionary['epoch_metrics'].items()] +
                [(k, v) for k, v in valid_dictionary['epoch_metrics'].items()] + [
                    ('epoch_progress', each_epoch / (epoch - (1 if epoch > 1 else 0)) * 100),
                    ('epoch_eta', eta), ('epoch_time_elapsed', str(train_time.get_elapsed_time()))
                ])
            print_item = ['Epoch'] + [x for x, v in epoch_dictionary['epoch_metrics'].items()] + \
                         [x for x, v in valid_dictionary['epoch_metrics'].items()] + [
                             'Progress', 'ETA', 'Time Elapsed']
            if json_type:
                logger.info(json.dumps(OrderedDict(
                    [((key, v[key]['value']) for key in v.keys()) if isinstance(v, defaultdict) else (k, v) for k, v in
                     epoch_item.items()])))
            else:
                logger.info(', '.join(
                    [": ".join([print_item[e], '{0:.2f}'.format(i[1]) if isinstance(i[1], float) else str(i[1])]) for
                     e, i in enumerate(epoch_item.items()) if
                     i[1] is not None]))
        for metric in self.evaluation_metrics:
            metric = metric.name
            epoch_dictionary['epoch_metrics']['epoch_' + metric] = evaluation_metrics_switch[metric]
            valid_dictionary['epoch_metrics']['valid_' + metric] = evaluation_metrics_switch[metric]
        epoch_item = OrderedDict(
            [('epochs', each_epoch)] + [(k, v) for k, v in epoch_dictionary.items()] +
            [('epoch_progress', each_epoch / (epoch - (1 if epoch > 1 else 0)) * 100),
             ('epoch_eta', eta), ('epoch_time_elapsed', str(train_time.get_elapsed_time()))
             ])
        valid_item = OrderedDict([(k, v) for k, v in valid_dictionary.items()])
        RZTDL_STORE.append_value_to_result_dict(model_name=self.model_name, mode=ModelMetaConstant.TRAIN_META,
                                                item=epoch_item)
        RZTDL_STORE.append_value_to_result_dict(model_name=self.model_name, mode=ModelMetaConstant.VALID_META,
                                                item=valid_item)

    def get_batch_result(self, batch_id: int, train_time: DLTimer, mode, evaluation_metrics_switch, train_batches: int,
                         json_type: bool = False, log=False):
        """
        | **@author:** Prathyush SP
        |
        | Used to fetch batch results
        :param evaluation_metrics_switch: Evaluation metrics switch
        :param mode: which mode whether TRAIN or VALID or TEST
        :param batch_id: Batch ID
        :param train_time: Train time [DLTimer Object]
        :param train_batches: Train Batches
        :param json_type: Format output as JSON String (Boolean)
        :param log: Log the Results
        """
        if batch_id == 0:
            self.time_for_one_batch = train_time.get_elapsed_time()
            self.batch_eta = train_time.get_elapsed_time() * train_batches
        if self.batch_eta < train_time.get_elapsed_time():
            self.batch_eta += (self.time_for_one_batch * (train_batches - batch_id))
        batch_eta = str(self.batch_eta - train_time.get_elapsed_time())
        batch_dictionary = {'batch_metrics': {}}
        for metric in self.evaluation_metrics:
            metric = metric.name
            batch_dictionary["batch_metrics"]['batch_' + metric] = \
                evaluation_metrics_switch[metric].metric_value[mode][ModelMetaConstant.BATCH_METRICS][-1]
        if log:
            print_item = ['Batch'] + [x for x in batch_dictionary['batch_metrics']] + ['Progress', 'ETA',
                                                                                       'Time Elapsed']
            batch_item = OrderedDict(
                [('batch_id', batch_id)] + [(k, v) for k, v in batch_dictionary["batch_metrics"].items()] + [
                    ('batch_progress', batch_id / (
                        train_batches * self.epoch - (1 if train_batches > 1 else 0)) * 100), ('batch_eta', batch_eta),
                    ('batch_time_elapsed', str(train_time.get_elapsed_time()))])
            if json_type:
                logger.info(json.dumps(OrderedDict([(k, v) for k, v in batch_item.items()])))
            else:
                logger.info(', '.join(
                    [": ".join([print_item[e], '{0:.2f}'.format(i[1]) if isinstance(i[1], float) else str(i[1])]) for
                     e, i in enumerate(batch_item.items()) if
                     i[1] is not None]))
        batch_dictionary = {'batch_metrics': {}}
        for metric in self.evaluation_metrics:
            metric = metric.name
            batch_dictionary["batch_metrics"]['batch_' + metric] = evaluation_metrics_switch[metric]
        batch_item = OrderedDict(
            [('batch_id', batch_id)] + [(k, v) for k, v in batch_dictionary.items()] + [
                ('batch_progress',
                 batch_id / (train_batches * self.epoch - (1 if train_batches > 1 else 0)) * 100),
                ('batch_eta', batch_eta), ('batch_time_elapsed', str(train_time.get_elapsed_time()))])
        RZTDL_STORE.append_value_to_result_dict(model_name=self.model_name, mode=mode,
                                                item=batch_item)

    @typechecked
    def get_test_result(self, test_time: DLTimer, evaluation_metrics_switch, json_type: bool = False, log=True):
        """
        | **@author:** Prathyush SP
        |
        | Used to fetch test result
        :param evaluation_metrics_switch: Evaluation metrics switch
        :param test_time: Test Time (DLTimer Object)
        :param json_type: Format output as JSON String (Boolean)
        :param log: Log the Results
        :return:
        """

        RZTDL_STORE.add_metrics_to_meta_data(model_name=self.model_name, mode=ModelMetaConstant.TEST_META,
                                             key="test_metrics", metric_constant="test_",
                                             value=[metric.name for metric in self.evaluation_metrics])
        test_dictionary = {'test_metrics': {}}
        for metric in self.evaluation_metrics:
            metric = metric.name
            test_dictionary['test_metrics']['test_' + metric] = evaluation_metrics_switch[metric].test_result_value[-1]
        if log:
            epoch_item = OrderedDict([(k, v) for k, v in test_dictionary['test_metrics'].items()] +
                                     [('test_time_elapsed', str(test_time.get_elapsed_time()))])
            print_item = [x for x, v in test_dictionary['test_metrics'].items()] + ['Time Elapsed']
            if json_type:
                logger.info(json.dumps(OrderedDict(
                    [(k, v) if not isinstance(k, OrderedDict) else [(key, k[key]['value']) for key in k.keys()] for k, v
                     in epoch_item.items()])))
            else:
                epoch_item = OrderedDict([(k, v) for k, v in test_dictionary['test_metrics'].items()] +
                                         [('test_time_elapsed', str(test_time.get_elapsed_time()))])
                logger.info(', '.join(
                    [": ".join([print_item[e], '{0:.2f}'.format(i[1]) if isinstance(i[1], float) else str(i[1])]) for
                     e, i in enumerate(epoch_item.items()) if i[1] is not None]))
        for metric in self.evaluation_metrics:
            metric = metric.name
            test_dictionary['test_metrics']['test_' + metric] = evaluation_metrics_switch[metric]
        test_item = OrderedDict([(k, v) for k, v in test_dictionary.items()] +
                                [('test_time_elapsed', str(test_time.get_elapsed_time()))])
        RZTDL_STORE.set_value_to_result_dict(model_name=self.model_name, mode=ModelMetaConstant.TEST_META,
                                             item=test_item)
