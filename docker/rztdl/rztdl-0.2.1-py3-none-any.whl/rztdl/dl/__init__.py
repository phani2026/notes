# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
|
| **Sphinx Documentation Status:**
|
..todo::
"""

from rztdl.dl.helpers.tfhelpers import TensorBoard, TFSummaries, TFTimeline, GraphUtils

# todo Prathyush SP: Check global usage of summary and timeline
tf_summary = TFSummaries()
tf_timeline = TFTimeline()
tf_graph_utils = GraphUtils()
from rztdl.dl.components import dl_layer as layer
from rztdl.dl.components import dl_operator as operator
from rztdl.dl.components import dl_cost as cost
from rztdl.dl.components import dl_optimizer as optimizers
from rztdl.dl.components import dl_buffer as buffer
from rztdl.dl.components import dl_metric as metric
from rztdl.dl import dataset as dataset
from rztdl.dl.model import Model
# from rztdl.dl.network import Network
from rztdl.dl.model_runner import ModelRunner
from rztdl.dl import flows as flow
# from rztdl.dl.predict import Prediction
# noinspection PyUnresolvedReferences
import rztdl.utils.string_constants as constants
# noinspection PyUnresolvedReferences
# import tensorflow.contrib
from rztdl.dl import dl_hooks as hooks



if __name__ == '__main__':
    print('rztdl.dl.__init__ success . . .')
