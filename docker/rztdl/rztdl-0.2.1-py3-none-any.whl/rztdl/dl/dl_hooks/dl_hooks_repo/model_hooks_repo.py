# -*- coding: utf-8 -*-
"""
| **@created on:** 17/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

__all__ = ['model_begin_hook', 'model_update_hook', 'model_close_hook']

from functools import partial, wraps
from rztdl.hooks import hook_controller
from rztdl.hooks.hooks_manager import wrap
from rztdl.utils.string_constants import Hook


# noinspection PyUnusedLocal
@hook_controller(hook_type=Hook.HookType.ModelHook, hook_pos=Hook.HookPosition.BeginHook, wrap_fn=wrap)
def model_begin_hook(func=None, always: bool = False, model_name: str = None):
    """
    | **author:** Prathyush SP
    |
    | Hook called during Initialization of Model
    | Note: Follows Decorator design
    :param func: Customer Function
    :param always: Debug related variable
    :param model_name: Model Name Restriction
    :return: Decorator Wrapper
    """
    if not __debug__ and not always:  # pragma: no cover
        return func
    if func is None:
        return partial(model_begin_hook, always=always)

    # noinspection PyUnusedLocal
    @wraps(func)
    def wrapper(*args, **kwargs):
        """
        | **author:** Prathyush SP
        |
        | Wrapped Decorator
        :param args: Function args
        :param kwargs: Function kwargs
        :return: Function
        """
        return func

    return wrapper


# noinspection PyUnusedLocal
@hook_controller(hook_type=Hook.HookType.ModelHook, hook_pos=Hook.HookPosition.CloseHook, wrap_fn=wrap)
def model_close_hook(func=None, always: bool = False, model_name: str = None):
    """
    | **author:** Prathyush SP
    |
    | Hook called on Model Close
    | Note: Follows Decorator design
    :param func: Customer Function
    :param always: Debug related variable
    :param model_name: Model Name Restriction
    :return: Decorator Wrapper
    """
    if not __debug__ and not always:  # pragma: no cover
        return func
    if func is None:
        return partial(model_close_hook, always=always)

    # noinspection PyUnusedLocal
    @wraps(func)
    def wrapper(*args, **kwargs):
        """
        | **author:** Prathyush SP
        |
        | Wrapped Decorator
        :param args: Function args
        :param kwargs: Function kwargs
        :return: Function
        """
        return func

    return wrapper


# noinspection PyUnusedLocal
@hook_controller(hook_type=Hook.HookType.ModelHook, hook_pos=Hook.HookPosition.UpdateHook, wrap_fn=wrap)
def model_update_hook(func=None, always: bool = False, model_name: str = None):
    """
    | **author:** Prathyush SP
    |
    | Hook called on Model Update / Change
    | Note: Follows Decorator design
    :param func: Customer Function
    :param always: Debug related variable
    :param model_name: Model Name Restriction
    :return: Decorator Wrapper
    """
    if not __debug__ and not always:  # pragma: no cover
        return func
    if func is None:
        return partial(model_update_hook, always=always)

    # noinspection PyUnusedLocal
    @wraps(func)
    def wrapper(*args, **kwargs):
        """
        | **author:** Prathyush SP
        |
        | Wrapped Decorator
        :param args: Function args
        :param kwargs: Function kwargs
        :return: Function
        """
        return func

    return wrapper
