# -*- coding: utf-8 -*-
"""
| **@created on:** 17/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

__all__ = ['component_begin_hook', 'component_end_hook']

from functools import partial, wraps
from rztdl.hooks import hook_controller
from rztdl.hooks.hooks_manager import wrap
from rztdl.utils.string_constants import Hook


# noinspection PyUnusedLocal
@hook_controller(hook_type=Hook.HookType.ComponentHook, hook_pos=Hook.HookPosition.BeginHook, wrap_fn=wrap)
def component_begin_hook(func=None, always: bool = False, component_name: str = None, component_type: str = None,
                         component_sub_type: str = None, model_name: str = None):
    """
    | **author:** Prathyush SP
    |
    | Hook called during initialization of Component
    | Note: Follows Decorator design
    :param func: Customer Function
    :param always: Debug related variable
    :param component_name: Component Name Restriction
    :param component_type: Component Type Restriction
    :param model_name: Model Name Restriction
    :param component_sub_type: Component Sub Type
    :return: Decorator Wrapper
    """
    if not __debug__ and not always:  # pragma: no cover
        return func
    if func is None:
        return partial(component_begin_hook, always=always)

    # noinspection PyUnusedLocal
    @wraps(func)
    def wrapper(*args, **kwargs):
        """
        | **author:** Prathyush SP
        |
        | Wrapped Decorator
        :param args: Function args
        :param kwargs: Function kwargs
        :return: Function
        """
        return func

    return wrapper


# noinspection PyUnusedLocal
@hook_controller(hook_type=Hook.HookType.ComponentHook, hook_pos=Hook.HookPosition.EndHook, wrap_fn=wrap)
def component_end_hook(func=None, always: bool = False, component_name: str = None, component_type: str = None,
                       component_sub_type: str = None, model_name: str = None):
    """
    | **author:** Prathyush SP
    |
    | Hook called during completion of Component
    | Note: Follows Decorator design
    :param func: Customer Function
    :param always: Debug related variable
    :param component_name: Component Name Restriction
    :param component_type: Component Type Restriction
    :param model_name: Model Name Restriction
    :param component_sub_type: Component Sub Type
    :return: Decorator Wrapper
    """
    if not __debug__ and not always:  # pragma: no cover
        return func
    if func is None:
        return partial(component_end_hook, always=always)

    # noinspection PyUnusedLocal
    @wraps(func)
    def wrapper(*args, **kwargs):
        """
        | **author:** Prathyush SP
        |
        | Wrapped Decorator
        :param args: Function args
        :param kwargs: Function kwargs
        :return: Function
        """
        return func

    return wrapper
