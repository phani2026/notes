# -*- coding: utf-8 -*-
"""
| **@created on:** 17/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

__all__ = ['flow_begin_hook', 'flow_update_hook', 'flow_end_hook']

from functools import partial, wraps
from rztdl.hooks import hook_controller
from rztdl.hooks.hooks_manager import wrap
from rztdl.utils.string_constants import Hook


# noinspection PyUnusedLocal
@hook_controller(hook_type=Hook.HookType.FlowHook, hook_pos=Hook.HookPosition.BeginHook, wrap_fn=wrap)
def flow_begin_hook(func=None, always: bool = False, model_runner_name: str = None, flow_name: str = None):
    """
    | **author:** Prathyush SP
    |
    | Hook called on Model Update / Change
    | Note: Follows Decorator design
    :param func: Customer Function
    :param always: Debug related variable
    :return: Decorator Wrapper
    """
    if not __debug__ and not always:  # pragma: no cover
        return func
    if func is None:
        return partial(flow_begin_hook, always=always)

    # noinspection PyUnusedLocal
    @wraps(func)
    def wrapper(*args, **kwargs):
        """
        | **author:** Prathyush SP
        |
        | Wrapped Decorator
        :param args: Function args
        :param kwargs: Function kwargs
        :return: Function
        """
        return func

    return wrapper


# noinspection PyUnusedLocal
@hook_controller(hook_type=Hook.HookType.FlowHook, hook_pos=Hook.HookPosition.EndHook, wrap_fn=wrap)
def flow_end_hook(func=None, always: bool = False, model_runner_name: str = None, flow_name: str = None):
    """
    | **author:** Prathyush SP
    |
    | Hook called on Model Update / Change
    | Note: Follows Decorator design
    :param func: Customer Function
    :param always: Debug related variable
    :return: Decorator Wrapper
    """
    if not __debug__ and not always:  # pragma: no cover
        return func
    if func is None:
        return partial(flow_begin_hook, always=always)

    # noinspection PyUnusedLocal
    @wraps(func)
    def wrapper(*args, **kwargs):
        """
        | **author:** Prathyush SP
        |
        | Wrapped Decorator
        :param args: Function args
        :param kwargs: Function kwargs
        :return: Function
        """
        return func

    return wrapper


# noinspection PyUnusedLocal
@hook_controller(hook_type=Hook.HookType.FlowHook, hook_pos=Hook.HookPosition.UpdateHook, wrap_fn=wrap)
def flow_update_hook(func=None, always: bool = False, model_runner_name: str = None,
                     flow_name: str = None, interval: int = 1, interval_type: str = 'epoch'):
    """
    | **author:** Prathyush SP
    |
    | Hook called on Model Update / Change
    | Note: Follows Decorator design
    :param func: Customer Function
    :param always: Debug related variable
    :return: Decorator Wrapper
    """
    if not __debug__ and not always:  # pragma: no cover
        return func
    if func is None:
        return partial(flow_begin_hook, always=always)

    # noinspection PyUnusedLocal
    @wraps(func)
    def wrapper(*args, **kwargs):
        """
        | **author:** Prathyush SP
        |
        | Wrapped Decorator
        :param args: Function args
        :param kwargs: Function kwargs
        :return: Function
        """
        return func

    return wrapper
