# -*- coding: utf-8 -*-
"""
| **@created on:** 17/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| Component Hooks Runner
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

__all__ = ['component_hooks_runner']

from typeguard import typechecked
from rztdl.dl.components import Component
from rztdl.hooks import HooksRunner
from rztdl.utils.string_constants import Hook
from rztdl.utils.singleton import Singleton


class _ComponentHooksRunner(HooksRunner, metaclass=Singleton):
    """
    | **@author:** Prathyush SP
    |
    | Component Hooks Runner
    """

    @typechecked
    def __init__(self, name: str):
        """

        :param name: Hook Name
        """
        super().__init__(name=name, hook_type=Hook.HookRunnerTypes.ComponentHookRunner)

    @typechecked
    def validate_rules(self, hook_argument: Component, conditions: dict):
        """
        | **@author:** Prathyush SP
        |
        | Rules Validation
        :param hook_argument: Component Object
        :param conditions: Conditions for hook runnable
        :return: Boolean value
        """
        if Hook.HookRules.ComponentName in conditions:
            if not hook_argument.name == conditions[Hook.HookRules.ComponentName]:
                return False
        if Hook.HookRules.ComponentType in conditions:
            if not hook_argument.component_type == conditions[Hook.HookRules.ComponentType]:
                return False
        if Hook.HookRules.ComponentSubType in conditions:
            if not hook_argument.component_sub_type == conditions[Hook.HookRules.ComponentSubType]:
                return False
        if Hook.HookRules.ModelName in conditions:
            if not hook_argument.model_name == conditions[Hook.HookRules.ModelName]:
                return False
        return True


component_hooks_runner = _ComponentHooksRunner('global_component_hooks_runner')
