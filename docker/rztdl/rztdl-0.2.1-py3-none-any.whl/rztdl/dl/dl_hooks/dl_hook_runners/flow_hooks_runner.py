# -*- coding: utf-8 -*-
"""
| **@created on:** 17/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| Flow Hooks Runner
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

__all__ = ['flow_hooks_runner']

from rztdl.hooks import HooksRunner
from rztdl.utils.string_constants import Hook
from rztdl.utils.singleton import Singleton


class _FlowHooksRunner(HooksRunner, metaclass=Singleton):
    """
    | **@author:** Prathyush SP
    |
    | Model Runner Hooks Runner
    """

    def __init__(self, name: str):
        """

        :param name: Hook Name
        """
        super().__init__(name=name, hook_type=Hook.HookRunnerTypes.FlowHookRunner)

    def validate_rules(self, hook_argument, conditions: dict):
        """
        | **@author:** Prathyush SP
        |
        | Rules Validation
        :param hook_argument: Component Object
        :param conditions: Conditions for hook runnable
        :return: Boolean value
        """
        if Hook.HookRules.FlowHookRules.FlowName in conditions:
            if not hook_argument.name == conditions[Hook.HookRules.FlowHookRules.FlowName]:
                return False
        if Hook.HookRules.FlowHookRules.ModelRunnerName in conditions:
            if not hook_argument.model.name == conditions[Hook.HookRules.FlowHookRules.ModelRunnerName]:
                return False
        if Hook.HookRules.FlowHookRules.IntervalType in conditions:
            if not (hook_argument['interval_type'] == conditions[Hook.HookRules.FlowHookRules.IntervalType] and
                    hook_argument['interval'] % conditions[Hook.HookRules.FlowHookRules.Interval] == 0):
                return False
        return True


flow_hooks_runner = _FlowHooksRunner('global_flow_hooks_runner')
