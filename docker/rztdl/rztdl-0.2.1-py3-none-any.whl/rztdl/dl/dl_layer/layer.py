# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Layer Module used to create deeplearning layers. It consists of
| 1. Input Layer
| 2. Fully Connected Layer
| 3. Output Layer
| 4. Convolution Layer
| 5. Pool Layer
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

from abc import ABCMeta, abstractmethod
from typeguard import typechecked
from rztdl.utils.validations import validate_name
import logging

logger = logging.getLogger(__name__)


class Layer(metaclass=ABCMeta):
    """
    | **@author:** Prathyush SP
    |
    | Base class, which defines abstract methods for layers
    """

    @typechecked
    def __init__(self, name: str, layer_type: str):
        """
        :param name: Name for the Layer
        """
        self.name = validate_name(name)
        self.layer_output = None
        self.id = None
        self.layer_dropout = None
        self.layer_input = None
        self.model_name = None
        self.layer_nodes = None
        self.layer_type = layer_type

    @abstractmethod
    def create_layer(self, model_name, layer, layer_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Used to create a dl_layer
        :param model_name: Model name
        :param layer: Previous Layer
        :param layer_id: Layer Id
        """
        pass  # pragma: no cover

    @abstractmethod
    def validate(self):
        """
        | **@author:** Prathyush SP
        |
        | Validation Method
        """
        pass  # pragma: no cover
