# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Layer Module used to create deeplearning layers. It consists of
| 1. Input Layer
| 2. Fully Connected Layer
| 3. Output Layer
| 4. Convolution Layer
| 5. Pool Layer
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
from typing import Union
from rztdl import RZTDL_CONFIG, RZTDL_DAG
import rztdl.utils.string_constants as constants
from rztdl.dl import tf_summary
from tensorflow import Tensor
import tensorflow as tf
from typeguard import typechecked
import logging
from rztdl.utils.dl_exception import LayerException
from collections import OrderedDict
from rztdl.dl.dl_layer.layer import Layer

logger = logging.getLogger(__name__)


class BatchNormalisationLayer(Layer):
    """
    | **@author:** Umesh Kumar
    |
    | Batch Normalisation Layer

    """

    @typechecked
    def __init__(self, name: str, layer_input: Union[str, Tensor] = None, axis=-1, momentum=0.99, epsilon=0.001,
                 center=True, scale=True, beta_initializer=tf.zeros_initializer(),
                 gamma_initializer=tf.ones_initializer(), moving_mean_initializer=tf.zeros_initializer(),
                 moving_variance_initializer=tf.ones_initializer(), beta_regularizer=None, gamma_regularizer=None,
                 training=False, trainable=True, reuse=None, renorm=False, renorm_clipping=None, renorm_momentum=0.99):
        """
        :param name: Name of the Layer
        """
        super().__init__(name=name, layer_type=constants.LAYERS.BATCH_NORMALIZATION_LAYER)
        self.name = name
        self.id = None
        self.model_name = None
        self.layer_input = layer_input
        self.layer_output = None
        self.axis = axis
        self.momentum = momentum
        self.epsilon = epsilon
        self.center = center
        self.scale = scale
        self.beta_initializer = beta_initializer
        self.gamma_initializer = gamma_initializer
        self.moving_mean_initializer = moving_mean_initializer
        self.moving_variance_initializer = moving_variance_initializer
        self.beta_regularizer = beta_regularizer
        self.gamma_regularizer = gamma_regularizer
        self.training = training
        self.trainable = trainable
        self.reuse = reuse
        self.renorm = renorm
        self.prev_layer_nodes = None
        self.prev_layer_output = None
        self.renorm_clipping = renorm_clipping
        self.renorm_momentum = renorm_momentum

    @typechecked
    def create_layer(self, model_name: str, layer, layer_id: int):
        """
        | **@author:** Umesh Kumar
        | Creates Batch Normalisation Layer
        |
        :param model_name: Model Name
        :param layer: Previous Layer
        :param layer_id: Layer Id
        :return: Batch Normalisation Layer Object
        """
        self.id = layer_id
        self.model_name = model_name
        self.prev_layer_output = layer.layer_output
        self.prev_layer_nodes = layer.layer_nodes
        self.validate()
        with tf.name_scope(self.name + '/'):
            self.layer_output = tf.layers.batch_normalization(inputs=self.layer_input, axis=self.axis,
                                                              momentum=self.momentum, epsilon=self.epsilon,
                                                              center=self.center, scale=self.scale,
                                                              beta_initializer=self.beta_initializer,
                                                              gamma_initializer=self.gamma_initializer,
                                                              moving_mean_initializer=self.moving_mean_initializer,
                                                              moving_variance_initializer=self.moving_variance_initializer,
                                                              beta_regularizer=self.beta_regularizer,
                                                              gamma_regularizer=self.gamma_regularizer,
                                                              training=self.training, trainable=self.trainable,
                                                              name=self.name, reuse=self.reuse)
            layer_details = OrderedDict(
                [(constants.MODEL_ARCHITECTURE.LAYER_OUTPUT, self.layer_output.get_shape().as_list().__str__())])
            if RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY:
                tf_summary.create_variable_summaries(tensor=self.layer_output)
        RZTDL_DAG.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                            layer_details=layer_details)
        tf.add_to_collection(self.layer_output.name, self.layer_output)
        return self

    def validate(self):
        """
        | **@author:** Umesh Kumar
        |
        | Validation method for Batch Normalisation Layer
        """
        with tf.name_scope(self.name + '/'):
            if self.layer_input is not None:
                if isinstance(self.layer_input, Tensor):
                    self.prev_layer_nodes = self.layer_input.get_shape().as_list()[1]
                else:
                    self.layer_input = RZTDL_DAG.get_layer(self.model_name, self.layer_input)
                    self.prev_layer_nodes = self.layer_input.get_shape().as_list()[1]
            else:
                self.layer_input = self.prev_layer_output
            if self.prev_layer_output is None:
                raise LayerException('Previous Layer Output is None')
            if not self.prev_layer_nodes or self.prev_layer_nodes <= 0:
                raise LayerException('Previous Layer Nodes is None or <=0')
            logger.info("Batch Normalisation Layer validation success . . .")