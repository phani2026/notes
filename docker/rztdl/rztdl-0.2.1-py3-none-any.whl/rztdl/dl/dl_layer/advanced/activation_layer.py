# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Layer Module used to create deeplearning layers. It consists of
| 1. Input Layer
| 2. Fully Connected Layer
| 3. Output Layer
| 4. Convolution Layer
| 5. Pool Layer
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
from typing import Union
from rztdl import RZTDL_CONFIG, RZTDL_DAG
import rztdl.utils.string_constants as constants
from rztdl.dl import tf_summary
from tensorflow import Tensor
import tensorflow as tf
from typeguard import typechecked
import logging
from rztdl.utils.dl_exception import RangeError, ActivationError, LayerException
from rztdl.dl.helpers.tfhelpers import Activation
from collections import OrderedDict
from rztdl.dl.dl_layer.layer import Layer
import functools
from rztdl.utils.dl_exception import DimensionError
import operator

logger = logging.getLogger(__name__)


class ActivationLayer(Layer):
    """
    | **@author:** Himaprasoon PT
    |
    | Activation Layer
    """

    @typechecked
    def __init__(self, name, layer_activation: str = constants.ACTIVATION.SIGMOID,
                 layer_input: Union[str, Tensor] = None,
                 layer_dropout: Union[float, None] = None):
        """
        :param name: Layer Name
        :param layer_activation: Layer Activation
        :param layer_input: Layer Input
        :param layer_dropout: Layer Dropout
        """
        super().__init__(name=name, layer_type=constants.LAYERS.ACTIVATION_LAYER)
        self.layer_activation = layer_activation
        self.prev_layer_output = None
        self.prev_layer_nodes = None
        self.layer_output = None
        self.layer_dropout = layer_dropout
        self.layer_input = layer_input

    @typechecked
    def create_layer(self, model_name: str, layer, layer_id: int):
        """
        | **@author:** Himaprasoon PT
        |
        | Create Activation Layer
        :param model_name: Model Name
        :param layer: Previous Layer
        :param layer_id: Layer Id
        :return: Activation Layer Object
        """
        self.id = layer_id
        self.model_name = model_name
        self.prev_layer_output = layer.layer_output
        self.prev_layer_nodes = layer.layer_nodes
        self.validate()
        with tf.name_scope(self.name + '/'):
            self.layer_output = Activation(input_tensor=self.layer_input).parse_activation(
                activation_type=self.layer_activation)

            layer_details = OrderedDict(
                [(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.layer_type),
                 (constants.MODEL_ARCHITECTURE.LAYER_ACTIVATION, self.layer_activation),
                 (constants.MODEL_ARCHITECTURE.LAYER_OUTPUT, self.layer_output.get_shape().as_list().__str__())])
            if self.layer_dropout:
                dropout_placeholder = tf.placeholder(dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE)
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_DROPOUT] = self.layer_dropout
                tf.add_to_collection(dropout_placeholder.name, dropout_placeholder)
                RZTDL_DAG.add_dropout_placeholder(model_name=self.model_name, placeholder_name=dropout_placeholder.name,
                                                  value=self.layer_dropout)
                self.layer_output = tf.nn.dropout(self.layer_output, keep_prob=dropout_placeholder)
            if RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY:
                tf_summary.create_variable_summaries(tensor=self.layer_output)
        RZTDL_DAG.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                            layer_details=layer_details)
        tf.add_to_collection(self.layer_output.name, self.layer_output)
        return self

    def validate(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Activation Layer Validation
        """
        with tf.name_scope(self.name + '/'):
            if self.layer_input is not None:
                if isinstance(self.layer_input, Tensor):
                    self.prev_layer_nodes = self.layer_input.get_shape().as_list()[1]
                else:
                    self.layer_input = RZTDL_DAG.get_layer(self.model_name, self.layer_input)
                    self.prev_layer_nodes = self.layer_input.get_shape().as_list()[1]
            else:
                self.layer_input = self.prev_layer_output
            if self.prev_layer_output is None:
                raise LayerException('Previous Layer Output is None')
            if not self.prev_layer_nodes or self.prev_layer_nodes <= 0:
                raise LayerException('Previous Layer Nodes is None or <=0')
            self.layer_nodes = self.prev_layer_nodes
            if self.layer_activation not in constants.ACTIVATION.__dict__.values():
                raise ActivationError("Not a valid Activation. Usage: NeuralNetwork.ACTIVATION.<>")
            if self.layer_dropout and not (0 <= self.layer_dropout <= 1):
                raise RangeError("Layer Dropout should be between 0 and 1 Found:", self.layer_dropout)
