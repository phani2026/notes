# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Layer Module used to create deeplearning layers. It consists of
| 1. Input Layer
| 2. Fully Connected Layer
| 3. Output Layer
| 4. Convolution Layer
| 5. Pool Layer
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
from types import FunctionType
from typing import Union
from numpy import ndarray
from rztdl import RZTDL_CONFIG, RZTDL_DAG
import rztdl.utils.string_constants as constants
from rztdl.dl import tf_summary
from tensorflow import Tensor
from rztdl.dl.dl_dict_parsers import parse_initialization_dict
import tensorflow as tf
from typeguard import typechecked
import logging
from rztdl.utils.dl_exception import DTypeError, DimensionError, RangeError, ActivationError, NormalizationError, PaddingError, \
    LayerException, ParameterError
from rztdl.dl.helpers.tfhelpers import Activation
from collections import OrderedDict
from rztdl.dl.dl_layer.layer import Layer
from rztdl.dl.helpers.tfhelpers import NormalizationLayer

logger = logging.getLogger(__name__)


class ConvolutionLayer(Layer):
    """
    | **@author:** Prathyush SP
    |
    | Convolution Layer
    .. todo::
        Prathyush SP:
            1. Defaults for Layer filters, bias and activation
    """

    @typechecked
    def __init__(self, name: str, filter_dimensions: list,
                 filter_strides: list, filter_padding: str,
                 layer_activation=constants.ACTIVATION.RELU,
                 layer_filter: Union[ndarray, dict, FunctionType] = None,
                 layer_bias: Union[ndarray, dict, FunctionType] = None, layer_dropout: float = None,
                 norm_type: str = None,
                 norm_parameters: dict = None,
                 layer_input: Union[str, Tensor] = None):
        """
        :param name: Name of the Layer
        :param layer_activation: Activation function for the Layer
        :param filter_dimensions:  Filter Dimensions
        :param filter_strides: Strides for the Filter
        :param filter_padding: Filter Padding
        :param layer_bias: Bias for the Layer
        :param layer_filter: Filters for the Layer
        """
        super().__init__(name=name, layer_type=constants.LAYERS.CONVOLUTION_LAYER)
        self.layer_bias = layer_bias
        self.layer_activation = layer_activation
        self.layer_filter = layer_filter
        self.filter_dimensions = filter_dimensions
        self.filter_strides = filter_strides
        self.filter_padding = filter_padding
        self.layer_dropout = layer_dropout
        self.prev_layer_output = None
        self.prev_layer_nodes = None
        self.layer_output = None
        self.layer_nodes = None
        self.norm_type = norm_type
        self.norm_parameters = norm_parameters
        self.layer_input = layer_input

    @typechecked
    def create_layer(self, model_name: str, layer, layer_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Create Convolution Layer
        |
        :param model_name: Model Name
        :param layer: Previous Layer
        :param layer_id: Layer ID
        :return: Convolution Layer Object
        """
        self.model_name = model_name
        self.prev_layer_output = layer.layer_output
        self.prev_layer_nodes = layer.layer_nodes
        self.id = layer_id
        self.validate()
        with tf.name_scope(self.name + '/'):
            self.layer_output = Activation(input_tensor=
                                           tf.nn.bias_add(tf.nn.conv2d(self.prev_layer_output, self.layer_filter,
                                                                       strides=self.filter_strides,
                                                                       padding=self.filter_padding),
                                                          self.layer_bias)).parse_activation(
                activation_type=self.layer_activation)
            layer_details = OrderedDict(
                [(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.layer_type),
                 (constants.MODEL_ARCHITECTURE.LAYER_FILTER, self.layer_filter.get_shape().as_list().__str__()),
                 (constants.MODEL_ARCHITECTURE.LAYER_STRIDES, self.filter_strides.__str__()),
                 (constants.MODEL_ARCHITECTURE.LAYER_BIAS, self.layer_bias.get_shape().as_list().__str__()),
                 (constants.MODEL_ARCHITECTURE.LAYER_ACTIVATION, self.layer_activation),
                 (constants.MODEL_ARCHITECTURE.LAYER_OUTPUT, self.layer_output.get_shape().as_list().__str__())])

            if self.layer_dropout:
                dropout_placeholder = tf.placeholder(dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE)
                tf.add_to_collection(dropout_placeholder.name, dropout_placeholder)
                RZTDL_DAG.add_dropout_placeholder(model_name=self.model_name, placeholder_name=dropout_placeholder.name,
                                                  value=self.layer_dropout)
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_DROPOUT] = self.layer_dropout
                self.layer_output = tf.nn.dropout(self.layer_output, keep_prob=dropout_placeholder)
            if self.norm_type:
                self.layer_output = NormalizationLayer(self.layer_output).parse_norm(
                    norm_type=self.norm_type, norm_parameters=self.norm_parameters)
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_NORMALIZATION] = OrderedDict(
                    [('type', self.norm_type), ('paramters', self.norm_parameters)])
            if RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY:
                tf_summary.create_variable_summaries(tensor=self.layer_output)
        RZTDL_DAG.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                            layer_details=layer_details)
        tf.add_to_collection(self.layer_output.name, self.layer_output)
        return self

    def validate(self):
        """
        | **@author:** Prathyush SP
        |
        | Convolution Layer Validation
        """
        with tf.name_scope(self.name + '/'):
            if self.layer_input is not None:
                if isinstance(self.layer_input, Tensor):
                    self.prev_layer_output = self.layer_input
                    self.prev_layer_nodes = self.prev_layer_output.get_shape().as_list()[-1]
                else:
                    self.prev_layer_output = RZTDL_DAG.get_layer(self.model_name, self.layer_input)
                    self.prev_layer_nodes = self.prev_layer_output.get_shape().as_list()[-1]
            if self.prev_layer_output is None:
                raise LayerException('Previous Layer Output is None')
            if not self.prev_layer_nodes or self.prev_layer_nodes <= 0:
                raise LayerException('Previous Layer Nodes is None or <=0')
            if self.filter_padding not in constants.PADDING.__dict__.values():
                raise PaddingError("Not a valid Padding. Usage: NeuralNetwork.PADDING.<>")
            if self.layer_activation not in constants.ACTIVATION.__dict__.values():
                raise ActivationError("Not a valid Activation. Usage: NeuralNetwork.ACTIVATION.<>")
            if len(self.filter_dimensions) < 4:
                raise DimensionError('Filter Dimensions needs 4 values. Ex: [1,2,2,1]')
            if len(self.filter_strides) < 4:
                raise DimensionError('Filter Strides needs 4 values. Ex: [1,2,2,1]')
            if self.layer_dropout and not (0 <= self.layer_dropout <= 1):
                raise RangeError("Layer Dropout should be between 0 and 1 Found:", self.layer_dropout)
            if self.norm_type not in [None, constants.NORMALIZATION.L2_NORM, constants.NORMALIZATION.LRN_NORM]:
                raise NormalizationError("For Convolution Layer Normalization should be L2_NORM / LRN")
            if self.norm_type:
                if self.norm_parameters is None:
                    if self.norm_type == constants.NORMALIZATION.L2_NORM:
                        self.norm_parameters = constants.NORMALIZATION.l2_norm()
                    elif self.norm_type == constants.NORMALIZATION.LRN_NORM:
                        self.norm_parameters = constants.NORMALIZATION.lrn_norm()
                else:
                    if self.norm_type == constants.NORMALIZATION.L2_NORM:
                        if self.norm_parameters is not None and not self.norm_parameters.keys() == constants.NORMALIZATION.l2_norm().keys():
                            raise ParameterError('Normalization Parameters do not match L2 Layer.')
                    elif self.norm_type == constants.NORMALIZATION.LRN_NORM:
                        if self.norm_parameters is not None and not self.norm_parameters.keys() == constants.NORMALIZATION.lrn_norm().keys():
                            raise ParameterError('Normalization Parameters do not match LRN Layer.')
            self.layer_nodes = self.filter_dimensions[-1]
            if self.prev_layer_output.get_shape().ndims == 2:
                if RZTDL_CONFIG.TensorflowConfig.AUTO_TENSOR_CONVERSION:
                    nodes = self.prev_layer_nodes ** 0.5
                    if not float(nodes).is_integer():
                        raise DimensionError(
                            "Cannot Use Auto Reshape feature. Use Manual reshape and convert previous dl_layer to rank 4 tensor")
                    self.prev_layer_output = tf.reshape(tensor=self.prev_layer_output,
                                                        shape=[-1, int(nodes), int(nodes), 1])
                else:
                    raise DimensionError('Auto Tensor Conversion is disabled. Only 2 dimensional input is allowed ')
            elif self.prev_layer_output.get_shape().ndims == 4:
                if not self.prev_layer_nodes == self.filter_dimensions[-2]:
                    raise DimensionError(
                        'Previous Layer out-channels and Current Layer in-channels do not match. ' + str(
                            self.prev_layer_nodes) + ' : ' + str(self.filter_dimensions[-2]))
            with tf.name_scope('filters'):
                if isinstance(self.layer_filter, ndarray):
                    if not str(self.layer_filter.dtype) == str(
                            RZTDL_CONFIG.TensorflowConfig.DTYPE.as_numpy_dtype).replace("<class 'numpy.", '').replace(
                        "'>", ''):
                        raise DTypeError(
                            'Datatype should match global datatype {}'.format(RZTDL_CONFIG.TensorflowConfig.DTYPE))

                    self.layer_filter = tf.Variable(self.layer_filter)
                elif isinstance(self.layer_filter, dict):
                    self.layer_filter = tf.Variable(parse_initialization_dict(initialization_dict=self.layer_filter,
                                                                              shape=self.filter_dimensions))
                else:
                    self.layer_filter = tf.Variable(
                        RZTDL_CONFIG.TensorflowConfig.DEFAULT_WEIGHT_FN(shape=self.filter_dimensions),
                        dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE)
                    logger.debug("Generating Filter for " + str(self.name))
                RZTDL_DAG.add_weights(model_name=self.model_name, layer_name=self.name,
                                      layer_weights=self.layer_filter.name)
                tf.add_to_collection(self.layer_filter.name, self.layer_filter)
                if RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY:
                    tf_summary.create_variable_summaries(tensor=self.layer_filter)
            with tf.name_scope('biases'):
                if isinstance(self.layer_bias, ndarray):
                    if not str(self.layer_bias.dtype) == str(
                            RZTDL_CONFIG.TensorflowConfig.DTYPE.as_numpy_dtype).replace("<class 'numpy.", '').replace(
                        "'>", ''):
                        raise DTypeError(
                            'Datatype should match global datatype {}'.format(RZTDL_CONFIG.TensorflowConfig.DTYPE))
                    self.layer_bias = tf.Variable(self.layer_bias)
                elif isinstance(self.layer_bias, dict):
                    self.layer_bias = tf.Variable(
                        parse_initialization_dict(initialization_dict=self.layer_bias, shape=[self.layer_nodes]))
                else:
                    self.layer_bias = tf.Variable(
                        RZTDL_CONFIG.TensorflowConfig.DEFAULT_BIAS_FN(shape=[self.layer_nodes]),
                        RZTDL_CONFIG.TensorflowConfig.DTYPE)
                    logger.debug("Generating Bias for " + str(self.name))
                RZTDL_DAG.add_bias(model_name=self.model_name, layer_name=self.name,
                                   layer_bias=self.layer_bias.name)
                tf.add_to_collection(self.layer_bias.name, self.layer_bias)
                if RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY:
                    tf_summary.create_variable_summaries(tensor=self.layer_bias)
                logger.info("Convolution Layer validation success . . .")
