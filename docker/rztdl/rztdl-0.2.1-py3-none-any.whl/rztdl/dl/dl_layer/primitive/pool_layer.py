# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Layer Module used to create deeplearning layers. It consists of
| 1. Input Layer
| 2. Fully Connected Layer
| 3. Output Layer
| 4. Convolution Layer
| 5. Pool Layer
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
from typing import Union
from rztdl import RZTDL_CONFIG, RZTDL_DAG
import rztdl.utils.string_constants as constants
from rztdl.dl import tf_summary
from tensorflow import Tensor
import tensorflow as tf
from typeguard import typechecked
import logging
from rztdl.utils.dl_exception import DimensionError, RangeError, NormalizationError, PaddingError, \
    LayerException, ParameterError
from rztdl.dl.helpers import tfhelpers
from collections import OrderedDict
from rztdl.dl.dl_layer.layer import Layer

logger = logging.getLogger(__name__)


class PoolLayer(Layer):
    """
    | **@author:** Prathyush SP
    |
    | Pool Layer Class
    .. note:: Pool Layer supports only 4 dimension input, usually Convolution Layer
    """

    @typechecked
    def __init__(self, name: str, pool_dimensions: list, pool_strides: list, pool_padding: str,
                 pool_type: str = constants.POOL.MAX_POOL, layer_dropout: float = None, norm_type: str = None,
                 norm_parameters: dict = None, layer_input: Union[str, Tensor] = None):
        """
        :param name: Name of the Layer
        :param pool_dimensions: Pool Dimensions
        :param pool_strides: Strides for the Pool
        :param pool_padding: Pool Padding
        :param pool_type: Pool type [max_pool, avg_pool]
        """
        super().__init__(name=name, layer_type=constants.LAYERS.POOL_LAYER)
        self.pool_dimensions = pool_dimensions
        self.pool_strides = pool_strides
        self.pool_padding = pool_padding
        self.pool_type = pool_type
        self.layer_dropout = layer_dropout
        self.prev_layer_output = None
        self.prev_layer_nodes = None
        self.layer_output = None
        self.layer_nodes = None
        self.norm_type = norm_type
        self.norm_parameters = norm_parameters
        self.layer_input = layer_input

    @typechecked
    def create_layer(self, model_name: str, layer, layer_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Create Pool Layer
        :param model_name: Model Name
        :param layer: Previous Layer
        :param layer_id: Layer ID
        :return: Pool Layer Object
        """
        self.model_name = model_name
        self.prev_layer_output = layer.layer_output
        self.prev_layer_nodes = layer.layer_nodes
        self.id = layer_id
        self.validate()
        with tf.name_scope(self.name):
            self.layer_output = tfhelpers.Pool(input_tensor=self.prev_layer_output).parse_pool(pool_type=self.pool_type,
                                                                                               ksize=self.pool_dimensions,
                                                                                               strides=self.pool_strides,
                                                                                               padding=self.pool_padding)
            layer_details = OrderedDict(
                [(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.layer_type),
                 (constants.MODEL_ARCHITECTURE.LAYER_DIMENSIONS, self.pool_dimensions.__str__()),
                 (constants.MODEL_ARCHITECTURE.LAYER_STRIDES, self.pool_strides.__str__()),
                 (constants.MODEL_ARCHITECTURE.LAYER_OUTPUT, self.layer_output.get_shape().as_list().__str__())])
            if self.layer_dropout:
                dropout_placeholder = tf.placeholder(dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE)
                tf.add_to_collection(dropout_placeholder.name, dropout_placeholder)
                RZTDL_DAG.add_dropout_placeholder(model_name=self.model_name, placeholder_name=dropout_placeholder.name,
                                                  value=self.layer_dropout)
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_DROPOUT] = self.layer_dropout
                self.layer_output = tf.nn.dropout(self.layer_output, keep_prob=dropout_placeholder)
            if self.norm_type:
                self.layer_output = tfhelpers.NormalizationLayer(self.layer_output).parse_norm(norm_type=self.norm_type,
                                                                                               norm_parameters=self.norm_parameters)
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_NORMALIZATION] = OrderedDict(
                    [('type', self.norm_type), ('parameters', self.norm_parameters)])
            if RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY:
                tf_summary.create_variable_summaries(tensor=self.layer_output)
        RZTDL_DAG.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                            layer_details=layer_details)
        tf.add_to_collection(self.layer_output.name, self.layer_output)
        return self

    def validate(self):
        """
        | **@author:** Prathyush SP
        |
        Pool Layer Validation
        """
        if self.layer_input is not None:
            if isinstance(self.layer_input, Tensor):
                self.prev_layer_output = self.layer_input
                self.prev_layer_nodes = self.prev_layer_output.get_shape().as_list()[-1]
            else:
                self.prev_layer_output = RZTDL_DAG.get_layer(self.model_name, self.layer_input)
                self.prev_layer_nodes = self.prev_layer_output.get_shape().as_list()[-1]
        if self.prev_layer_output is None:
            raise LayerException('Previous Layer Ouput is None')
        if not self.prev_layer_nodes or self.prev_layer_nodes <= 0:
            raise LayerException('Previous Layer Nodes is None or <=0')
        self.layer_nodes = self.prev_layer_nodes
        if self.layer_dropout and not (0 <= self.layer_dropout <= 1):
            raise RangeError("Layer Dropout should be between 0 and 1 Found:", self.layer_dropout)
        if self.norm_type not in [None, constants.NORMALIZATION.L2_NORM, constants.NORMALIZATION.LRN_NORM]:
            raise NormalizationError("For Convolution Layer Normalization should be L2_NORM / LRN")
        if self.norm_type:
            if self.norm_parameters is None:
                if self.norm_type == constants.NORMALIZATION.L2_NORM:
                    self.norm_parameters = constants.NORMALIZATION.l2_norm()
                elif self.norm_type == constants.NORMALIZATION.LRN_NORM:
                    self.norm_parameters = constants.NORMALIZATION.lrn_norm()
            else:
                if self.norm_type == constants.NORMALIZATION.L2_NORM:
                    if self.norm_parameters is not None and not self.norm_parameters.keys() == constants.NORMALIZATION.l2_norm().keys():
                        raise ParameterError('Normalization Parameters do not match L2 Layer.')
                elif self.norm_type == constants.NORMALIZATION.LRN_NORM:
                    if self.norm_parameters is not None and not self.norm_parameters.keys() == constants.NORMALIZATION.lrn_norm().keys():
                        raise ParameterError('Normalization Parameters do not match LRN Layer.')
        if self.pool_padding not in constants.PADDING.__dict__.values():
            raise PaddingError("Not a valid Padding. Usage: constant.PADDING.<>")
        if self.prev_layer_output.get_shape().ndims < 4:
            raise DimensionError('Pooling Operation doesnt support ndim < 4')
        if len(self.pool_dimensions) < 4:
            raise DimensionError('Pool Dimensions needs 4 values. Ex: [1,2,2,1]')
        if len(self.pool_strides) < 4:
            raise DimensionError('Pool Strides needs 4 values. Ex: [1,2,2,1]')
        logger.info("Pool Layer validation success . . .")
