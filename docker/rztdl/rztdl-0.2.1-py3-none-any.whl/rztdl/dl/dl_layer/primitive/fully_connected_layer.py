# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Layer Module used to create deeplearning layers. It consists of
| 1. Input Layer
| 2. Fully Connected Layer
| 3. Output Layer
| 4. Convolution Layer
| 5. Pool Layer
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
import functools
import operator
from types import FunctionType
from typing import Union
from numpy import ndarray
from rztdl import RZTDL_CONFIG, RZTDL_DAG
import rztdl.utils.string_constants as constants
from rztdl.dl import tf_summary
from tensorflow import Tensor
from rztdl.dl.dl_dict_parsers import parse_initialization_dict
import tensorflow as tf
from typeguard import typechecked
import logging
from rztdl.utils.dl_exception import DTypeError, DimensionError, RangeError, ActivationError, NormalizationError, \
    LayerException, ParameterError
from rztdl.dl.helpers import tfhelpers
from collections import OrderedDict
from rztdl.dl.dl_layer.layer import Layer

logger = logging.getLogger(__name__)


class FullyConnectedLayer(Layer):
    """
    | **@author:** Prathyush SP
    |
    | Fully Connected Layer
    .. todo::
        Prathyush SP:
            1. Defaults for Layer weights, bias and activation
    """

    # todo: Prathyush SP - Defaults for Layer weights, bias and activation
    @typechecked
    def __init__(self, name: str, layer_activation: str = constants.ACTIVATION.SIGMOID, layer_nodes: int = 4,
                 layer_weights: Union[ndarray, dict, FunctionType] = None,
                 layer_bias: Union[list, ndarray, dict, FunctionType] = None, layer_input: Union[str, Tensor] = None,
                 layer_dropout: Union[float, None] = None, norm_type: str = None, norm_parameters: dict = None):
        """
        :param name: Name of the Layer
        :param layer_activation: Layer Activation [Usage: NeuralNetwork.Activation.<>]
        :param layer_weights: Weights for the dl_layer
        :param layer_bias: Bias for the dl_layer
        :param layer_nodes: Number of nodes in the dl_layer
        """
        super().__init__(name=name, layer_type=constants.LAYERS.FULLY_CONNECTED_LAYER)
        self.layer_weights = layer_weights
        self.layer_bias = layer_bias
        self.layer_activation = layer_activation
        self.layer_nodes = layer_nodes
        self.prev_layer_output = None
        self.prev_layer_nodes = None
        self.layer_output = None
        self.layer_dropout = layer_dropout
        self.layer_input = layer_input
        self.norm_type = norm_type
        self.norm_parameters = norm_parameters
        self.scope = None

    @typechecked
    def create_layer(self, model_name: str, layer, layer_id: int):
        """
        | **@author:** Prathyush SP
        | Creates Fully Connected Layer
        |
        :param model_name: Model Name
        :param layer: Previous Layer
        :param layer_id: Layer Id
        :return: Fully Connected Layer Object
        """
        self.id = layer_id
        self.model_name = model_name
        self.prev_layer_output = layer.layer_output
        self.prev_layer_nodes = layer.layer_nodes
        self.validate()
        with tf.name_scope(self.name + '/'):
            self.layer_output = tfhelpers.Activation(input_tensor=
                                           tf.add(tf.matmul(self.layer_input, self.layer_weights),
                                                  self.layer_bias)).parse_activation(
                activation_type=self.layer_activation)
            layer_details = OrderedDict(
                [(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.layer_type),
                 (constants.MODEL_ARCHITECTURE.LAYER_WEIGHTS, self.layer_weights.get_shape().as_list().__str__()),
                 (constants.MODEL_ARCHITECTURE.LAYER_BIAS, self.layer_bias.get_shape().as_list().__str__()),
                 (constants.MODEL_ARCHITECTURE.LAYER_ACTIVATION, self.layer_activation),
                 (constants.MODEL_ARCHITECTURE.LAYER_OUTPUT, self.layer_output.get_shape().as_list().__str__())])
            if self.layer_dropout:
                dropout_placeholder = tf.placeholder(dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE)
                tf.add_to_collection(dropout_placeholder.name, dropout_placeholder)
                RZTDL_DAG.add_dropout_placeholder(model_name=self.model_name, placeholder_name=dropout_placeholder.name,
                                                  value=self.layer_dropout)
                self.layer_output = tf.nn.dropout(self.layer_output, keep_prob=dropout_placeholder)
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_DROPOUT] = self.layer_dropout
            if self.norm_type:
                self.layer_output = tfhelpers.NormalizationLayer(self.layer_output).l2_norm(self.norm_parameters)
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_NORMALIZATION] = OrderedDict(
                    [('Type', constants.NORMALIZATION.L2_NORM), ('Parameters', self.norm_parameters)])
            if RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY:
                tf_summary.create_variable_summaries(tensor=self.layer_output)
        RZTDL_DAG.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                            layer_details=layer_details)
        tf.add_to_collection(self.layer_output.name, self.layer_output)
        return self

    def validate(self):
        """
        | **@author:** Prathyush SP
        |
        | Validation method for Fully Connected Layer
        """
        with tf.name_scope(self.name + '/'):
            if self.layer_input is not None:
                if isinstance(self.layer_input, Tensor):
                    self.prev_layer_nodes = self.layer_input.get_shape().as_list()[1]
                else:
                    self.layer_input = RZTDL_DAG.get_layer(self.model_name, self.layer_input)
                    self.prev_layer_nodes = self.layer_input.get_shape().as_list()[1]
            else:
                self.layer_input = self.prev_layer_output
            if self.prev_layer_output is None:
                raise LayerException('Previous Layer Output is None')
            if not self.prev_layer_nodes or self.prev_layer_nodes <= 0:
                raise LayerException('Previous Layer Nodes is None or <=0')
            elif self.layer_activation not in constants.ACTIVATION.__dict__.values():
                raise ActivationError("Not a valid Activation. Usage: NeuralNetwork.ACTIVATION.<>")
            if self.layer_dropout and not (0 <= self.layer_dropout <= 1):
                raise RangeError("Layer Dropout should be between 0 and 1 Found:", self.layer_dropout)
            if self.norm_type not in [None, constants.NORMALIZATION.L2_NORM]:
                raise NormalizationError("For FullyConnected Layer Normalization should be L2_NORM")
            if self.norm_type:
                if self.norm_parameters is None:
                    self.norm_parameters = constants.NORMALIZATION.l2_norm()
                else:
                    if self.norm_parameters is not None and not self.norm_parameters.keys() == constants.NORMALIZATION.l2_norm().keys():
                        raise ParameterError('Normalization Parameters do not match the respective dl_layer.')
            if self.layer_input.get_shape().ndims == 4:
                if RZTDL_CONFIG.TensorflowConfig.AUTO_TENSOR_CONVERSION:
                    nodes = functools.reduce(operator.mul, self.layer_input.get_shape().as_list()[1:])
                    self.layer_input, self.prev_layer_nodes = tf.reshape(tensor=self.layer_input,
                                                                         shape=[-1, int(nodes)]), nodes
                else:
                    raise DimensionError('Auto Tensor Conversion is disabled. Only 2 dimensional input is allowed ')
            with tf.name_scope('weights'):
                if isinstance(self.layer_weights, ndarray):
                    if not str(self.layer_weights.dtype) == str(
                            RZTDL_CONFIG.TensorflowConfig.DTYPE.as_numpy_dtype).replace("<class 'numpy.", '').replace(
                        "'>", ''):
                        raise DTypeError(
                            'Datatype should match global datatype {}'.format(RZTDL_CONFIG.TensorflowConfig.DTYPE))

                    self.layer_weights = tf.Variable(self.layer_weights)
                elif isinstance(self.layer_weights, dict):
                    self.layer_weights = tf.Variable(parse_initialization_dict(initialization_dict=self.layer_weights,
                                                                               shape=[self.prev_layer_nodes,
                                                                                      self.layer_nodes]))
                else:
                    self.layer_weights = tf.Variable(RZTDL_CONFIG.TensorflowConfig.DEFAULT_WEIGHT_FN(
                        shape=[self.prev_layer_nodes, self.layer_nodes], dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE))
                    logger.debug("Generating Weights for " + str(self.name))
                RZTDL_DAG.add_weights(model_name=self.model_name, layer_name=self.name,
                                      layer_weights=self.layer_weights.name)
                tf.add_to_collection(self.layer_weights.name, self.layer_weights)
                if RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY:
                    tf_summary.create_variable_summaries(tensor=self.layer_weights)
            with tf.name_scope('biases'):
                if isinstance(self.layer_bias, ndarray):
                    if not str(self.layer_bias.dtype) == str(
                            RZTDL_CONFIG.TensorflowConfig.DTYPE.as_numpy_dtype).replace("<class 'numpy.", '').replace(
                        "'>", ''):
                        raise DTypeError(
                            'Datatype should match global datatype {}'.format(RZTDL_CONFIG.TensorflowConfig.DTYPE))
                    self.layer_bias = tf.Variable(self.layer_bias)
                elif isinstance(self.layer_bias, dict):
                    self.layer_bias = tf.Variable(
                        parse_initialization_dict(initialization_dict=self.layer_bias, shape=[self.layer_nodes]))
                else:
                    self.layer_bias = tf.Variable(
                        RZTDL_CONFIG.TensorflowConfig.DEFAULT_BIAS_FN(shape=[self.layer_nodes],
                                                                      dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE))
                    logger.debug("Generating Bias for " + str(self.name))
                RZTDL_DAG.add_bias(model_name=self.model_name, layer_name=self.name,
                                   layer_bias=self.layer_bias.name)
                tf.add_to_collection(self.layer_bias.name, self.layer_bias)
                if RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY:
                    tf_summary.create_variable_summaries(tensor=self.layer_bias)
            logger.info("Fully Connected Layer validation success . . .")
