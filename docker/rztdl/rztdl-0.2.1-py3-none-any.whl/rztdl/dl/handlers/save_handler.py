# -*- coding: utf-8 -*-
"""
| **@created on:** 23/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

import rztdl.utils.string_constants as constants
import tensorflow as tf
from rztdl import RZTDL_CONFIG
from rztdl.utils.pyutils import path_fixer
from rztdl.utils.singleton import Singleton
from rztdl.utils.dl_exception import SaveHandlerException


class _SaveHandler(metaclass=Singleton):
    """

    """

    def __init__(self, name: str):
        self.name = name

    # def create_directories(self):

    # noinspection PyProtectedMember
    def restore_model_using_loader(self, model_loader: constants.ModelHandler):
        """

        :param model_loader:
        :return:
        """
        # todo: Prathyush SP - Fetch checkpoint based on checkpoint_step instead of current latest_checkpoint
        if model_loader[constants.ModelHandler._Parameters.SavePath]:
            model_save_path = path_fixer(path='/'.join([model_loader[constants.ModelHandler._Parameters.SavePath],
                                                                     RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_DL]))
        else:
            if None in [model_loader[constants.ModelHandler._Parameters.ModelName],
                        model_loader[
                            constants.ModelHandler._Parameters.ModelRunnerName],
                        model_loader[constants.ModelHandler._Parameters.FlowName]]:
                raise SaveHandlerException(component_name=self.name,
                                           message='None is save parameters. Check Model Loader load config')
            else:
                model_save_path = path_fixer(path='/'.join([RZTDL_CONFIG.CommonConfig.PATH_RZTDL,
                                                            model_loader[constants.ModelHandler._Parameters.ModelName],
                                                            model_loader[
                                                                constants.ModelHandler._Parameters.ModelRunnerName],
                                                            model_loader[constants.ModelHandler._Parameters.FlowName],
                                                            RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_DL]))
        print(model_save_path)
        model_save_path = tf.train.latest_checkpoint(model_save_path)

        if model_save_path is None:
            raise SaveHandlerException(component_name=self.name,
                                       message="Unable to find checkpoints in path: {}".format(model_save_path))
        return model_save_path

    def restore_model_using_meta(self, meta_path: str):
        pass


save_handler = _SaveHandler('global_save_handler')
