# -*- coding: utf-8 -*-
"""
| **@created on:** 21/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

from rztdl import RZTDL_CONFIG
from rztdl.utils.singleton import Singleton
import logging
import os
from rztdl.utils.pyutils import generate_timestamp, path_fixer

logger = logging.getLogger(__name__)


class DirectoryStructure(object):
    def __init__(self, model_name: str, model_runner_name: str, flow_name: str, save_path: str):
        if save_path:
            self.rztdl_root_path = save_path
        elif RZTDL_CONFIG.CommonConfig.PARALLEL_MODELS:
            print([RZTDL_CONFIG.CommonConfig.PATH_RZTDL, model_name, model_runner_name, flow_name])
            self.rztdl_root_path = '/'.join(
                [RZTDL_CONFIG.CommonConfig.PATH_RZTDL, model_name, model_runner_name, flow_name])
        else:
            self.rztdl_root_path = '/'.join(
                [RZTDL_CONFIG.CommonConfig.PATH_RZTDL, model_name, model_runner_name, flow_name, generate_timestamp()])
        self.rztdl_root_path = path_fixer(self.rztdl_root_path)
        self.logs_path = path_fixer(path=self.rztdl_root_path + '/' + RZTDL_CONFIG.CommonConfig.PATH_LOG+'/')
        self.dl_model_save_path = path_fixer(
            path=self.rztdl_root_path + '/' + RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_DL)
        self.timeline_path = path_fixer(path=self.rztdl_root_path + '/' + RZTDL_CONFIG.CommonConfig.PATH_TIMELINE)
        self.graph_path = path_fixer(path=self.rztdl_root_path + '/' + RZTDL_CONFIG.CommonConfig.PATH_GRAPH)
        self.data_path = path_fixer(path=self.rztdl_root_path + '/' + RZTDL_CONFIG.CommonConfig.PATH_DATA)


class _DirectoryHandler(metaclass=Singleton):
    def __init__(self, name: str):
        self.name = name

    def initialize_directory_structure_for_train_flow(self, model_name: str, model_runner_name: str, flow_name: str,
                                                      save_path: str = None):
        ds = DirectoryStructure(model_name=model_name, model_runner_name=model_runner_name, flow_name=flow_name,
                                save_path=save_path)
        for p_name, path in ds.__dict__.items():
            logger.debug('Creating path for {} in {}'.format(p_name, path))
            os.system('mkdir -p {}'.format(path))
        return ds

    def initialize_directory_structure_for_inference_flow(self, model_name: str, model_runner_name: str, flow_name: str,
                                                          save_path: str = None):
        ds = DirectoryStructure(model_name=model_name, model_runner_name=model_runner_name, flow_name=flow_name,
                                save_path=save_path)
        for p_name, path in ds.__dict__.items():
            if p_name in ['logs_path', 'data_path', 'graph_path']:
                logger.debug('Creating path for {} in {}'.format(p_name, path))
                os.system('mkdir -p {}'.format(path))
        return ds


DIRECTORY_HANDLER = _DirectoryHandler('global_directory_handler')
