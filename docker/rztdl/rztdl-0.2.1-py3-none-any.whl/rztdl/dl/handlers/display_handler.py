# -*- coding: utf-8 -*-
"""
| **@created on:** 21/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** --
|
..todo::
"""
from rztdl.utils.singleton import Singleton
from collections import OrderedDict
from rztdl.utils.pyutils import ROrderedDict
import rztdl.utils.string_constants as constants
from functools import partial, wraps
import logging
from weakref import ref

logger = logging.getLogger(__name__)


class GlobalDisplayHandler(metaclass=Singleton):
    def __init__(self, name):
        self.name = name
        self.display_configuration = OrderedDict()

    def add_display_configuration(self, model_name: str, flow_name: ref, flow_meta: str, interval_type: str,
                                  interval: int):
        if model_name in self.display_configuration and flow_name in self.display_configuration[model_name]:
            self.display_configuration[model_name][flow_name]['data'].append(
                {"interval_type": interval_type, "interval": interval})
        else:
            self.display_configuration[model_name] = ROrderedDict(
                [(flow_name, {"meta": flow_meta(), "data": [{"interval_type": interval_type, "interval": interval}]})])

    def display(self, f=None, always: bool = False):
        """
        | **@author:** Prathyush SP
        |
        | Custom Exception Decorator.
        :param f:
        :param always:
        :return:
        """
        if f is None:
            return partial(self.display, always=always)

        @wraps(f)
        def wrapped(*args, **kwargs):
            r = f(*args, **kwargs)
            try:
                if kwargs['split_name'] == self.display_configuration[kwargs['model_name']][kwargs['flow_name']]['meta'].train_split.name:
                    if kwargs['flow_name'] in self.display_configuration[kwargs['model_name']]:
                        for config in self.display_configuration[kwargs['model_name']][kwargs['flow_name']]['data']:
                            if kwargs['interval_type'] == config['interval_type'] and kwargs['interval'] % config[
                                'interval'] == 0:
                                logger.info(kwargs)
                    else:
                        logger.warning(
                            "Display Configuration for Model ({}), Flow ({}) not set".format(kwargs['model_name'],
                                                                                             kwargs['flow_name']))
                else:
                    logger.info(kwargs)
            except KeyError as e:
                logger.error(
                    'keys model_name, flow_name not found in kwargs. Error in display handler configuration / usage.')
            return r

        return wrapped


global_display_handler = GlobalDisplayHandler('global_display_handler')
