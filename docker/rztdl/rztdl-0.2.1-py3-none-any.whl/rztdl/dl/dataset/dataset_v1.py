# -*- coding: utf-8 -*-
"""
| **@created on:** 11/06/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Dataset Module which defines abstract class
|
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['Dataset']

import logging
import typing
from abc import ABCMeta, abstractmethod
from rztdl.dl.dataset.dataset_split import DatasetSplit
from typeguard import typechecked
import tensorflow as tf

logger = logging.getLogger(__name__)


class Dataset(metaclass=ABCMeta):
    """
    | **@author:** Prathyush SP
    |
    | Abstract Dataset class
    """

    @typechecked
    def __init__(self, name: str, column_names: typing.Dict[str, typing.List[typing.Union[int, str]]]):
        """

        :param name: Name of the Dataset
        :param column_names: Column Names. ex: {"features": [10,22], "label": ["x", "y"]}. Supports both range and column names
        """
        self.name = name
        self.column_names = column_names #[(i, column_names[i]) for i in sorted(column_names.keys())]
        self.split_data = {}
        self.finalize = False
        self.id = None
        self.iterator = None

    @abstractmethod
    def initialize_dataset(self, dataset_id: int) -> 'Dataset':
        """
        | **@author:** Prathyush SP
        |
        | Abstract method to initialize dataset
        :param dataset_id: Dataset Id
        """
        pass

    @abstractmethod
    def prepare_dataset(self, split_template: DatasetSplit) -> 'Dataset':
        """
        | **@author:** Prathyush SP
        |
        | Abstract method to initialize dataset
        :param split_template: Split Template
        """
        pass

    @abstractmethod
    def evaluate(self, tensorflow_session: tf.Session):
        """
        | **@author:** Prathyush SP
        |
        | Evaluate Dataset
        :param tensorflow_session:
        :return: Dataset Evaluation
        """
        # todo: Prathyush SP: Evaluate Dataset
        pass

    @abstractmethod
    def validate(self):
        """
        | **@author:** Prathyush SP
        |
        | Dataset Validation
        """
        pass
