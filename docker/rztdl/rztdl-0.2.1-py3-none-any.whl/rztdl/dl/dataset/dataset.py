# # -*- coding: utf-8 -*-
# """
# | **@created on:** 17/05/18,
# | **@author:** Prathyush SP,
# | **@version:** v0.0.1
# |
# | **Description:**
# | Dataset Module which defines abstract class
# |
# |
# | **Sphinx Documentation Status:** Complete
# |
# ..todo::
#     --
# """
#
# __all__ = ['Dataset']
#
# from abc import ABCMeta, abstractmethod
# from typeguard import typechecked
# from rztdl.utils.validations import validate_name
# import logging
# import rztdl.utils.string_constants as constants
# from rztdl.dl.dataset.dataset_metric import DatasetMetric
# from rztdl import RZTDL_STORE
# import typing
# from rztdl.utils.dl_exception import DatasetException, SizeError, DataFeedException
# from weakref import WeakSet
#
# logger = logging.getLogger(__name__)
#
#
# class Dataset(metaclass=ABCMeta):
#     """
#     | **@author:** Prathyush SP
#     |
#     | Base class, which defines abstract methods for dataset
#     """
#
#     __slots__ = ['name', 'dataset_type', 'template', 'metrics', 'batch_size', 'data', 'id', 'idx', '__weakref__']
#
#     @typechecked
#     def __init__(self, name: str, dataset_type: constants.DatasetType, template: constants.DatasetTemplate, data: dict,
#                  batch_size: int = None, metrics: typing.List[str] = None):
#         """
#         :param name: Name for the metric
#         :param dataset_type: Type of Objective Function
#         :param template: Dataset Template type
#         :param data: Data dictionary
#         :param batch_size: Batch Size
#         :param metrics: Metric Objects
#         """
#         self.name = validate_name(name)
#         self.dataset_type = dataset_type
#         self.template = template
#         self.metrics = metrics
#         self.batch_size = batch_size
#         self.data = data
#         self.id = None
#         self.idx = 0
#         RZTDL_STORE.add_dataset(dataset_name=self.name, dataset=self)
#
#     # noinspection PyProtectedMember
#     @staticmethod
#     def classify_datasets(datasets: typing.List['Dataset']):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Classify datasets into train , valid and test templates
#         :param datasets: Dataset objects
#         :return: Train Dataset, Valid Datasets, Test Datasets in WeakRefSets format
#         """
#         # todo: Prathyush SP - Optimize this method
#         train_dataset, valid_datasets, test_datasets = WeakSet(), WeakSet(), WeakSet()
#         for dataset in datasets:
#             if dataset.template._DATASET_TEMPLATE == constants.DatasetTemplate._TRAIN_TEMPLATE:
#                 train_dataset.add(dataset)
#             elif dataset.template._DATASET_TEMPLATE == constants.DatasetTemplate._VALID_TEMPLATE:
#                 valid_datasets.add(dataset)
#             elif dataset.template._DATASET_TEMPLATE == constants.DatasetTemplate._TEST_TEMPLATE:
#                 test_datasets.add(dataset)
#             else:
#                 raise DatasetException('Given template does not match Train / Valid / Test template'.format(
#                     dataset.template._DATASET_TEMPLATE))
#         return train_dataset, valid_datasets, test_datasets
#
#     def __iter__(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Iter method which returns Dataset object
#         :return Dataset Object
#         """
#         return self
#
#     @abstractmethod
#     def __next__(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Fetch next set of samples from the dataset
#         """
#         pass  # pragma: no cover
#
#     @typechecked
#     def add_metric(self, metric: DatasetMetric):
#         self.metrics.append(metric)
#
#     @abstractmethod
#     def create_dataset(self, model_name: str, dataset_id: int):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Used to create a metric function
#         :param model_name: Model Name
#         :param dataset_id: Dataset Id
#         """
#         return self  # pragma: no cover
#
#     @typechecked
#     def validate_placeholders(self, model_name: str):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Used to create a metric function
#         :param model_name: Model Name
#         """
#         model_placeholders = RZTDL_STORE.get_all_placeholders(model_name)
#         if not len(model_placeholders) == len(self.data):
#             for key in model_placeholders.keys():
#                 if key not in self.data.keys():
#                     raise DataFeedException('Feed train data for "{}" Buffer'.format(key))
#
#         if len(set([len(val) for val in self.data.values()])) > 1:
#             initial_placeholder = next(iter(self.data))
#             initial_length = len(self.data[initial_placeholder])
#             for placeholder_name, values in self.data.items():
#                 if not initial_length == len(values):
#                     raise SizeError("Size of {} {} doesn't match with Size of {} {} ".format(initial_placeholder,
#                                                                                              self.data[
#                                                                                                  initial_placeholder].shape,
#                                                                                              placeholder_name,
#                                                                                              values.shape))
#         logger.info('Fetching Placeholders . . .')
#         for key in self.data.keys():
#             if key not in model_placeholders.keys():
#                 raise DataFeedException('Buffer does not have a feed: "{}"'.format(key))
#
#     @abstractmethod
#     def validate(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Validation Method
#         """
#         pass  # pragma: no cover
