# -*- coding: utf-8 -*-
"""
| **@created on:** 15/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

__all__ = ['Split', 'DatasetSplit', 'InferenceSplit']

import typing
from typeguard import typechecked
from rztdl.utils.dl_exception import SplitException
from rztdl.utils import string_constants as constants
from rztdl.utils.validations import validate_name
import logging
from rztdl.utils.dl_exception import DatasetSplitException

logger = logging.getLogger(__name__)


class Split(object):
    """
    | **@author:** Prathyush SP
    |
    | Split Class to maintain dataset splits
    """

    __slots__ = ['name', 'template', 'metrics', 'id']

    @typechecked
    def __init__(self, name: str, template: constants.DatasetTemplate, metrics: typing.Set[str]):
        """

        :param name: Name of the split
        :param template: Template of the split. refer constants.DatasetTemplate
        :param metrics: Metrics to be run on the split
        """
        self.name = validate_name(name)
        self.template = template
        self.metrics = metrics
        self.id = None

    def __dict__(self):
        return {"name": self.name, "template": self.template.__dict__, "metrics": self.metrics, "id": self.id}

    @typechecked
    def create_split(self, split_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Create given split
        :param split_id: Split Id
        :return: Split Object
        """
        self.id = split_id
        return self

    def validate(self):
        """
        | **@author:** Prathyush SP
        |
        | Split Validation
        """
        pass


class InferenceSplit(object):
    """
    | **@author:** Prathyush SP
    |
    | Split Class to maintain dataset splits
    """

    __slots__ = ['name', 'template', 'id', 'metrics']

    @typechecked
    def __init__(self, name: str):
        """

        :param name: Name of the split
        :param template: Template of the split. refer constants.DatasetTemplate
        :param metrics: Metrics to be run on the split
        """
        self.name = validate_name(name)
        self.template = constants.DatasetTemplate.test()
        self.metrics  = set()
        self.id = None

    def __dict__(self):
        return {"name": self.name, "template": self.template.__dict__, "id": self.id}

    @typechecked
    def create_split(self, split_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Create given split
        :param split_id: Split Id
        :return: Split Object
        """
        self.id = split_id
        return self

    def validate(self):
        """
        | **@author:** Prathyush SP
        |
        | Split Validation
        """
        pass


class DatasetSplit(object):
    """
    | **@author:** Prathyush SP
    |
    | Dataset split class which handles splits
    """

    __slots__ = ['name', 'split_ratio', 'split_id', 'split_list', 'is_finalized', '_split', 'split_metrics', 'reuse',
                 'idx']

    @typechecked
    def __init__(self, name: str, split_ratio: typing.List[int], split_metrics: typing.Set[str], reuse: bool = False):
        """

        :param name: Name of the Dataset Split
        :param split_ratio: Split ratio
        """
        self.name = validate_name(name)
        self.split_ratio = split_ratio
        self.split_id = 1
        self.split_list = []
        self._split = Split
        self.split_metrics = split_metrics
        self.is_finalized = False
        self.reuse = reuse
        self.idx = 0
        if not sum(self.split_ratio) == 100:
            raise SplitException(component_name=self.name, message='Sum of splits should be always equal to 100')

    def __iter__(self):
        return self

    def __next__(self):
        """
        | **@author:** Prathyush SP
        |
        | Used to iterate next batch of data
        :return: Numpy Dataset Object
        """
        self.idx += 1
        try:
            return self.split_list[self.idx - 1]
        except IndexError:
            self.idx = 0
            raise StopIteration

    @typechecked
    def add_split(self, split: typing.Union[Split, InferenceSplit]) -> typing.Union[Split, InferenceSplit]:
        """
        | **@author:** Prathyush SP
        |
        | Add splits to the DatasetSplits
        :param split: Split Object
        :return Split Object
        """
        self.validate()
        self._split = split.create_split(split_id=self.split_id)
        self.split_list.append(self._split)
        self.split_id += 1
        return self._split

    def close(self):
        """
        | **@author:** Prathyush SP
        |
        | Close DatasetSplit Template
        :return DatasetSplit Object
        """
        combined_metrics_of_each_split = set()
        for sp in self.split_list:
            if sp.metrics:
                combined_metrics_of_each_split = combined_metrics_of_each_split.union(sp.metrics)

        for metric in list(combined_metrics_of_each_split):
            if metric not in self.split_metrics:
                raise DatasetSplitException(component_name=self.name,
                                            message="Metric [{}] not found in split metrics".format(metric))
        if len(self.split_list) < len(self.split_ratio):
            raise SplitException(component_name=self.name,
                                 message="Given splits less than declared split ratio. Declared:{} Given:{}".format(
                                     len(self.split_ratio), len(self.split_list)))

        # Only one train template is allowed, and a split must have a train template
        templates = {sp.name: sp.template for sp in self.split_list if sp.template[
            constants.DatasetTemplate._Parameters.DATASET_TEMPLATE] == constants.DatasetTemplate._Parameters.TRAIN_TEMPLATE}

        if len(templates) > 1:
            raise DatasetSplitException(component_name=self.name,
                                        message="Split supports only one Train Template. Given:{}, {}".format(
                                            len(templates), list(templates.keys())))

        self.is_finalized = True
        return self

    def validate(self):
        """
        | **@author:** Prathyush SP
        |
        | Validate DatasetSplit Object
        """

        if self.split_id > len(self.split_ratio):
            raise SplitException(component_name=self.name, message='Trying to add splits greater than split ratio')

        if self.is_finalized:
            raise SplitException(component_name=self.name, message='Split is finalized, Cannot add more splits')
