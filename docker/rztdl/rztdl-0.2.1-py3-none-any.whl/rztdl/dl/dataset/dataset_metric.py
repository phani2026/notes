# -*- coding: utf-8 -*-
"""
| **@created on:** 17/05/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Cost Module used to create deeplearning objective functions.
|
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

from abc import ABCMeta, abstractmethod
from typeguard import typechecked
from rztdl.utils.validations import validate_name
import logging
import rztdl.utils.string_constants as constants
from rztdl.dl.components import Component
from typing import List

logger = logging.getLogger(__name__)


class DatasetMetric(metaclass=ABCMeta):
    """
    | **@author:** Prathyush SP
    |
    | Dataset metric class
    """

    @typechecked
    def __init__(self, name: str,
                 interval_type: constants.DatasetMetricIntervalType = constants.DatasetMetricIntervalType.EPOCH,
                 interval: int = 1):
        """
        :param name: Name for the metric
        :param interval_type: Type of Interval
        :param interval: Interval
        """
        self.name = validate_name(name)
        self.interval_type = interval_type
        self.interval = interval
        self.id = None

    # @abstractmethod
    # def create_dataset(self, dataset_id: int):
    #     """
    #     | **@author:** Prathyush SP
    #     |
    #     | Used to create a metric function
    #     :param dataset_id: Dataset Id
    #     """
    #     pass  # pragma: no cover

    def validate(self):
        """
        | **@author:** Prathyush SP
        |
        | Validation Method
        """
        pass  # pragma: no cover
