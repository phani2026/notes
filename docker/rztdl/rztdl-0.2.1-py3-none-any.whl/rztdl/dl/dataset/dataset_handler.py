# -*- coding: utf-8 -*-
"""
| **@created on:** 15/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

__all__ = ['DatasetHandler']

import typing
import tensorflow as tf
from typeguard import typechecked
from rztdl.dl import GraphUtils
from rztdl.dl.dataset.dataset_v1 import Dataset
from rztdl.dl.dataset.dataset_split import DatasetSplit
from rztdl.utils.validations import validate_name
from rztdl.utils.dl_exception import DatasetException
import logging
import itertools
from collections import OrderedDict

logger = logging.getLogger(__name__)


class DatasetHandler(object):
    """
    | **@author:** Prathyush SP
    |
    | Base class, which defines abstract methods for dataset
    """

    __slots__ = ['name', 'dataset_elements', 'split_template', 'id', 'is_finalized', 'datasets', '_dataset',
                 'dataset', 'dataset_handle', 'iterators', 'feedable_iterator', 'batch_placeholder', 'reuse']

    @typechecked
    def __init__(self, name: str, dataset_elements: typing.Set[str], split_template: DatasetSplit = None,
                 reuse: bool = False):
        """

        :param name: DatasetHandle Name
        :param dataset_elements: Dataset elements
        :param split_template: Split Template
        """
        self.name = validate_name(name)
        self.dataset_elements = dataset_elements
        self.split_template = split_template
        self.id = 0
        self.is_finalized = False
        self.datasets = []
        self._dataset = Dataset
        self.dataset = None
        self.dataset_handle = None
        self.iterators = None
        self.feedable_iterator = None
        self.batch_placeholder = None
        self.reuse = reuse

    @typechecked
    def add_dataset(self, dataset: Dataset) -> Dataset:
        """
        | **@author:** Prathyush SP
        |
        | Add a type of Dataset
        :param dataset: Dataset
        :return: Dataset object
        """
        self.validate()
        self._dataset = dataset.initialize_dataset(self.id)
        self.id += 1
        self.datasets.append(self._dataset)
        return self._dataset

    @typechecked
    def initialize_dataset(self, split_template: DatasetSplit) -> 'DatasetHandler':
        """
        | **@author:** Prathyush SP
        |
        | Initialize Dataset
        :param split_template: Split Template
        :return: Dataset Handle Object
        """

        self.batch_placeholder = tf.placeholder(dtype=tf.int64).name
        self.split_template = split_template
        self.datasets = [dataset.prepare_dataset(self.split_template) for dataset in self.datasets]

        split_data = {}
        # Initialize Splits
        for i in split_template.split_list:
            split_data[i.name] = {}

        all_colnames = []
        for dataset in self.datasets:
            all_colnames.extend(dataset.column_names)

        def map_func(*t):
            k = []
            for i in t:
                if isinstance(i, tuple):
                    k.extend(i)
                else:
                    k.append(i)
            return {buffer: data for buffer, data in zip(all_colnames, k)}

        new_split = {}
        for split in split_data:
            if len(self.datasets) > 1:
                new_split[split] = tf.data.Dataset.zip(
                    tuple([data_set.split_data[split] for data_set in self.datasets])).map(
                    map_func).batch(GraphUtils.get_tensor(self.batch_placeholder))
            else:
                new_split[split] = self.datasets[0].split_data[split].map(
                    map_func).batch(GraphUtils.get_tensor(self.batch_placeholder))

        self.dataset = new_split
        return self

    def initialize_iterators(self) -> 'DatasetHandler':
        """
        | **@author:** Prathyush SP
        |
        | Create Iterators
        :return: DatasetHandle Object
        """
        with tf.name_scope(name=self.name+'/'):
            self.dataset_handle = tf.placeholder(tf.string, shape=[]).name
        self.iterators = {dk: dd.make_initializable_iterator() for dk, dd in self.dataset.items()}
        self.feedable_iterator = tf.data.Iterator.from_string_handle(
            GraphUtils.get_tensor(self.dataset_handle), list(self.iterators.values())[0].output_types)
        return self

    def close(self) -> 'DatasetHandler':
        """
        | **@author:** Prathyush SP
        |
        | Close Dataset Handle
        :return: DatasetHandle Object
        """
        combined_elements_of_each_dataset = set(
            itertools.chain(*[ds.column_names.keys() for ds in self.datasets]))
        if len(combined_elements_of_each_dataset) > len(self.dataset_elements):
            raise DatasetException(component_name=self.name,
                                   message="Provided Dataset Elements greater than declared dataset elements. Declare these datasets [{}] or remove them".format(
                                       combined_elements_of_each_dataset - self.dataset_elements))
        else:
            for elem in list(self.dataset_elements):
                if elem not in combined_elements_of_each_dataset:
                    raise DatasetException(component_name=self.name,
                                           message="Element [{}] not found in dataset_elements".format(elem))

        self.is_finalized = True
        return self

    @typechecked
    def evaluate(self, tensorflow_session: tf.Session):
        """
        | **@author:** Prathyush SP
        |
        | Evaluate Dataset Handler
        :param tensorflow_session:
        :return: Handler Evaluation
        """
        # todo: Prathyush SP: Evaluate Dataset Handler
        pass

    def validate(self):
        """
        | **@author:** Prathyush SP
        |
        | Validate DatasetHandle
        """
        if self.is_finalized:
            raise Exception('Attempting to add dataset after finalize')
