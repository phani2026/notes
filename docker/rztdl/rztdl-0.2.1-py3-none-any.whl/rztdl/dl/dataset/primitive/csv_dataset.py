# -*- coding: utf-8 -*-
"""
| **@created on:** 15/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

__all__ = ['CsvDataset']

import typing
import numpy as np
import pandas as pd
import tensorflow as tf
from typeguard import typechecked
from rztdl.dl.dataset.dataset_split import DatasetSplit
from rztdl.dl.dataset.dataset_v1 import Dataset
import logging

logger = logging.getLogger(__name__)


class CsvDataset(Dataset):
    """
    | **@author:** Prathyush SP
    |
    | CSV Dataset used to read csv files
    """

    __slots__ = ['file_name']

    @typechecked
    def __init__(self, name: str, file_name: str, column_names: typing.Dict[str, typing.List[typing.Union[int, str]]]):
        """

        :param name: Name of the Dataset
        :param file_name: File Name
        :param column_names: Column Names: ex: {"features": [10,22], "label": ["x", "y"]}. Supports both range and column names
        """
        super().__init__(name=name, column_names=column_names)
        self.file_name = file_name

    @typechecked
    def initialize_dataset(self, dataset_id: int) -> Dataset:
        """
        | **@author:** Prathyush SP
        |
        | Initialize Dataset
        |
        | Description - This function is used to read the file
        :param dataset_id: Dataset Id
        """
        self.id = dataset_id
        return self

    @typechecked
    def prepare_dataset(self, split_template: DatasetSplit) -> Dataset:
        """
        | **@author:** Prathyush SP
        |
        | Prepare CSV Dataset
        |
        | Description - This function is used to split given data according to the split template.
        :param split_template: Split Template
        """
        # todo: Prathyush SP - Change static float32 to load from RZTDL Config File
        all_columns = []
        for buffer_name, col_names in self.column_names.items():
            all_columns.extend(col_names)
        df = pd.read_csv(filepath_or_buffer=self.file_name, usecols=all_columns, header=0, dtype=np.float32)

        split_consumer_dict = {}
        k_agg = 0
        len_df = len(df)
        for split, split_R in zip(split_template.split_list, split_template.split_ratio):
            split_size = int(len_df * split_R / 100)
            split_consumer_dict[split.name] = []
            for buffer_name, col_names in self.column_names.items():
                split_consumer_dict[split.name].append(tf.data.Dataset.from_tensor_slices(
                    df[col_names].iloc[k_agg:(k_agg + split_size)].values.astype('float32', copy=False)))
            k_agg += split_size
        for split_name, split_consumer in split_consumer_dict.items():
            self.split_data[split_name] = tf.data.Dataset.zip(tuple(split_consumer_dict[split_name]))

        return self

    def evaluate(self, tensorflow_session: tf.Session):
        """
        | **@author:** Prathyush SP
        |
        | Evaluate CSV Dataset Dataset
        :param tensorflow_session:
        :return: Dataset Evaluation
        """
        # todo: Prathyush SP: Evaluate CSV Dataset
        pass

    def validate(self):
        """
        | **@author:** Prathyush SP
        |
        | CSV Dataset used to read csv files
        """
        pass
