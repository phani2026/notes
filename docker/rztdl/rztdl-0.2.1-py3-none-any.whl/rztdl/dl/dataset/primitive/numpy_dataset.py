# # -*- coding: utf-8 -*-
# """
# | **@created on:** 18/05/18,
# | **@author:** prathyushsp,
# | **@version:** v0.0.1
# |
# | **Description:**
# | Numpy dataset module which accepts type of numpy dataset
# |
# | **Sphinx Documentation Status:** --
# |
# ..todo::
# """
#
# # Deprecated
#
# __all__ = ['NumpyDataset']
#
# from typeguard import typechecked
# import logging
# import rztdl.utils.string_constants as constants
# from rztdl.dl.dataset.dataset import Dataset
# from rztdl import RZTDL_STORE
# from rztdl.utils.dl_exception import SizeError
# from collections import OrderedDict
# from rztdl.dl.helpers.tfhelpers import GraphUtils
# import typing
#
# logger = logging.getLogger(__name__)
#
#
# class NumpyDataset(Dataset):
#     """
#     | **@author:** Prathyush SP
#     |
#     | Base class, which defines abstract methods for dataset
#     """
#
#     @typechecked
#     def __init__(self, name: str, data: dict, template: constants.DatasetTemplate,
#                  batch_size: int = None, metrics: typing.List[str] = None):
#         """
#         :param name: Name for the metric
#         :param data: A dictionary consisting of {'input buffer name': numpy array}
#         :param template: Template for the dataset, varies between Train, Valid and Test
#         :param batch_size: Batch Size for the data
#         :param metrics: Metrics to be run for the given dataset
#         """
#         super().__init__(name=name, dataset_type=constants.DatasetType.NUMPY, metrics=metrics,
#                          template=template, data=data, batch_size=batch_size)
#
#     def create_dataset(self, model_name: str, dataset_id: int):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Used to create a metric function
#         :param model_name: Name of the model
#         :param dataset_id: Dataset Id
#         :return: Numpy Dataset Object
#         """
#         self.validate()
#         self.validate_placeholders(model_name=model_name)
#         # noinspection PyTypeChecker
#         self.data = self._generate_batches(model_name=model_name, data=self.data, batch_size=self.batch_size)
#         return self
#
#     def __next__(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Used to iterate next batch of data
#         :return: Numpy Dataset Object
#         """
#         self.idx += 1
#         try:
#             return self.data[self.idx - 1]
#         except IndexError:
#             self.idx = 0
#             raise StopIteration
#
#     def _generate_batches(self, model_name: str, data: dict, batch_size: int):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Generate Batches based on placeholders , data and batch parameters
#         :param model_name: Model Name
#         :param data: Data
#         :param batch_size: Batch Size
#         :return: Feed Dictionary for Session
#         """
#         feed_dict = OrderedDict()
#         samples = len(data[[k for k in data.keys()][0]])
#         # todo: Prathyush SP - Removing support for batches option in favour of batch_size option until further development
#         # if batches > 1:
#         #     if batches > samples:
#         #         raise SizeError("Batches can't be greater than total samples")
#         #     batch_size = int(samples / batches)
#         # elif batch_size:
#         if batch_size:
#             if batch_size > samples:
#                 raise SizeError("Batch_size can't be greater than total samples")
#             batches = int(samples / batch_size)
#         else:
#             batch_size = samples
#             batches = 1
#         RZTDL_STORE.update_value_of_result_key(model_name, self.name + "_batches", batches)
#         RZTDL_STORE.update_value_of_result_key(model_name, self.name + "_batch_size", batch_size)
#         placeholders = RZTDL_STORE.get_all_placeholders(model_name)
#         for holder in placeholders.items():
#             feed_dict[GraphUtils.get_tensor(holder[1])] = data[holder[0]]
#         feed_dict = [{key: v[k:k + batch_size] for key, v in feed_dict.items()} for k in range(0, samples, batch_size)]
#         return feed_dict
#
#     def validate(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Validation Method
#         """
#         logger.info("Numpy Dataset ({}) validation success . . .".format(self.name))
