# -*- coding: utf-8 -*-
"""
| **@created on:** 15/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

__all__ = ['KafkaDataset']

import json
import typing
import numpy as np
import tensorflow as tf
from kafka import KafkaConsumer, TopicPartition
from rztdl.dl.dataset.dataset_split import DatasetSplit
from rztdl.dl.dataset.dataset_v1 import Dataset
import logging
from typeguard import typechecked

logger = logging.getLogger(__name__)


class KafkaDataset(Dataset):
    """
    | **@author:** Himaprasoon PT
    |
    | Kafka Dataset which reads from a kafka topic
    | TODO : Add support for index based column mapping
    """

    __slots__ = ['topic_name', 'server', 'end_key_msg', 'max_samples']

    @typechecked
    def __init__(self, name: str, topic_name: str,
                 column_names: typing.Dict[str, typing.List[typing.Union[int, str]]], server: str, end_key_msg="end",
                 max_samples=10000, consumer_timeout_ms=10000):
        """

        :param name: name of the dataset
        :param topic_name: topic name from which data has to be read
        :param column_names: column mapping of the format {"buffer_name1":[col_list],"buffer_name2":[col_list]}
        :param server: IP and port of the kafka server of the format ip:port
        :param end_key_msg: Key of the message which is last in the queue
        :param max_samples: Max num of samples to read
        :param consumer_timeout_ms: Maximum time in millisecond to wait for messages. if timeout is crossed, reading is stopped
        """
        super().__init__(name=name, column_names=column_names)
        self._column_names = [(i, self.column_names[i]) for i in sorted(self.column_names.keys())]
        self.topic_name = topic_name
        self.server = server
        self.end_key_msg = end_key_msg.encode()
        self.max_samples = max_samples
        self.consumer_timeout_ms = consumer_timeout_ms

    @typechecked
    def initialize_dataset(self, dataset_id: int):
        """
        | **@author:** Himaprasoon PT
        |
        | Initialize Kafka Dataset
        :param dataset_id: Dataset Id
        :return: Kafka Dataset
        """
        self.id = dataset_id
        return self

    def prepare_dataset(self, split_template: DatasetSplit):
        """
        Creates a kafka consumer for each split
        :param split_template: split_template
        :return:
        """

        split_data = {}
        # Initialize Splits
        split_consumer_dict = {}
        for split_id, split in enumerate(split_template.split_list):
            split_data[split.name] = {}
            consumer = KafkaConsumer(bootstrap_servers=self.server, auto_offset_reset='earliest',
                                     consumer_timeout_ms=self.consumer_timeout_ms)
            consumer.assign([TopicPartition(self.topic_name, split_id)])
            split_consumer_dict[split.name] = consumer

        len_column_names = len(self._column_names)

        def generator_creator(_consumer, _len_column_names, column_names):
            # TODO move this function outside and make it parameterized
            def _gen():
                for counter, msg in enumerate(_consumer):
                    if msg.key == self.end_key_msg or counter >= self.max_samples:
                        raise StopIteration
                    row = json.loads(msg.value)
                    if not isinstance(row, dict):
                        raise Exception("Msg - {} with key - {} not encoded as json \n".format(row, msg.key.decode()))
                    try:
                        t = tuple(
                            np.asarray([row[col] for col in col_names]) for buffer_name, col_names in column_names)
                    except KeyError as key_error:
                        raise KeyError("Message {} in topic {} has no Key {}".format(row, self.topic_name, key_error))
                    yield t[0] if _len_column_names <= 1 else t
                raise StopIteration

            return _gen

        out_shape = tuple(len(col_names) for buffer_name, col_names in self._column_names)
        out_type = tuple(tf.float32 for i in range(len_column_names))

        for split_name, split_consumer in split_consumer_dict.items():
            self.split_data[split_name] = tf.data.Dataset.from_generator(
                generator_creator(split_consumer, len_column_names, self._column_names),
                output_types=out_type if len_column_names > 1 else tf.float32,
                output_shapes=out_shape)
        return self

    def evaluate(self, tensorflow_session: tf.Session):
        """
        | **@author:** Prathyush SP
        |
        | Evaluate Kafka Dataset
        :param tensorflow_session:
        :return: Kafka Dataset Evaluation
        """
        # todo: Prathyush SP: Evaluate Kafka Dataset
        pass

    def validate(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Kafka Dataset Validation
        """
        pass
