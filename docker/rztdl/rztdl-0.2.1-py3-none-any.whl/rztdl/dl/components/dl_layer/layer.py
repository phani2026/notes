# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Layer Module used to create deeplearning layers
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['Layer']

from abc import ABCMeta, abstractmethod
from typeguard import typechecked
from rztdl.utils.validations import validate_name
import logging
import tensorflow as tf
from numpy import ndarray
from rztdl import RZTDL_CONFIG, RZTDL_STORE
from rztdl.utils.dl_exception import DTypeError, DimensionError, ComponentException
from rztdl.dl.dl_dict_parsers import parse_initialization_dict
from types import FunctionType
from rztdl.dl import tf_summary
import functools
import operator
from tensorflow.python import Tensor
import rztdl.utils.string_constants as constants
from rztdl.dl.components import Component
import typing
from rztdl.dl.helpers.tfhelpers import GraphUtils

logger = logging.getLogger(__name__)


class Layer(Component, metaclass=ABCMeta):
    """
    | **@author:** Prathyush SP
    |
    | Base class, which defines abstract methods for layers
    """

    __slots__ = ['component_sub_type', 'layer_nodes', 'layer_scopes', 'layer_dropout', 'layer_summaries']

    @typechecked
    def __init__(self, name: str, layer_type: constants.LayerType, layer_scopes: typing.List[str],
                 component_input: typing.Union[str, Tensor, None],
                 component_output: typing.Union[str, None, list], layer_summaries: typing.Union[bool, None]):
        """
        :param name: Name for the Layer
        :param layer_type: Type of the Layer
        :param layer_scopes: Scopes for the layer
        :param component_input: Component Input
        :param component_output: Component Output
        :param layer_summaries: Layer Summaries
        """
        super().__init__(name=name, component_type=constants.ComponentType.LAYER,
                         component_input=component_input, component_output=component_output)
        self.layer_dropout = None
        self.layer_nodes = None
        self.component_sub_type = layer_type
        self.layer_scopes = set([validate_name(scope) for scope in layer_scopes])
        self.layer_summaries = RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY if layer_summaries is None else layer_summaries

    @abstractmethod
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Used to create a dl_layer
        :param model_name: Model name
        :param previous_component: Previous Layer
        :param component_id: Layer Id
        """
        pass  # pragma: no cover

    @typechecked
    def _auto_tensor_conversion_2d_to_4d(self, filter_dimensions: typing.List[int], layer_input: str):
        """
        | **@author:** Prathyush SP
        |
        | Auto Tensor Conversion 2D to 4D
        :param filter_dimensions: Filter Dimensions
        :param layer_input: Layer Input
        :return: Nodes and Tensor
        """
        prev_layer_nodes = GraphUtils.get_tensor(layer_input).get_shape().as_list()[-1]
        if GraphUtils.get_tensor(layer_input).get_shape().ndims == 2:
            if RZTDL_CONFIG.TensorflowConfig.AUTO_TENSOR_CONVERSION:
                nodes = prev_layer_nodes ** 0.5
                if not float(nodes).is_integer():
                    raise DimensionError(component_name=self.name, message=
                    "Cannot Use Auto Reshape feature. Use Manual reshape and convert previous dl_layer to rank 4 tensor")
                layer_input = tf.reshape(tensor=GraphUtils.get_tensor(name=layer_input),
                                         shape=[-1, int(nodes), int(nodes), 1]).name
                return prev_layer_nodes, layer_input
            else:
                raise DimensionError(component_name=self.name,
                                     message='Auto Tensor Conversion is disabled. Only 2 dimensional input is allowed ')
        elif GraphUtils.get_tensor(name=layer_input).get_shape().ndims == 4:
            if not prev_layer_nodes == filter_dimensions[-2]:
                raise DimensionError(component_name=self.name, message=
                'Previous Layer out-channels and Current Layer in-channels do not match. ' + str(
                    prev_layer_nodes) + ' : ' + str(filter_dimensions[-2]))
            return prev_layer_nodes, layer_input
        else:
            raise DimensionError(component_name=self.name, message=
            'This layer supports inputs of 2 Dimensions with Auto Tensor Conversion and 4 Dimensions. Given dimension {}'.format(
                GraphUtils.get_tensor(name=layer_input).get_shape().ndims))

    @typechecked
    def _auto_tensor_conversion_nd_to_2d(self, layer_input: str):
        """
        | **@author:** Prathyush SP
        |
        | Auto Tensor Conversion N-D to 4D
        :param layer_input: String
        :return: Layer Nodes, Reshaped Layer Input
        """
        if GraphUtils.get_tensor(name=layer_input).get_shape().ndims > 2:
            if RZTDL_CONFIG.TensorflowConfig.AUTO_TENSOR_CONVERSION:
                with tf.name_scope('auto_tensor_conversion'):
                    layer_nodes = functools.reduce(operator.mul,
                                                   GraphUtils.get_tensor(name=layer_input).get_shape().as_list()[1:])
                    layer_input = tf.reshape(tensor=GraphUtils.get_tensor(name=layer_input),
                                             shape=[-1, int(layer_nodes)]).name

                    return layer_nodes, layer_input
            else:
                raise DimensionError(component_name=self.name,
                                     message='Auto Tensor Conversion is disabled. Only 2 dimensional input is allowed ')
        else:
            # If conversion is not required, return original tensor and original tensor nodes
            return GraphUtils.get_tensor(name=layer_input).get_shape().as_list()[-1], layer_input

    @typechecked
    def _get_or_create_weights(self, weights_dimensions: typing.List[int],
                               layer_weights_param: typing.Union[list, ndarray, dict, FunctionType, str] = None):
        """
        | **@author:** Prathyush SP
        |
        | Generate Layer Weights
        :param weights_dimensions: Weights Dimensions 
        :param layer_weights_param: Layer Weights Configuration
        :return: Layer Weights
        """
        with tf.name_scope('weights'):
            if isinstance(layer_weights_param, ndarray):
                if not str(layer_weights_param.dtype) == str(
                        RZTDL_CONFIG.TensorflowConfig.DTYPE.as_numpy_dtype).replace("<class 'numpy.", '').replace(
                    "'>", ''):
                    raise DTypeError(component_name=self.name, message=
                    'Datatype should match global datatype {}'.format(RZTDL_CONFIG.TensorflowConfig.DTYPE))

                layer_weights = tf.Variable(initial_value=layer_weights_param).name
            elif isinstance(layer_weights_param, dict):
                layer_weights = tf.Variable(
                    initial_value=parse_initialization_dict(initialization_dict=layer_weights_param,
                                                            shape=weights_dimensions)).name
            elif isinstance(layer_weights_param, str):
                generator_shape = RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name,
                                                                             component_name=layer_weights_param).shape
                if weights_dimensions != generator_shape:
                    raise DimensionError(component_name=self.name, message=
                    'Expected shape of {}, got {}'.format(weights_dimensions, generator_shape))
                layer_weights = tf.Variable(
                    initial_value=RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name,
                                                                             component_name=layer_weights_param)).name
            else:
                parse_initialization_dict(
                    initialization_dict=RZTDL_CONFIG.TensorflowConfig.DEFAULT_WEIGHT_FN,
                    shape=weights_dimensions)
                layer_weights = tf.Variable(initial_value=parse_initialization_dict(
                    initialization_dict=RZTDL_CONFIG.TensorflowConfig.DEFAULT_WEIGHT_FN,
                    shape=weights_dimensions)).name
                logger.debug("Generating Weights for " + str(self.name))
            RZTDL_STORE.add_weights(model_name=self.model_name, layer_name=self.name,
                                    layer_weights=layer_weights)
            tf.add_to_collection(layer_weights, GraphUtils.get_variable(name=layer_weights))
            if self.layer_summaries:
                tf_summary.create_variable_summaries(tensor=GraphUtils.get_variable(name=layer_weights))
            # todo: Prathyush SP - Move update graph to model api [Dependency for scope validation]
            RZTDL_STORE.update_graph(model_name=self.model_name, graph=tf.get_default_graph())
            RZTDL_STORE.add_to_scopes(model_name=self.model_name, scopes=self.layer_scopes,
                                      tensor_name=layer_weights)
            return layer_weights

    @typechecked
    def _get_or_create_bias(self, bias_dimensions: typing.List[int],
                            layer_bias_param: typing.Union[list, ndarray, dict, FunctionType, str] = None):
        """
        | **@author:** Prathyush SP
        |
        | Generate Layer Bias
        :param layer_bias_param: Layer Bias Configuration
        :return: Layer Bias
        """
        with tf.name_scope('biases'):
            if isinstance(layer_bias_param, ndarray):
                if not str(layer_bias_param.dtype) == str(
                        RZTDL_CONFIG.TensorflowConfig.DTYPE.as_numpy_dtype).replace("<class 'numpy.", '').replace(
                    "'>", ''):
                    raise DTypeError(component_name=self.name, message=
                    'Datatype should match global datatype {}'.format(RZTDL_CONFIG.TensorflowConfig.DTYPE))
                layer_bias = tf.Variable(initial_value=layer_bias_param).name
            elif isinstance(layer_bias_param, dict):
                layer_bias = tf.Variable(initial_value=
                                         parse_initialization_dict(initialization_dict=layer_bias_param,
                                                                   shape=bias_dimensions)).name
            elif isinstance(layer_bias_param, str):
                generator_shape = RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name,
                                                                             component_name=layer_bias_param).shape
                if bias_dimensions != generator_shape:
                    raise DimensionError(component_name=self.name, message=
                    'Expected shape of {}, got {}'.format(bias_dimensions, generator_shape))
                layer_bias = tf.Variable(
                    initial_value=RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name,
                                                                             component_name=layer_bias_param)).name
            else:
                layer_bias = tf.Variable(initial_value=parse_initialization_dict(
                    initialization_dict=RZTDL_CONFIG.TensorflowConfig.DEFAULT_BIAS_FN,
                    shape=bias_dimensions)).name
                logger.debug("Generating Bias for " + str(self.name))
            RZTDL_STORE.add_bias(model_name=self.model_name, layer_name=self.name,
                                 layer_bias=layer_bias)
            tf.add_to_collection(layer_bias, GraphUtils.get_variable(name=layer_bias))
            if self.layer_summaries:
                tf_summary.create_variable_summaries(tensor=GraphUtils.get_variable(name=layer_bias))
            # todo: Prathyush SP - Move update graph to model api [Dependency for scope validation]
            RZTDL_STORE.update_graph(model_name=self.model_name, graph=tf.get_default_graph())
            RZTDL_STORE.add_to_scopes(model_name=self.model_name, scopes=self.layer_scopes,
                                      tensor_name=layer_bias)
            return layer_bias

    @typechecked
    def _map_input_layer(self, previous_component: Component, layer_input: typing.Union[str, Tensor, None]):
        """
        | **@author:** Prathyush SP
        |
        | Map previous layer input
        |
        | Preference:
        | 1. Component Input of type Tensor
        | 2. Component Input of type String
        | 2. Previous Component, if Component is of type Layer
        :param previous_component: Previous Component
        :param layer_input: Layer Input
        :return: Layer Nodes and Layer Input
        """

        # If component input is a tensor
        if isinstance(layer_input, Tensor):
            layer_nodes = layer_input.get_shape().as_list()[-1]
            layer_input = layer_input.name

        # If Component Input is None, then use Internal
        elif layer_input is None:
            if isinstance(previous_component, Layer):
                if previous_component.layer_nodes <= 0:
                    raise ComponentException(component_name=self.name,
                                             message="Previous Component Layer Nodes is None or 0")
                layer_nodes = previous_component.layer_nodes
                # Replace above line with
                # layer_nodes = GraphUtils.get_tensor(name=previous_component.component_output).get_shape().as_list()[1]
                try:
                    layer_input = GraphUtils.get_tensor(name=previous_component.component_output).name
                except Exception:
                    raise ComponentException(component_name=self.name,
                                             message='Unable to fetch tensor {} from current graph'.format(
                                                 previous_component.component_output))

            else:
                raise ComponentException(component_name=self.name,
                                         message='Previous Component is not Layer. Please specify component_input')

        # If Component Input if of type String
        else:
            try:
                layer_input = RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=layer_input).name
            except Exception:
                raise ComponentException(component_name=self.name,
                                         message='Unable to fetch layer ({}) from model ({})'.format(
                                             layer_input, self.model_name))
            try:
                layer_nodes = GraphUtils.get_tensor(name=layer_input).get_shape().as_list()[-1]
            except Exception:
                raise ComponentException(component_name=self.name,
                                         message='Unable to fetch tensor {} from current graph'.format(
                                             layer_input))
        if layer_nodes <= 0:
            raise ComponentException(component_name=self.name, message='Previous Component Nodes is None or <=0')
        return layer_nodes, layer_input

    @abstractmethod
    def validate(self, previous_component: Component):
        """
        | **@author:** Prathyush SP
        |
        | Validation Method
        """
        pass  # pragma: no cover
