# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Activation Layer Module
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['ActivationLayer']

from collections import OrderedDict

import logging
import rztdl.utils.string_constants as constants
import tensorflow as tf
import typing
from rztdl import RZTDL_CONFIG, RZTDL_STORE
from rztdl.blueprint import Blueprint
from rztdl.dl import tf_summary
from rztdl.dl.components.component import Component
from rztdl.dl.components.dl_layer.layer import Layer
from rztdl.dl.helpers.tfhelpers import Activation
from rztdl.dl.helpers.tfhelpers import GraphUtils
from rztdl.utils.dl_exception import RangeError
from tensorflow import Tensor
from typeguard import typechecked

logger = logging.getLogger(__name__)


class ActivationLayer(Layer):
    """
    | **@author:** Himaprasoon PT
    |
    | Activation Layer
    """
    __slots__ = ['layer_activation', 'prev_layer_nodes', 'layer_dropout']

    @classmethod
    def blueprint(cls):
        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        bp.add_outputs(name="component_output", optional=False, status=constants.STATUS.ACTIVE,
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        bp.add_parameter(name="name", optional=False, status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        bp.add_parameter(name="layer_activation", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.ActivationType.RELU.name,
                         status=constants.ActivationType.blueprint().status,
                         possible_values=constants.ActivationType.blueprint().parameters,
                         class_name=constants.ActivationType.blueprint().class_name)
        bp.add_parameter(name="layer_summaries", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="layer_dropout", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT, status=constants.STATUS.ACTIVE)
        return bp

    @typechecked
    def __init__(self, name, layer_activation: constants.ActivationType = constants.ActivationType.SIGMOID,
                 layer_dropout: typing.Union[float, None] = None,
                 component_input: typing.Union[str, Tensor] = None,
                 component_output: typing.Union[str, Tensor] = None, layer_summaries: bool = None):
        """
        :param name: Layer Name
        :param layer_activation: Layer Activation
        :param component_input: Component Input
        :param component_output: Component Output
        :param layer_dropout: Layer Dropout
        :param layer_summaries: Layer Summaries
        """
        super().__init__(name=name, layer_type=constants.LayerType.ACTIVATION_LAYER,
                         component_input=component_input, component_output=component_output,
                         layer_scopes=[], layer_summaries=layer_summaries)
        self.layer_activation = layer_activation
        self.prev_layer_nodes = None
        self.layer_dropout = layer_dropout

    @typechecked
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Himaprasoon PT
        |
        | Create Activation Layer
        :param model_name: Model Name
        :param previous_component: Previous Layer
        :param component_id: Layer Id
        :return: Activation Layer Object
        """
        self.id = component_id
        self.model_name = model_name
        self.validate(previous_component=previous_component)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.component_output = Activation(
                input_tensor=GraphUtils.get_tensor(name=self.component_input)).parse_activation(
                activation_type=self.layer_activation).name
            layer_details = OrderedDict(
                [(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.component_sub_type),
                 (constants.MODEL_ARCHITECTURE.LAYER_ACTIVATION, self.layer_activation),
                 (constants.MODEL_ARCHITECTURE.LAYER_OUTPUT,
                  GraphUtils.get_tensor(name=self.component_output).get_shape().as_list().__str__())])
            if self.layer_dropout:
                dropout_placeholder = tf.placeholder(dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE).name
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_DROPOUT] = self.layer_dropout
                tf.add_to_collection(name=dropout_placeholder, value=GraphUtils.get_tensor(name=dropout_placeholder))
                RZTDL_STORE.add_dropout_placeholder(model_name=self.model_name, placeholder_name=dropout_placeholder,
                                                    value=self.layer_dropout)
                self.component_output = tf.nn.dropout(x=GraphUtils.get_tensor(name=self.component_output),
                                                      keep_prob=GraphUtils.get_tensor(name=dropout_placeholder)).name
            if self.layer_summaries:
                tf_summary.create_variable_summaries(tensor=GraphUtils.get_tensor(name=self.component_output))
        RZTDL_STORE.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                              layer_details=layer_details)
        tf.add_to_collection(name=self.component_output, value=GraphUtils.get_tensor(name=self.component_output))
        RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.name, tensor_name=self.component_output)

        if self.component_output_name:
            tf.add_to_collection(name=self.component_output_name,
                                 value=GraphUtils.get_tensor(name=self.component_output))
            RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.component_output_name,
                                                       tensor_name=self.component_output)

        return self

    def validate(self, previous_component: Component):
        """
        | **@author:** Himaprasoon PT
        |
        | Activation Layer Validation
        """
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.prev_layer_nodes, self.component_input = self._map_input_layer(previous_component=previous_component,
                                                                                layer_input=self.component_input)
            self.layer_nodes = self.prev_layer_nodes
            if self.layer_dropout and not (0 <= self.layer_dropout <= 1):
                raise RangeError(component_name=self.name,
                                 message="Layer Dropout should be between 0 and 1. Got:{}".format(self.layer_dropout))
        logger.info("Activation Layer ({}) validation success . . .".format(self.name))
