# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Batch Normalization Layer
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['BatchNormalisationLayer']

from rztdl import RZTDL_CONFIG, RZTDL_STORE
import rztdl.utils.string_constants as constants
from rztdl.dl import tf_summary
from tensorflow import Tensor
import tensorflow as tf
from typeguard import typechecked
import logging
from rztdl.utils.dl_exception import LayerException
from collections import OrderedDict
from rztdl.dl.components.dl_layer.layer import Layer
import typing
from rztdl.dl.components.component import Component
from rztdl.dl.helpers.tfhelpers import GraphUtils

logger = logging.getLogger(__name__)


class BatchNormalisationLayer(Layer):
    """
    | **@author:** Umesh Kumar
    |
    | Batch Normalisation Layer

    """

    # __version__ = "0.0.1"
    # __status__ = constants.STATUS.ACTIVE
    # __blueprint__ = {
    #     "version": __version__,
    #     "status": __status__,
    #     "inputs": [
    #         {
    #             "name": "layer_input",
    #             "status": constants.STATUS.ACTIVE,
    #             "description": "",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE
    #         }
    #     ],
    #     "outputs": [],
    #     "parameters": [
    #         {
    #             "name": "name",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
    #             "status": constants.STATUS.ACTIVE,
    #             "description": "",
    #
    #         },
    #         {
    #             "name": "axis",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
    #             "status": constants.STATUS.ACTIVE,
    #             "description": "",
    #             "optional": True,
    #             "default_value": -1
    #
    #         },
    #         {
    #             "name": "momentum",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
    #             "status": constants.STATUS.ACTIVE,
    #             "description": "",
    #             "optional": True,
    #             "default_value": 0.99
    #
    #         },
    #         {
    #             "name": "epsilon",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
    #             "status": constants.STATUS.ACTIVE,
    #             "description": "",
    #             "optional": True,
    #             "default_value": 0.001
    #
    #         },
    #         {
    #             "name": "scale",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
    #             "status": constants.STATUS.ACTIVE,
    #             "description": "",
    #             "optional": True,
    #             "default_value": True
    #
    #         },
    #         {
    #             "name": "center",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
    #             "status": constants.STATUS.ACTIVE,
    #             "description": "",
    #             "optional": True,
    #             "default_value": True
    #
    #         },
    #         {
    #             "name": "beta_initializer",
    #             "description": "",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
    #             "status": constants.InitializerType.__status__,
    #             "possibleValues": constants.InitializerType.__meta__,
    #             "optional": True,
    #             "default_value": constants.InitializerType.ZEROS
    #         },
    #         {
    #             "name": "gamma_initializer",
    #             "description": "",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
    #             "status": constants.InitializerType.__status__,
    #             "possibleValues": constants.InitializerType.__meta__,
    #             "optional": True,
    #             "default_value": constants.InitializerType.ONES
    #         },
    #         {
    #             "name": "moving_mean_initializer",
    #             "description": "",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
    #             "status": constants.InitializerType.__status__,
    #             "possibleValues": constants.InitializerType.__meta__,
    #             "optional": True,
    #             "default_value": constants.InitializerType.ZEROS
    #         },
    #         {
    #             "name": "moving_variance_initializer",
    #             "description": "",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
    #             "status": constants.InitializerType.__status__,
    #             "possibleValues": constants.InitializerType.__meta__,
    #             "optional": True,
    #             "default_value": constants.InitializerType.ONES
    #         },
    #         {
    #             "name": "beta_regularizer",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
    #             "status": constants.STATUS.ACTIVE,
    #             "description": "",
    #             "optional": True,
    #             "default_value": None
    #
    #         },
    #         {
    #             "name": "gamma_regularizer",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
    #             "status": constants.STATUS.ACTIVE,
    #             "description": "",
    #             "optional": True,
    #             "default_value": None
    #
    #         },
    #         {
    #             "name": "training",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
    #             "status": constants.STATUS.ACTIVE,
    #             "description": "",
    #             "optional": True,
    #             "default_value": False
    #
    #         },
    #         {
    #             "name": "trainable",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
    #             "status": constants.STATUS.ACTIVE,
    #             "description": "",
    #             "optional": True,
    #             "default_value": True
    #
    #         },
    #         {
    #             "name": "reuse",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
    #             "status": constants.STATUS.ACTIVE,
    #             "description": "",
    #             "optional": True,
    #             "default_value": None
    #
    #         },
    #         {
    #             "name": "renorm",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
    #             "status": constants.STATUS.ACTIVE,
    #             "description": "",
    #             "optional": True,
    #             "default_value": False
    #
    #         },
    #         {
    #             "name": "renorm_clipping",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
    #             "status": constants.STATUS.ACTIVE,
    #             "description": "",
    #             "optional": True,
    #             "default_value": None
    #
    #         },
    #         {
    #             "name": "renorm_momentum",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
    #             "status": constants.STATUS.ACTIVE,
    #             "description": "",
    #             "optional": True,
    #             "default_value": 0.99
    #
    #         },
    #     ]
    # }

    __slots__ = ['axis', 'momentum', 'epsilon', 'center', 'scale', 'beta_initializer', 'gamma_initializer',
                 'moving_mean_initializer', 'moving_variance_initializer', 'beta_regularizer', 'gamma_regularizer',
                 'training', 'trainable', 'reuse', 'renorm', 'prev_layer_nodes', 'renorm_clipping', 'renorm_momentum']

    @typechecked
    def __init__(self, name: str, component_input: typing.Union[str, Tensor, None] = None, axis=-1, momentum=0.99,
                 epsilon=0.001, center=True, scale=True, beta_initializer=tf.zeros_initializer(),
                 gamma_initializer=tf.ones_initializer(), moving_mean_initializer=tf.zeros_initializer(),
                 moving_variance_initializer=tf.ones_initializer(), beta_regularizer=None, gamma_regularizer=None,
                 training=False, trainable=True, reuse=None, renorm=False, renorm_clipping=None, renorm_momentum=0.99,
                 component_output: typing.Union[str, None] = None, layer_summaries: bool = None):
        """
        todo: Umesh - Describe parameters
        :param name: Name of the Layer
        """
        super().__init__(name=name, layer_type=constants.LayerType.BATCH_NORMALIZATION_LAYER,
                         component_input=component_input, component_output=component_output,
                         layer_summaries=layer_summaries, layer_scopes=[])
        self.axis = axis
        self.momentum = momentum
        self.epsilon = epsilon
        self.center = center
        self.scale = scale
        self.beta_initializer = beta_initializer
        self.gamma_initializer = gamma_initializer
        self.moving_mean_initializer = moving_mean_initializer
        self.moving_variance_initializer = moving_variance_initializer
        self.beta_regularizer = beta_regularizer
        self.gamma_regularizer = gamma_regularizer
        self.training = training
        self.trainable = trainable
        self.reuse = reuse
        self.renorm = renorm
        self.prev_layer_nodes = None
        self.renorm_clipping = renorm_clipping
        self.renorm_momentum = renorm_momentum

    @typechecked
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Umesh Kumar
        | Creates Batch Normalisation Layer
        |
        :param model_name: Model Name
        :param previous_component: Previous Component
        :param component_id: Component Id
        :return: Batch Normalisation Layer Object
        """
        self.id = component_id
        self.model_name = model_name
        self.validate(previous_component=previous_component)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.component_output = tf.layers.batch_normalization(
                inputs=GraphUtils.get_tensor(name=self.component_input),
                axis=self.axis, momentum=self.momentum, epsilon=self.epsilon, center=self.center, scale=self.scale,
                beta_initializer=self.beta_initializer, gamma_initializer=self.gamma_initializer,
                moving_mean_initializer=self.moving_mean_initializer, beta_regularizer=self.beta_regularizer,
                moving_variance_initializer=self.moving_variance_initializer, gamma_regularizer=self.gamma_regularizer,
                training=self.training, trainable=self.trainable, name=self.name, reuse=self.reuse).name
            layer_details = OrderedDict(
                [(constants.MODEL_ARCHITECTURE.LAYER_OUTPUT,
                  GraphUtils.get_tensor(name=self.component_input).get_shape().as_list().__str__())])
            if self.layer_summaries:
                tf_summary.create_variable_summaries(tensor=GraphUtils.get_tensor(name=self.component_output))
        RZTDL_STORE.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                              layer_details=layer_details)
        tf.add_to_collection(name=self.component_output, value=GraphUtils.get_tensor(name=self.component_output))
        RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.name, tensor_name=self.component_output)
        if self.component_output_name:
            tf.add_to_collection(name=self.component_output_name,
                                 value=GraphUtils.get_tensor(name=self.component_output))
            RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.component_output_name,
                                                       tensor_name=self.component_output)
        return self

    def validate(self, previous_component: Component):
        """
        | **@author:** Umesh Kumar
        |
        | Validation method for Batch Normalisation Layer
        """
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.prev_layer_nodes, self.component_input = self._map_input_layer(
                previous_component=previous_component, layer_input=self.component_input)
        logger.info("Batch Normalisation Layer ({}) validation success . . .".format(self.name))
