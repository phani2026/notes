# -*- coding: utf-8 -*-
"""
| **@created on:** 03/05/18,
| **@author:** Umesh Kumar,
| **@version:** v0.1.9
|
| **Description:**
| RNN layer is implementation of TensorFlow Dynamic RNN layer
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
from rztdl.blueprint import Blueprint, BluePrintProperties
from rztdl.dl.helpers import tfhelpers

__all__ = ['RNNLayer']

import logging
import typing
from collections import OrderedDict

import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked

import rztdl.utils.string_constants as constants
from rztdl import RZTDL_CONFIG, RZTDL_STORE, RZTDL_DAG
from rztdl.dl import GraphUtils, tf_summary
from rztdl.dl.components.component import Component
from rztdl.dl.components.dl_layer.layer import Layer
from rztdl.dl.helpers.tfhelpers.rnn_cells import RNNCells
from rztdl.utils.dl_exception import RangeError, ComponentException, NormalizationError

logger = logging.getLogger(__name__)


# noinspection PyProtectedMember
class RNNLayer(Layer):
    """
    | **@author:** Umesh Kumar
    |
    | Dynamic RNN Layer
    """

    @classmethod
    def blueprint(cls):
        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        bp.add_inputs(name="initial_state", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE)
        bp.add_outputs(name="component_output", optional=False, status=constants.STATUS.ACTIVE,
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        p1 = BluePrintProperties(name="name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                                 status=constants.STATUS.ACTIVE, link_to_attribute="rnn_outputs")
        p2 = BluePrintProperties(name="index", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=constants.STATUS.ACTIVE, link_to_attribute="component_indices")
        bp.add_outputs(name="rnn_outputs", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                       properties=[p1, p2], status=constants.STATUS.ACTIVE, repeatable=True)
        p1 = BluePrintProperties(name="name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=constants.STATUS.ACTIVE, link_to_attribute="layer_control_state")
        bp.add_outputs(name="layer_control_state", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                       properties=[p1], status=constants.STATUS.ACTIVE)
        p1 = BluePrintProperties(name="name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=constants.STATUS.ACTIVE, link_to_attribute="layer_hidden_state")
        bp.add_outputs(name="layer_hidden_state", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                       properties=[p1], status=constants.STATUS.ACTIVE)

        bp.add_parameter(name="name", optional=False, status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        p1 = BluePrintProperties(name="cell_type", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                                 status=constants.RNNCell.blueprint().status,
                                 possible_values=constants.RNNCell.blueprint().parameters,
                                 class_name=constants.RNNCell.blueprint().class_name)
        bp.add_parameter(name="layer_cells", optional=True, repeatable=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                         status=constants.STATUS.ACTIVE,
                         properties=[p1])
        bp.add_parameter(name="sequence_length", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="initial_state", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.InitializerType._Parameters.ZEROS.name,
                         status=constants.InitializerType.blueprint().status,
                         possible_values=constants.InitializerType.blueprint().parameters,
                         class_name=constants.InitializerType.blueprint().class_name)
        bp.add_parameter(name="parallel_iterations", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="swap_memory", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="time_major", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="normalisation", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.NormalizationType._Parameters.L2_NORM.name,
                         status=constants.NormalizationType.blueprint().status,
                         class_name=constants.NormalizationType.blueprint().class_name,
                         possible_values=constants.NormalizationType.blueprint().parameters)
        bp.add_parameter(name="layer_summaries", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="layer_scopes", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="layer_dropout", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT, status=constants.STATUS.ACTIVE)
        return bp

    __slots__ = ['layer_control_state', 'layer_hidden_state', 'layer_cells', 'prev_layer_nodes', 'sequence_length',
                 'initial_state', 'parallel_iterations', 'swap_memory', 'time_major', 'component_indices',
                 'normalisation', "rnn_outputs"]

    @typechecked
    def __init__(self, name: str, layer_cells: typing.Union[dict, list],
                 layer_control_state: str = None, layer_hidden_state: str = None,
                 sequence_length: typing.Union[int, None] = None, initial_state: Tensor = None,
                 parallel_iterations: int = None, swap_memory: bool = False, time_major: bool = False,
                 layer_scopes: typing.List[str] = [],
                 component_input: typing.Union[str, Tensor] = None,
                 normalisation: constants.NormalizationType = None,
                 layer_dropout: typing.Union[float, None] = None,
                 component_output: typing.Union[str, None] = None,
                 rnn_outputs: typing.List[typing.Union[str, None]] = None,
                 component_indices: typing.List[typing.Union[int, None]] = None,
                 layer_summaries: bool = None):
        """
        :param name: Name of the Layer
        :param layer_cells: List of dictionaries depicting the RNN Cell Variants or Single Cell
        :param component_input: List of Input Tensors
        :param component_output: Last timestep Output name
        :param rnn_outputs: List of Output names
        :param component_indices: List of Output index
        :param layer_scopes: Layer Scopes
        :param layer_control_state: Layer Control state Output
        :param layer_hidden_state: Layer Hidden state Output
        :param normalisation: Normalisation Type
        :param layer_dropout: Layer Dropout
        :param sequence_length: An int32/int64 vector sized `[batch_size]`.
                Used to copy-through state and zero-out outputs when past a batch
                element's sequence length.  So it's more for correctness than performance.
        :param initial_state: An initial state for the RNN.
                  If `cell.state_size` is an integer, this must be
                  a `Tensor` of appropriate type and shape `[batch_size, cell.state_size]`.
                  If `cell.state_size` is a tuple, this should be a tuple of
                  tensors having shapes `[batch_size, s] for s in cell.state_size`.
        :param parallel_iterations: The number of iterations to run in
                      parallel.  Those operations which do not have any temporal dependency
                      and can be run in parallel, will be.  This parameter trades off
                      time for space.  Values >> 1 use more memory but take less time,
                      while smaller values use less memory but computations take longer.
        :param swap_memory: Transparently swap the tensors produced in forward inference
                            but needed for back prop from GPU to CPU.  This allows training RNNs which would
                             typically not fit on a single GPU, with very minimal (or no) performance penalty.
        :param time_major: The shape format of the `inputs` and `outputs` Tensors.
                            If true, these `Tensors` must be shaped `[max_time, batch_size, depth]`.
                            If false, these `Tensors` must be shaped `[batch_size, max_time, depth]`.
                            Using `time_major = True` is a bit more efficient because it avoids
                            transposes at the beginning and end of the RNN calculation.  However,
                            most TensorFlow data is batch-major, so by default this function
                            accepts input and emits output in batch-major form.
        """
        super().__init__(name=name, layer_type=constants.LayerType.RNN_LAYER, layer_scopes=layer_scopes,
                         component_input=component_input, component_output=component_output,
                         layer_summaries=layer_summaries)
        self.component_output_name = component_output
        self.rnn_outputs = rnn_outputs
        self.normalisation = normalisation
        self.layer_dropout = layer_dropout
        self.component_indices = component_indices
        self.layer_control_state = layer_control_state
        self.layer_hidden_state = layer_hidden_state
        self.layer_cells = layer_cells
        self.prev_layer_nodes = None
        self.sequence_length = sequence_length
        self.initial_state = initial_state
        self.parallel_iterations = parallel_iterations
        self.swap_memory = swap_memory
        self.time_major = time_major

    @typechecked
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Umesh Kumar
        |
        | Create RNN Layer
        :param model_name: Model Name
        :param previous_component: Previous Component
        :param component_id: Component Id
        :return: Layer Object
        """
        # todo: Umesh - Handle scopes
        self.id = component_id
        self.model_name = model_name
        self.validate(previous_component=previous_component)
        RZTDL_DAG.add_node_to_dag(node=self.name, component_type=constants.LayerType)
        RZTDL_DAG.add_edge_to_node(from_node=previous_component.name, to_node=self.name)
        layer_details = OrderedDict([(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.component_sub_type),
                                     (constants.MODEL_ARCHITECTURE.LAYER_CELLS, self.layer_cells)])
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            cells = []
            rnn_cell_object = RNNCells()
            if isinstance(self.layer_cells, list):
                for cell in self.layer_cells:
                    cells.append(
                        rnn_cell_object.switch(rnn_cell=cell[constants.RNNCell._Parameters.CELL.name],
                                               cell_parameters=cell))
            else:
                cells.append(rnn_cell_object.switch(rnn_cell=self.layer_cells[constants.RNNCell._Parameters.CELL.name],
                                                    cell_parameters=self.layer_cells))
            outputs, states = tf.nn.dynamic_rnn(cell=rnn_cell_object.multi_rnn_cell(cells=cells),
                                                inputs=GraphUtils.get_tensor(self.component_input),
                                                sequence_length=self.sequence_length, initial_state=self.initial_state,
                                                dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE,
                                                parallel_iterations=self.parallel_iterations,
                                                swap_memory=self.swap_memory, time_major=self.time_major)
            output = tf.transpose(outputs, [1, 0, 2]).name
            if self.rnn_outputs:
                for each_output, each_index in zip(self.rnn_outputs, self.component_indices):
                    result = tf.gather(GraphUtils.get_tensor(output), each_index).name
                    tf.add_to_collection(name=each_output, value=GraphUtils.get_tensor(result))
                    RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=each_output,
                                                               tensor_name=result)
            if self.layer_control_state:
                tf.add_to_collection(name=self.layer_control_state, value=states[-1][0])
                RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                           component_name=self.layer_control_state,
                                                           tensor_name=states[-1][0].name)
                RZTDL_STORE.add_rnn_state(model_name=self.model_name, state_name=self.layer_control_state,
                                          tensor_name=states[-1][0].name)
            if self.layer_hidden_state:
                tf.add_to_collection(name=self.layer_hidden_state, value=states[-1][1])
                RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                           component_name=self.layer_hidden_state,
                                                           tensor_name=states[-1][1].name)
                RZTDL_STORE.add_rnn_state(model_name=self.model_name, state_name=self.layer_hidden_state,
                                          tensor_name=states[-1][1].name)
            del outputs, cells, states
            self.component_output = tf.gather(GraphUtils.get_tensor(output),
                                              int(GraphUtils.get_tensor(output).get_shape()[0]) - 1).name
            self.layer_nodes = GraphUtils.get_tensor(name=output).get_shape().as_list()[-1]
            if self.layer_dropout:
                dropout_placeholder = tf.placeholder(dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE).name
                tf.add_to_collection(name=dropout_placeholder,
                                     value=GraphUtils.get_tensor(name=dropout_placeholder))
                RZTDL_STORE.add_dropout_placeholder(model_name=self.model_name, placeholder_name=dropout_placeholder,
                                                    value=self.layer_dropout)
                self.component_output = tf.nn.dropout(x=GraphUtils.get_tensor(name=self.component_output),
                                                      keep_prob=GraphUtils.get_tensor(
                                                          name=dropout_placeholder)).name
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_DROPOUT] = self.layer_dropout
            if self.normalisation:
                self.component_output = tfhelpers.NormalizationLayer(
                    input_tensor=GraphUtils.get_tensor(self.component_output)).l2_norm(self.normalisation).name
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_NORMALIZATION] = OrderedDict(
                    [('Parameters', self.normalisation.__dict__)])
            if self.layer_summaries:
                tf_summary.create_variable_summaries(tensor=GraphUtils.get_tensor(self.component_output))
            layer_details[constants.MODEL_ARCHITECTURE.LAYER_OUTPUT] = GraphUtils.get_tensor(
                self.component_output).get_shape().as_list().__str__()
        RZTDL_STORE.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                              layer_details=layer_details)
        tf.add_to_collection(name=self.component_output, value=GraphUtils.get_tensor(self.component_output))
        RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.name,
                                                   tensor_name=self.component_output)
        if self.component_output_name:
            tf.add_to_collection(name=self.component_output_name,
                                 value=GraphUtils.get_tensor(name=self.component_output))
            RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                       component_name=self.component_output_name,
                                                       tensor_name=self.component_output)
        return self

    # noinspection PyProtectedMember
    def validate(self, previous_component: Component):
        """
        | **@author:** Umesh Kumar
        |
        | RNN layer Validation
        :param previous_component: Previous Component
        """
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.prev_layer_nodes, self.component_input = self._map_input_layer(previous_component=previous_component,
                                                                                layer_input=self.component_input)
            if len(GraphUtils.get_tensor(self.component_input).get_shape().as_list()) != 3:
                raise ComponentException(component_name=self.name,
                                         message="Component Input for RNN layer always expect 3D input")
            if self.rnn_outputs:
                if not self.component_indices:
                    raise ComponentException(component_name=self.name,
                                             message="If RNN output is given then we have "
                                                     "specify Component indices also")
                else:
                    if len(self.rnn_outputs) != len(self.component_indices):
                        raise ComponentException(component_name=self.name,
                                                 message="RNN Output and indices are should of same length")
                for each_index in self.component_indices:
                    if each_index >= GraphUtils.get_tensor(self.component_input).get_shape().as_list()[1]:
                        raise ComponentException(component_name=self.name,
                                                 message="RNN Output indices should be in range [0, {}). Given {}".format(
                                                     GraphUtils.get_tensor(self.component_input).get_shape().as_list()[
                                                         1], each_index))
            all_cells = self.layer_cells if isinstance(self.layer_cells, list) else [self.layer_cells]
            for cell in all_cells:
                if cell[constants.RNNCell._Parameters.NUM_UNITS.name] <= 0:
                    raise RangeError(component_name=self.name,
                                     message="num_units field should be an integer greater than zero")
                if cell[constants.RNNCell._Parameters.CELL.name] == constants.RNNCell._Parameters.LSTMCELL or cell[
                    constants.RNNCell._Parameters.CELL.name] == constants.RNNCell._Parameters.BASIC_LSTM_CELL.name:
                    if cell[constants.RNNCell._Parameters.FORGET_BIAS.name] < 0 or cell[
                        constants.RNNCell._Parameters.FORGET_BIAS.name] > 1.0:
                        raise RangeError(component_name=self.name,
                                         message=" Forget bias of an RNN Cell should be within 0 and 1 ")
            if self.normalisation and not self.normalisation[
                                              constants.NormalizationType._Parameters.NORM_TYPE.name] == constants.NormalizationType._Parameters.L2_NORM:
                raise NormalizationError(component_name=self.name,
                                         message="For RNN Layer Normalization should be L2_NORM")
            if self.layer_dropout and not (0 <= self.layer_dropout <= 1):
                raise RangeError(component_name=self.name,
                                 message="Layer Dropout should be between 0 and 1. Got: {}".format(self.layer_dropout))
            logger.info("RNNLayer ({}) Validation Success . . .".format(self.name))
