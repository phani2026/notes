# -*- coding: utf-8 -*-
"""
| **@created on:** 04/05/18,
| **@author:** Umesh Kumar,
| **@version:** v0.1.9
|
| **Description:**
| Bidirectional RNN layer is implementation of TensorFlow Dynamic Bidirectional RNN layer
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
from rztdl.blueprint import Blueprint, BluePrintProperties

__all__ = ['BidirectionalRNNLayer']

import logging
import typing
from collections import OrderedDict

import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked

import rztdl.utils.string_constants as constants
from rztdl import RZTDL_CONFIG, RZTDL_STORE
from rztdl.dl import tf_summary
from rztdl.dl.components.component import Component
from rztdl.dl.components.dl_layer.layer import Layer
from rztdl.dl.helpers import tfhelpers
from rztdl.dl.helpers.tfhelpers import GraphUtils
from rztdl.dl.helpers.tfhelpers.rnn_cells import RNNCells
from rztdl.utils.dl_exception import RangeError, ComponentException, NormalizationError

logger = logging.getLogger(__name__)


class BidirectionalRNNLayer(Layer):
    """
    | **@author:** Umesh Kumar
    |
    | Dynamic Bidirectional RNN Layer
    |
    """

    # noinspection PyProtectedMember
    @classmethod
    def blueprint(cls):
        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        bp.add_inputs(name="initial_state_forward", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="initial_state_backward", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE)
        bp.add_outputs(name="component_output", optional=False, status=constants.STATUS.ACTIVE,
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        p1 = BluePrintProperties(name="name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=constants.STATUS.ACTIVE, link_to_attribute="forward_cell_output")
        p2 = BluePrintProperties(name="index", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=constants.STATUS.ACTIVE, link_to_attribute="forward_cell_output_indices")
        bp.add_outputs(name="forward_cell_output", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                       properties=[p1, p2], status=constants.STATUS.ACTIVE, repeatable=True)
        p1 = BluePrintProperties(name="name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=constants.STATUS.ACTIVE, link_to_attribute="backward_cell_output")
        p2 = BluePrintProperties(name="index", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=constants.STATUS.ACTIVE, link_to_attribute="backward_cell_output_indices")
        bp.add_outputs(name="backward_cell_output", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                       properties=[p1, p2], status=constants.STATUS.ACTIVE, repeatable=True)
        p1 = BluePrintProperties(name="name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=constants.STATUS.ACTIVE, link_to_attribute="forward_cell_control_state_name")
        bp.add_outputs(name="forward_cell_control_state_name",
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                       properties=[p1], status=constants.STATUS.ACTIVE)
        p1 = BluePrintProperties(name="name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=constants.STATUS.ACTIVE, link_to_attribute="forward_cell_hidden_state_name")
        bp.add_outputs(name="forward_cell_hidden_state_name",
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                       properties=[p1], status=constants.STATUS.ACTIVE)
        p1 = BluePrintProperties(name="name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=constants.STATUS.ACTIVE, link_to_attribute="backward_cell_control_state_name")
        bp.add_outputs(name="backward_cell_control_state_name",
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                       properties=[p1], status=constants.STATUS.ACTIVE)
        p1 = BluePrintProperties(name="name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=constants.STATUS.ACTIVE, link_to_attribute="backward_cell_hidden_state_name")
        bp.add_outputs(name="backward_cell_hidden_state_name",
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                       properties=[p1], status=constants.STATUS.ACTIVE)

        bp.add_parameter(name="name", optional=False, status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        p1 = BluePrintProperties(name="cell_type", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                                 status=constants.RNNCell.blueprint().status,
                                 possible_values=constants.RNNCell.blueprint().parameters,
                                 class_name=constants.RNNCell.blueprint().class_name)
        bp.add_parameter(name="forward_cell", optional=True, repeatable=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                         properties=[p1],
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="backward_cell", optional=True, repeatable=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                         properties=[p1],
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="sequence_length", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="initial_state_forward", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.InitializerType._Parameters.ZEROS.name,
                         status=constants.InitializerType.blueprint().status,
                         possible_values=constants.InitializerType.blueprint().parameters,
                         class_name=constants.InitializerType.blueprint().class_name)
        bp.add_parameter(name="initial_state_backward", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.InitializerType._Parameters.ZEROS.name,
                         status=constants.InitializerType.blueprint().status,
                         possible_values=constants.InitializerType.blueprint().parameters,
                         class_name=constants.InitializerType.blueprint().class_name)
        bp.add_parameter(name="parallel_iterations", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="swap_memory", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="time_major", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="normalisation", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.NormalizationType._Parameters.L2_NORM.name,
                         status=constants.NormalizationType.blueprint().status,
                         class_name=constants.NormalizationType.blueprint().class_name,
                         possible_values=constants.NormalizationType.blueprint().parameters)
        bp.add_parameter(name="layer_summaries", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="layer_scopes", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="layer_dropout", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT, status=constants.STATUS.ACTIVE)
        return bp

    __slots__ = ["forward_cell_outputs", "backward_cell_outputs", "forward_cell_control_state",
                 "forward_cell_hidden_state", "backward_cell_control_state", "backward_cell_hidden_state",
                 "forward_cell", "backward_cell", "sequence_length", "initial_state_forward", "initial_state_backward",
                 "parallel_iterations", "swap_memory", "time_major", "normalisation", "forward_cell_output_indices",
                 "backward_cell_output_indices", "prev_layer_nodes"]

    @typechecked
    def __init__(self, name: str, forward_cell: typing.Union[dict, list], backward_cell: typing.Union[dict, list],
                 forward_cell_output: list = None, backward_cell_output: list = None,
                 forward_cell_output_indices: list = None, backward_cell_output_indices: list = None,
                 forward_cell_control_state_name: str = None, forward_cell_hidden_state_name: str = None,
                 backward_cell_control_state_name: str = None, backward_cell_hidden_state_name: str = None,
                 sequence_length: typing.Union[int, None] = None, initial_state_forward: Tensor = None,
                 initial_state_backward: Tensor = None, parallel_iterations: int = None,
                 swap_memory: bool = False, time_major: bool = False, layer_scopes: typing.List[str] = [],
                 component_input: typing.Union[str, Tensor] = None,
                 component_output: typing.Union[str, Tensor] = None,
                 normalisation: constants.NormalizationType = None,
                 layer_dropout: typing.Union[float, None] = None,
                 layer_summaries: bool = None):
        """
        :param name: Name of the Layer
        :param forward_cell_output : List of Forward cell Outputs.
        :param backward_cell_output : List of Forward cell Outputs.
        :param forward_cell_output_indices : List of Forward cell Output indices
        :param backward_cell_output_indices : List of Backward cell Output indices
        :param forward_cell : An instance of RNNCell, to be used for forward direction.
        :param backward_cell : An instance of RNNCell, to be used for backend direction.
        :param forward_cell_control_state_name : Forward cell control state for further reference
        :param forward_cell_hidden_state_name : Forward cell hidden state for further reference
        :param backward_cell_control_state_name : Backward cell control state for further reference
        :param backward_cell_hidden_state_name : Backward cell hidden state for further reference
        :param normalisation: Normalisation Type
        :param layer_dropout: Layer Dropout
        :param sequence_length: An int32/int64 vector sized `[batch_size]`.
                Used to copy-through state and zero-out outputs when past a batch
                element's sequence length.  So it's more for correctness than performance.
        :param initial_state_forward: An initial state for the RNN.
                  If `cell.state_size` is an integer, this must be
                  a `Tensor` of appropriate type and shape `[batch_size, cell.state_size]`.
                  If `cell.state_size` is a tuple, this should be a tuple of
                  tensors having shapes `[batch_size, s] for s in cell.state_size`.
        :param initial_state_backward : Same as for `initial_state_fw`, but using
                    the corresponding properties of `cell_bw`.
        :param parallel_iterations: The number of iterations to run in
                      parallel.  Those operations which do not have any temporal dependency
                      and can be run in parallel, will be.  This parameter trades off
                      time for space.  Values >> 1 use more memory but take less time,
                      while smaller values use less memory but computations take longer.
        :param swap_memory: Transparently swap the tensors produced in forward inference
                            but needed for back prop from GPU to CPU.  This allows training RNNs which would
                            typically not fit on a single GPU, with very minimal (or no) performance penalty.
        :param time_major: The shape format of the `inputs` and `outputs` Tensors.
                            If true, these `Tensors` must be shaped `[max_time, batch_size, depth]`.
                            If false, these `Tensors` must be shaped `[batch_size, max_time, depth]`.
                            Using `time_major = True` is a bit more efficient because it avoids
                            transposes at the beginning and end of the RNN calculation.  However,
                            most TensorFlow data is batch-major, so by default this function
                            accepts input and emits output in batch-major form.
        """

        # todo: Umesh - Handle scopes
        super().__init__(name=name, layer_type=constants.LayerType.BI_DIRECTIONAL_RNN_LAYER, layer_scopes=layer_scopes,
                         component_input=component_input, component_output=component_output,
                         layer_summaries=layer_summaries)
        self.component_output_name = component_output
        self.forward_cell_output_indices = forward_cell_output_indices
        self.backward_cell_output_indices = backward_cell_output_indices
        self.forward_cell_outputs = forward_cell_output
        self.backward_cell_outputs = backward_cell_output
        self.forward_cell_control_state = forward_cell_control_state_name
        self.forward_cell_hidden_state = forward_cell_hidden_state_name
        self.backward_cell_control_state = backward_cell_control_state_name
        self.backward_cell_hidden_state = backward_cell_hidden_state_name
        self.forward_cell = forward_cell
        self.backward_cell = backward_cell
        self.sequence_length = sequence_length
        self.initial_state_forward = initial_state_forward
        self.initial_state_backward = initial_state_backward
        self.parallel_iterations = parallel_iterations
        self.swap_memory = swap_memory
        self.time_major = time_major
        self.prev_layer_nodes = None
        self.layer_dropout = layer_dropout
        self.normalisation = normalisation

    # noinspection PyProtectedMember
    @typechecked
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Umesh Kumar
        |
        | Create RNN Layer
        |
        |
        :param model_name: Model Name
        :param previous_component: Previous Component
        :param component_id: Component Id
        :return: Layer Object
        """
        self.id = component_id
        self.model_name = model_name
        self.validate(previous_component=previous_component)
        layer_details = OrderedDict([(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.component_sub_type),
                                     (constants.MODEL_ARCHITECTURE.LAYER_CELLS + "_forward_cells", self.forward_cell),
                                     (constants.MODEL_ARCHITECTURE.LAYER_CELLS + "_backward_cells",
                                      self.backward_cell)])
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            forward_cells, backward_cells = [], []
            rnn_cell_object = RNNCells()
            if isinstance(self.forward_cell, list):
                for cell in self.forward_cell:
                    forward_cells.append(
                        rnn_cell_object.switch(rnn_cell=cell[constants.RNNCell._Parameters.CELL.name],
                                               cell_parameters=cell))
            else:
                forward_cells.append(
                    rnn_cell_object.switch(rnn_cell=self.forward_cell[constants.RNNCell._Parameters.CELL.name],
                                           cell_parameters=self.forward_cell))
            if isinstance(self.backward_cell, list):
                for cell in self.backward_cell:
                    backward_cells.append(
                        rnn_cell_object.switch(rnn_cell=cell[constants.RNNCell._Parameters.CELL.name],
                                               cell_parameters=cell))
            else:
                backward_cells.append(
                    rnn_cell_object.switch(rnn_cell=self.backward_cell[constants.RNNCell._Parameters.CELL.name],
                                           cell_parameters=self.backward_cell))
            outputs, states = tf.nn.bidirectional_dynamic_rnn(
                cell_fw=rnn_cell_object.multi_rnn_cell(cells=forward_cells),
                cell_bw=rnn_cell_object.multi_rnn_cell(cells=backward_cells),
                inputs=GraphUtils.get_tensor(self.component_input),
                sequence_length=self.sequence_length,
                initial_state_fw=self.initial_state_forward,
                initial_state_bw=self.initial_state_backward,
                parallel_iterations=self.parallel_iterations,
                dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE,
                swap_memory=self.swap_memory, time_major=self.time_major)
            forward_cells_output = tf.transpose(outputs[0], [1, 0, 2]).name
            backward_cells_output = tf.transpose(outputs[1], [1, 0, 2]).name
            states = list(states)
            forward_states = list(states[0])
            backward_states = list(states[1])
            if self.forward_cell_outputs:
                for each_output, each_index in zip(self.forward_cell_outputs, self.forward_cell_output_indices):
                    result = tf.gather(GraphUtils.get_tensor(forward_cells_output), each_index).name
                    tf.add_to_collection(name=each_output, value=GraphUtils.get_tensor(result))
                    RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=each_output,
                                                               tensor_name=result)
            if self.backward_cell_outputs:
                for each_output, each_index in zip(self.backward_cell_outputs, self.backward_cell_output_indices):
                    result = tf.gather(GraphUtils.get_tensor(backward_cells_output), each_index).name
                    tf.add_to_collection(name=each_output, value=GraphUtils.get_tensor(result))
                    RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=each_output,
                                                               tensor_name=result)
            if self.forward_cell_control_state:
                tf.add_to_collection(name=self.forward_cell_control_state, value=forward_states[-1][0])
                RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                           component_name=self.forward_cell_control_state,
                                                           tensor_name=forward_states[-1][0].name)
                RZTDL_STORE.add_rnn_state(model_name=self.model_name, state_name=self.forward_cell_control_state,
                                          tensor_name=forward_states[-1][0].name)
            if self.forward_cell_hidden_state:
                tf.add_to_collection(name=self.forward_cell_hidden_state, value=forward_states[-1][1])
                RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                           component_name=self.forward_cell_hidden_state,
                                                           tensor_name=forward_states[-1][1].name)
                RZTDL_STORE.add_rnn_state(model_name=self.model_name, state_name=self.forward_cell_hidden_state,
                                          tensor_name=forward_states[-1][1].name)
            if self.backward_cell_control_state:
                tf.add_to_collection(name=self.backward_cell_control_state, value=backward_states[-1][0])
                RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                           component_name=self.backward_cell_control_state,
                                                           tensor_name=backward_states[-1][0].name)
                RZTDL_STORE.add_rnn_state(model_name=self.model_name, state_name=self.backward_cell_control_state,
                                          tensor_name=backward_states[-1][0].name)
            if self.backward_cell_hidden_state:
                tf.add_to_collection(name=self.backward_cell_hidden_state, value=backward_states[-1][1])
                RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                           component_name=self.backward_cell_hidden_state,
                                                           tensor_name=backward_states[-1][1].name)
                RZTDL_STORE.add_rnn_state(model_name=self.model_name, state_name=self.backward_cell_hidden_state,
                                          tensor_name=backward_states[-1][1].name)
            del states, forward_cells, backward_cells, outputs
            self.component_output = tf.gather(GraphUtils.get_tensor(backward_cells_output),
                                              int(GraphUtils.get_tensor(backward_cells_output).get_shape()[
                                                      0]) - 1).name
            self.layer_nodes = GraphUtils.get_tensor(name=self.component_output).get_shape().as_list()[-1]
            if self.layer_dropout:
                dropout_placeholder = tf.placeholder(dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE).name
                tf.add_to_collection(name=dropout_placeholder,
                                     value=GraphUtils.get_tensor(name=dropout_placeholder))
                RZTDL_STORE.add_dropout_placeholder(model_name=self.model_name, placeholder_name=dropout_placeholder,
                                                    value=self.layer_dropout)
                self.component_output = tf.nn.dropout(x=GraphUtils.get_tensor(name=self.component_output),
                                                      keep_prob=GraphUtils.get_tensor(
                                                          name=dropout_placeholder)).name
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_DROPOUT] = self.layer_dropout
            if self.normalisation:
                self.component_output = tfhelpers.NormalizationLayer(
                    input_tensor=GraphUtils.get_tensor(self.component_output)).l2_norm(self.normalisation).name
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_NORMALIZATION] = OrderedDict(
                    [('Parameters', self.normalisation.__dict__)])
            if self.layer_summaries:
                tf_summary.create_variable_summaries(tensor=GraphUtils.get_tensor(self.component_output))
            layer_details[constants.MODEL_ARCHITECTURE.LAYER_OUTPUT] = GraphUtils.get_tensor(
                self.component_output).get_shape().as_list().__str__()
        RZTDL_STORE.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                              layer_details=layer_details)
        tf.add_to_collection(name=self.component_output, value=GraphUtils.get_tensor(self.component_output))
        RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.name,
                                                   tensor_name=self.component_output)
        if self.component_output_name:
            tf.add_to_collection(name=self.component_output_name,
                                 value=GraphUtils.get_tensor(name=self.component_output))
            RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                       component_name=self.component_output_name,
                                                       tensor_name=self.component_output)
        return self

    # noinspection PyProtectedMember
    def validate(self, previous_component: Component):
        """
        | **@author:** Umesh Kumar
        |
        | Bidirectional RNN layer Validation
        :param previous_component: Previous Component
        """
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.prev_layer_nodes, self.component_input = self._map_input_layer(previous_component=previous_component,
                                                                                layer_input=self.component_input)
            if len(GraphUtils.get_tensor(self.component_input).get_shape().as_list()) != 3:
                raise ComponentException(component_name=self.name,
                                         message="Component Input for Bidirectional RNN layer always expect 3D input")
            if self.forward_cell_outputs:
                if not self.forward_cell_output_indices:
                    raise ComponentException(component_name=self.name,
                                             message="If forward cell output is given then we have "
                                                     "specify forward cell output indices also")
                else:
                    if len(self.forward_cell_outputs) != len(self.forward_cell_output_indices):
                        raise ComponentException(component_name=self.name,
                                                 message="Forward cell Output and indices are should of same length")
                for each_index in self.forward_cell_output_indices:
                    if each_index >= GraphUtils.get_tensor(self.component_input).get_shape().as_list()[1]:
                        raise ComponentException(component_name=self.name,
                                                 message="Forward cell Output indices should be in range [0, {}). Given {}".format(
                                                     GraphUtils.get_tensor(self.component_input).get_shape().as_list()[
                                                         1], each_index))
            if self.backward_cell_outputs:
                if not self.backward_cell_output_indices:
                    raise ComponentException(component_name=self.name,
                                             message="If backward cell output is given then we have "
                                                     "specify backward cell output indices also")
                else:
                    if len(self.backward_cell_outputs) != len(self.backward_cell_output_indices):
                        raise ComponentException(component_name=self.name,
                                                 message="Backward cell Output and indices are should of same length")
                for each_index in self.backward_cell_output_indices:
                    if each_index >= GraphUtils.get_tensor(self.component_input).get_shape().as_list()[1]:
                        raise ComponentException(component_name=self.name,
                                                 message="Backward cell Output indices should be in range [0, {}). Given {}".format(
                                                     GraphUtils.get_tensor(self.component_input).get_shape().as_list()[
                                                         1], each_index))
            forward_cells = self.forward_cell if isinstance(self.forward_cell, list) else [self.forward_cell]
            backward_cells = self.backward_cell if isinstance(self.backward_cell, list) else [self.backward_cell]
            all_cells = forward_cells + backward_cells
            for cell in all_cells:
                if cell[constants.RNNCell._Parameters.NUM_UNITS.name] <= 0:
                    raise RangeError(component_name=self.name,
                                     message="num_units field should be an integer greater than zero")
                if cell[constants.RNNCell._Parameters.CELL.name] == constants.RNNCell._Parameters.LSTMCELL or cell[
                    constants.RNNCell._Parameters.CELL.name] == constants.RNNCell._Parameters.BASIC_LSTM_CELL.name:
                    if cell[constants.RNNCell._Parameters.FORGET_BIAS.name] < 0 or cell[
                        constants.RNNCell._Parameters.FORGET_BIAS.name] > 1.0:
                        raise RangeError(component_name=self.name,
                                         message=" Forget bias of an RNN Cell should be within 0 and 1 ")
            if self.normalisation and not self.normalisation[
                                              constants.NormalizationType._Parameters.NORM_TYPE.name] == constants.NormalizationType._Parameters.L2_NORM:
                raise NormalizationError(component_name=self.name,
                                         message="For Bidirectional Layer Normalization should be L2_NORM")
            if self.layer_dropout and not (0 <= self.layer_dropout <= 1):
                raise RangeError(component_name=self.name,
                                 message="Layer Dropout should be between 0 and 1. Got: {}".format(self.layer_dropout))
            logger.info("Bidirectional RNNLayer ({}) Validation Success . . .".format(self.name))
