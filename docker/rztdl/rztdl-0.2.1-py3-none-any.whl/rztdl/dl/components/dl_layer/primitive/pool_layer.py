# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Pool Layer Module
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['PoolLayer']

import logging
import typing
from collections import OrderedDict
import rztdl.utils.string_constants as constants
import tensorflow as tf
from rztdl import RZTDL_CONFIG, RZTDL_STORE, RZTDL_DAG
from rztdl.blueprint import Blueprint
from rztdl.dl import tf_summary
from rztdl.dl.components.component import Component
from rztdl.dl.components.dl_layer.layer import Layer
from rztdl.dl.helpers import tfhelpers
from rztdl.dl.helpers.tfhelpers import GraphUtils
from rztdl.utils.dl_exception import DimensionError, RangeError, PaddingError
from tensorflow import Tensor
from typeguard import typechecked

logger = logging.getLogger(__name__)


class PoolLayer(Layer):
    """
    | **@author:** Prathyush SP
    |
    | Pool Layer Class
    .. note:: Pool Layer supports only 4 dimension input, usually Convolution Layer
    """

    __slots__ = ['pool_dimensions', 'pool_strides', 'pool_padding', 'pool_type', 'normalisation',
                 'prev_layer_nodes']

    # noinspection PyProtectedMember
    @classmethod
    def blueprint(cls):
        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        bp.add_parameter(name="name", optional=False, status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        bp.add_outputs(name="component_output", optional=False, status=constants.STATUS.ACTIVE,
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        bp.add_parameter(name="pool_dimensions", optional=False, status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.ARRAYOFINT)
        bp.add_parameter(name="pool_strides", optional=False, status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.ARRAYOFINT)

        bp.add_parameter(name="pool_padding", optional=False,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.PaddingType.SAME.name,
                         status=constants.PaddingType.blueprint().status,
                         possible_values=constants.PaddingType.blueprint().parameters,
                         class_name=constants.PaddingType.blueprint().class_name)
        bp.add_parameter(name="pool_type", optional=False,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.PoolType.MAX_POOL.name,
                         status=constants.PoolType.blueprint().status,
                         possible_values=constants.PoolType.blueprint().parameters,
                         class_name=constants.PoolType.blueprint().class_name)
        bp.add_parameter(name="normalisation", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.NormalizationType._Parameters.L2_NORM.name,
                         status=constants.NormalizationType.blueprint().status,
                         class_name=constants.NormalizationType.blueprint().class_name,
                         possible_values=constants.NormalizationType.blueprint().parameters)
        bp.add_parameter(name="layer_dropout", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT, status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="layer_summaries", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                         status=constants.STATUS.ACTIVE)
        return bp

    @typechecked
    def __init__(self, name: str, pool_dimensions: list, pool_strides: list, pool_padding: constants.PaddingType,
                 pool_type: constants.PoolType = constants.PoolType.MAX_POOL, layer_dropout: float = None,
                 normalisation: constants.NormalizationType = None,
                 component_input: typing.Union[str, Tensor] = None,
                 component_output: typing.Union[str, None] = None,
                 layer_summaries: bool = None):
        """
        :param name: Name of the Layer
        :param pool_dimensions: Pool Dimensions
        :param pool_strides: Strides for the Pool
        :param pool_padding: Pool Padding
        :param pool_type: Pool type [max_pool, avg_pool]
        :param normalisation: Normalisation
        :param component_input: Component Input
        :param component_output: Component Output
        :param layer_summaries: Layer Summaries
        :param layer_dropout: Layer Dropout
        """
        super().__init__(name=name, layer_type=constants.LayerType.POOL_LAYER, layer_scopes=[],
                         component_input=component_input, component_output=component_output,
                         layer_summaries=layer_summaries)
        self.pool_dimensions = pool_dimensions
        self.pool_strides = pool_strides
        self.pool_padding = pool_padding
        self.pool_type = pool_type
        self.layer_dropout = layer_dropout
        self.prev_layer_nodes = None
        self.layer_nodes = None
        self.normalisation = normalisation

    @typechecked
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Create Pool Layer
        :param model_name: Model Name
        :param previous_component: Previous Component
        :param component_id: Component ID
        :return: Pool Layer Object
        """
        self.model_name = model_name
        self.id = component_id
        self.validate(previous_component=previous_component)
        RZTDL_DAG.add_node_to_dag(node=self.name, component_type=constants.LayerType)
        RZTDL_DAG.add_edge_to_node(from_node=previous_component.name, to_node=self.name)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.component_output = Pool(input_tensor=GraphUtils.get_tensor(name=self.component_input)).parse_pool(
                pool_type=self.pool_type,
                ksize=self.pool_dimensions,
                strides=self.pool_strides,
                padding=self.pool_padding.name).name
            layer_details = OrderedDict(
                [(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.component_sub_type),
                 (constants.MODEL_ARCHITECTURE.LAYER_DIMENSIONS, self.pool_dimensions.__str__()),
                 (constants.MODEL_ARCHITECTURE.LAYER_STRIDES, self.pool_strides.__str__()),
                 (constants.MODEL_ARCHITECTURE.LAYER_OUTPUT,
                  GraphUtils.get_tensor(name=self.component_output).get_shape().as_list().__str__())])
            if self.layer_dropout:
                dropout_placeholder = tf.placeholder(dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE).name
                tf.add_to_collection(dropout_placeholder, GraphUtils.get_tensor(name=dropout_placeholder))
                RZTDL_STORE.add_dropout_placeholder(model_name=self.model_name, placeholder_name=dropout_placeholder,
                                                    value=self.layer_dropout)
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_DROPOUT] = self.layer_dropout
                self.component_output = tf.nn.dropout(x=GraphUtils.get_tensor(name=self.component_output),
                                                      keep_prob=self.layer_dropout).name
            if self.normalisation:
                self.component_output = tfhelpers.NormalizationLayer(
                    input_tensor=GraphUtils.get_tensor(name=self.component_output)).parse_norm(
                    norm_type=self.normalisation).name
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_NORMALIZATION] = OrderedDict(
                    [('Parameters', self.normalisation.__dict__)])
            if self.layer_summaries:
                tf_summary.create_variable_summaries(tensor=GraphUtils.get_tensor(name=self.component_output))
        RZTDL_STORE.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                              layer_details=layer_details)
        tf.add_to_collection(name=self.component_output, value=GraphUtils.get_tensor(name=self.component_output))
        RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.name, tensor_name=self.component_output)
        if self.component_output_name:
            tf.add_to_collection(name=self.component_output_name,
                                 value=GraphUtils.get_tensor(name=self.component_output))
            RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.component_output_name,
                                                       tensor_name=self.component_output)
        return self

    def validate(self, previous_component: Component):
        """
        | **@author:** Prathyush SP
        |
        Pool Layer Validation
        """
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.prev_layer_nodes, self.component_input = self._map_input_layer(previous_component=previous_component,
                                                                                layer_input=self.component_input)
            self.layer_nodes = self.prev_layer_nodes
            if self.layer_dropout and not (0 <= self.layer_dropout <= 1):
                raise RangeError(component_name=self.name,
                                 message="Layer Dropout should be between 0 and 1 Got:{}".format(
                                     self.layer_dropout))
            if self.pool_padding not in constants.PaddingType.__dict__.values():
                raise PaddingError(component_name=self.name, message="Not a valid Padding. Usage: constant.PADDING.<>")
            if GraphUtils.get_tensor(name=self.component_input).get_shape().ndims < 4:
                raise DimensionError(component_name=self.name, message='Pooling Operation doesnt support ndim < 4')
            if len(self.pool_dimensions) < 4:
                raise DimensionError(component_name=self.name, message='Pool Dimensions needs 4 values. Ex: [1,2,2,1]')
            if len(self.pool_strides) < 4:
                raise DimensionError(component_name=self.name, message='Pool Strides needs 4 values. Ex: [1,2,2,1]')
        logger.info("Pool Layer ({}) validation success . . .".format(self.name))


class Pool(object):
    """
    | **@author**: Prathyush SP
    |
    | The class handles pool functions available in tensorflow
    | It consists of:
    | 1. Max Pool
    | 2. Average Pool
    """

    @typechecked
    def __init__(self, input_tensor: Tensor):
        """
        :param input_tensor: Input Tensor
        """
        self.input_tensor = input_tensor
        pass

    def max_pool(self, ksize: list, strides: list, padding: str) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Max Pool
        """
        return tf.nn.max_pool(self.input_tensor, ksize=ksize, strides=strides, padding=padding)

    def avg_pool(self, ksize: list, strides: list, padding: str) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Average Pool
        """
        return tf.nn.avg_pool(self.input_tensor, ksize=ksize, strides=strides, padding=padding)

    def max_pool3d(self, ksize: list, strides: list, padding: str) -> Tensor:
        """
        | **@author**: Vivek A Gupta
        |
        :return: Max Pool 3D
        """
        return tf.nn.max_pool3d(self.input_tensor, ksize=ksize, strides=strides, padding=padding)

    def avg_pool3d(self, ksize: list, strides: list, padding: str) -> Tensor:
        """
        | **@author**: Vivek A Gupta
        |
        :return: Average Pool 3d
        """
        return tf.nn.avg_pool3d(self.input_tensor, ksize=ksize, strides=strides, padding=padding)

    @typechecked
    def parse_pool(self, pool_type: constants.PoolType, ksize: list, strides: list, padding: str):
        """
        | **@author**: Prathyush SP
        |
        | Parse Activations
        :param pool_type: Type of Pool
        :param ksize: Pool Size
        :param strides: Pool strides
        :param padding: Pool Padding
        :return: Tensor. Activation Function applied over a tensor
        """
        activation_switch = {
            constants.PoolType.MAX_POOL: self.max_pool,
            constants.PoolType.AVG_POOL: self.avg_pool,
            constants.PoolType.MAX_POOL_3D: self.max_pool3d,
            constants.PoolType.AVG_POOL_3D: self.avg_pool3d,
        }
        return activation_switch[pool_type](ksize, strides, padding)
