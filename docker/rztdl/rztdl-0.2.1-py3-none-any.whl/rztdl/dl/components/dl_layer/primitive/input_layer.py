# # -*- coding: utf-8 -*-
# """
# | **@created on:** 16/12/16,
# | **@author:** Prathyush SP,
# | **@version:** v0.0.1
# |
# | **Description:**
# | Layer Module used to create deeplearning layers. It consists of
# | 1. Input Layer
# | 2. Fully Connected Layer
# | 3. Output Layer
# | 4. Convolution Layer
# | 5. Pool Layer
# |
# | **Sphinx Documentation Status:** Complete
# |
# ..todo::
#     --
# """
#
# from rztdl import RZTDL_CONFIG, RZTDL_DAG
# import rztdl.utils.string_constants as constants
# import tensorflow as tf
# from typeguard import typechecked
# import logging
# from rztdl.utils.dl_exception import ShapeError
# from collections import OrderedDict
# from rztdl.dl.components.dl_layer.layer import Layer
# from rztdl.dl.components.component import Component
#
# logger = logging.getLogger(__name__)
#
#
# class InputLayer(Layer):
#     """
#     | **@author:** Prathyush SP
#     |
#     | Input Layer
#     """
#
#     @typechecked
#     def __init__(self, name: str, layer_nodes: int = None, layer_shape: list = None):
#         """
#         :param name: Name of the Layer
#         :param layer_nodes: Input Layer Nodes
#         """
#         super().__init__(name=name, layer_type=constants.LayerType.INPUT_LAYER)
#         self.shape = layer_shape
#         self.layer_nodes = layer_nodes
#
#     @typechecked
#     def create_component(self, model_name, previous_component, component_id: int):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Creates Input Layer
#         |
#         :param model_name: Model Name
#         :param previous_component: Previous Component [Not used]
#         :param component_id: Layer ID
#         :return Input Layer object
#         """
#         self.id = component_id
#         self.model_name = model_name
#         self.validate(previous_component)
#         with tf.name_scope(self.model_name + '/' + self.name + '/'):
#             self.component_output = tf.placeholder(shape=self.shape, dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE,
#                                                    name=self.name).name
#             RZTDL_DAG.add_placeholder(model_name=self.model_name, layer_name=self.name,
#                                       placeholder_name=self.component_output)
#             RZTDL_DAG.add_prediction_placeholder(model_name=self.model_name, layer_name=self.name,
#                                                  placeholder_name=self.component_output)
#             layer_details = OrderedDict([(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.layer_type),
#                                          (constants.MODEL_ARCHITECTURE.LAYER_OUTPUT,
#                                           self.get_tensor(name=self.component_output).get_shape().as_list().__str__())])
#             RZTDL_DAG.update_model_architecture(model_name=self.model_name, layer_name=self.name,
#                                                 layer_details=layer_details)
#             tf.add_to_collection(self.component_output, self.get_tensor(name=self.component_output))
#         return self
#
#     def validate(self, previous_component):
#         """
#         | **@author:** Prathyush SP
#         |
#         | This method is used to perform Input Layer validations
#         """
#         if self.layer_nodes is None and self.shape is None:
#             raise ShapeError("Input Layer is missing Layer Nodes / Layer Shape")
#         if self.shape and len(self.shape) < 2:
#             raise ShapeError("Input Layer Shape should have at least 2 dimensions else use layer_nodes parameter")
#         if self.shape is None:
#             self.shape = [None, self.layer_nodes]
#         self.layer_nodes = self.shape[-1]
#         logger.info("Input Layer validation success . . .")
