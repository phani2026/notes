# # -*- coding: utf-8 -*-
# """
# | **@created on:** 16/12/16,
# | **@author:** Prathyush SP,
# | **@version:** v0.0.1
# |
# | **Description:**
# | Layer Module used to create deeplearning layers. It consists of
# | 1. Input Layer
# | 2. Fully Connected Layer
# | 3. Output Layer
# | 4. Convolution Layer
# | 5. Pool Layer
# |
# | **Sphinx Documentation Status:** Complete
# |
# ..todo::
#     --
# """
# import logging
# from collections import OrderedDict
# from typing import Union
#
# import tensorflow as tf
# from tensorflow import Tensor
# from typeguard import typechecked
#
# import rztdl.utils.string_constants as constants
# from rztdl import RZTDL_CONFIG, RZTDL_DAG
# from rztdl.dl import tf_summary
# from rztdl.dl.dl_layer.layer import Layer
# from rztdl.utils.dl_exception import RangeError, ActivationError, SizeError
#
# logger = logging.getLogger(__name__)
#
#
# class RNNLayer(Layer):
#     """
#     | **@author:** Sumith Krishna
#     |
#     | RNN Layer
#     """
#
#     @typechecked
#     def __init__(self, name: str, layer_cells: list, layer_input: Union[dict, Tensor]):
#         """
#         :param name: Name of the Layer
#         :param layer_cells: List of dictionaries depicting the RNN Cell Variants
#         :param layer_input: List of Input Tensors
#         """
#         super().__init__(name=name, layer_type="RNNLayer")
#         self.layer_output = None
#         self.layer_input = layer_input
#         self.layer_cells = layer_cells
#         self.layer_nodes = None
#
#     @typechecked
#     def create_layer(self, model_name: str, layer, layer_id: int):
#         """
#         | **@author:** Sumith Krishna
#         |
#         | Create RNN Layer
#         :param model_name: Model Name
#         :param layer: Layer
#         :param layer_id: Layer Id
#         :return: Layer Object
#         """
#         self.id = layer_id
#         self.model_name = model_name
#         self.validate()
#         activation_switch = {
#             constants.ACTIVATION.SIGMOID: tf.nn.sigmoid,
#             constants.ACTIVATION.SOFTMAX: tf.nn.softmax,
#             constants.ACTIVATION.TANH: tf.nn.tanh,
#             constants.ACTIVATION.RELU: tf.nn.relu,
#             constants.ACTIVATION.RELU6: tf.nn.relu6,
#             constants.ACTIVATION.ELU: tf.nn.elu,
#             constants.ACTIVATION.SOFT_PLUS: tf.nn.softplus,
#             constants.ACTIVATION.SOFT_SIGN: tf.nn.softsign,
#             constants.ACTIVATION.CRELU: tf.nn.crelu,
#         }
#         layer_details = OrderedDict([(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.layer_type),
#                                      (constants.MODEL_ARCHITECTURE.LAYER_CELLS, self.layer_cells)])
#
#         with tf.name_scope(self.model_name + '/' + self.name + '/'):
#             cells = []
#             for cell in self.layer_cells:
#                 if cell[constants.RNNTYPES.CELL] == constants.RNNTYPES.BASIC_RNN_CELL:
#                     cells.append(tf.nn.rnn_cell.BasicRNNCell(num_units=cell[constants.PARAMETERS.NUM_UNITS],
#                                                              activation=activation_switch[
#                                                                  cell[constants.PARAMETERS.ACTIVATION]]))
#
#                 if cell[constants.RNNTYPES.CELL] == constants.RNNTYPES.GRUCELL:
#                     cells.append(tf.nn.rnn_cell.GRUCell(num_units=cell[constants.PARAMETERS.NUM_UNITS],
#                                                         activation=activation_switch[
#                                                             cell[constants.PARAMETERS.ACTIVATION]]))
#
#                 if cell[constants.RNNTYPES.CELL] == constants.RNNTYPES.BASIC_LSTM_CELL:
#                     cells.append(tf.nn.rnn_cell.BasicLSTMCell(num_units=cell[constants.PARAMETERS.NUM_UNITS],
#                                                               activation=activation_switch[
#                                                                   cell[constants.PARAMETERS.ACTIVATION]],
#                                                               forget_bias=cell[constants.PARAMETERS.FORGET_BIAS]))
#
#                 if cell[constants.RNNTYPES.CELL] == constants.RNNTYPES.LSTMCELL:
#                     cells.append(tf.nn.rnn_cell.LSTMCell(num_units=cell[constants.PARAMETERS.NUM_UNITS],
#                                                          activation=activation_switch[
#                                                              cell[constants.PARAMETERS.ACTIVATION]],
#                                                          use_peepholes=cell[constants.PARAMETERS.USE_PEEPHOLES],
#                                                          forget_bias=cell[constants.PARAMETERS.FORGET_BIAS],
#                                                          initializer=cell[constants.PARAMETERS.INITIALIZER]))
#
#             self.layer_cells = cells
#             multi_rnn_cell = tf.nn.rnn_cell.MultiRNNCell(self.layer_cells)
#             outputs, states = tf.nn.static_rnn(multi_rnn_cell, self.layer_input, dtype=tf.float32)
#             self.layer_output = outputs[-1]
#             self.layer_nodes = self.layer_output.get_shape().as_list()[-1]
#             if RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY:
#                 tf_summary.create_variable_summaries(tensor=self.layer_output)
#             layer_details[constants.MODEL_ARCHITECTURE.LAYER_OUTPUT] = self.layer_output.get_shape().as_list().__str__()
#         RZTDL_DAG.update_model_architecture(model_name=self.model_name, layer_name=self.name,
#                                             layer_details=layer_details)
#         tf.add_to_collection(self.layer_output.name, self.layer_output)
#         return self
#
#     def validate(self):
#         """
#         | **@author:** Sumith Krishna
#         |
#         | LSTMCell Validation
#         """
#         with tf.name_scope(self.model_name + '/' + self.name + '/'):
#             if isinstance(self.layer_input, dict):
#                 if isinstance(self.layer_input[constants.PARAMETERS.INPUT_NAME], list):
#                     self.layer_input = [RZTDL_DAG.get_layer(model_name=self.model_name, layer_name=tensor) for tensor in
#                                         self.layer_input[constants.PARAMETERS.INPUT_NAME]]
#                 else:
#                     self.layer_input, _ = RZTDL_DAG.get_unstack_operator(model_name=self.model_name,
#                                                                          layer_name=self.layer_input[
#                                                                              constants.PARAMETERS.INPUT_NAME],
#                                                                          start_index=self.layer_input[
#                                                                              constants.PARAMETERS.START_INDEX],
#                                                                          end_index=self.layer_input[
#                                                                              constants.PARAMETERS.END_INDEX])
#             if len(self.layer_cells) == 0:
#                 raise SizeError('Atleast one RNNCell type is expected')
#             for cell in self.layer_cells:
#                 if cell[constants.PARAMETERS.ACTIVATION] not in constants.ACTIVATION.__dict__.values():
#                     raise ActivationError("Not a valid Activation. Usage: NeuralNetwork.ACTIVATION.<>")
#                 if cell[constants.PARAMETERS.NUM_UNITS] <= 0:
#                     raise RangeError("num_units field should be an integer greater than zero")
#                 if cell[constants.RNNTYPES.CELL] == constants.RNNTYPES.LSTMCELL or cell[
#                     constants.RNNTYPES.CELL] == constants.RNNTYPES.BASIC_LSTM_CELL:
#                     if cell[constants.PARAMETERS.FORGET_BIAS] < 0 or cell[constants.PARAMETERS.FORGET_BIAS] > 1.0:
#                         raise RangeError(" Forget bias of an LSTM Cell should be within 0 and 1 ")
#             logger.info("RNNLayer Validation Success !!")
