# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Convolution Layer Module
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['ConvolutionLayer']

from types import FunctionType
from numpy import ndarray
from rztdl import RZTDL_CONFIG, RZTDL_STORE, RZTDL_DAG
import rztdl.utils.string_constants as constants
from rztdl.dl import tf_summary
from tensorflow import Tensor
import tensorflow as tf
from typeguard import typechecked
import logging
from rztdl.utils.dl_exception import DimensionError, RangeError
from rztdl.dl.helpers.tfhelpers import Activation
from collections import OrderedDict
from rztdl.dl.components.dl_layer.layer import Layer
import typing
from rztdl.dl.components.component import Component
from rztdl.dl.helpers.tfhelpers import GraphUtils
from rztdl.blueprint import BluePrintProperties, Blueprint
from rztdl.dl.helpers.tfhelpers.normalization import NormalizationLayer

logger = logging.getLogger(__name__)


class ConvolutionLayer(Layer):
    """
    | **@author:** Prathyush SP
    |
    | Convolution Layer
    .. todo::
        Prathyush SP:
            1. Defaults for Layer filters, bias and activation
    """

    __slots__ = ['layer_bias_param', 'layer_filter_param', 'layer_bias_name', 'layer_filter_name', 'layer_activation',
                 'filter_dimensions', 'filter_strides', 'filter_padding', 'prev_layer_nodes', 'norm_type',
                 'layer_bias', 'layer_filter', 'bias_dimensions']
    __meta2__ = None

    @classmethod
    def blueprint(cls):
        if cls.__meta2__ is not None:
            return cls.__meta2__

        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        bp.add_inputs(name="layer_filter", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="layer_bias", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE)
        bp.add_outputs(name="component_output", optional=False, status=constants.STATUS.ACTIVE,
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)

        p1 = BluePrintProperties(name="name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                                 status=constants.STATUS.ACTIVE)
        bp.add_outputs(name="layer_filter_output", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                       properties=[p1], status=constants.STATUS.ACTIVE)

        p1 = BluePrintProperties(name="name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                                 status=constants.STATUS.ACTIVE)
        bp.add_outputs(name="layer_bias_output", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                       properties=[p1], status=constants.STATUS.ACTIVE)

        bp.add_parameter(name="name", optional=False, status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        bp.add_parameter(name="filter_dimensions", optional=False,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.ARRAYOFINT,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="filter_strides", optional=False,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.ARRAYOFINT,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="filter_padding", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.PaddingType.SAME.name,
                         status=constants.PaddingType.blueprint().status,
                         possible_values=constants.PaddingType.blueprint().parameters,
                         class_name=constants.PaddingType.blueprint().class_name)
        bp.add_parameter(name="layer_activation", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.ActivationType.RELU.name,
                         status=constants.ActivationType.blueprint().status,
                         possible_values=constants.ActivationType.blueprint().parameters,
                         class_name=constants.ActivationType.blueprint().class_name)
        bp.add_parameter(name="layer_filter", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.InitializerType._Parameters.XAVIER.name,
                         status=constants.InitializerType.blueprint().status,
                         possible_values=constants.InitializerType.blueprint().parameters,
                         class_name=constants.InitializerType.blueprint().class_name)

        bp.add_parameter(name="layer_bias", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.InitializerType._Parameters.ONES.name,
                         status=constants.InitializerType.blueprint().status,
                         possible_values=constants.InitializerType.blueprint().parameters,
                         class_name=constants.InitializerType.blueprint().class_name)
        bp.add_parameter(name="normalisation", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.NormalizationType._Parameters.L2_NORM.name,
                         status=constants.NormalizationType.blueprint().status,
                         class_name=constants.NormalizationType.blueprint().class_name,
                         possible_values=constants.NormalizationType.blueprint().parameters)
        bp.add_parameter(name="layer_summaries", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="layer_scopes", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.ARRAYOFSTRING,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="layer_dropout", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT, status=constants.STATUS.ACTIVE)
        cls.__meta2__ = bp
        return cls.__meta2__

    @typechecked
    def __init__(self, name: str, filter_dimensions: list,
                 filter_strides: list, filter_padding: constants.PaddingType,
                 layer_activation=constants.ActivationType.RELU,
                 layer_filter: typing.Union[ndarray, dict, FunctionType] = None,
                 layer_filter_output: str = None, layer_bias_output: str = None,
                 layer_bias: typing.Union[ndarray, dict, FunctionType] = None, layer_dropout: float = None,
                 normalisation: constants.NormalizationType = None,
                 component_input: typing.Union[str, Tensor, None] = None,
                 component_output: typing.Union[str, None] = None,
                 layer_scopes: typing.List[str] = [], layer_summaries: bool = None):
        """

        :param name: Name of the Layer
        :param filter_dimensions: Filter Dimensions
        :param filter_strides: Strides for the Filter
        :param filter_padding: Filter Padding
        :param layer_activation: Activation function for the Layer
        :param layer_filter: Filters for the Layer
        :param layer_filter_output: Layer filter name for further reference
        :param layer_bias_output: Layer bias name for further reference
        :param layer_bias: Bias for the Layer
        :param layer_dropout: Layer Dropout
        :param normalisation: Normalisation type
        :param component_input: Component Input
        :param component_output: Component Output
        :param layer_scopes: Scopes for the layer
        :param layer_summaries: Layer Summaries
        """
        super().__init__(name=name, layer_type=constants.LayerType.CONVOLUTION_LAYER, layer_scopes=layer_scopes,
                         component_input=component_input, component_output=component_output,
                         layer_summaries=layer_summaries)
        self.layer_bias_param = layer_bias
        self.layer_filter_param = layer_filter
        self.layer_filter_name = layer_filter_output
        self.layer_bias_name = layer_bias_output
        self.layer_activation = layer_activation
        self.filter_dimensions = filter_dimensions
        self.filter_strides = filter_strides
        self.filter_padding = filter_padding
        self.layer_dropout = layer_dropout
        self.prev_layer_nodes = None
        self.layer_nodes = None
        self.norm_type = normalisation
        self.layer_bias = None
        self.layer_filter = None
        self.bias_dimensions = None

    @typechecked
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Create Convolution Layer
        |
        :param model_name: Model Name
        :param previous_component: Previous Component
        :param component_id: Component ID
        :return: Convolution Layer Object
        """
        self.model_name = model_name
        self.id = component_id
        self.validate(previous_component=previous_component)
        RZTDL_DAG.add_node_to_dag(node=self.name, component_type=constants.LayerType)
        RZTDL_DAG.add_edge_to_node(from_node=previous_component.name, to_node=self.name)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.component_output = Activation(input_tensor=
            tf.nn.bias_add(
                tf.nn.conv2d(GraphUtils.get_tensor(name=self.component_input),
                             GraphUtils.get_variable(
                                 name=self.layer_filter),
                             strides=self.filter_strides,
                             padding=self.filter_padding.name),
                GraphUtils.get_variable(
                    name=self.layer_bias))).parse_activation(
                activation_type=self.layer_activation).name
            layer_details = OrderedDict(
                [(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.component_sub_type),
                 (constants.MODEL_ARCHITECTURE.LAYER_FILTER,
                  GraphUtils.get_variable(name=self.layer_filter).get_shape().as_list().__str__()),
                 (constants.MODEL_ARCHITECTURE.LAYER_STRIDES, self.filter_strides.__str__()),
                 (constants.MODEL_ARCHITECTURE.LAYER_BIAS,
                  GraphUtils.get_variable(name=self.layer_bias).get_shape().as_list().__str__()),
                 (constants.MODEL_ARCHITECTURE.LAYER_ACTIVATION, self.layer_activation),
                 (constants.MODEL_ARCHITECTURE.LAYER_OUTPUT,
                  GraphUtils.get_tensor(name=self.component_output).get_shape().as_list().__str__())])
            if self.layer_dropout:
                dropout_placeholder = tf.placeholder(dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE).name
                tf.add_to_collection(dropout_placeholder, GraphUtils.get_tensor(name=dropout_placeholder))
                RZTDL_STORE.add_dropout_placeholder(model_name=self.model_name, placeholder_name=dropout_placeholder,
                                                    value=self.layer_dropout)
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_DROPOUT] = self.layer_dropout
                self.component_output = tf.nn.dropout(GraphUtils.get_tensor(name=self.component_output),
                                                      keep_prob=GraphUtils.get_tensor(name=dropout_placeholder)).name
            if self.norm_type:
                self.component_output = NormalizationLayer(
                    GraphUtils.get_tensor(name=self.component_output)).parse_norm(
                    norm_type=self.norm_type).name
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_NORMALIZATION] = OrderedDict(
                    [('Parameters', self.norm_type.__dict__)])
            if self.layer_summaries:
                tf_summary.create_variable_summaries(tensor=GraphUtils.get_tensor(name=self.component_output))
        RZTDL_STORE.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                              layer_details=layer_details)
        tf.add_to_collection(self.component_output, GraphUtils.get_tensor(name=self.component_output))
        RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.name, tensor_name=self.component_output)
        if self.component_output_name:
            tf.add_to_collection(name=self.component_output_name,
                                 value=GraphUtils.get_tensor(name=self.component_output))
            RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.component_output_name,
                                                       tensor_name=self.component_output)
        return self

    def validate(self, previous_component: Component):
        """
        | **@author:** Prathyush SP
        |
        | Convolution Layer Validation
        :param previous_component: Previous Component
        """
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.prev_layer_nodes, self.component_input = self._map_input_layer(previous_component=previous_component,
                                                                                layer_input=self.component_input)
            if not len(self.filter_dimensions) == 4:
                raise DimensionError(component_name=self.name,
                                     message='Filter Dimensions needs 4 values. Ex: [1,2,2,1]')
            if not len(self.filter_strides) == 4:
                raise DimensionError(component_name=self.name, message='Filter Strides needs 4 values. Ex: [1,2,2,1]')
            if self.layer_dropout and not (0 <= self.layer_dropout <= 1):
                raise RangeError(component_name=self.name,
                                 message="Layer Dropout should be between 0 and 1. Got:{}".format(self.layer_dropout))
            self.layer_nodes = self.filter_dimensions[-1]
            self.prev_layer_nodes, self.component_input = self._auto_tensor_conversion_2d_to_4d(
                filter_dimensions=self.filter_dimensions, layer_input=self.component_input)
            self.bias_dimensions = [self.layer_nodes]
            self.layer_filter = self._get_or_create_weights(weights_dimensions=self.filter_dimensions,
                                                            layer_weights_param=self.layer_filter_param)
            if self.layer_filter_name:
                tf.add_to_collection(self.layer_filter_name, GraphUtils.get_tensor(name=self.layer_filter))
                RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.layer_filter_name,
                                                           tensor_name=self.layer_filter)
            self.layer_bias = self._get_or_create_bias(bias_dimensions=self.bias_dimensions,
                                                       layer_bias_param=self.layer_bias_param)
            if self.layer_bias_name:
                tf.add_to_collection(self.layer_bias_name, GraphUtils.get_tensor(name=self.layer_bias))
                RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.layer_bias_name,
                                                           tensor_name=self.layer_bias)
        logger.info("Convolution Layer ({}) validation success . . .".format(self.name))
