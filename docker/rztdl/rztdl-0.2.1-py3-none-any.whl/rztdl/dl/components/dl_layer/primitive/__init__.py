# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Layer Module used to create deeplearning layers. It consists of
| 1. Input Layer
| 2. Fully Connected Layer
| 3. Output Layer
| 4. Convolution Layer
| 5. Pool Layer
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

from rztdl.dl.components.dl_layer.primitive.convolution_layer import ConvolutionLayer
from rztdl.dl.components.dl_layer.primitive.convolution_3d_layer import Convolution3DLayer
from rztdl.dl.components.dl_layer.primitive.fully_connected_layer import FullyConnectedLayer
# todo: Prathyush SP - Deprecated Input Layer in favour of In Buffer
# from rztdl.dl.components.dl_layer.primitive.input_layer import InputLayer
from rztdl.dl.components.dl_layer.primitive.pool_layer import PoolLayer
# todo: Prathyush SP - Deprecated RNN Layer in favour of Dynamic RNN in advance layer
# from rztdl.dl.dl_layer.primitive.rnn_layer import RNNLayer
