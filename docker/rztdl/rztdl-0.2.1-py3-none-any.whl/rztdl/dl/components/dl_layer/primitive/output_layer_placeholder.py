# # -*- coding: utf-8 -*-
# """
# | **@created on:** 16/12/16,
# | **@author:** Prathyush SP,
# | **@version:** v0.0.1
# |
# | **Description:**
# | Layer Module used to create deeplearning layers. It consists of
# | 1. Input Layer
# | 2. Fully Connected Layer
# | 3. Output Layer
# | 4. Convolution Layer
# | 5. Pool Layer
# |
# | **Sphinx Documentation Status:** Complete
# |
# ..todo::
#     --
# """
# import functools
# import operator
# from typing import Union
# from rztdl import RZTDL_CONFIG, RZTDL_DAG
# import rztdl.utils.string_constants as constants
# from rztdl.dl import tf_summary
# from tensorflow import Tensor
# import tensorflow as tf
# from typeguard import typechecked
# import logging
# from rztdl.utils.dl_exception import DimensionError, ActivationError, LayerException
# from rztdl.dl.helpers.tfhelpers import Activation
# from collections import OrderedDict
# from rztdl.dl.dl_layer.layer import Layer
# 
# logger = logging.getLogger(__name__)
# 
# 
# class OutputLayerPlaceholder(Layer):
#     """
#     | **@author:** Prathyush SP
#     |
#     | Output Layer Placeholder
#     | - To be used during placeholder requirements without weights and bias
#     """
# 
#     @typechecked
#     def __init__(self, name: str, layer_activation: str, layer_nodes: int, layer_input: Union[str, Tensor] = None):
#         """
#         :param name: Name of the Layer
#         :param layer_activation: Layer Activation        
#         """
#         super().__init__(name=name, layer_type=constants.LAYERS.OUTPUT_LAYER)        
#         self.layer_activation = layer_activation
#         self.prev_layer_output = None
#         self.prev_layer_nodes = None
#         self.layer_nodes = layer_nodes
#         self.layer_output_placeholder = tf.placeholder(shape=[None, self.layer_nodes], dtype=tf.float32,
#                                                        name=self.name).name
#         self.layer_input = layer_input        
# 
#     @typechecked
#     def create_layer(self, model_name: str, layer, layer_id: int):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Creates Output Layer Placeholder
#         |
#         :param model_name: Model Name
#         :param layer: Previous Layer
#         :param layer_id: Layer Id
#         :return: Output Layer Object
#         """
#         self.id = layer_id
#         self.model_name = model_name
#         self.prev_layer_output = layer.layer_output
#         self.prev_layer_nodes = layer.layer_nodes
#         self.validate()
#         with tf.name_scope(self.model_name + '/' + self.name + '/'):
#             self.layer_output = Activation(input_tensor=self.get_tensor(name=self.layer_input)).parse_activation(
#                 activation_type=self.layer_activation).name
#             layer_details = OrderedDict(
#                 [(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.layer_type),
#                  (constants.MODEL_ARCHITECTURE.LAYER_ACTIVATION, self.layer_activation),
#                  (constants.MODEL_ARCHITECTURE.LAYER_OUTPUT,
#                   self.get_tensor(name=self.layer_output).get_shape().as_list().__str__())])
#             if RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY:
#                 tf_summary.create_variable_summaries(tensor=self.get_tensor(name=self.layer_output))
#         RZTDL_DAG.add_placeholder(model_name=self.model_name, layer_name=self.name,
#                                   placeholder_name=self.layer_output_placeholder)
#         RZTDL_DAG.update_model_architecture(model_name=self.model_name, layer_name=self.name,
#                                             layer_details=layer_details)
#         tf.add_to_collection(self.layer_output_placeholder, self.get_tensor(name=self.layer_output_placeholder))
#         tf.add_to_collection(self.layer_output, self.get_tensor(name=self.layer_output))
#         return self
# 
#     def validate(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Validation method for Output Layer Placeholder
#         """
#         with tf.name_scope(self.model_name + '/' + self.name + '/'):
#             if self.layer_input is not None:
#                 if isinstance(self.layer_input, Tensor):
#                     self.prev_layer_nodes = self.layer_input.get_shape().as_list()[1]
#                     self.layer_input = self.layer_input.name
#                 else:
#                     self.layer_input = RZTDL_DAG.get_layer(self.model_name, self.layer_input).name
#                     self.prev_layer_nodes = self.get_tensor(name=self.layer_input).get_shape().as_list()[1]
#             else:
#                 self.layer_input = self.prev_layer_output
#             if self.prev_layer_output is None:
#                 raise LayerException('Previous Layer Output is None')
#             if not self.prev_layer_nodes or self.prev_layer_nodes <= 0:
#                 raise LayerException('Previous Layer Nodes is None or <=0')
#             if self.layer_activation not in constants.ActivationType.__dict__.values():
#                 raise ActivationError("Not a valid Activation. Usage: NeuralNetwork.ACTIVATION.<>")
#             if self.get_tensor(name=self.layer_input).get_shape().ndims == 4:
#                 if RZTDL_CONFIG.TensorflowConfig.AUTO_TENSOR_CONVERSION:
#                     nodes = functools.reduce(operator.mul,
#                                              self.get_tensor(name=self.layer_input).get_shape().as_list()[1:])
#                     self.layer_input = tf.reshape(tensor=self.get_tensor(name=self.layer_input),
#                                                   shape=[-1, int(nodes)]).name
#                     self.prev_layer_nodes = nodes
#                 else:
#                     raise DimensionError('Auto Tensor Conversion is disabled. Only 2 dimensional input is allowed ')
#             logger.info("Output Layer Placeholder validation success . . .")
