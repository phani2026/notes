# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Fully Connected Layer Module
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['FullyConnectedLayer']

import logging
import typing
from collections import OrderedDict
from types import FunctionType
import tensorflow as tf
from numpy import ndarray
from rztdl import RZTDL_CONFIG, RZTDL_STORE, RZTDL_DAG
from rztdl.blueprint import Blueprint, BluePrintProperties
from rztdl.dl import tf_summary
from rztdl.dl.components.component import Component
from rztdl.dl.components.dl_layer.layer import Layer
from rztdl.dl.helpers import tfhelpers
from rztdl.dl.helpers.tfhelpers import GraphUtils
from rztdl.utils import string_constants as constants
from rztdl.utils.dl_exception import RangeError, NormalizationError
from tensorflow import Tensor
from typeguard import typechecked

logger = logging.getLogger(__name__)


class FullyConnectedLayer(Layer):
    """
    | **@author:** Prathyush SP
    |
    | Fully Connected Layer
    """

    @classmethod
    def blueprint(cls):
        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        bp.add_inputs(name="layer_weights", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="layer_bias", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE)
        bp.add_outputs(name="component_output", optional=False, status=constants.STATUS.ACTIVE,
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        p1 = BluePrintProperties(name="name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                                 status=constants.STATUS.ACTIVE)
        bp.add_outputs(name="layer_weights_output", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                       properties=[p1], status=constants.STATUS.ACTIVE)

        p1 = BluePrintProperties(name="name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                                 status=constants.STATUS.ACTIVE)
        bp.add_outputs(name="layer_bias_output", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                       properties=[p1], status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="name", optional=False, status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        bp.add_parameter(name="layer_nodes", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                         status=constants.STATUS.ACTIVE)

        bp.add_parameter(name="layer_activation", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.ActivationType.SIGMOID.name,
                         status=constants.ActivationType.blueprint().status,
                         possible_values=constants.ActivationType.blueprint().parameters,
                         class_name=constants.ActivationType.blueprint().class_name)
        bp.add_parameter(name="layer_weights", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.InitializerType._Parameters.XAVIER.name,
                         status=constants.InitializerType.blueprint().status,
                         possible_values=constants.InitializerType.blueprint().parameters,
                         class_name=constants.InitializerType.blueprint().class_name)

        bp.add_parameter(name="layer_bias", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.InitializerType._Parameters.ONES.name,
                         status=constants.InitializerType.blueprint().status,
                         possible_values=constants.InitializerType.blueprint().parameters,
                         class_name=constants.InitializerType.blueprint().class_name)
        bp.add_parameter(name="normalisation", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                         default_value=constants.NormalizationType._Parameters.L2_NORM.name,
                         status=constants.NormalizationType.blueprint().status,
                         class_name=constants.NormalizationType.blueprint().class_name,
                         possible_values=constants.NormalizationType.blueprint().parameters)
        bp.add_parameter(name="layer_summaries", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="layer_scopes", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.ARRAYOFSTRING,
                         status=constants.STATUS.ACTIVE)
        bp.add_parameter(name="layer_dropout", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT, status=constants.STATUS.ACTIVE)
        return bp

    __slots__ = ['layer_weights_param', 'layer_bias_param', 'layer_activation', 'layer_nodes',
                 'prev_layer_nodes', 'layer_dropout', 'normalisation',
                 'layer_weights', 'layer_bias', 'weights_dimensions', 'bias_dimensions',
                 'layer_weight_name', 'layer_bias_name']

    # todo: Prathyush SP - Defaults for Layer weights, bias and activation
    @typechecked
    def __init__(self, name: str, layer_nodes: int,
                 layer_activation: constants.ActivationType = constants.ActivationType.SIGMOID,
                 layer_weights: typing.Union[ndarray, dict, FunctionType, str, constants.InitializerType] = None,
                 layer_bias: typing.Union[list, ndarray, dict, FunctionType, str, constants.InitializerType] = None,
                 component_input: typing.Union[str, Tensor, None] = None,
                 layer_weights_output: str = None, layer_bias_output: str = None,
                 layer_dropout: typing.Union[float, None] = None, normalisation: constants.NormalizationType = None,
                 layer_scopes: typing.List[str] = [], component_output: typing.Union[str, None] = None,
                 layer_summaries: bool = None):
        """

        :param name: Name of the Layer
        :param layer_activation: Layer Activation [Usage: NeuralNetwork.Activation.<>]
        :param layer_nodes: Number of nodes in the dl_layer
        :param layer_weights: Weights for the dl_layer
        :param layer_bias: Bias for the dl_layer
        :param component_input: Layer Input
        :param layer_dropout: Layer Dropout
        :param normalisation: Normalization Type
        :param layer_scopes: Layer Scopes
        :param layer_weights_output: Layer Weights name for further reference
        :param layer_bias_output: Layer Bias name for further reference
        :param component_output: Name for component output for future reference
        :param layer_summaries: Tensorboard summaries
        """
        super().__init__(name=name, layer_type=constants.LayerType.FULLY_CONNECTED_LAYER,
                         layer_summaries=layer_summaries, layer_scopes=layer_scopes,
                         component_input=component_input, component_output=component_output)
        self.layer_weights_param = layer_weights
        self.layer_bias_param = layer_bias
        self.layer_activation = layer_activation
        self.layer_nodes = layer_nodes
        self.component_output_name = component_output
        self.prev_layer_nodes = None
        self.layer_weight_name = layer_weights_output
        self.layer_bias_name = layer_bias_output
        self.layer_dropout = layer_dropout
        self.normalisation = normalisation
        self.layer_nodes = layer_nodes
        self.prev_layer_nodes = None
        self.layer_weights = None
        self.layer_bias = None
        self.weights_dimensions = None
        self.bias_dimensions = None

    @typechecked
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        | Creates Fully Connected Layer
        |
        :param model_name: Model Name
        :param previous_component: Previous Layer
        :param component_id: Layer Id
        :return: Fully Connected Layer Object
        """
        self.id = component_id
        self.model_name = model_name
        self.validate(previous_component=previous_component)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.component_output = tfhelpers.Activation(input_tensor=
            tf.add(
                tf.matmul(GraphUtils.get_tensor(name=self.component_input),
                          GraphUtils.get_variable(name=self.layer_weights)),
                GraphUtils.get_variable(self.layer_bias))).parse_activation(
                activation_type=self.layer_activation).name
            # noinspection PyTypeChecker
            layer_details = OrderedDict(
                [(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.component_sub_type),
                 (constants.MODEL_ARCHITECTURE.LAYER_WEIGHTS,
                  GraphUtils.get_variable(name=self.layer_weights).get_shape().as_list().__str__()),
                 (constants.MODEL_ARCHITECTURE.LAYER_BIAS,
                  GraphUtils.get_variable(name=self.layer_bias).get_shape().as_list().__str__()),
                 (constants.MODEL_ARCHITECTURE.LAYER_ACTIVATION, self.layer_activation),
                 (constants.MODEL_ARCHITECTURE.LAYER_OUTPUT,
                  GraphUtils.get_tensor(name=self.component_output).get_shape().as_list().__str__())])
            if self.layer_dropout:
                dropout_placeholder = tf.placeholder(dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE).name
                tf.add_to_collection(name=dropout_placeholder,
                                     value=GraphUtils.get_tensor(name=dropout_placeholder))
                RZTDL_STORE.add_dropout_placeholder(model_name=self.model_name, placeholder_name=dropout_placeholder,
                                                    value=self.layer_dropout)
                self.component_output = tf.nn.dropout(x=GraphUtils.get_tensor(name=self.component_output),
                                                      keep_prob=GraphUtils.get_tensor(
                                                          name=dropout_placeholder)).name
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_DROPOUT] = self.layer_dropout
            if self.normalisation:
                self.component_output = tfhelpers.NormalizationLayer(
                    input_tensor=GraphUtils.get_tensor(self.component_output)).l2_norm(self.normalisation).name
                layer_details[constants.MODEL_ARCHITECTURE.LAYER_NORMALIZATION] = OrderedDict(
                    [('Parameters', self.normalisation.__dict__)])
            if self.layer_summaries:
                tf_summary.create_variable_summaries(tensor=GraphUtils.get_tensor(name=self.component_output))
        RZTDL_STORE.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                              layer_details=layer_details)
        tf.add_to_collection(name=self.component_output, value=GraphUtils.get_tensor(name=self.component_output))
        RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.name,
                                                   tensor_name=self.component_output)

        if self.component_output_name:
            tf.add_to_collection(name=self.component_output_name,
                                 value=GraphUtils.get_tensor(name=self.component_output))
            RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                       component_name=self.component_output_name,
                                                       tensor_name=self.component_output)

        return self

    def validate(self, previous_component: Component):
        """
        | **@author:** Prathyush SP
        |
        | Validation method for Fully Connected Layer
        :param previous_component: Previous Component
        """
        RZTDL_DAG.add_node_to_dag(node=self.name, component_type=constants.LayerType)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.prev_layer_nodes, self.component_input = self._map_input_layer(previous_component=previous_component,
                                                                                layer_input=self.component_input)
            RZTDL_DAG.add_edge_to_node(
                from_node=self.component_input if self.component_input else previous_component.name,
                to_node=self.name)
            if self.layer_dropout and not (0 <= self.layer_dropout <= 1):
                raise RangeError(component_name=self.name,
                                 message="Layer Dropout should be between 0 and 1. Got: {}".format(self.layer_dropout))
            # noinspection PyProtectedMember
            if self.normalisation and not self.normalisation[
                                              constants.NormalizationType._Parameters.NORM_TYPE.name] == constants.NormalizationType._Parameters.L2_NORM:
                raise NormalizationError(component_name=self.name,
                                         message="For FullyConnected Layer Normalization should be L2_NORM")
            self.prev_layer_nodes, self.component_input = self._auto_tensor_conversion_nd_to_2d(
                layer_input=self.component_input)
            self.weights_dimensions = [self.prev_layer_nodes, self.layer_nodes]
            self.bias_dimensions = [self.layer_nodes]
            self.layer_weights = self._get_or_create_weights(weights_dimensions=self.weights_dimensions,
                                                             layer_weights_param=self.layer_weights_param)
            if self.layer_weight_name:
                tf.add_to_collection(name=self.layer_weight_name,
                                     value=GraphUtils.get_tensor(name=self.layer_weights))
                RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                           component_name=self.layer_weight_name,
                                                           tensor_name=self.layer_weights)
            self.layer_bias = self._get_or_create_bias(bias_dimensions=self.bias_dimensions,
                                                       layer_bias_param=self.layer_bias_param)
            if self.layer_bias_name:
                tf.add_to_collection(name=self.layer_bias_name,
                                     value=GraphUtils.get_tensor(name=self.layer_bias))
                RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                           component_name=self.layer_bias_name,
                                                           tensor_name=self.layer_bias)
        logger.info("Fully Connected Layer ({}) validation success . . .".format(self.name))
