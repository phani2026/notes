# # -*- coding: utf-8 -*-
# """
# | **@created on:** 16/12/16,
# | **@author:** Prathyush SP,
# | **@version:** v0.0.1
# |
# | **Description:**
# | Layer Module used to create deeplearning layers. It consists of
# | 1. Input Layer
# | 2. Fully Connected Layer
# | 3. Output Layer
# | 4. Convolution Layer
# | 5. Pool Layer
# |
# | **Sphinx Documentation Status:** Complete
# |
# ..todo::
#     --
# """
# import functools
# import operator
# from types import FunctionType
# from typing import Union
# from numpy import ndarray
# from rztdl import RZTDL_CONFIG, RZTDL_DAG
# import rztdl.utils.string_constants as constants
# from rztdl.dl import tf_summary
# from tensorflow import Tensor
# from rztdl.dl.dl_dict_parsers import parse_initialization_dict
# import tensorflow as tf
# from typeguard import typechecked
# import logging
# from rztdl.utils.dl_exception import DTypeError, DimensionError, ActivationError, LayerException
# from rztdl.dl.helpers.tfhelpers import Activation
# from collections import OrderedDict
# from rztdl.dl.dl_layer.layer import Layer
# 
# logger = logging.getLogger(__name__)
# 
# 
# class OutputLayer(Layer):
#     """
#     | **@author:** Prathyush SP
#     |
#     | Output Layer
#     """
# 
#     @typechecked
#     def __init__(self, name: str, layer_activation: str, layer_nodes: int,
#                  layer_weights: Union[list, ndarray, dict, FunctionType] = None,
#                  layer_bias: Union[list, ndarray, dict, FunctionType] = None,
#                  layer_input: Union[str, Tensor] = None):
#         """
#         :param name: Name of the Layer
#         :param layer_activation: Layer Activation
#         :param layer_weights: Weights for the Layer
#         :param layer_bias: Bias for the Layer
#         """
#         super().__init__(name=name, layer_type=constants.LAYERS.OUTPUT_LAYER)
#         self.layer_weights_param = layer_weights
#         self.layer_bias_param = layer_bias
#         self.layer_activation = layer_activation
#         self.prev_layer_output = None
#         self.prev_layer_nodes = None
#         self.layer_nodes = layer_nodes
#         self.layer_output_placeholder = tf.placeholder(shape=[None, self.layer_nodes], dtype=tf.float32,
#                                                        name=self.name).name
#         self.layer_input = layer_input
#         self.layer_weights = None
#         self.layer_bias = None
#         self.weights_dimensions = None
#         self.bias_dimensions = None
# 
#     @typechecked
#     def create_component(self, model_name, component, component_id: int):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Creates Output Layer
#         |
#         :param model_name: Model Name
#         :param component: Previous Layer
#         :param component_id: Layer Id
#         :return: Output Layer Object
#         """
#         self.id = component_id
#         self.model_name = model_name
#         self.prev_layer_output = component.component_output
#         self.prev_layer_nodes = component.layer_nodes
#         self.validate()
#         with tf.name_scope(self.model_name + '/' + self.name + '/'):
#             self.component_output = Activation(
#                 input_tensor=tf.add(
#                     tf.matmul(self.get_tensor(name=self.layer_input), self.get_variable(name=self.layer_weights)),
#                     self.get_variable(name=self.layer_bias))).parse_activation(
#                 activation_type=self.layer_activation).name
#             layer_details = OrderedDict(
#                 [(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.layer_type),
#                  (constants.MODEL_ARCHITECTURE.LAYER_WEIGHTS,
#                   self.get_variable(name=self.layer_weights).get_shape().as_list().__str__()),
#                  (constants.MODEL_ARCHITECTURE.LAYER_BIAS,
#                   self.get_variable(name=self.layer_bias).get_shape().as_list().__str__()),
#                  (constants.MODEL_ARCHITECTURE.LAYER_ACTIVATION, self.layer_activation),
#                  (constants.MODEL_ARCHITECTURE.LAYER_OUTPUT,
#                   self.get_tensor(name=self.component_output).get_shape().as_list().__str__())])
#             if RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY:
#                 tf_summary.create_variable_summaries(tensor=self.get_tensor(name=self.component_output))
#         RZTDL_DAG.add_placeholder(model_name=self.model_name, layer_name=self.name,
#                                   placeholder_name=self.layer_output_placeholder)
#         RZTDL_DAG.update_model_architecture(model_name=self.model_name, layer_name=self.name,
#                                             layer_details=layer_details)
#         tf.add_to_collection(self.layer_output_placeholder, self.get_tensor(name=self.layer_output_placeholder))
#         tf.add_to_collection(self.component_output, self.get_tensor(name=self.component_output))
#         return self
# 
#     def validate(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Validation method for Output Layer
#         """
#         with tf.name_scope(self.model_name + '/' + self.name):
#             self.prev_layer_nodes, self.layer_input = [self.prev_layer_nodes, self.prev_layer_output] \
#                 if self.layer_input is None else self._map_input_layer(layer_input=self.layer_input)
#             if self.prev_layer_output is None:
#                 raise LayerException('Previous Layer Output is None')
#             if not self.prev_layer_nodes or self.prev_layer_nodes <= 0:
#                 raise LayerException('Previous Layer Nodes is None or <=0')
#             if self.layer_activation not in constants.ActivationType.__dict__.values():
#                 raise ActivationError("Not a valid Activation. Usage: NeuralNetwork.ACTIVATION.<>")
#             self.prev_layer_nodes, self.layer_input = self._auto_tensor_conversion_nd_to_2d(
#                 layer_input=self.layer_input)
#             self.weights_dimensions = [self.prev_layer_nodes, self.layer_nodes]
#             self.bias_dimensions = [self.layer_nodes]
#             self.layer_weights = self._generate_weights(weights_dimensions=self.weights_dimensions,
#                                                         layer_weights_param=self.layer_weights_param)
#             self.layer_bias = self._generate_bias(bias_dimensions=self.bias_dimensions,
#                                                   layer_bias_param=self.layer_bias_param)
#             logger.info("Output Layer validation success . . .")
