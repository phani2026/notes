# -*- coding: utf-8 -*-
"""
| **@created on:** 07/05/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| Optimizer Abstract Module
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

__all__ = ['Optimizer']

from abc import ABCMeta, abstractmethod
from typeguard import typechecked
import rztdl.utils.string_constants as constants
from rztdl.dl.components import Component
from rztdl import RZTDL_STORE
from rztdl.utils.validations import validate_name
import typing
import tensorflow as tf
from rztdl import RZTDL_CONFIG


class Optimizer(Component, metaclass=ABCMeta):
    """
    | **@author:** Prathyush SP
    |
    | Base class, which defines abstract methods for layers
    """

    __slots__ = ['component_sub_type', 'optimizer_scopes', 'learning_rate_placeholder']

    @typechecked
    def __init__(self, name: str, optimizer_type: constants.OptimizerTypes, optimizer_scopes: typing.List[str],
                 component_input: str, component_output: typing.Union[str, None]):
        """
        :param name: Name for the Optimizer
        :param optimizer_type: Type of the Optimizer
        :param component_input: Component Input
        :param component_output: Component Output
        """
        super().__init__(name=name, component_type=constants.ComponentType.OPTIMIZER,
                         component_input=component_input, component_output=component_output)
        self.component_sub_type = optimizer_type
        self.optimizer_scopes = optimizer_scopes
        # todo: Prathyush SP - Revert None to place holder declaration with access to model object
        self.learning_rate_placeholder = None


    @abstractmethod
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Used to create a dl_layer
        :param model_name: Model name
        :param previous_component: Previous Component
        :param component_id: Component Id
        """
        pass  # pragma: no cover

    def get_optimizer_scope(self):
        self.optimizer_scopes = self.get_trainable_variables(
            var_names=RZTDL_STORE.get_tensors_from_scopes(model_name=self.model_name,
                                                          scopes=set([validate_name(scope) for scope in
                                                                      self.optimizer_scopes])))
        if len(self.optimizer_scopes) == 0:
            self.optimizer_scopes = None

    @typechecked
    def get_trainable_variables(self, var_names: typing.List[str]):
        return [var for var in tf.trainable_variables() if var.name in var_names]

    @abstractmethod
    def validate(self, previous_component: Component):
        """
        | **@author:** Prathyush SP
        |
        | Validation Method
        """
        pass  # pragma: no cover
