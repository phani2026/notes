# -*- coding: utf-8 -*-
"""
| **@created on:** 07/05/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| Adam Optimizer Module
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

__all__ = ['AdamOptimizer']

import logging
import typing

import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked

import rztdl.utils.string_constants as constants
from rztdl import RZTDL_STORE, RZTDL_CONFIG, RZTDL_DAG
from rztdl.blueprint import Blueprint
from rztdl.dl.components.component import Component
from rztdl.dl.components.dl_optimizer.optimizer import Optimizer
from rztdl.dl.helpers.tfhelpers import GraphUtils

logger = logging.getLogger(__name__)


class AdamOptimizer(Optimizer):
    """
    | **@author:** Prathyush SP
    |
    | Adam Optimizer
    """

    @classmethod
    def blueprint(cls):

        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        bp.add_outputs(name="component_output", optional=False, status=constants.STATUS.ACTIVE,
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        bp.add_parameter(name="name", optional=False, status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        bp.add_parameter(name="optimizer_scopes", optional=False,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.ARRAYOFSTRING,
                         status=constants.STATUS.ACTIVE, default_value=False)
        return bp

    @typechecked
    def __init__(self, name: str, component_input: str, optimizer_scopes: typing.List[str] = [],
                 component_output: typing.Union[str, None] = None):
        """
        |
        | todo: Prathyush SP -  Expose Adam optimizer configs in __init__
        |
        :param name: Name of the Optimizer
        :param component_input: Component Input
        :param component_output: Component Output
        :param optimizer_scopes: Scopes for the optimizer
        """
        super().__init__(name=name, optimizer_type=constants.OptimizerTypes.ADAM, optimizer_scopes=optimizer_scopes,
                         component_input=component_input, component_output=component_output)

    @typechecked
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Creates Adam Optimizer
        |
        :param model_name: Model Name
        :param previous_component: Previous Layer [Not used]
        :param component_id: Layer ID
        :return Input Layer object
        """
        self.id = component_id
        self.model_name = model_name
        self.get_optimizer_scope()
        # self.loss_component = RZTDL_STORE.get_component(model_name=model_name, component_name=self.component_input)
        self.validate(previous_component)

        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.learning_rate_placeholder = tf.placeholder(dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE).name
            tf.add_to_collection(name=self.learning_rate_placeholder,
                                 value=GraphUtils.get_tensor(name=self.learning_rate_placeholder))
            RZTDL_STORE.add_lr_placeholder(model_name=self.model_name, optimiser_name=self.name,
                                           placeholder_name=self.learning_rate_placeholder)
            # with tf.control_dependencies([GraphUtils.get_operation(self.loss_component.control_dependency)]):
            self.component_output = tf.train.AdamOptimizer(
                learning_rate=GraphUtils.get_tensor(name=self.learning_rate_placeholder)).minimize(
                loss=GraphUtils.get_tensor(name=self.component_input),
                global_step=tf.train.get_or_create_global_step(),
                var_list=self.optimizer_scopes).name
            # RZTDL_DAG.add_placeholder(model_name=self.model_name, layer_name=self.name,
            #                           placeholder_name=self.component_output)
            # RZTDL_DAG.add_prediction_placeholder(model_name=self.model_name, layer_name=self.name,
            #                                      placeholder_name=self.component_output)
            # layer_details = OrderedDict([(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.layer_type),
            #                              (constants.MODEL_ARCHITECTURE.LAYER_OUTPUT,
            #                               self.get_tensor(name=self.component_output).get_shape().as_list().__str__())])
            # RZTDL_DAG.update_model_architecture(model_name=self.model_name, layer_name=self.name,
            #                                     layer_details=layer_details)
            tf.add_to_collection(self.component_output, GraphUtils.get_operation(name=self.component_output))
            RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.name,
                                                       tensor_name=self.component_output)
            if self.component_output_name:
                tf.add_to_collection(name=self.component_output_name,
                                     value=GraphUtils.get_operation(name=self.component_output))
                RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                           component_name=self.component_output_name,
                                                           tensor_name=self.component_output)

        return self

    def validate(self, previous_component: Component):
        """
        | **@author:** Prathyush SP
        |
        | This method is used to perform Input Layer validations
        |
        | todo: Prathyush SP -  Extend Validations
        """
        RZTDL_DAG.add_node_to_dag(node=self.name, component_type=constants.OptimizerTypes)
        RZTDL_DAG.add_edge_to_node(from_node=self.component_input if self.component_input else previous_component.name,
                                   to_node=self.name)
        if isinstance(self.component_input, str):
            self.component_input = RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name,
                                                                              component_name=self.component_input).name
        elif isinstance(self.component_input, Tensor):
            self.component_input = self.component_input.name
        logger.info("Optimizer component ({}) validation success . . .".format(self.name))
