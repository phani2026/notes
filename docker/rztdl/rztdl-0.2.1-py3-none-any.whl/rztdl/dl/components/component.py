# -*- coding: utf-8 -*-
"""
| **@created on:** 17/05/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Component Module
|
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['Component']

from abc import ABCMeta, abstractmethod
from typeguard import typechecked
from rztdl.utils.validations import validate_name
import logging
import rztdl.utils.string_constants as constants
import typing
from tensorflow import Tensor

logger = logging.getLogger(__name__)


class Component(metaclass=ABCMeta):
    """
    | **@author:** Prathyush SP
    |
    | Base class, which defines abstract methods for components
    """

    __slots__ = ['name', 'component_output_name', 'component_input', 'id', 'model_name', 'component_type',
                 'component_output', 'component_sub_type', '__weakref__']

    @typechecked
    def __init__(self, name: str, component_type: constants.ComponentType,
                 component_input: typing.Union[str, None, Tensor, typing.List[typing.Union[str, Tensor]]],
                 component_output: typing.Union[str, None, typing.List[str]]):
        """
        :param name: Name of the component
        :param component_type: Type of the component
        :param component_input: Component Input
        :param component_output: Component Output
        """
        self.name = validate_name(name)
        self.component_input = component_input
        self.component_type = component_type
        self.component_output = component_output
        self.component_output_name = component_output
        self.component_sub_type = None
        self.id = None
        self.model_name = None

    @abstractmethod
    def create_component(self, model_name: str, previous_component: 'Component', component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Used to create a dl component
        :param model_name: Model name
        :param previous_component: Previous Component
        :param component_id: Component Id
        """
        return self  # pragma: no cover

    @abstractmethod
    def validate(self, previous_component: 'Component'):
        """
        | **@author:** Prathyush SP
        |
        | Validation Method
        """
        pass  # pragma: no cover
