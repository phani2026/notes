# -*- coding: utf-8 -*-
"""
| **@created on:** 09/05/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Buffer Module
|
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['Buffer']

from abc import ABCMeta, abstractmethod
from typeguard import typechecked
import logging
import typing
import rztdl.utils.string_constants as constants
from rztdl.dl.components import Component
from tensorflow import Tensor

logger = logging.getLogger(__name__)


class Buffer(Component, metaclass=ABCMeta):
    """
    | **@author:** Prathyush SP
    |
    | Base class, which defines abstract methods for buffers
    """

    __slots__ = ['component_sub_type']

    @typechecked
    def __init__(self, name: str, buffer_type: constants.BufferType, component_output: typing.Union[str, None],
                 component_input: typing.Union[str, Tensor, None] = None):
        """
        :param name: Name for the Buffer
        :param buffer_type: Type of the Buffer
        :param component_input: Component Input - Is None for Buffers
        :param component_output: Name for component output for future reference
        """
        self.component_sub_type = buffer_type
        super().__init__(name=name, component_type=constants.ComponentType.BUFFER,
                         component_input=component_input, component_output=component_output)

    @abstractmethod
    def create_component(self, model_name: str, previous_component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Used to create a dl_layer
        :param model_name: Model name
        :param previous_component: Previous Component [Not Used]
        :param component_id: Layer Id
        """
        pass  # pragma: no cover

    @abstractmethod
    def validate(self, previous_component: Component):
        """
        | **@author:** Prathyush SP
        |
        | Validation Method
        """
        pass  # pragma: no cover
