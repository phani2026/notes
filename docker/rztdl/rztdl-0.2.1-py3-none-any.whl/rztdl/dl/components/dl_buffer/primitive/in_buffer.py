# -*- coding: utf-8 -*-
"""
| **@created on:** 09/05/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Input Buffer Module
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['InBuffer']

import logging
import typing
from collections import OrderedDict
import tensorflow as tf
from typeguard import typechecked
import rztdl.utils.string_constants as constants
from rztdl import RZTDL_CONFIG, RZTDL_STORE, RZTDL_DAG
from rztdl.dl.components.dl_buffer.buffer import Buffer
from rztdl.dl.helpers.tfhelpers.graph_utils import GraphUtils
from rztdl.utils.dl_exception import ShapeError
from rztdl.blueprint import Blueprint
from rztdl.dl.components.component import Component

logger = logging.getLogger(__name__)


class InBuffer(Buffer):
    """
    | **@author:** Prathyush SP
    |
    | In Buffer Component
    """

    @classmethod
    def blueprint(cls):
        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_outputs(name="component_output", status=constants.STATUS.ACTIVE, optional=False,
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        bp.add_parameter(name="name", status=constants.STATUS.ACTIVE, optional=False,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        bp.add_parameter(name="buffer_features", status=constants.STATUS.ACTIVE, optional=False,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER)
        bp.add_parameter(name="buffer_shape", status=constants.STATUS.ACTIVE, optional=False,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.ARRAYOFINT)
        return bp

    __slots__ = ['shape', 'buffer_features']

    @typechecked
    def __init__(self, name: str, buffer_features: int = None,
                 buffer_shape: list = None, component_output: typing.Union[str, None] = None):
        """
        :param name: Name of the Buffer
        :param buffer_features: Input Buffer Features
        :param buffer_shape: Shape of the Input Buffer
        :param component_output: Name for component output for future reference
        """
        super().__init__(name=name, buffer_type=constants.BufferType.IN_BUFFER, component_output=component_output)
        self.shape = buffer_shape
        self.buffer_features = buffer_features

    @typechecked
    def create_component(self, model_name: str, previous_component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Creates Input Buffer
        |
        :param model_name: Model Name
        :param previous_component: Previous Component [Not used]
        :param component_id: Layer ID
        :return In Buffer object
        """
        self.id = component_id
        self.model_name = model_name
        self.validate(previous_component)
        RZTDL_DAG.add_node_to_dag(node=self.name, component_type=constants.BufferType)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.component_output = tf.placeholder(shape=self.shape, dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE).name
            RZTDL_STORE.add_placeholder(model_name=self.model_name, layer_name=self.name,
                                        placeholder_name=self.component_output)
            RZTDL_STORE.add_prediction_placeholder(model_name=self.model_name, layer_name=self.name,
                                                   placeholder_name=self.component_output)
            layer_details = OrderedDict([(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.component_sub_type),
                                         (constants.MODEL_ARCHITECTURE.LAYER_OUTPUT,
                                          GraphUtils.get_tensor(
                                              name=self.component_output).get_shape().as_list().__str__())])
            RZTDL_STORE.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                                  layer_details=layer_details)
            tf.add_to_collection(self.component_output, GraphUtils.get_tensor(name=self.component_output))
            RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.name,
                                                       tensor_name=self.component_output)
            if self.component_output_name:
                tf.add_to_collection(name=self.component_output_name,
                                     value=GraphUtils.get_tensor(name=self.component_output))
                RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                           component_name=self.component_output_name,
                                                           tensor_name=self.component_output)
        return self

    def validate(self, previous_component: Component):
        """
        | **@author:** Prathyush SP
        |
        | This method is used to perform Input Layer validations
        """
        if self.buffer_features is None and self.shape is None:
            raise ShapeError(component_name=self.name, message="Input Buffer is missing Features / Shape")
        if self.shape and len(self.shape) < 2:
            raise ShapeError(component_name=self.name,
                             message="InBuffer shape should have at least 2 dimensions else use layer_nodes parameter")
        if self.shape is None:
            self.shape = [None, self.buffer_features]
        self.buffer_features = self.shape[-1]
        logger.info("Input Buffer ({}) validation success . . .".format(self.name))
