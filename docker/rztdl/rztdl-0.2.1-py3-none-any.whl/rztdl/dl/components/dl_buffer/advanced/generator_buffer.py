# -*- coding: utf-8 -*-
"""
| **@created on:** 10/05/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Generator buffer module
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['GeneratorBuffer']

import rztdl.utils.string_constants as constants
import tensorflow as tf
from typeguard import typechecked
import logging
from rztdl.dl.components.dl_buffer.buffer import Buffer
from rztdl.dl.components.component import Component
from rztdl.dl.helpers.tfhelpers.graph_utils import GraphUtils
from rztdl.dl.dl_dict_parsers import parse_initialization_dict
import typing

logger = logging.getLogger(__name__)


class GeneratorBuffer(Buffer):
    """
    | **@author:** Prathyush SP
    |
    | In Buffer
    """

    __slots__ = ['shape', 'generator_type']

    @typechecked
    def __init__(self, name: str, generator_type: dict, buffer_shape: list,
                 component_output: typing.Union[str, None] = None):
        """
        :param name: Name of the Buffer
        :param generator_type: Type of the generator
        :param buffer_shape: Shape of the Input Buffer
        :param component_output: Name for component output for future reference
        """
        super().__init__(name=name, buffer_type=constants.BufferType.IN_BUFFER, component_output=component_output)
        self.shape = buffer_shape
        self.generator_type = generator_type

    @typechecked
    def create_component(self, model_name: str, previous_component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Creates Input Buffer
        |
        :param model_name: Model Name
        :param previous_component: Previous Component [Not used]
        :param component_id: Layer ID
        :return In Buffer object
        """
        self.id = component_id
        self.model_name = model_name
        self.validate(previous_component)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.component_output = parse_initialization_dict(initialization_dict=self.generator_type,
                                                              shape=self.shape).name
            # layer_details = OrderedDict([(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.buffer_type),
            #                              (constants.MODEL_ARCHITECTURE.LAYER_OUTPUT,
            #                               GraphUtils.get_tensor(
            #                                   name=self.component_output).get_shape().as_list().__str__())])
            # RZTDL_STORE.update_model_architecture(model_name=self.model_name, layer_name=self.name,
            #                                       layer_details=layer_details)
            # RZTDL_STORE.add_layer(model_name=self.model_name, layer_name=self.name, tensor_name=self.component_output)
            tf.add_to_collection(self.component_output, GraphUtils.get_tensor(name=self.component_output))
        return self

    def validate(self, previous_component):
        """
        | **@author:** Prathyush SP
        |
        | This method is used to perform Input Layer validations
        """
        logger.info("Generator Buffer ({}) validation success . . .".format(self.name))
