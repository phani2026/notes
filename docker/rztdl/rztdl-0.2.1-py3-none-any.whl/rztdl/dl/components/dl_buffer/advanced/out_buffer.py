# -*- coding: utf-8 -*-
"""
| **@created on:** 23/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| Output Buffer Module
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

__all__ = ['OutBuffer']

import logging
import typing
from collections import OrderedDict
import tensorflow as tf
from typeguard import typechecked
import rztdl.utils.string_constants as constants
from rztdl import RZTDL_STORE, RZTDL_DAG
from rztdl.dl.components.dl_buffer.buffer import Buffer
from rztdl.dl.helpers.tfhelpers.graph_utils import GraphUtils
from rztdl.dl.components.component import Component
from rztdl.blueprint import Blueprint


logger = logging.getLogger(__name__)


class OutBuffer(Buffer):
    """
    | **@author:** Prathyush SP
    |
    | Out Buffer Component
    """

    @classmethod
    def blueprint(cls):
        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_outputs(name="component_input", status=constants.STATUS.ACTIVE, optional=False,
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        bp.add_parameter(name="name", status=constants.STATUS.ACTIVE, optional=False,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        return bp

    __slots__ = []

    @typechecked
    def __init__(self, name: str, component_input: typing.Union[str, None] = None):
        """
        :param name: Name of the Buffer
        :param component_input: Component Input
        """
        super().__init__(name=name, buffer_type=constants.BufferType.IN_BUFFER, component_input=component_input,
                         component_output=None)

    @typechecked
    def create_component(self, model_name: str, previous_component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Creates Output Buffer
        |
        :param model_name: Model Name
        :param previous_component: Previous Component [Not used]
        :param component_id: Layer ID
        :return In Buffer object
        """
        self.id = component_id
        self.model_name = model_name
        self.validate(previous_component)
        RZTDL_DAG.add_node_to_dag(node=self.name, component_type=constants.BufferType)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.component_output = self.component_input
            layer_details = OrderedDict([(constants.MODEL_ARCHITECTURE.LAYER_TYPE, self.component_sub_type),
                                         (constants.MODEL_ARCHITECTURE.LAYER_OUTPUT,
                                          GraphUtils.get_tensor(
                                              name=self.component_output).get_shape().as_list().__str__())])
            RZTDL_STORE.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                                  layer_details=layer_details)
            # tf.add_to_collection(self.component_output, GraphUtils.get_tensor(name=self.component_output))
            RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.name,
                                                       tensor_name=self.component_output)
        return self

    def validate(self, previous_component: Component):
        """
        | **@author:** Prathyush SP
        |
        | This method is used to perform Input Layer validations
        """
        if self.component_input is None:
            self.component_input = previous_component.component_output
        else:
            self.component_input = RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name,
                                                                              component_name=self.component_input).name
        logger.info("Output Buffer ({}) validation success . . .".format(self.name))

