# -*- coding: utf-8 -*-
"""
| **@created on:** 07/05/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Mean square error module
|
| **Sphinx Documentation Status:** Complete
|
..todo:: Prathyush SP - Provide example with custom cost and validation function.
    --
"""

from rztdl import RZTDL_STORE
import rztdl.utils.string_constants as constants
import tensorflow as tf
from typeguard import typechecked
import logging
from collections import OrderedDict
from rztdl.dl.components.dl_cost.cost import Cost
from tensorflow import Tensor
from rztdl.dl import tf_graph_utils
from typing import Callable, Union
from rztdl.utils.pyutils import FrozenDict
from rztdl.dl.components import Component
from typing import List

logger = logging.getLogger(__name__)


class CustomCost(Cost):
    """
    | **@author:** Prathyush SP
    |
    | Custom Cost Function
    """

    __version__ = "0.0.1"
    __status__ = constants.STATUS.ACTIVE
    __blueprint__ = {
        "version": __version__,
        "status": __status__,
        "inputs": [
            {
                "name": "input",
                "status": constants.STATUS.ACTIVE,
                "repeatable": True,
                "description": "",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                "values": [
                    {
                        "name": "name",
                        "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                        "status": constants.STATUS.ACTIVE,
                        "description": ""

                    }]
            }],
        "outputs": [],
        "parameters": [
            {
                "name": "name",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                "status": constants.STATUS.ACTIVE,
                "description": ""

            },
            {
                "name": "custom_cost_function",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                "status": constants.STATUS.ACTIVE,
                "description": "",
            },
            {
                "name": "custom_cost_function_args",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                "status": constants.STATUS.ACTIVE,
                "description": ""
            },
            {
                "name": "custom_cost_validation_function",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                "status": constants.STATUS.ACTIVE,
                "description": "",
                "optional": True,
            },
            {
                "name": "custom_cost_validation_function_args",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                "status": constants.STATUS.ACTIVE,
                "description": "",
                "optional": True,
            },
            {
                "name": "log_component",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                "status": constants.STATUS.ACTIVE,
                "description": "",
                "optional": True,
                "default_value": False
            }
        ]
    }

    @typechecked
    def __init__(self, name: str, custom_cost_function: Callable, custom_cost_function_args: dict,
                 custom_cost_validation_function: Union[None, Callable] = None,
                 custom_cost_validation_function_args: dict = FrozenDict(), log_component: bool = False):
        """
        :param name: Name of the Cost Function
        :param custom_cost_function: Callable Cost function
        :param custom_cost_function_args: Arguments to be passed for custom cost function
        :param custom_cost_validation_function: Callable Validation function
        :param custom_cost_validation_function_args: Arguments to be passed for custom validation function
        """
        super().__init__(name=name, cost_type=constants.CostType.CUSTOM_COST)
        self.custom_cost_function = custom_cost_function
        self.custom_cost_function_args = custom_cost_function_args
        self.custom_validation_function_args = custom_cost_validation_function_args
        self.custom_validation_function = custom_cost_validation_function
        self.log_component = log_component

    @typechecked
    def create_component(self, model_name, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Creates Input Layer
        |
        :param model_name: Model Name
        :param previous_component: Previous Component
        :param component_id: Component Id
        :return Input Layer object
        """
        self.id = component_id
        self.model_name = model_name
        if isinstance(self.custom_validation_function, Callable):
            try:
                self.custom_validation_function(**self.custom_validation_function_args)
            except Exception as e:
                import traceback
                raise Exception(
                    'Custom Validation function threw error which was not caught in the validation. \nTraceback:\n{}'.format(
                        traceback.format_exc()))
        else:
            logger.warning('Warning!! - Custom cost function is missing validation. ')
        self.validate(previous_component)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.component_output = self.custom_cost_function(**self.custom_cost_function_args)
            if not isinstance(self.component_output, Tensor):
                raise Exception(
                    'Output of custom cost function must be a tensor. Found: {}'.format(type(self.component_output)))
            self.component_output = self.component_output.name
            if self.log_component:
                RZTDL_STORE.add_components_to_log(model_name=model_name, component_name=self.name,
                                                  tensor_name=self.component_output)
            layer_details = OrderedDict([(constants.MODEL_ARCHITECTURE.COST_TYPE, self.cost_type),
                                         (constants.MODEL_ARCHITECTURE.COST_OUTPUT,
                                          tf_graph_utils.get_tensor(
                                              name=self.component_output).get_shape().as_list().__str__())])
            RZTDL_STORE.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                                  layer_details=layer_details)
            tf.add_to_collection(self.component_output, tf_graph_utils.get_tensor(name=self.component_output))
        return self

    def validate(self, previous_component):
        """
        | **@author:** Prathyush SP
        |
        | This method is used to perform Input Layer validations
        """
        logger.info("Custom Cost - {} validation success . . .".format(self.name))
