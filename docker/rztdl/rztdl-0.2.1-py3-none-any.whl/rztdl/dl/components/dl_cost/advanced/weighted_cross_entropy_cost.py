# -*- coding: utf-8 -*-
"""
| **@created on:** 07/05/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Mean square error module
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

from rztdl import RZTDL_CONFIG, RZTDL_STORE
import rztdl.utils.string_constants as constants
import tensorflow as tf
from typeguard import typechecked
import logging
from rztdl.utils.dl_exception import ShapeError
from collections import OrderedDict
from rztdl.dl.components.dl_cost.cost import Cost
from tensorflow import Tensor
from rztdl.dl.helpers.tfhelpers import GraphUtils
from typing import Union
from rztdl.dl.components.component import Component

logger = logging.getLogger(__name__)


class WeightedCrossEntropy(Cost):
    """
    | **@author:** Prathyush SP
    |
    | Weighted Cross Entropy
    """

    __version__ = "0.0.1"
    __status__ = constants.STATUS.ACTIVE
    __blueprint__ = {
        "version": __version__,
        "status": __status__,
        "inputs": [
            {
                "name": "labels",
                "status": constants.STATUS.ACTIVE,
                "description": "",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE
            },
            {
                "name": "predictions",
                "status": constants.STATUS.ACTIVE,
                "description": "",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE

            }],
        "outputs": [],
        "parameters": [
            {
                "name": "name",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                "status": constants.STATUS.ACTIVE,
                "description": ""

            },
            {
                "name": "positive_weight",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.FLOAT,
                "status": constants.STATUS.ACTIVE,
                "description": "",
            },
            {
                "name": "log_component",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                "status": constants.STATUS.ACTIVE,
                "description": "",
                "optional": True,
                "default_value": False
            }
        ]
    }

    @typechecked
    def __init__(self, name: str, labels: Union[str, Tensor], predictions: Union[str, Tensor],
                 positive_weight: float, log_component: bool = False):
        """
        :param name: Name of the Layer
        :param labels: True labels for the given data
        :param predictions: Predictions given by the model
        :param positive_weight: Positive Weight
        """
        super().__init__(name=name, cost_type=constants.CostType.WEIGHTED_CROSS_ENTOPY)
        self.labels = labels
        self.predictions = predictions
        self.pos_weights = positive_weight
        self.log_component = log_component

    @typechecked
    def create_component(self, model_name, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Creates Sigmoid cross entropy
        :param model_name: Model Name
        :param previous_component: Previous Component
        :param component_id: Component Id
        :return Input Layer object
        """
        self.id = component_id
        self.model_name = model_name
        self.validate(previous_component)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.component_output = tf.reduce_mean(
                tf.nn.weighted_cross_entropy_with_logits(logits=self.predictions, labels=self.labels,
                                                         pos_weight=self.pos_weights))
            if self.log_component:
                RZTDL_STORE.add_components_to_log(model_name=model_name, component_name=self.name,
                                                  tensor_name=self.component_output)
            layer_details = OrderedDict([(constants.MODEL_ARCHITECTURE.COST_TYPE, self.cost_type),
                                         (constants.MODEL_ARCHITECTURE.COST_OUTPUT,
                                          GraphUtils.get_tensor(
                                              name=self.component_output).get_shape().as_list().__str__())])
            RZTDL_STORE.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                                  layer_details=layer_details)
            tf.add_to_collection(self.component_output, GraphUtils.get_tensor(name=self.component_output))
        return self

    def validate(self, previous_component):
        """
        | **@author:** Prathyush SP
        |
        | This method is used to perform Input Layer validations
        """
        if isinstance(self.predictions, Tensor):
            self.predictions = self.predictions.name
        else:
            self.predictions = RZTDL_STORE.get_component_output_as_tensor(self.model_name, self.predictions).name
        if isinstance(self.labels, Tensor):
            self.labels = self.labels.name
        else:
            self.labels = RZTDL_STORE.get_component_output_as_tensor(self.model_name, self.labels).name
        if not tf.shape(GraphUtils.get_tensor(self.predictions)).shape == tf.shape(
                GraphUtils.get_tensor(self.labels)).shape:
            raise ShapeError(
                "Shape of Predictions {} and Labels {} do not match".format(
                    GraphUtils.get_tensor(self.predictions).shape, GraphUtils.get_tensor(self.labels).shape))
        logger.info("Mean Square Error validation success . . .")
