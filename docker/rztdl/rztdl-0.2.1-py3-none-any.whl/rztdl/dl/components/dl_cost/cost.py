# -*- coding: utf-8 -*-
"""
| **@created on:** 07/05/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Cost Module used to create deeplearning objective functions.
|
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['Cost']

from abc import ABCMeta, abstractmethod
from typeguard import typechecked
import logging
import rztdl.utils.string_constants as constants
from rztdl.dl.components import Component
import typing
from tensorflow import Tensor
import tensorflow as tf
from rztdl.dl.helpers.tfhelpers import GraphUtils
from rztdl import RZTDL_STORE

logger = logging.getLogger(__name__)


class Cost(Component, metaclass=ABCMeta):
    """
    | **@author:** Prathyush SP
    |
    | Base class, which defines abstract methods for costs
    """

    __slots__ = ['component_sub_type', 'log_component', 'ema', 'moving_average_decay', 'control_dependency',
                 'moving_average', 'required_inputs', 'required_input_placeholders']

    @typechecked
    def __init__(self, name: str, cost_type: constants.CostType, component_output: typing.Union[str, None],
                 component_input: typing.Union[str, Tensor, None] = None, moving_average_decay: float = 0.9):
        """
        :param name: Name for the cost
        :param cost_type: Type of Objective Function
        :param component_input: Component Input
        :param component_output: Component Output
        """
        super().__init__(name=name, component_type=constants.ComponentType.COST,
                         component_input=component_input, component_output=component_output)
        self.component_sub_type = cost_type
        self.log_component = False
        self.moving_average_decay = moving_average_decay
        # self.ema = tf.train.ExponentialMovingAverage(decay=self.moving_average_decay)
        self.control_dependency = []
        self.moving_average = None
        self.required_inputs = {}
        self.required_input_placeholders = {}

    @typechecked
    def create_placeholders_for_inputs(self, required_inputs: typing.List[str]):
        """
        | **@author:** Prathyush SP
        |
        | Create placeholders for inputs and use placeholders instead of direct inputs for running
        | only metrics as a separate component
        :param required_inputs: Required Inputs
        :return: Dictionary of {Required Input Name: Corresponding Node}, {Required Input Name: Corresponding Placeholder}
        """
        self.required_inputs = {
            inp: RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=inp).name for inp
            in
            required_inputs}
        for itms in required_inputs:
            with tf.name_scope(self.model_name + '/' + itms + '/'):
                self.required_input_placeholders[itms] = self.get_or_create_placeholder_with_default(
                    component_name=itms)
        return self.required_inputs, self.required_input_placeholders

    @typechecked
    def get_or_create_placeholder_with_default(self, component_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Get or create placeholder for required inputs
        | This method is used to avoid redundant placeholder creation for common metrics
        :param component_name: Component Name
        :return: Placeholder Name
        """
        try:
            return RZTDL_STORE.get_required_input_for_metrics_as_tensor(model_name=self.model_name,
                                                                        metric_component_name=component_name)
        except KeyError:
            pl = tf.placeholder_with_default(
                input=RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name,
                                                                 component_name=component_name),
                shape=RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name,
                                                                 component_name=component_name).shape).name
            RZTDL_STORE.add_required_input_for_metrics_as_tensor(model_name=self.model_name,
                                                                 metric_component_name=component_name, tensor_name=pl)
            return pl

    @abstractmethod
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Used to create a objective function
        :param model_name: Model name
        :param previous_component: Previous Component
        :param component_id: Component Id
        """
        pass  # pragma: no cover

    # def apply_moving_average(self):
    #     self.control_dependency = self.ema.apply([GraphUtils.get_tensor(self.component_output)]).name
    #     self.moving_average = self.ema.average(GraphUtils.get_tensor(self.component_output)).name

    @abstractmethod
    def validate(self, previous_component: Component):
        """
        | **@author:** Prathyush SP
        |
        | Validation Method
        :param previous_component: Previous Component
        """
        pass  # pragma: no cover
