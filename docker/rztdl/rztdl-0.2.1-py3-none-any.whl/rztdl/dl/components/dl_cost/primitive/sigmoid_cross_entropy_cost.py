# -*- coding: utf-8 -*-
"""
| **@created on:** 07/05/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Mean square error module
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

import logging
from collections import OrderedDict
import typing
import rztdl.utils.string_constants as constants
import tensorflow as tf
from rztdl import RZTDL_STORE
from rztdl.blueprint import Blueprint
from rztdl.dl.components.component import Component
from rztdl.dl.components.dl_cost.cost import Cost
from rztdl.dl.helpers.tfhelpers import GraphUtils
from rztdl.utils.dl_exception import ShapeError
from tensorflow import Tensor
from typeguard import typechecked

logger = logging.getLogger(__name__)


class SigmoidCrossEntropy(Cost):
    """
    | **@author:** Prathyush SP
    |
    | Sigmoid Cross Entropy
    """

    @classmethod
    def blueprint(cls):

        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="labels", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        bp.add_inputs(name="predictions", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        bp.add_outputs(name="component_output", optional=False, status=constants.STATUS.ACTIVE,
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        bp.add_parameter(name="name", optional=False, status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        bp.add_parameter(name="log_component", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                         status=constants.STATUS.ACTIVE, default_value=False)
        return bp

    @typechecked
    def __init__(self, name: str, labels: typing.Union[str, Tensor], predictions: typing.Union[str, Tensor],
                 component_output: typing.Union[str, None] = None,
                 log_component: bool = False):
        """
        :param name: Name of the Layer
        :param labels: True labels for the given data
        :param predictions: Predictions given by the model
        """
        super().__init__(name=name, cost_type=constants.CostType.SIGMOID_CROSS_ENTROPY,
                         component_input=None,
                         component_output=component_output
                         )
        self.labels = labels
        self.predictions = predictions
        self.log_component = log_component

    @typechecked
    def create_component(self, model_name, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Creates Sigmoid cross entropy
        :param model_name: Model Name
        :param previous_component: Previous Component
        :param component_id: Component Id
        :return Input Layer object
        """
        self.id = component_id
        self.model_name = model_name
        self.validate(previous_component)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.component_output = tf.reduce_mean(
                tf.nn.sigmoid_cross_entropy_with_logits(logits=self.predictions, labels=self.labels))
            if self.log_component:
                RZTDL_STORE.add_components_to_log(model_name=model_name, component_name=self.name,
                                                  tensor_name=self.component_output)
            layer_details = OrderedDict([(constants.MODEL_ARCHITECTURE.COST_TYPE, self.component_sub_type),
                                         (constants.MODEL_ARCHITECTURE.COST_OUTPUT,
                                          GraphUtils.get_tensor(
                                              name=self.component_output).get_shape().as_list().__str__())])
            RZTDL_STORE.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                                  layer_details=layer_details)
            tf.add_to_collection(self.component_output, GraphUtils.get_tensor(name=self.component_output))
        return self

    def validate(self, previous_component):
        """
        | **@author:** Prathyush SP
        |
        | This method is used to perform Input Layer validations
        """
        if isinstance(self.predictions, Tensor):
            self.predictions = self.predictions.name
        else:
            self.predictions = RZTDL_STORE.get_component_output_as_tensor(self.model_name, self.predictions).name
        if isinstance(self.labels, Tensor):
            self.labels = self.labels.name
        else:
            self.labels = RZTDL_STORE.get_component_output_as_tensor(self.model_name, self.labels).name
        if not GraphUtils.get_tensor(self.predictions).get_shape().as_list() == GraphUtils.get_tensor(
                self.labels).get_shape().as_list():
            raise ShapeError(component_name=self.name,
                             message="Shape of Predictions {} and Labels {} do not match".format(
                                 GraphUtils.get_tensor(self.predictions).shape,
                                 GraphUtils.get_tensor(self.labels).shape))
        logger.info("Mean Square Error validation success . . .")
