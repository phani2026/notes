# -*- coding: utf-8 -*-
"""
| **@created on:** 17/05/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

from rztdl.dl.components.dl_metric.primitive.gini_metric import GiniMetric
