# -*- coding: utf-8 -*-
"""
| **@created on:** 17/05/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Gini Metric
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

import logging
import typing
from collections import OrderedDict

import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked

import rztdl.utils.string_constants as constants
from rztdl import RZTDL_STORE, RZTDL_DAG
from rztdl.blueprint import Blueprint
from rztdl.dl.components.component import Component
from rztdl.dl.components.dl_metric.metric import Metric
from rztdl.dl.helpers.tfhelpers import GraphUtils
from rztdl.utils.dl_exception import ShapeError

logger = logging.getLogger(__name__)


class GiniMetric(Metric):
    """
    | **@author:** Prathyush SP
    |
    | Gini Metric
    """

    __slots__ = ['labels', 'predictions', 'log_component']

    @classmethod
    def blueprint(cls):

        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="labels", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        bp.add_inputs(name="predictions", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        bp.add_outputs(name="component_output", optional=False, status=constants.STATUS.ACTIVE,
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        bp.add_parameter(name="name", optional=False, status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING)
        bp.add_parameter(name="log_component", optional=True,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                         status=constants.STATUS.ACTIVE, default_value=False)
        return bp

    @typechecked
    def __init__(self, name: str, labels: typing.Union[str, Tensor], predictions: typing.Union[str, Tensor],
                 log_component: bool = False, component_output: typing.Union[str, None] = None):
        """
        :param name: Name of the Layer
        :param labels: True labels for the given data
        :param predictions: Predictions given by the model
        :param component_output: Component Output
        """
        super().__init__(name=name, metric_type=constants.MetricType.GINI_METRIC, component_input=None,
                         component_output=component_output)
        self.labels = labels
        self.predictions = predictions
        self.log_component = log_component

    @typechecked
    def create_component(self, model_name, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Creates Component
        |
        :param model_name: Model Name
        :param previous_component: Previous Component
        :param component_id: Component Id
        :return Gini Metric object
        """
        self.id = component_id
        self.model_name = model_name
        self.validate(previous_component)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            # todo: Prathyush SP -  Check if python operators work
            self.component_output = tf.subtract(tf.multiply(tf.metrics.auc(labels=GraphUtils.get_tensor(self.labels),
                                                                           predictions=GraphUtils.get_tensor(
                                                                               self.predictions))[0], 2.0), 1.0).name
            # self.component_output = 2.0 * tf.metrics.auc(labels=GraphUtils.get_tensor(self.labels),
            #                                              predictions=GraphUtils.get_tensor(
            #                                                  self.predictions)) - 1
            if self.log_component:
                RZTDL_STORE.add_components_to_log(model_name=model_name, component_name=self.name,
                                                  tensor_name=self.component_output)
            layer_details = OrderedDict([(constants.MODEL_ARCHITECTURE.COST_TYPE, self.component_sub_type),
                                         (constants.MODEL_ARCHITECTURE.COST_OUTPUT,
                                          GraphUtils.get_tensor(
                                              name=self.component_output).get_shape().as_list().__str__())])
            RZTDL_STORE.update_model_architecture(model_name=self.model_name, layer_name=self.name,
                                                  layer_details=layer_details)
            tf.add_to_collection(self.component_output, GraphUtils.get_tensor(name=self.component_output))
        return self

    def validate(self, previous_component):
        """
        | **@author:** Prathyush SP
        |
        | This method is used to perform Input Layer validations
        """
        RZTDL_DAG.add_node_to_dag(node=self.name, component_type=constants.MetricType)
        RZTDL_DAG.add_edge_to_node(from_node=self.labels, to_node=self.name)
        RZTDL_DAG.add_edge_to_node(from_node=self.predictions, to_node=self.name)
        if isinstance(self.predictions, Tensor):
            self.predictions = self.predictions.name
        else:
            self.predictions = RZTDL_STORE.get_component_output_as_tensor(self.model_name, self.predictions).name
        if isinstance(self.labels, Tensor):
            self.labels = self.labels.name
        else:
            self.labels = RZTDL_STORE.get_component_output_as_tensor(self.model_name, self.labels).name
        if not GraphUtils.get_tensor(self.predictions).get_shape().as_list() == GraphUtils.get_tensor(
                self.labels).get_shape().as_list():
            raise ShapeError(component_name=self.name,
                             message="Shape of Predictions {} and Labels {} do not match".format(
                                 GraphUtils.get_tensor(self.predictions).shape,
                                 GraphUtils.get_tensor(self.labels).shape))
        logger.info("Gini Metric  validation success . . .")
