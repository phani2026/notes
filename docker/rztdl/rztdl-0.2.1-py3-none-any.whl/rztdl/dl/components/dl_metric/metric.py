# -*- coding: utf-8 -*-
"""
| **@created on:** 17/05/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Cost Module used to create deeplearning objective functions.
|
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

import logging
import typing
from abc import ABCMeta, abstractmethod

from tensorflow import Tensor
from typeguard import typechecked

import rztdl.utils.string_constants as constants
from rztdl.dl.components import Component
from rztdl.utils.validations import validate_name

logger = logging.getLogger(__name__)


class Metric(Component, metaclass=ABCMeta):
    """
    | **@author:** Prathyush SP
    |
    | Base class, which defines abstract methods for metric
    """

    @typechecked
    def __init__(self, name: str, metric_type: constants.MetricType, component_output: typing.Union[str, None],
                 component_input: typing.Union[str, Tensor, None] = None):
        """
        :param name: Name for the metric
        :param metric_type: Type of Objective Function
        :param component_input: Component input
        :param component_output: Component Output
        """
        self.name = validate_name(name)
        self.id = None
        self.model_name = None
        self.component_sub_type = metric_type
        self.log_component = False
        super().__init__(name=name, component_type=constants.ComponentType.METRIC, component_input=component_input,
                         component_output=component_output)

    @abstractmethod
    def create_component(self, model_name, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Used to create a metric function
        :param model_name: Model name
        :param previous_component: Previous Component
        :param component_id: Component Id
        """
        pass  # pragma: no cover

    @abstractmethod
    def validate(self, previous_component):
        """
        | **@author:** Prathyush SP
        |
        | Validation Method
        :param previous_component: Previous Component
        """
        pass  # pragma: no cover
