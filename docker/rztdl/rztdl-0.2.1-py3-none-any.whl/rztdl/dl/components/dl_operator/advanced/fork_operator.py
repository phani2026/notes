# -*- coding: utf-8 -*-
"""
| *@created on:* 19/06/18,
| *@author:* Umesh Kumar,
| *@version:* v0.0.1
|
| *Description:*
| 
| *Sphinx Documentation Status:* Complete
|
"""

__all__ = ['ForkOperator']

import logging
import typing
from collections import OrderedDict

import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked

import rztdl.utils.string_constants as constants
from rztdl import RZTDL_STORE
from rztdl.blueprint import Blueprint, BluePrintProperties
from rztdl.dl import GraphUtils
from rztdl.dl.components.component import Component
from rztdl.dl.components.dl_operator import Operator
from rztdl.utils.dl_exception import SizeError

logger = logging.getLogger(__name__)


class ForkOperator(Operator):
    """
    | **@author:** Umesh Kumar
    |
    | Addition Operator
    """

    @classmethod
    def blueprint(cls):
        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        p1 = BluePrintProperties(name="index", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=constants.STATUS.ACTIVE, optional=False)
        bp.add_outputs(name="component_output", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                       properties=[p1], status=constants.STATUS.ACTIVE, repeatable=True, optional=False)
        bp.add_parameter(name="name", status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING, optional=False)
        return bp

    __slots__ = []

    @typechecked
    def __init__(self, name: str, component_input: typing.Union[str, Tensor],
                 component_output: typing.List[typing.Union[str, Tensor]]):
        """
        :param name: Operator Name
        :param component_input: Operator Input
        :param component_output: Operator Output
        """
        super().__init__(name=name, operator_type=constants.OperatorTypes.ADD_OPERATOR, component_input=component_input,
                         component_output=component_output)

    @typechecked
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Umesh Kumar
        |
        | Creates Addition dl_operator
        :param model_name: Model Name
        :param previous_component : Previous Component
        :param component_id: Component ID
        :return: Add operator object
        """
        self.model_name = model_name
        self.id = component_id
        self.validate(previous_component=previous_component)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            for output in self.component_output:
                RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=output,
                                                           tensor_name=GraphUtils.get_tensor(self.component_input).name)
                tf.add_to_collection(output, GraphUtils.get_tensor(self.component_input))
            operator_details = OrderedDict([
                (constants.MODEL_ARCHITECTURE.OPERATOR_INPUT,
                 GraphUtils.get_tensor(self.component_input).get_shape().as_list().__str__()),
                (constants.MODEL_ARCHITECTURE.OPERATOR_OUTPUT,
                 [GraphUtils.get_tensor(self.component_input).get_shape().as_list().__str__() for output in
                  self.component_output])])
        RZTDL_STORE.update_model_operator_architecture(model_name=self.model_name, operator_name=self.name,
                                                       operator_details=operator_details)
        self.component_output = [GraphUtils.get_tensor(self.component_input).name for i in
                                 range(len(self.component_output))]
        return self

    def validate(self, previous_component: Component):
        """
        | **@author:** Umesh Kumar
        |
        | Addition Operator validation

        :param previous_component: Previous Component
        """
        self.component_input = self._map_input_operator(component_input=self.component_input)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            if len(self.component_output) < 2:
                raise SizeError(component_name=self.name,
                                message='Requires minimum of 2 outputs. Given inputs: {}'.format(self.name))
        logger.info("Fork Operator ({}) validation success . . .".format(self.name))
