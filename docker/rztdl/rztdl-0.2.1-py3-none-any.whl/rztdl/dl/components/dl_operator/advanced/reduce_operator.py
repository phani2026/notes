# -*- coding: utf-8 -*-
"""
| **@created on:** 10/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
from rztdl.dl.components.dl_operator import Operator
from typing import Union
from tensorflow import Tensor
from typeguard import typechecked
from rztdl import RZTDL_STORE
import tensorflow as tf
import rztdl.utils.string_constants as constants
from collections import OrderedDict
from rztdl.dl.helpers import tfhelpers


class ReduceOperator(Operator):
    """
    | **@author:** Thebzeera V
    |
    | Reduce  Operator Constructor
    """

    __version__ = "0.0.1"
    __status__ = constants.STATUS.ACTIVE
    __blueprint__ = {
        "version": __version__,
        "status": __status__,
        "inputs": [
            {
                "name": "operator_input",
                "status": constants.STATUS.ACTIVE,
                "description": "",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE
            }
        ],
        "outputs": [
            {
                "name": "operator_output",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                "status": constants.STATUS.ACTIVE,
                "description": ""
            },
        ],
        "parameters": [
            {
                "name": "name",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                "status": constants.STATUS.ACTIVE,
                "description": ""
            },
            {
                "name": "dimension",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                "status": constants.STATUS.ACTIVE,
                "description": ""
            },
            {
                "name": "keep_dimension",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN,
                "status": constants.STATUS.ACTIVE,
                "description": ""
            },
            {
                "name": "operator_type",
                "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                "status": constants.STATUS.ACTIVE,
                "description": "",
                "possibleValues": constants.REDUCE_OPERATOR.__meta__
            }

        ]
    }

    @typechecked
    def __init__(self, name: str, operator_input: Union[str, Tensor], operator_output: str,
                 operator_type: str = constants.REDUCE_OPERATOR.MAX, keep_dimension: bool = False,
                 dimension: int = None):
        """

        :param name: Operator name
        :param operator_input: Operator input
        :param dimension:  Dimension
        :param keep_dimension: Keep dimension
        :param operator_output: Operator output
        :param operator_type: Reduce Operator type
        """
        super().__init__(name=name, operator_type=constants.OperatorTypes.REDUCE_OPERATOR)
        self.operator_input = operator_input
        self.keep_dimension = keep_dimension
        self.dimension = dimension
        self.reduce_max_name = operator_output
        self.operator_type = operator_type

    @typechecked
    def create_operator(self, model_name: str, operator_id: int):
        """
        | **@author:** Thebzeera V
        |
        | Creates Reduce  dl_operator
        :param model_name: Model Name
        :param operator_id: Operator ID
        :return: reduce Operator
        """

        self.model_name = model_name
        self.operator_id = operator_id
        self.validate()
        with tf.name_scope(self.name + '/'):
            self.operator_output = ReduceOp(input_tensor=self.operator_input,
                                            axis=self.dimension,
                                            keep_dims=self.keep_dimension).parse_reduce_operator(
                type=self.operator_type)
            operator_details = OrderedDict(
                [(constants.MODEL_ARCHITECTURE.OPERATOR_INPUT, self.operator_input.get_shape().as_list().__str__()),
                 (constants.MODEL_ARCHITECTURE.REDUCE_OPERATOR_DIMENSION, self.dimension),
                 (constants.MODEL_ARCHITECTURE.KEEP_DIMENSION, self.keep_dimension),
                 (constants.MODEL_ARCHITECTURE.OPERATOR_OUTPUT,
                  self.operator_output.get_shape().as_list().__str__())
                 ])
        tf.add_to_collection(self.operator_output.name, self.operator_output)
        RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.reduce_max_name,
                                                   tensor_name=self.operator_output.name)
        RZTDL_STORE.update_model_operator_architecture(model_name=self.model_name, operator_name=self.name,
                                                       operator_details=operator_details)

        return self

    def validate(self):
        """
        | **@author:** Thebzeera V
        |
        | Reduce  Operator validation
        """
        if isinstance(self.operator_input, str):
            self.operator_input = RZTDL_STORE.get_component_output_as_tensor(self.model_name, self.operator_input)
        if self.dimension:
            if not self.dimension < len(self.operator_input.get_shape()):
                raise Exception("Dimension should be less than {}".format(len(self.operator_input.get_shape())))
        if isinstance(self.operator_type, str):
            if self.operator_type not in constants.REDUCE_OPERATOR.__dict__.values():
                raise Exception("Not a valid Reduce dl_operator. Usage: REDUCEOPERATOR.<>")


class ReduceOp(object):
    """
       | **@author**: Thebzeera V
       |
       | The class handles reduce  operation available in tensorflow
       | It consists of:
       |
       | 1. Reduce Max
       | 2. Reduce Min
       | 3. Reduce Mean
    """

    @typechecked
    def __init__(self, input_tensor: Union[str, Tensor], axis: Union[int, None], keep_dims: bool):
        """

        :param input_tensor: Input Tensor
        :param axis: Axis
        :param keep_dims: Keep Dimension
        """
        self.input_tensor = input_tensor
        self.axis = axis
        self.keep_dimension = keep_dims

    def reduce_max(self):
        """

        :return: Reduce Max
        """
        return tf.reduce_max(input_tensor=self.input_tensor, axis=self.axis, keep_dims=self.keep_dimension)

    def reduce_min(self):
        """

        :return: Reduce Min
        """

        return tf.reduce_min(input_tensor=self.input_tensor, axis=self.axis, keep_dims=self.keep_dimension)

    def reduce_mean(self):
        """

        :return: Reduce Mean
        """

        return tf.reduce_mean(input_tensor=self.input_tensor, axis=self.axis, keep_dims=self.keep_dimension)

    @typechecked
    def parse_reduce_operator(self, type: str):
        """

        :param type:
        :param input_tensor:
        :param axis:
        :param keep_dims:
        :return:
        """
        switch = {
            constants.REDUCE_OPERATOR.MAX: self.reduce_max,
            constants.REDUCE_OPERATOR.MIN: self.reduce_min,
            constants.REDUCE_OPERATOR.MEAN: self.reduce_mean
        }
        return switch[type]()
