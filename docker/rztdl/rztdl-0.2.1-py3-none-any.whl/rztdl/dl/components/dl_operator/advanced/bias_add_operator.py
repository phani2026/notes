# -*- coding: utf-8 -*-
"""
| **@created on:** 10/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
|
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
from rztdl.dl.components.dl_operator import Operator
from typing import Union
from tensorflow import Tensor
from typeguard import typechecked
from rztdl import RZTDL_STORE, RZTDL_CONFIG
import tensorflow as tf
import rztdl.utils.string_constants as constants
from collections import OrderedDict
from numpy import ndarray
from types import FunctionType
from rztdl.dl import tf_summary
import logging
from rztdl.dl.dl_dict_parsers import parse_initialization_dict

from rztdl.utils.dl_exception import DTypeError, ShapeError

logger = logging.getLogger(__name__)


class BiasAddOperator(Operator):
    """
    | **@author:** Himaprasoon P T
    |
    | BiasAdd Operator
    """

    __version__ = "0.0.1"
    __status__ = constants.STATUS.ACTIVE
    # __blueprint__ = {
    #     "version": __version__,
    #     "status": __status__,
    #     "inputs": [
    #         {
    #             "name": "operator_input",
    #             "status": constants.STATUS.ACTIVE,
    #             "description": "",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE
    #         }
    #     ],
    #     "outputs": [
    #         {
    #             "name": "operator_output",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
    #             "status": constants.STATUS.ACTIVE,
    #             "description": ""
    #         },
    #     ],
    #     "parameters": [
    #         {
    #             "name": "name",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
    #             "status": constants.STATUS.ACTIVE,
    #             "description": ""
    #         },
    #         {
    #             "name": "bias",
    #             "description": "",
    #             "dataType": constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
    #             "status": constants.INITIALIZER.__status__,
    #             "possibleValues": constants.INITIALIZER.__meta__,
    #             "optional": True,
    #             "default_value": constants.INITIALIZER.ONES
    #         }
    #     ]
    # }

    @typechecked
    def __init__(self, name: str, operator_input: Union[str, Tensor], operator_output: str,
                 bias: Union[ndarray, dict, FunctionType, float, int] = None):
        """

        :param name: dl_operator name
        :param operator_input: Operator input : A tensor or name of a dl_layer/dl_operator
        :param operator_output: Name of the dl_operator to be used in subsequent layers/operatore
        :param bias: Bias to be added, Should be a 1 D vector
        """
        if isinstance(bias, int):
            bias = float(bias)
        super().__init__(name=name, operator_type=constants.OperatorTypes.BIAS_ADD_OPERATOR)
        self.operator_input = operator_input
        self.bias = bias
        self.operator_input_name = operator_output
        self.bias_dimension = None

    @typechecked
    def create_operator(self, model_name: str, operator_id: int):
        """
        | **@author:** Himaprasoon P T
        |
        | Create BiasAdd Operator
        :param model_name: Model Name
        :param operator_id: Operator Id
        :return: BiasAdd Operator
        """
        self.model_name = model_name
        self.operator_id = operator_id

        self.validate()
        with tf.name_scope(self.name):
            self.operator_output = tf.nn.bias_add(self.operator_input, bias=self.bias)
            operator_details = OrderedDict(
                [(constants.MODEL_ARCHITECTURE.OPERATOR_INPUT, self.operator_input.get_shape().as_list().__str__()),
                 (constants.MODEL_ARCHITECTURE.BIAS_SHAPE, self.bias.get_shape().as_list().__str__()),
                 (constants.MODEL_ARCHITECTURE.OPERATOR_OUTPUT,
                  self.operator_output.get_shape().as_list().__str__())
                 ])
        RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=self.operator_input_name,
                                                   tensor_name=self.operator_output.name)
        RZTDL_STORE.update_model_operator_architecture(model_name=self.model_name, operator_name=self.name,
                                                       operator_details=operator_details)
        return self

    def validate(self):
        """
        | **@author:** Himaprasoon P T
        |
        | BiasAdd Operator Validation
        """
        if isinstance(self.operator_input, str):
            self.operator_input = RZTDL_STORE.get_component_output_as_tensor(self.model_name, self.operator_input)
        self.bias_dimension = [int(self.operator_input.get_shape()[-1])]
        with tf.name_scope(self.name + "/"):
            with tf.name_scope('biases'):
                if isinstance(self.bias, ndarray):
                    self.bias = self.bias.astype(RZTDL_CONFIG.TensorflowConfig.DTYPE.as_numpy_dtype)
                    if not str(self.bias.dtype) == str(
                            RZTDL_CONFIG.TensorflowConfig.DTYPE.as_numpy_dtype).replace("<class 'numpy.", '').replace(
                        "'>", ''):
                        raise DTypeError(
                            'Datatype should match global datatype {}'.format(RZTDL_CONFIG.TensorflowConfig.DTYPE))
                    if self.bias.shape != (self.bias_dimension[0],):
                        raise ShapeError("Bias should be 1D array of shape ({},) ".format(self.bias_dimension[0]))
                    self.bias = tf.Variable(self.bias)
                elif isinstance(self.bias, dict):
                    self.bias = tf.Variable(
                        parse_initialization_dict(initialization_dict=self.bias, shape=self.bias_dimension))
                elif isinstance(self.bias, float):
                    self.bias = tf.constant(self.bias, shape=[self.operator_input.get_shape().as_list()[-1]])
                else:
                    self.bias = tf.Variable(
                        RZTDL_CONFIG.TensorflowConfig.DEFAULT_BIAS_FN(shape=self.bias_dimension,
                                                                      dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE))
                    logger.debug("Generating Bias for " + str(self.name))
                RZTDL_STORE.add_bias(model_name=self.model_name, layer_name=self.name,
                                     layer_bias=self.bias.name)
                tf.add_to_collection(self.bias.name, self.bias)
                if RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY:
                    tf_summary.create_variable_summaries(tensor=self.bias)
