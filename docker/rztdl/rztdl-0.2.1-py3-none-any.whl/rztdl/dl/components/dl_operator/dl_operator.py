# -*- coding: utf-8 -*-
"""
| **@created on:** 10/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| Operator Module
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['Operator']

import typing
from abc import ABCMeta, abstractmethod
from tensorflow import Tensor
from typeguard import typechecked
import rztdl.utils.string_constants as constants
from rztdl.utils.validations import validate_name
from rztdl.dl.components.component import Component
from rztdl import RZTDL_STORE


class Operator(Component, metaclass=ABCMeta):
    """
    | **@author:** Prathyush SP
    |
    | Operator Parent Class
    """

    __slots__ = ['component_sub_type', 'operator_id']

    @typechecked
    def __init__(self, name: str, operator_type: constants.OperatorTypes,
                 component_input: typing.Union[str, None, Tensor, typing.List[typing.Union[str, Tensor]]],
                 component_output: typing.Union[str, None, typing.List[str]]):
        """
        :param name: Operator Name
        """
        super().__init__(name=name, component_type=constants.ComponentType.LAYER,
                         component_input=component_input, component_output=component_output)
        self.name = validate_name(name)
        self.component_sub_type = operator_type
        self.operator_id = None
        self.model_name = None

    @abstractmethod
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Creates Operator
        :param model_name: Model Name
        :param previous_component: Previous Component
        :param component_id: Component ID
        :return: Operator
        """
        pass  # pragma: no cover

    @typechecked
    def _map_input_operator(self, component_input: typing.Union[str, Tensor]):

        # Input is tensor
        if isinstance(component_input, Tensor):
            return component_input.name

        # Input is a string
        elif isinstance(component_input, str):
            return RZTDL_STORE.get_component_output_as_tensor(self.model_name, component_input).name

    @abstractmethod
    def validate(self, previous_component: Component):
        """
        | **@author:** Prathyush SP
        |
        | Operator Validation
        :param previous_component: Previous Component
        """
        pass  # pragma: no cover
