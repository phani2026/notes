# -*- coding: utf-8 -*-
"""
| **@created on:** 10/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| Concat Operator Module
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['ConcatOperator']

import logging
import typing
from collections import OrderedDict
import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked
import rztdl.utils.string_constants as constants
from rztdl import RZTDL_STORE
from rztdl.blueprint import Blueprint
from rztdl.dl import GraphUtils
from rztdl.dl.components.component import Component
from rztdl.dl.components.dl_operator import Operator
from rztdl.utils.dl_exception import DimensionError, SizeError

logger = logging.getLogger(__name__)


class ConcatOperator(Operator):
    """
    | **@author:** Prathyush SP
    |
    | Concat Operation
    """

    @classmethod
    def blueprint(cls):
        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, repeatable=True, optional=False, minimum_inputs=2)
        bp.add_outputs(name="component_output", status=constants.STATUS.ACTIVE,
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING, optional=False)
        bp.add_parameter(name="name", status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING, optional=False)
        bp.add_parameter(name="dimension", status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER, optional=False)
        return bp

    __slots__ = ["dimension"]

    @typechecked
    def __init__(self, name, component_input: typing.List[typing.Union[str, Tensor]], component_output: str,
                 dimension: int):
        """
        :param name: Operator Name
        :param component_input: Operator Input
        :param component_output: Operator Output
        :param dimension: Dimension
        """
        super().__init__(name=name, operator_type=constants.OperatorTypes.CONCAT_OPERATOR,
                         component_output=component_output, component_input=component_input)
        self.component_output_name = component_output
        self.dimension = dimension

    @typechecked
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Creates Concat Operator
        :param model_name: Model Name
        :param previous_component : Previous Component
        :param component_id: Operator Id
        :return: Concat Operator object
        """
        self.model_name = model_name
        self.id = component_id
        self.validate(previous_component)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.component_output = tf.concat(values=[GraphUtils.get_tensor(tensor) for tensor in self.component_input],
                                              axis=self.dimension).name
            operator_details = OrderedDict(
                [(constants.MODEL_ARCHITECTURE.OPERATOR_INPUT, self.component_input),
                 (constants.MODEL_ARCHITECTURE.CONCAT_DIMENSION, self.dimension),
                 (constants.MODEL_ARCHITECTURE.OPERATOR_OUTPUT,
                  GraphUtils.get_tensor(self.component_output).get_shape().as_list().__str__())
                 ])
        RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                   component_name=self.component_output_name,
                                                   tensor_name=self.component_output)
        RZTDL_STORE.update_model_operator_architecture(model_name=self.model_name, operator_name=self.name,
                                                       operator_details=operator_details)
        tf.add_to_collection(self.component_output, GraphUtils.get_tensor(self.component_output))
        return self

    def validate(self, previous_component: Component):
        """
        | **@author:** Prathyush SP
        |
        | Concat Operator Validation
        :param previous_component: Previous Component
        """
        tensor_list = []
        tensor_dimension = None
        first_tensor = None
        if len(self.component_input) < 2:
            raise SizeError(component_name=self.name,
                            message='Requires minimum of 2 inputs. Given inputs: {}'.format(self.name))
        for tensor in self.component_input:
            tensor = self._map_input_operator(component_input=tensor)
            tensor_list.append(tensor)
            if not tensor_dimension:
                first_tensor = tensor
                tensor_dimension = len(GraphUtils.get_tensor(tensor).get_shape().as_list())
            if tensor_dimension:
                if len(GraphUtils.get_tensor(tensor).get_shape().as_list()) != tensor_dimension:
                    raise DimensionError(component_name=self.name,
                                         message="Tensor Dimension doesn't match {}:{}".format(
                                             GraphUtils.get_tensor(tensor).get_shape().as_list(),
                                             GraphUtils.get_tensor(first_tensor).get_shape().as_list()))
        self.component_input = tensor_list
        if self.dimension > len(GraphUtils.get_tensor(first_tensor).get_shape().as_list()):
            raise DimensionError(component_name=self.name,
                                 message="Dimension parameter takes value between 0 and {}".format(
                                     tensor_dimension))
        logger.info("Concat Operator ({}) validation success . . .".format(self.name))
