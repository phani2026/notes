# -*- coding: utf-8 -*-
"""
| **@created on:** 10/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| Divide Operator
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['DivideOperator']

from collections import OrderedDict
import typing
import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked
import rztdl.utils.string_constants as constants
from rztdl import RZTDL_STORE
from rztdl.blueprint import Blueprint
from rztdl.dl import GraphUtils
from rztdl.dl.components.dl_operator import Operator
from rztdl.utils.dl_exception import ShapeError, SizeError
import logging
from rztdl.dl.components.component import Component

logger = logging.getLogger(__name__)


class DivideOperator(Operator):
    """
    | **@author:** Prathyush SP
    |
    | Division Operator
    """

    @classmethod
    def blueprint(cls):
        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, repeatable=True, optional=False, minimum_inputs=2)
        bp.add_outputs(name="component_output", status=constants.STATUS.ACTIVE,
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING, optional=False)
        bp.add_parameter(name="name", status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING, optional=False)
        return bp

    __slots__ = []

    @typechecked
    def __init__(self, name: str, component_input: typing.List[typing.Union[str, Tensor]], component_output: str):
        """
        | **@author:** Prathyush SP
        |
        | Division Operator Constructor
        :param name: Operator Name
        :param component_input: Operator Input
        :param component_output: Operator Output
        """
        super().__init__(name=name, operator_type=constants.OperatorTypes.DIVIDE_OPERATOR,
                         component_input=component_input,
                         component_output=component_output)

    @typechecked
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Creates Division dl_operator
        :param model_name: Model Name
        :param previous_component: Previous component
        :param component_id: Operator ID
        :return: Divide Operator
        """
        self.model_name = model_name
        self.id = component_id
        self.validate(previous_component=previous_component)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.component_output = self.component_input[0]
            for tensors in self.component_input[1:]:
                self.component_output = tf.divide(GraphUtils.get_tensor(self.component_output),
                                                  GraphUtils.get_tensor(tensors)).name
            operator_details = OrderedDict([
                (constants.MODEL_ARCHITECTURE.OPERATOR_INPUT,
                 [GraphUtils.get_tensor(each_input).get_shape().as_list().__str__() for each_input in
                  self.component_input]),
                (constants.MODEL_ARCHITECTURE.OPERATOR_OUTPUT,
                 GraphUtils.get_tensor(self.component_output).get_shape().as_list().__str__())])
        RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                   component_name=self.component_output_name,
                                                   tensor_name=self.component_output)
        tf.add_to_collection(self.component_output, GraphUtils.get_tensor(self.component_output))
        RZTDL_STORE.update_model_operator_architecture(model_name=self.model_name, operator_name=self.name,
                                                       operator_details=operator_details)
        return self

    def validate(self, previous_component: Component):
        """
        | **@author:** Prathyush SP
        |
        | Division Operator validation
        :param previous_component: Previous Component
        """
        if len(self.component_input) < 2:
            raise SizeError(component_name=self.name,
                            message='Requires minimum of 2 inputs. Given inputs: {}'.format(self.name))
        tensor_list = [self._map_input_operator(component_input=tensor) for tensor in self.component_input]
        tensor_list_shape = [GraphUtils.get_tensor(tensor).get_shape().as_list() for tensor in tensor_list]
        for shape, t in zip(tensor_list_shape, tensor_list):
            if not shape == tensor_list_shape[0]:
                raise ShapeError(component_name=self.name,
                                 message='Tensor Shapes do not Match {}({}):{}({})'.format(t, shape, tensor_list[0],
                                                                                           tensor_list_shape[0]))
        self.component_input = tensor_list
        logger.info("Divide Operator ({}) validation success . . .".format(self.name))
