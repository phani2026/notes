# -*- coding: utf-8 -*-
"""
| **@created on:** 10/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| Reshape Operator Module
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['ReshapeOperator']

from collections import OrderedDict
import typing
import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked
import rztdl.utils.string_constants as constants
from rztdl import RZTDL_STORE, RZTDL_DAG
from rztdl.blueprint import Blueprint
from rztdl.dl import GraphUtils
from rztdl.dl.components.dl_operator import Operator
import logging
from rztdl.dl.components.component import Component
from functools import reduce
from rztdl.utils.dl_exception import ComponentException
import operator

logger = logging.getLogger(__name__)


class ReshapeOperator(Operator):
    """
    | **@author:** Prathyush SP
    |
    | Reshape Operator
    """

    @classmethod
    def blueprint(cls):
        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        bp.add_outputs(name="component_output", status=constants.STATUS.ACTIVE,
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING, optional=False)
        bp.add_parameter(name="name", status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING, optional=False)
        bp.add_parameter(name="shape", status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.ARRAYOFINT, optional=False)
        return bp

    __slots__ = ['shape']

    @typechecked
    def __init__(self, name: str, component_input: typing.Union[str, Tensor], component_output: str,
                 shape: list):
        """
        :param name: Operator Name
        :param component_input: Operator Input
        :param component_output: Operator Output
        :param shape: Shape
        """
        super().__init__(name=name, operator_type=constants.OperatorTypes.RESHAPE_OPERATOR,
                         component_input=component_input,
                         component_output=component_output)
        self.shape = shape

    @typechecked
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Creates Reshape dl_operator
        :param model_name: Model Name
        :param previous_component: Previous Component
        :param component_id: Operator ID
        :return: Reshape Operator
        """
        self.model_name = model_name
        self.operator_id = component_id
        self.validate(previous_component)
        RZTDL_DAG.add_node_to_dag(node=self.name, component_type=constants.LayerType)
        RZTDL_DAG.add_edge_to_node(from_node=previous_component.name, to_node=self.name)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.component_output = tf.reshape(tensor=GraphUtils.get_tensor(self.component_input),
                                               shape=self.shape).name
            operator_details = OrderedDict(
                [
                    (constants.MODEL_ARCHITECTURE.OPERATOR_INPUT,
                     GraphUtils.get_tensor(self.component_input).get_shape().as_list().__str__()),
                    (constants.MODEL_ARCHITECTURE.OPERATOR_SHAPE, self.shape),
                    (constants.MODEL_ARCHITECTURE.OPERATOR_OUTPUT,
                     GraphUtils.get_tensor(self.component_output).get_shape().as_list().__str__())])
        RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                   component_name=self.component_output_name,
                                                   tensor_name=self.component_output)
        RZTDL_STORE.update_model_operator_architecture(model_name=self.model_name, operator_name=self.name,
                                                       operator_details=operator_details)
        tf.add_to_collection(self.component_output, GraphUtils.get_tensor(self.component_output))
        return self

    def validate(self, previous_component):
        """
        | **@author:** Prathyush SP
        |
        | Reshape Operator validation
        """
        if len(self.shape) < 2:
            raise ComponentException(component_name=self.name,
                                     message="Shape parameter needs at the minimum two inputs. Ex [-1, shape...]")
        if not self.shape[0] == -1:
            raise ComponentException(component_name=self.name,
                                     message="Dim 0 of shape parameter should always be -1 to support batch size")
        self.component_input = self._map_input_operator(component_input=self.component_input)
        if not reduce(operator.mul, GraphUtils.get_tensor(self.component_input).shape.as_list()[1:]) == reduce(
                operator.mul,
                self.shape[1:]):
            raise ComponentException(component_name=self.name, message="Unable to reshape input of {} to {}".format(
                GraphUtils.get_tensor(self.component_input).shape.as_list(), self.shape))
        logger.info("Reshape Operator ({}) validation success . . .".format(self.name))
