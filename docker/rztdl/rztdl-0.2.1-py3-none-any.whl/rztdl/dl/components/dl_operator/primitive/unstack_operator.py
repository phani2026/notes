# -*- coding: utf-8 -*-
"""
| **@created on:** 10/08/17,
| **@author:** prathyushsp,Umesh Kumar
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** Complete
|
"""
from rztdl.utils.dl_exception import DimensionError, ComponentException

__all__ = ['UnstackOperator']

from collections import OrderedDict
from typing import Union
import logging

import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked

import rztdl.utils.string_constants as constants
from rztdl import RZTDL_STORE
from rztdl.blueprint import Blueprint, BluePrintProperties
from rztdl.dl import GraphUtils
from rztdl.dl.components.dl_operator import Operator

logger = logging.getLogger(__name__)


class UnstackOperator(Operator):
    """
    | **@author:** Umesh Kumar
    |
    |Unstack Operator Constructor
    """

    @classmethod
    def blueprint(cls):
        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        p1 = BluePrintProperties(name="name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                                 status=constants.STATUS.ACTIVE, link_to_attribute="component_output", optional=False)
        bp.add_outputs(name="component_output", status=constants.STATUS.ACTIVE, repeatable=True,
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX, properties=[p1],
                       optional=False)
        bp.add_parameter(name="name", status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING, optional=False)
        bp.add_parameter(name="dimension", status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER, optional=False)
        return bp

    __slots__ = ["dimension"]

    @typechecked
    def __init__(self, name: str, component_input: Union[str, Tensor], component_output: list, dimension: int):
        """
        | **@author:** Umesh Kumar
        |
        | Unstack Operator Constructor
        :param name: Operator Name
        :param component_input: Operator Input
        :param component_output: Operator Output
        """
        super().__init__(name=name, operator_type=constants.OperatorTypes.UNSTACK_OPERATOR,
                         component_input=component_input, component_output=component_output)
        self.dimension = dimension

    @typechecked
    def create_component(self, model_name, previous_component, component_id: int):
        """
        | **@author:** Umesh Kumar
        |
        | Creates Unstack dl_operator
        :param model_name: Model Name
        :param component_id: Operator ID
        :param previous_component: Previous component
        :return: Unstack Operator
        """
        self.model_name = model_name
        self.operator_id = component_id
        self.validate(previous_component)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.component_output = [output.name for output in
                                     tf.unstack(value=GraphUtils.get_tensor(self.component_input), axis=self.dimension)]
            operator_details = OrderedDict(
                [(constants.MODEL_ARCHITECTURE.OPERATOR_INPUT,
                  GraphUtils.get_tensor(self.component_input).get_shape().as_list().__str__()),
                 (constants.MODEL_ARCHITECTURE.UNSTACK_SIZE, len(self.component_output_name)),
                 (constants.MODEL_ARCHITECTURE.UNSTACK_DIMENSION, self.dimension),
                 (constants.MODEL_ARCHITECTURE.OPERATOR_OUTPUT,
                  [GraphUtils.get_tensor(each_input).get_shape().as_list().__str__() for each_input in
                   self.component_output])
                 ])
        for name, tensor in list(zip(self.component_output_name, self.component_output)):
            RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=name,
                                                       tensor_name=tensor)
            tf.add_to_collection(tensor, GraphUtils.get_tensor(tensor))
        RZTDL_STORE.update_model_operator_architecture(model_name=self.model_name, operator_name=self.name,
                                                       operator_details=operator_details)
        return self

    def validate(self, previous_component):
        """
        | **@author:** Umesh Kumar
        |
        | Unstack Operator validation
        """
        self.component_input = self._map_input_operator(component_input=self.component_input)
        if self.dimension >= len(
                GraphUtils.get_tensor(self.component_input).get_shape().as_list()) or self.dimension == 0:
            raise DimensionError(component_name=self.name,
                                 message="Dimension parameter takes value in range (0, {}). Given dimension {}".format(
                                     len(GraphUtils.get_tensor(self.component_input).get_shape().as_list()),
                                     self.dimension))
        if len(self.component_output_name) != GraphUtils.get_tensor(self.component_input).get_shape()[self.dimension]:
            raise ComponentException(component_name=self.name,
                                     message="Length of Component Output should be equal to {}. Given {}".format(
                                         GraphUtils.get_tensor(self.component_input).get_shape()[self.dimension],
                                         len(self.component_output_name)))
        logger.info("Unstack Operator ({}) validation success . . .".format(self.name))
