# -*- coding: utf-8 -*-
"""
| **@created on:** 10/08/17,
| **@author:** prathyushsp, Umesh Kumar
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
import logging
from collections import OrderedDict
from typing import Union

import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked

import rztdl.utils.string_constants as constants
from rztdl import RZTDL_STORE
from rztdl.blueprint import Blueprint
from rztdl.dl import GraphUtils
from rztdl.dl.components.dl_operator import Operator
from rztdl.utils.dl_exception import ShapeError, SizeError, DimensionError

logger = logging.getLogger(__name__)


class SliceOperator(Operator):
    """
    | **@author:** Thebzeera V
    |
    |Slice Operator
    """

    @classmethod
    def blueprint(cls):
        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        bp.add_outputs(name="component_output", status=constants.STATUS.ACTIVE,
                       data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING, optional=False)
        bp.add_parameter(name="name", status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING, optional=False)
        bp.add_parameter(name="begin", status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.ARRAYOFINT, optional=False)
        bp.add_parameter(name="slice_size", status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.ARRAYOFINT, optional=False)
        return bp

    __slots__ = ["begin", "slice_size"]

    @typechecked
    def __init__(self, name: str, component_input: Union[str, Tensor], begin: list, slice_size: list,
                 component_output: str):
        """
        | **@author:** Thebzeera V
        |
        | Slice Operator Constructor
        :param name: Operator Name
        :param component_input: Operator Input
        :param component_output: Operator Output
        :param begin: Begin
        :param size: Size
        """
        super().__init__(name=name, operator_type=constants.OperatorTypes.SLICE_OPERATOR,
                         component_input=component_input, component_output=component_output)
        self.begin = begin
        self.slice_size = slice_size

    @typechecked
    def create_component(self, model_name, previous_component, component_id: int):
        """
        | **@author:** Thebzeera V
        |
        | Creates Slice dl_operator
        :param model_name: Model Name
        :param previous_component: Previous Component
        :param component_id: Operator ID
        :return: Slice Operator
        """
        self.model_name = model_name
        self.operator_id = component_id
        self.validate(previous_component)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            self.component_output = tf.slice(input_=GraphUtils.get_tensor(self.component_input), begin=self.begin,
                                             size=self.slice_size).name
        tf.add_to_collection(self.component_output, GraphUtils.get_tensor(self.component_output))
        operator_details = OrderedDict(
            [(constants.MODEL_ARCHITECTURE.OPERATOR_INPUT,
              GraphUtils.get_tensor(self.component_input).get_shape().as_list().__str__()),
             (constants.MODEL_ARCHITECTURE.SLICE_BEGIN, self.begin),
             (constants.MODEL_ARCHITECTURE.SLICE_SIZE, self.slice_size),
             (constants.MODEL_ARCHITECTURE.OPERATOR_OUTPUT,
              GraphUtils.get_tensor(self.component_output).get_shape().as_list().__str__())])
        RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name,
                                                   component_name=self.component_output_name,
                                                   tensor_name=self.component_output)
        RZTDL_STORE.update_model_operator_architecture(model_name=self.model_name, operator_name=self.name,
                                                       operator_details=operator_details)

        return self

    def validate(self, previous_component):
        """
        | **@author:** Thebzeera V
        |
        | Slice Operator validation
        """
        self.component_input = self._map_input_operator(component_input=self.component_input)
        if len(self.begin) != len(GraphUtils.get_tensor(self.component_input).get_shape()):
            raise ShapeError(component_name=self.name, message="Length of begin should be equal to "
                                                               "length of the shape of input")
        if len(self.slice_size) != len(GraphUtils.get_tensor(self.component_input).get_shape()):
            raise ShapeError(component_name=self.name, message="Length of slice size parameter should be equal to "
                                                               "length of the shape of input")
        if self.begin[0] != 0:
            raise DimensionError(component_name=self.name,
                                 message="Begin Oth dimension should be always 0, since we can't change batch size")
        if self.slice_size[0] != -1:
            raise DimensionError(component_name=self.name,
                                 message="Slice Oth dimension should be always -1, since we can't change batch size")
        for each_dimension in range(1, len(self.begin), 1):
            if self.begin[each_dimension] + self.slice_size[each_dimension] > \
                    GraphUtils.get_tensor(self.component_input).get_shape()[each_dimension]:
                raise DimensionError(component_name=self.name,
                                     message="Begin[i] + Size[i] can't be greater than component_input[i] "
                                             "for i in [0, Dn]. "
                                             "It is not proper along dimension {}".format(each_dimension))
        logger.info("Slice Operator ({}) validation success . . .".format(self.name))
