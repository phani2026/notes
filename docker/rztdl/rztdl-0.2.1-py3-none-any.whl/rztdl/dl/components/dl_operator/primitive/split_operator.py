# -*- coding: utf-8 -*-
"""
| **@created on:** 10/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| Split Operator Module
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['SplitOperator']

from rztdl.blueprint import Blueprint, BluePrintProperties
from rztdl.dl.components.dl_operator import Operator
import typing
from tensorflow import Tensor
from typeguard import typechecked
from rztdl import RZTDL_STORE
import tensorflow as tf
from rztdl.dl import GraphUtils
import rztdl.utils.string_constants as constants
from collections import OrderedDict
from rztdl.utils.dl_exception import ComponentException
from rztdl.dl.components.component import Component
import logging

logger = logging.getLogger(__name__)


class SplitOperator(Operator):
    """
    | **@author:** Prathyush SP
    |
    | Split Operator
    """

    @classmethod
    def blueprint(cls):
        bp = Blueprint(cls, version="0.0.1", status=constants.STATUS.ACTIVE)
        bp.add_inputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        p1 = BluePrintProperties(name="name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING,
                                 status=constants.STATUS.ACTIVE, link_to_attribute="component_output", optional=False)
        p2 = BluePrintProperties(name="split_size", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                 status=constants.STATUS.ACTIVE, link_to_attribute="size_splits", optional=False)
        bp.add_outputs(name="component_output", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                       properties=[p1, p2], status=constants.STATUS.ACTIVE, repeatable=True, optional=False,
                       minimum_outputs=2)
        bp.add_parameter(name="name", status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING, optional=False)
        bp.add_parameter(name="dimension", status=constants.STATUS.ACTIVE,
                         data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER, optional=False)
        return bp

    __slots__ = ["num_or_size_splits", "dimension"]

    @typechecked
    def __init__(self, name: str, component_input: typing.Union[str, Tensor], component_output: typing.List[str],
                 dimension: int,
                 size_splits: typing.List[int] = None):
        """
        :param size_splits: Size of splits
        :param name: Operator Name
        :param component_input: Operator Input
        :param component_output: Operator Output
        :param dimension: Dimension
        """
        super().__init__(name=name, operator_type=constants.OperatorTypes.SPLIT_OPERATOR,
                         component_input=component_input, component_output=component_output)
        self.num_or_size_splits = size_splits
        self.dimension = dimension

    @typechecked
    def create_component(self, model_name: str, previous_component: Component, component_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Create Split Operator
        :param model_name: Model Name
        :param previous_component: Previous component
        :param component_id: Operator Id
        :return: Split Operator
        """
        self.model_name = model_name
        self.id = component_id
        self.validate(previous_component)
        with tf.name_scope(self.model_name + '/' + self.name + '/'):
            split_tensors = [output.name for output in tf.split(value=GraphUtils.get_tensor(self.component_input),
                                                                num_or_size_splits=self.num_or_size_splits,
                                                                axis=self.dimension)]
            operator_details = OrderedDict(
                [
                    (constants.MODEL_ARCHITECTURE.OPERATOR_INPUT,
                     GraphUtils.get_tensor(self.component_input).get_shape().as_list().__str__()),
                    (constants.MODEL_ARCHITECTURE.SPLIT_SIZE, len(self.component_output_name)),
                    (constants.MODEL_ARCHITECTURE.SPLIT_DIMENSION, self.dimension),
                    (constants.MODEL_ARCHITECTURE.OPERATOR_OUTPUT,
                     [GraphUtils.get_tensor(each_input).get_shape().as_list().__str__() for each_input in
                      split_tensors])
                ])
        for name, tensor in list(zip(self.component_output_name, split_tensors)):
            RZTDL_STORE.add_component_output_as_tensor(model_name=self.model_name, component_name=name,
                                                       tensor_name=tensor)
            tf.add_to_collection(tensor, GraphUtils.get_tensor(tensor))
        RZTDL_STORE.update_model_operator_architecture(model_name=self.model_name, operator_name=self.name,
                                                       operator_details=operator_details)
        self.component_output = split_tensors
        return self

    def validate(self, previous_component):
        """
        | **@author:** Prathyush SP
        |
        | Split Operator Validation
        """

        self.component_input = self._map_input_operator(component_input=self.component_input)
        if not len(self.component_output) >= 2:
            raise ComponentException(component_name=self.name,
                                     message="Length of splits should be atleast 2. Given: {}".format(
                                         len(self.component_output)))
        if isinstance(self.num_or_size_splits, list):
            if len(self.num_or_size_splits) != len(self.component_output_name):
                raise ComponentException(component_name=self.name, message=
                "Length of Size split and Length of Operator Output should be equal. Given elements in size split:{} Output:{}".format(
                    len(self.num_or_size_splits), len(self.component_output_name)))
            if sum(self.num_or_size_splits) != GraphUtils.get_tensor(self.component_input).get_shape()[self.dimension]:
                raise ComponentException(component_name=self.name,
                                         message="Sum of size splits should be equal to input layer shape. Given sum: {}, required sum: {}".format(
                                             sum(self.num_or_size_splits),
                                             GraphUtils.get_tensor(self.component_input).get_shape()[self.dimension]))
        else:
            self.num_or_size_splits = len(self.component_output_name)
        logger.info("Split Operator ({}) validation success . . .".format(self.name))
