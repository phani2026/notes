# -*- coding: utf-8 -*-
"""
| **@created on:** 17/05/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Component Module
|
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

from typeguard import typechecked
import logging
import rztdl.utils.string_constants as constants
from rztdl.dl.metric_store import MetricStore
import typing
from rztdl.dl.flows.flow import Flow
from rztdl.dl.model import Model
from rztdl import RZTDL_CONFIG, RZTDL_STORE, RZTDL_DAG
from rztdl.utils.pyutils import Directories, generate_timestamp, DLTimer
from collections import OrderedDict
from rztdl.utils.dl_exception import SizeError, DataFeedException

logger = logging.getLogger(__name__)


class SimpleTrainFlow(Flow):
    """
    | **@author:** Prathyush SP
    |
    | Train Flow Class
    """

    @typechecked
    def __init__(self, name: str,
                 epoch: int, learning_rate: typing.Union[float, typing.List[float]],
                 optimizers: typing.Union[str, typing.List[str]], metrics_for_train: typing.Union[list, str],
                 metrics_for_valid: typing.Union[list, str], metrics_for_test: typing.Union[list, str],
                 train_data: dict, valid_data: dict = None, test_data: dict = None,
                 train_batch_size: int = 0, valid_batch_size: int = 0, test_batch_size: int = 0,
                 init=False, session=None):
        """

        :param name:
        :param epoch:
        :param learning_rate:
        :param optimizers:
        :param metrics_for_train:
        :param metrics_for_valid:
        :param metrics_for_test:
        :param train_data:
        :param valid_data:
        :param test_data:
        :param train_batch_size:
        :param valid_batch_size:
        :param test_batch_size:
        :param init:
        :param session:
        """
        super().__init__(name=name, flow_type=constants.FlowType.TRAIN, init=init, dataset_handler=None,
                         session=session)
        self.epoch = epoch
        self.learning_rate = learning_rate
        self.optimizers = optimizers
        self.train_data = train_data
        self.valid_data = valid_data
        self.test_data = test_data
        self.metrics_for_train = metrics_for_train
        self.metrics_for_test = metrics_for_test
        self.metrics_for_valid = metrics_for_valid
        # todo: Prathyush SP - Modify this attribute with train and persist train
        self.init = init
        self.session = session
        self.train_batch_size = train_batch_size
        self.test_batch_size = test_batch_size
        self.valid_batch_size = valid_batch_size
        self.model = None
        self.save_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL
        self.timestamp = generate_timestamp()
        self.network_params = OrderedDict()

    def close(self):
        self.train_data = None
        self.valid_data = None
        self.test_data = None
        self.session = None
        self.model = None
        del self.train_data
        del self.valid_data
        del self.test_data
        del self.session
        del self.model

    # def get_or_create_session(self, init, shared_session):
    #     if isinstance(self.session, tf.Session):
    #         self.using_global_session = False
    #         self.using_external_session = True
    #         logger.debug('Using external session . . .')
    #         if init:
    #             logger.debug('Initializing external session . . .')
    #             self.session.run(GraphUtils.get_operation(name=self.init_op))
    #     elif init:
    #         logger.debug('Creating a new Session and Initializing session . . .')
    #         self.session = tf.Session()
    #         self.session.run(GraphUtils.get_operation(name=self.init_op))
    #         self.using_global_session = False
    #     else:
    #         logger.debug('Using global shared session . . .')
    #         self.session = shared_session

    def close_session(self):
        if not self.using_global_session and not self.using_external_session:
            logger.debug('Closing session . . .')
            self.session.close()

    def run_flow(self, model: Model, previous_flow: 'Flow', flow_id: int, metric_store, model_runner):
        """
        | **@author:** Prathyush SP
        |
        | Used to create a dl flow
        :param model_graph:
        :param model_runner:
        :param metric_store:
        :param shared_session: Shared session
        :param model: Model Object
        :param previous_flow: Previous flow
        :param flow_id: Flow Id
        """
        self.get_or_create_session(init=self.init, shared_session=shared_session)
        self.model = model
        self.validate(previous_flow=previous_flow)
        train_dict, valid_dict, test_dict = self._train_validation(train_data=self.train_data,
                                                                   valid_data=self.valid_data,
                                                                   test_data=self.test_data,
                                                                   train_batch_size=self.train_batch_size,
                                                                   valid_batch_size=self.valid_batch_size,
                                                                   test_batch_size=self.test_batch_size,
                                                                   )
        metric_store = MetricStore(total_epochs=self.epoch)

        self.save_path += '/' + self.name + '/' + self.timestamp + '/'

        self._create_directories(save_path=self.save_path)
        logger.info('Initializing Tensors . . .')
        train_time = DLTimer().set_time()
        optimizers_components = [model.get_component(ops).component_output for ops in self.optimizers]
        for epoch in range(self.epoch):
            for batch_id, batch_data in enumerate(train_dict):
                _, tensors_to_log = self.session.run(
                    [optimizers_components, RZTDL_STORE.get_components_to_log(model.name)],
                    feed_dict={**batch_data, **self.network_params,
                               **RZTDL_STORE.get_all_dropout_placeholders(model_name=self.model.name,
                                                                          mode=constants.NETWORK_MODE.TRAIN)})
                # metric_store.batch_result(current_batch=batch_id, train_time=train_time, batches=self.train_batches,
                #                           template="", metrics=tensors_to_log)
            # metric_store.epoch_result(current_epoch=epoch, train_time=train_time, template="", metrics=tensors_to_log)
            #
            print(' '.join([k + ": " + str(v) for k, v in tensors_to_log.items()]))
        self.close_session()
        return self

    @typechecked
    def _create_directories(self, save_path: str = RZTDL_CONFIG.CommonConfig.PATH_RZTDL):
        """
        | **@author:** Prathyush SP
        |
        | Create required directories for the Network
        :param save_path: Save Path [Default: '/tmp/rztdl_logs/' ]
        .. todo::
            Prathyush SP:
                1. Complete Model Meta
                2. Move Model Metadata to RZTDL_DAG Metadata
        """
        # todo:: Prathyush SP: Move Model Metadata to RZTDL_DAG Metadata
        RZTDL_STORE.add_meta_data(self.model.name, 'timestamp', self.timestamp)
        init_path = save_path + '/' + self.name + '/' + RZTDL_STORE.get_meta_data_by_key(self.model.name,
                                                                                         'timestamp') + '/'
        if not RZTDL_CONFIG.CommonConfig.DRY_RUN:
            [Directories.mkdir(init_path + path, force=False) for path in
             [RZTDL_CONFIG.CommonConfig.PATH_LOG, RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_DL,
              RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_ML, RZTDL_CONFIG.CommonConfig.PATH_GRAPH,
              RZTDL_CONFIG.CommonConfig.PATH_DATA, RZTDL_CONFIG.CommonConfig.PATH_BENCHMARK]]
            RZTDL_STORE.add_logs_to_tmp(path=init_path + RZTDL_CONFIG.CommonConfig.PATH_LOG)

    def _generate_batches(self, buffer_placeholders, data, batch_size, mode):
        """
        | **@author:** Prathyush SP
        |
        | Generate Batches based on placeholders , data and batch parameters
        :param buffer_placeholders: Placeholders
        :param data: Data
        :param batch_size: Batch Size
        :return: Feed Dictionary for Session
        """
        if not len(buffer_placeholders) == len(data):
            if len(buffer_placeholders) < len(data):
                for placeholder in data.keys():
                    if placeholder not in buffer_placeholders:
                        raise SizeError(component_name=self.name,
                                        message="Placeholder {} is not connected to selected optimizers. "
                                                "Given for {} data".format(placeholder, mode))
            else:
                for placeholder in buffer_placeholders:
                    if placeholder not in data.keys():
                        raise DataFeedException('Feed {} data for "{}" Layer'.format(mode, placeholder))
        if len(set([len(val) for val in data.values()])) > 1:
            initial_placeholder = next(iter(data))
            initial_length = len(data[initial_placeholder])
            for placeholder_name, values in data.items():
                if not initial_length == len(values):
                    raise SizeError(component_name=self.name,
                                    message="Size of {} {} doesn't match with Size of {} {} for {} data".format(
                                        initial_placeholder,
                                        data[
                                            initial_placeholder].shape,
                                        placeholder_name,
                                        values.shape, mode))
        feed_dict = OrderedDict()
        samples = len(data[list(data.keys())[0]])
        if batch_size:
            if batch_size > samples:
                raise SizeError(component_name=self.name,
                                message="Batch_size can't be greater than total samples for {} data".format(mode))
        else:
            batch_size = samples
        if mode == 'train':
            self.train_batch_size = batch_size
        RZTDL_STORE.update_value_of_result_key(self.model.name, mode + "_batch_size", batch_size)
        for placeholder in buffer_placeholders:
            feed_dict[RZTDL_STORE.get_placeholder(model_name=self.model.name, layer_name=placeholder)] = data[
                placeholder]
        feed_dict = [feed_dict] if feed_dict == 0 else [
            {key: v[k:k + batch_size] for key, v in feed_dict.items()} for k in range(0, samples, batch_size)]
        return feed_dict

    def _train_validation(self, train_data, valid_data, test_data, train_batch_size, valid_batch_size, test_batch_size):
        """
        | **@author:** Prathyush SP
        |
        | Network Train Validation
        :param train_data: Train Data
        :param valid_data: Valid Data
        :param test_data: Test Data
        :param train_batch_size: Train Batch Size
        :param valid_batch_size: Valid Batch Size
        :param test_batch_size: Test Batch Size
        :return: Feed Dictionaries - [Train, Valid and Test (Batched Data) ]
        """
        self.optimizers = self.optimizers if isinstance(self.optimizers, list) else [self.optimizers]
        self.learning_rate = self.learning_rate if isinstance(self.learning_rate, list) else [self.learning_rate]
        if len(self.optimizers) != len(self.learning_rate):
            raise SizeError(component_name=self.name,
                            message="No of Optimizers selected :{} is not equal to "
                                    "length of learning rates given :{}".format(len(self.optimizers),
                                                                                len(self.learning_rate)))
        for optimizer, learning_rate in zip(self.optimizers, self.learning_rate):
            self.network_params[
                RZTDL_STORE.get_all_lr_placeholders(model_name=self.model.name)[optimizer]] = learning_rate
        # RZTDL_STORE.add_meta_data(model_name=self.model_name, key=ModelMetaConstant.TRAIN_OP,
        #                           value=OrderedDict([('lr_placeholder', lr_placeholder.name)]))

        logger.info("Fetching all buffers of selected Optimizers")
        buffer_placeholders = self.get_all_buffers()

        # Train Placeholder - Feed Data Validation
        logger.info('Creating Train Batches . . .')
        return_feeds = [self._generate_batches(data=train_data, buffer_placeholders=buffer_placeholders,
                                               batch_size=train_batch_size, mode="train")]

        # Valid Placeholder - Feed Data Validation
        if valid_data:
            logger.info('Creating Valid Batches . . .')
            return_feeds.append(self._generate_batches(data=valid_data, buffer_placeholders=buffer_placeholders,
                                                       batch_size=valid_batch_size, mode="valid"))
        else:
            return_feeds.append([])

        # Test Placeholder - Feed Data Validation
        if test_data:
            logger.info('Creating Test Batches . . .')
            return_feeds.append(self._generate_batches(data=test_data, buffer_placeholders=buffer_placeholders,
                                                       batch_size=test_batch_size, mode="test"))
        else:
            return_feeds.append([])
        return return_feeds

    def get_all_buffers(self):
        """
        | **@author:** Umesh Kumar
        |
        | Get all buffers of selected Optimisers
        """
        buffer_placeholders = []
        for optimizer in self.optimizers:
            buffer_placeholders += RZTDL_DAG.get_ancestors_by_type(node=optimizer,
                                                                   component_type=constants.BufferType)
        return list(set(buffer_placeholders))

    def validate(self, previous_flow: Flow):
        """
        | **@author:** Prathyush SP
        |
        | Validation Method
        """
        # self.init = tf.group(tf.global_variables_initializer(),
        #                      tf.local_variables_initializer()) if self.init else self.init
        pass
