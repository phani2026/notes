# -*- coding: utf-8 -*-
"""
| **@created on:** 17/05/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Flow Module
|
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['Flow']

from abc import ABCMeta, abstractmethod
from typeguard import typechecked
from rztdl.utils.validations import validate_name
import logging
import rztdl.utils.string_constants as constants
from rztdl.dl.model import Model
import tensorflow as tf
from rztdl.dl.dataset import DatasetHandler
from rztdl.utils.dl_exception import FlowException
from rztdl import RZTDL_STORE
import typing
from rztdl.dl.stores import METRIC_STORE
from rztdl.dl.handlers.display_handler import global_display_handler
from weakref import ref

logger = logging.getLogger(__name__)


class Flow(metaclass=ABCMeta):
    """
    | **@author:** Prathyush SP
    |
    | Base class, which defines abstract methods for flows
    """

    __slots__ = ['name', 'id', 'flow_type', 'using_global_session', 'using_external_session', 'session', 'init',
                 'dataset_handler', 'dataset_split', 'saver', 'input_mapping', 'model', 'dataset_mapping',
                 'metrics_mapping', 'model_graph', 'model_runner_name']

    @typechecked
    def __init__(self, name: str, flow_type: constants.FlowType, dataset_handler: DatasetHandler,
                 dataset_mapping: typing.Union[None, typing.Dict[str, str]]):
        """

        :param name: Name of the flow
        :param flow_type: Type of the flow
        :param init: Initialize Tensorflow DAG
        :param dataset_handler: Datasets
        :param session: Tensorflow Session
        """
        # todo: Prathyush SP - Expose init=True, session=None parameters when iterator replacement using input_map issue is resolved
        self.name = validate_name(name)
        self.dataset_handler = dataset_handler
        self.flow_type = flow_type
        self.dataset_mapping = dataset_mapping
        self.saver = None
        self.id = None
        self.using_global_session = True
        self.using_external_session = False
        self.session = None
        self.input_mapping = {}
        self.model = None
        self.model_runner_name = None

    @abstractmethod
    def run_flow(self, model: Model, previous_flow: 'Flow', flow_id: int, metric_store: ref,
                 model_runner: ref) -> 'Flow':
        """
        | **@author:** Prathyush SP
        |
        | Used to create a dl flow
        :param model_graph:
        :param model_runner:
        :param metric_store:
        :param model: Model Object
        :param shared_session: Shared Global Session
        :param previous_flow: Previous flow
        :param flow_id: Flow Id
        """

        # todo: Prathyush SP - Expose shared_session: typing.Union[tf.Session, tf.InteractiveSession, tf.train.MonitoredSession] parameters once tf.dataset API issues are resolved
        pass  # pragma: no cover

    def configure_metric_store(self, metric_store, model_runner_name: str, run_parameters: dict):
        METRIC_STORE.add_flow(model_name=self.model.name, model_runner_name=model_runner_name, flow_name=self.name,
                              run_parameters=run_parameters,
                              splits=self.dataset_split.split_list)

    def configure_display_handler(self, display_handler: typing.List[constants.DisplayHandler]):
        for config in display_handler:
            global_display_handler.add_display_configuration(model_name=self.model.name, flow_name=self.name,
                                                             flow_meta=ref(self),
                                                             interval_type=config[
                                                                 constants.DisplayHandler._Parameters.INTERVAL_TYPE.name],
                                                             interval=config[
                                                                 constants.DisplayHandler._Parameters.INTERVAL.name])

    def prepare_inference_graph(self):
        self.dataset_handler.initialize_dataset(split_template=self.dataset_split)
        self.dataset_handler.initialize_iterators()

        next_elem = self.dataset_handler.feedable_iterator.get_next()

        # Verify DatasetHandler Reuse
        if self.dataset_handler.reuse:
            if self.dataset_mapping is None:
                raise FlowException(component_name=self.name,
                                    message="Dataset Handler {} is set to reuse. Provide dataset mapping".format(
                                        self.dataset_handler.name))
            self.input_mapping = {
                RZTDL_STORE.get_component_output_as_tensor(model_name=self.model.name,
                                                           component_name=buffer_name).name:
                    next_elem[dataset_map] for buffer_name, dataset_map in
                self.dataset_mapping.items()}

        else:
            if self.dataset_mapping is not None:
                logger.warning(
                    "Dataset Handler {} has reuse=False. Overriding default dataset mapping with given dataset mapping. Use reuse=True to discard the warning".format(
                        self.dataset_handler.name))
                self.input_mapping = {
                    RZTDL_STORE.get_component_output_as_tensor(model_name=self.model.name,
                                                               component_name=buffer_name).name:
                        next_elem[dataset_map] for buffer_name, dataset_map in
                    self.dataset_mapping.items()}
            else:
                self.input_mapping = {
                    RZTDL_STORE.get_component_output_as_tensor(model_name=self.model.name,
                                                               component_name=buffer_name).name:
                        next_elem[buffer_name] for buffer_name in self.dataset_handler.dataset_elements}
        # noinspection PyUnresolvedReferences

        tf.train.import_meta_graph(meta_graph_or_file=self.model.model_meta_graph, input_map=self.input_mapping)

    def prepare_graph(self):
        """
        | **@author:** Prathyush SP
        |
        | Prepare graph for current flow configuration
        | Steps:
        | 1. Export model meta graph as meta_graph
        | 2. Reset Default Graoh
        | 3. Initialize Dataset Handler
        | 4. Initialze Corresponding Iterators
        | 5. Validate Dataset Mapping
        | 6. Create Input Mapping based on previous validations
        | 7. Import Model graph with corresponding input replacements
        """
        self.dataset_handler.initialize_dataset(split_template=self.dataset_split)
        self.dataset_handler.initialize_iterators()

        next_elem = self.dataset_handler.feedable_iterator.get_next()

        # Verify DatasetHandler Reuse
        if self.dataset_handler.reuse:
            if self.dataset_mapping is None:
                raise FlowException(component_name=self.name,
                                    message="Dataset Handler {} is set to reuse. Provide dataset mapping".format(
                                        self.dataset_handler.name))
            self.input_mapping = {
                RZTDL_STORE.get_component_output_as_tensor(model_name=self.model.name,
                                                           component_name=buffer_name).name:
                    next_elem[dataset_map] for buffer_name, dataset_map in
                self.dataset_mapping.items()}

        else:
            if self.dataset_mapping is not None:
                logger.warning(
                    "Dataset Handler {} has reuse=False. Overriding default dataset mapping with given dataset mapping. Use reuse=True to discard the warning".format(
                        self.dataset_handler.name))
                self.input_mapping = {
                    RZTDL_STORE.get_component_output_as_tensor(model_name=self.model.name,
                                                               component_name=buffer_name).name:
                        next_elem[dataset_map] for buffer_name, dataset_map in
                    self.dataset_mapping.items()}
            else:
                self.input_mapping = {
                    RZTDL_STORE.get_component_output_as_tensor(model_name=self.model.name,
                                                               component_name=buffer_name).name:
                        next_elem[buffer_name] for buffer_name in self.dataset_handler.dataset_elements}
        # noinspection PyUnresolvedReferences

        tf.train.import_meta_graph(meta_graph_or_file=self.model.model_meta_graph, input_map=self.input_mapping)

    @abstractmethod
    def close(self):
        """
        | **@author:** Prathyush SP
        |
        | Used for flow cleanup
        """
        pass  # pragma: no cover

    # todo: Prathyush SP - Model Runner global session deprecated unless tf.dataset API issues are resolved.
    # def get_or_create_session(self, init: bool, shared_session: tf.Session) -> tf.Session:
    #     """
    #     | **@author:** Prathyush SP
    #     |
    #     | Session Management
    #     :param init: Initialize tensorflow DAG
    #     :param shared_session: Global shared tensorflow session
    #     :return: Tensorflow Session
    #     """
    #     # todo: Prathyush SP -  Optimizer self.session variable
    #     if isinstance(self.session, tf.Session):
    #         self.using_global_session = False
    #         self.using_external_session = True
    #         logger.debug('Using external session . . .')
    #         if init:
    #             logger.debug('Initializing external session . . .')
    #             self.session.run(tf.group(tf.global_variables_initializer(), tf.local_variables_initializer()))
    #     elif init:
    #         logger.debug('Creating a new Session and Initializing session . . .')
    #         self.session = tf.Session()
    #         self.session.run(tf.group(tf.global_variables_initializer(), tf.local_variables_initializer()))
    #         self.using_global_session = False
    #     else:
    #         logger.debug('Using global shared session . . .')
    #         self.session = shared_session
    #     return self.session

    def close_session(self):
        """
        | **@author:** Prathyush SP
        |
        | Close Tensorflow session if session is created only for the current flow.
        """
        if not self.using_global_session and not self.using_external_session:
            logger.debug('Closing session . . .')
            self.session.close()

    @abstractmethod
    def __dict__(self):
        pass

    @abstractmethod
    def __repr__(self):
        pass

    @abstractmethod
    def validate(self, previous_flow: 'Flow'):
        """
        | **@author:** Prathyush SP
        |
        | Validation Method
        """
        pass  # pragma: no cover
