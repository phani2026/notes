# -*- coding: utf-8 -*-
"""
| **@created on:** 07/06/18,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Train Flow Module
|
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

__all__ = ['TrainFlow']

from typeguard import typechecked
import logging
import rztdl.utils.string_constants as constants
import typing
from rztdl.dl.flows.flow import Flow
from rztdl.dl.model import Model
from rztdl import RZTDL_STORE
from collections import OrderedDict
import tensorflow as tf
from rztdl.dl.dataset.dataset_split import DatasetSplit
from rztdl.dl.dataset.dataset_handler import DatasetHandler
from rztdl.utils.dl_exception import FlowException
from rztdl.dl.helpers.tfhelpers import GraphUtils
from rztdl.dl.dl_hooks.dl_hook_runners.flow_hooks_runner import flow_hooks_runner
import traceback
from rztdl.hooks.hooks_manager import hooks_manager
from rztdl import RZTDL_CONFIG
from threading import Thread
from rztdl.dl.stores import METRIC_STORE
from weakref import ref

from rztdl.dl.handlers.directory_handler import DIRECTORY_HANDLER

logger = logging.getLogger(__name__)


class TrainFlow(Flow):
    """
    | **@author:** Prathyush SP
    |
    | Train Flow Class
    """

    # __slots__ = ['epoch', 'learning_rate', 'optimizers', 'network_params', 'total_batches', 'display_step']

    @typechecked
    def __init__(self, name: str, epoch: int, batch_size: int, learning_rate: typing.List[float],
                 optimizers: typing.List[str],
                 dataset_handler: DatasetHandler, dataset_split: DatasetSplit,
                 dataset_mapping: typing.Dict[str, str] = None, metrics_mapping: typing.Dict[str, str] = None,
                 display_handler: typing.List[constants.DisplayHandler] = tuple(
                     [constants.DisplayHandler.display_config()]),
                 save_handler: constants.ModelHandler = constants.ModelHandler.save_model()):
        """

        :param name: Name of the flow
        :param epoch: Type of the flow
        :param learning_rate: Learning rate for optimizers
        :param optimizers: Optimizers
        :param dataset_handler: Dataset Handle
        :param dataset_mapping: Dataset Mapping in the format {Input Buffer Name in Model: Dataset Element Name}
        :param metrics_mapping: Metrics Mapping in the format {Metric given in splits: Mertic Name in Model}
        """
        # todo: Prathyush SP - Expose init=True, session=None parameters when iterator replacement using input_map issue is resolved
        super().__init__(name=name, flow_type=constants.FlowType.TRAIN, dataset_handler=dataset_handler,
                         dataset_mapping=dataset_mapping)
        self.learning_rate = learning_rate
        self.optimizers = optimizers
        self.metrics_mapping = metrics_mapping
        self.dataset_split = dataset_split
        # todo: Prathyush SP - Modify this attribute with train and persist train
        self.network_params = OrderedDict()
        self.display_handler = display_handler
        self.epoch = epoch
        self.batch_size = batch_size
        self.save_handler = save_handler
        self.threads = []
        self.train_split = None
        self.step_counter = 1
        self.saver = None
        self.directory_structure = None
        tf.reset_default_graph()

    # noinspection PyProtectedMember
    def run_flow(self, model: Model, previous_flow: 'Flow', flow_id: int, metric_store,
                 model_runner: ref):
        """
        | **@author:** Prathyush SP
        |
        | Used to create a dl flow
        :param model_runner:
        :param metric_store:
        :param model: Model Object
        :param previous_flow: Previous flow
        :param flow_id: Flow Id
        """
        self.model_runner_name = model_runner().name
        current_graph = tf.Graph()
        with current_graph.as_default():

            logger.info('Initializing Flow with parameters: {}'.format(self.__dict__()))
            self.model = model

            self.validate(previous_flow=previous_flow)

            # Setup Metric store for the flow
            logger.debug("Configuring Metric store for the flow . . .")
            self.configure_metric_store(metric_store=metric_store, model_runner_name=self.model_runner_name,
                                        run_parameters=self.__dict__())

            # Setup display handlers for the flow
            logger.debug("Configuring Display Handler for the flow . . .")
            self.configure_display_handler(display_handler=self.display_handler)

            self.session = tf.Session(graph=current_graph)
            # Setup Save Handler
            logger.info("Configuring Save Handler for the flow . . .")
            self.create_hooks_for_save()

            # Setup Directory Handler
            self.directory_structure = DIRECTORY_HANDLER.initialize_directory_structure_for_train_flow(
                model_name=model.name,
                model_runner_name=self.model_runner_name,
                flow_name=self.name,
                save_path=self.save_handler[
                    constants.ModelHandler._Parameters.SavePath])

            # Save Graph
            logger.debug("Saving Graph . . .")
            GraphUtils(graph=RZTDL_STORE.get_graph(model_name=model.name)).save_graph(
                save_path=self.directory_structure.graph_path)

            # Save Logs
            logger.debug("Saving Logs . . .")
            RZTDL_STORE.add_logs_to_tmp(path=self.directory_structure.logs_path)

            # Initialize Tensorflow Graph
            logger.debug("Initializing Graph . . .")

            initialize = tf.global_variables_initializer()

            self.session.run(initialize)

            # Create Hooks
            logger.debug("Initializing hooks . . .")
            self.train_split, tr_iterator = self.create_hooks_for_split(metric_store=metric_store)

            try:
                optimizer_components = [RZTDL_STORE.get_component(model_name=model.name, component_name=opt) for opt in
                                        self.optimizers]
            except Exception:
                raise FlowException(component_name=self.name,
                                    message='Unable to fetch optimizer components. {}'.format(traceback.format_exc()))

            optimizer_ops = {comp.name: comp.component_output for comp in optimizer_components}
            feed_dict_ops = {opt.learning_rate_placeholder: lr for opt, lr in
                             zip(optimizer_components, self.learning_rate)}

            tensors_to_log = {}

            # Epoch For Loop
            for epoch in range(1, self.epoch + 1):
                # batch_algo = (self.batch_size)

                # Initialize Training Iterator
                self.session.run(tr_iterator.initializer,
                                 feed_dict={self.dataset_handler.batch_placeholder: self.batch_size})

                try:
                    # Batch For Loop
                    while True:
                        tensors_to_log = self.session.run(
                            {**optimizer_ops, **RZTDL_STORE.get_components_to_log(model.name)},
                            feed_dict={
                                **{self.dataset_handler.dataset_handle: self.session.run(tr_iterator.string_handle())},
                                **feed_dict_ops})

                        # Remove optimizer keys from tensors_to_log
                        tensors_to_log = {k: v for k, v in tensors_to_log.items() if k not in optimizer_ops.keys()}

                        # Update Metric Store after each batch, also calls display internally
                        METRIC_STORE.update_store(model_name=self.model.name, model_runner_name=self.model_runner_name,
                                                  flow_name=self.name,
                                                  split_name=self.train_split.name,
                                                  metrics=tensors_to_log,
                                                  interval_type=constants.DatasetIntervalType.BATCH.name,
                                                  interval=self.step_counter)

                        # Run Flow hook (for Batch) for TrainUpdateHook Position
                        flow_hooks_runner.run(
                            hook_with_conditions=hooks_manager.fetch_hook(hook_type=constants.Hook.HookType.FlowHook,
                                                                          hook_pos=constants.Hook.HookPosition.TrainUpdateHook),
                            hook_argument={'flow': self, 'interval': self.step_counter,
                                           'interval_type': constants.DatasetIntervalType.BATCH})
                        self.step_counter += 1
                except tf.errors.OutOfRangeError:
                    if epoch % 1 == 0:
                        # Update Metric Store after each epoch, also calls display internally
                        METRIC_STORE.update_store(model_name=self.model.name,
                                                  model_runner_name=self.model_runner_name,
                                                  flow_name=self.name,
                                                  split_name=self.train_split.name,
                                                  metrics=tensors_to_log,
                                                  interval_type=constants.DatasetIntervalType.EPOCH.name,
                                                  interval=epoch)

                        # Run Flow hook (for Epoch) for TrainUpdateHook Position
                        flow_hooks_runner.run(
                            hook_with_conditions=hooks_manager.fetch_hook(hook_type=constants.Hook.HookType.FlowHook,
                                                                          hook_pos=constants.Hook.HookPosition.TrainUpdateHook),
                            hook_argument={'flow': self, 'interval': epoch,
                                           'interval_type': constants.DatasetIntervalType.EPOCH})

            # Run Flow hook for TrainEndHook Position
            flow_hooks_runner.run(
                hook_with_conditions=hooks_manager.fetch_hook(hook_type=constants.Hook.HookType.FlowHook,
                                                              hook_pos=constants.Hook.HookPosition.TrainEndHook),
                hook_argument={'flow': self})

            # Wait for splits run, if threads enabled
            if len(self.threads) > 0:
                [t.join() for t in self.threads]

            # Close Session

            self.close_session()
        return self

    # noinspection PyProtectedMember
    def create_hooks_for_split(self, metric_store):
        """
        | **@author:** Prathyush SP
        |
        | Create hooks for splits
        :return: Train Iterator
        """
        train_split, tr_iterator = None, None
        for split, itr in zip(self.dataset_split, self.dataset_handler.iterators.items()):
            if split.template[
                constants.DatasetTemplate._Parameters.DATASET_TEMPLATE] == constants.DatasetTemplate._Parameters.TRAIN_TEMPLATE:
                if tr_iterator is None:
                    tr_iterator = itr[1]
                    train_split = split
                else:
                    raise FlowException(component_name=self.name,
                                        message="Found more than one train template in DatasetSplit ({}).".format(
                                            self.dataset_split.name))
            elif split.template[
                constants.DatasetTemplate._Parameters.DATASET_TEMPLATE] == constants.DatasetTemplate._Parameters.VALID_TEMPLATE:
                hooks_manager.add_hook(hook=metrics_runner,
                                       hook_args={"interval_type": split.template[
                                           constants.DatasetTemplate._Parameters.INTERVAL_TYPE],
                                                  "interval": split.template[
                                                      constants.DatasetTemplate._Parameters.INTERVAL]},
                                       kwargs={
                                           "split_name": split.name, "session": self.session,
                                           "iterator_handle": self.dataset_handler.dataset_handle,
                                           "iterator": itr[1],
                                           "batch_placeholder": self.dataset_handler.batch_placeholder,
                                           "metric_store": METRIC_STORE,
                                           "metrics": [RZTDL_STORE.get_component(model_name=self.model.name,
                                                                                 component_name=self.metrics_mapping[
                                                                                     s_metric]) for s_metric
                                                       in split.metrics]},
                                       hook_type=constants.Hook.HookType.FlowHook,
                                       hook_pos=constants.Hook.HookPosition.TrainUpdateHook)
            elif split.template[
                constants.DatasetTemplate._Parameters.DATASET_TEMPLATE] == constants.DatasetTemplate._Parameters.TEST_TEMPLATE:
                hooks_manager.add_hook(hook=metrics_runner,
                                       hook_args={},
                                       kwargs={
                                           "split_name": split.name, "session": self.session,
                                           "iterator_handle": self.dataset_handler.dataset_handle,
                                           "iterator": itr[1],
                                           "batch_placeholder": self.dataset_handler.batch_placeholder,
                                           "metric_store": METRIC_STORE,
                                           "metrics": [RZTDL_STORE.get_component(model_name=self.model.name,
                                                                                 component_name=self.metrics_mapping[
                                                                                     s_metric]) for s_metric
                                                       in split.metrics]},
                                       hook_type=constants.Hook.HookType.FlowHook,
                                       hook_pos=constants.Hook.HookPosition.TrainEndHook)
        # Fetch optimizer components
        if tr_iterator is None:
            raise FlowException(component_name=self.name,
                                message="DatasetSplit ({}) missing Train Template. Provide a single train template".format(
                                    self.dataset_split.name))
        return train_split, tr_iterator

    # noinspection PyProtectedMember
    def create_hooks_for_save(self):
        """
        | **@author:** Prathyush SP
        |
        | Create hooks for splits
        :return: Train Iterator
        """
        self.saver = tf.train.Saver(
            max_to_keep=self.save_handler[constants.ModelHandler._Parameters.MaxCheckpointsToKeep])
        hooks_manager.add_hook(hook=saver,
                               hook_args={"interval_type": self.save_handler[
                                   constants.ModelHandler._Parameters.IntervalType],
                                          "interval": 1},
                               kwargs={
                                   "session": self.session,
                                   "saver": self.saver,
                                   "save_path": self.save_handler[constants.ModelHandler._Parameters.SavePath],
                                   "step": self.step_counter},
                               hook_type=constants.Hook.HookType.FlowHook,
                               hook_pos=constants.Hook.HookPosition.TrainUpdateHook)

    def close(self):
        """
        | **@author:** Prathyush SP
        |
        | Flow Cleanup Method
        """
        self.dataset_handler = None
        self.session = None
        del self.dataset_handler
        del self.session
        del self.model

    def __dict__(self):
        """
        | **@author:** Prathyush SP
        |
        | Method to return flow parameters
        :return: Flow parameters
        """
        return {'epoch': self.epoch, 'batch_size': self.batch_size}

    def __repr__(self):
        """
        | **@author:** Prathyush SP
        |
        | Method to return flow parameters in a stringified form
        :return: Stringified form of flow parameters
        """
        return self.__dict__().__str__()

    def validate(self, previous_flow: Flow):
        """
        | **@author:** Prathyush SP
        |
        | Validation Method
        """
        # Check if dataset handler is finalized
        if not self.dataset_handler.is_finalized:
            raise FlowException(component_name=self.name,
                                message="DatasetHandler [{}] is not finalized".format(self.dataset_handler.name))

        # Check if dataset split is finalized
        if not self.dataset_split.is_finalized:
            raise FlowException(component_name=self.name,
                                message="DatasetSplit [{}] is not finalized".format(self.dataset_split.name))

        # Check learning rate and optimizer
        if not len(self.learning_rate) == len(self.optimizers):
            raise FlowException(component_name=self.name, message=
            'Given learning rates do not match optimizers. {} learning rates for {} optimizers'.format(
                len(self.learning_rate), len(self.optimizers)))

        self.prepare_graph()

        # Verify Metrics Mapping
        if self.dataset_split.reuse:
            if self.metrics_mapping is None:
                raise FlowException(component_name=self.name,
                                    message="Dataset Split {} is set to reuse. Provide metrics mapping".format(
                                        self.dataset_split.name))
        else:
            if self.metrics_mapping is not None:
                logger.warning(
                    "Dataset Split {} has reuse=False. Overriding default metrics mapping with given metrics mapping. Use reuse=True to discard the warning".format(
                        self.dataset_split.name))
            else:
                self.metrics_mapping = {metric: metric for metric in list(self.dataset_split.split_metrics)}


def saver(*args, **kwargs):
    def closure_fn(*args):
        args = {**args[0], **args[1]}
        logger.info("Running save hook . . .")
        logger.debug('Saving model checkpoint in {} . . .'.format(args['flow'].directory_structure.dl_model_save_path))
        args['saver'].save(sess=args['session'],
                           save_path=args['flow'].directory_structure.dl_model_save_path + '/rztdl.ckpt',
                           global_step=args['flow'].step_counter)

    if RZTDL_CONFIG.CommonConfig.RUN_SAVES_IN_THREADS:
        t = Thread(target=closure_fn, args=args)
        args[0]['flow'].threads.append(t)
        t.start()
    else:
        closure_fn(*args)


def metrics_runner(*args, **kwargs):
    def closure_fn(*args):
        args = {**args[0], **args[1]}
        logger.debug("Running metric hook for {} split . . .".format(args["split_name"]))

        # Initialize Iterator
        args["session"].run(args["iterator"].initializer,
                            feed_dict={
                                args["batch_placeholder"]: RZTDL_CONFIG.TensorflowConfig.DEFAULT_VALID_BATCH_SIZE})

        # todo: Umesh - Validate metrics based on optimizer
        # Fetch required inputs for metrics and metric outputs
        required_data, metric_outputs = {}, {}
        for metric in args["metrics"]:
            for m_name, m_placeH in metric.required_input_placeholders.items():
                required_data[m_name] = m_placeH
            metric_outputs[metric.name] = metric.component_output

        # todo: Prathyush SP - Validation for enitre dataset fit on GPU
        metric_data = {k: [] for k in required_data.keys()}
        try:
            while True:
                for k, v in args["session"].run(required_data,
                                                feed_dict={args["iterator_handle"]: args["session"].run(
                                                    args["iterator"].string_handle())}).items():
                    metric_data[k].extend(v)
        except tf.errors.OutOfRangeError:
            logger.debug("Completed data fetch for all metrics on {} split . . .".format(args["split_name"]))

        # Prepare Feed Dict for metric:
        metric_feed_dict = {}
        for m_name, m_placeH in metric_data.items():
            metric_feed_dict[required_data[m_name]] = m_placeH

        # Calculate metrics based on new data
        metric_result = args["session"].run(metric_outputs, feed_dict=metric_feed_dict)
        args['metric_store'].update_store(model_name=args['flow'].model.name,
                                          model_runner_name=args['flow'].model_runner_name,
                                          flow_name=args['flow'].name,
                                          split_name=args['split_name'],
                                          metrics=metric_result,
                                          interval_type=args['interval_type'].name if 'interval_type' in args else None,
                                          interval=args['interval'] if 'interval' in args else None)
        # print({args["split_name"]: metric_result})

    if RZTDL_CONFIG.CommonConfig.RUN_SPLITS_IN_THREADS:
        t = Thread(target=closure_fn, args=args)
        args[0]['flow'].threads.append(t)
        t.start()
    else:
        closure_fn(*args)
