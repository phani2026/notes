# -*- coding: utf-8 -*-
"""
| **@created on:** 22/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

__all__ = ['InferenceFlow']

from typeguard import typechecked
import logging
import rztdl.utils.string_constants as constants
import typing
from rztdl.dl.flows.flow import Flow
from rztdl.dl.model import Model
from rztdl import RZTDL_STORE
import tensorflow as tf
from rztdl.dl.dataset.dataset_split import DatasetSplit
from rztdl.dl.dataset.dataset_handler import DatasetHandler
from rztdl.utils.dl_exception import FlowException
from rztdl.dl.helpers.tfhelpers import GraphUtils
from weakref import ref
from rztdl.dl.dataset.dataset_split import InferenceSplit
import numpy as np
import pandas as pd
from rztdl.dl.handlers.directory_handler import DIRECTORY_HANDLER
from rztdl.dl.handlers.save_handler import save_handler

logger = logging.getLogger(__name__)


class InferenceFlow(Flow):
    """
    | **@author:** Prathyush SP
    |
    | Train Flow Class
    """

    # __slots__ = ['epoch', 'learning_rate', 'optimizers', 'network_params', 'total_batches', 'display_step']

    @typechecked
    def __init__(self, name: str, batch_size: int, component_list: typing.List[str],
                 dataset_handler: DatasetHandler, dataset_mapping: typing.Dict[str, str] = None,
                 data_save_path: str = None, model_checkpoint_path: str = None,
                 model_loader: constants.ModelHandler = None, model_meta_file: str = None,
                 save_handler: constants.ModelHandler = constants.ModelHandler.save_model()):
        """

        :param name: Name of the flow
        :param epoch: Type of the flow
        :param learning_rate: Learning rate for optimizers
        :param optimizers: Optimizers
        :param dataset_handler: Dataset Handle
        :param init: Intialize Tensorflow DAG
        :param session: Provide external Session
        :param dataset_mapping: Dataset Mapping in the format {Input Buffer Name in Model: Dataset Element Name}
        :param metrics_mapping: Metrics Mapping in the format {Metric given in splits: Mertic Name in Model}
        """
        # todo: Prathyush SP - Expose init=True, session=None parameters when iterator replacement using input_map issue is resolved
        super().__init__(name=name, flow_type=constants.FlowType.INFER, dataset_handler=dataset_handler,
                         dataset_mapping=dataset_mapping)

        # todo: Prathyush SP - Modify this attribute with train and persist train
        self.batch_size = batch_size
        self.threads = []
        self.directory_structure = None
        tf.reset_default_graph()
        self.component_list = component_list
        self.dataset_split = self.create_inference_split()
        self.saver = None
        self.data_save_path = data_save_path
        self.model_checkpoint_path = model_checkpoint_path
        self.model_loader = model_loader
        self.model_meta_file = model_meta_file
        self.model_save_path = None
        self.save_handler = save_handler

    # noinspection PyProtectedMember
    def run_flow(self, model: Model, previous_flow: 'Flow', flow_id: int, metric_store,
                 model_runner: ref):
        """
        | **@author:** Prathyush SP
        |
        | Used to create a dl flow
        :param model_runner:
        :param metric_store:
        :param model: Model Object
        :param previous_flow: Previous flow
        :param flow_id: Flow Id
        """
        self.model_runner_name = model_runner().name
        current_graph = tf.Graph()
        with current_graph.as_default():

            logger.info('Initializing Flow with parameters: {}'.format(self.__dict__()))
            self.model = model

            self.validate(previous_flow=previous_flow)

            self.session = tf.Session(graph=current_graph)

            # Setup Directory Handler
            self.directory_structure = DIRECTORY_HANDLER.initialize_directory_structure_for_inference_flow(
                model_name=model.name,
                model_runner_name=self.model_runner_name,
                flow_name=self.name,
                save_path=self.save_handler[
                    constants.ModelHandler._Parameters.SavePath])

            # Save Graph
            logger.debug("Saving Graph . . .")
            GraphUtils(graph=RZTDL_STORE.get_graph(model_name=model.name)).save_graph(
                save_path=self.directory_structure.graph_path)

            # Save Logs
            logger.debug("Saving Logs . . .")
            RZTDL_STORE.add_logs_to_tmp(path=self.directory_structure.logs_path)

            # Initialize Tensorflow Graph
            logger.debug("Initializing Graph . . .")

            initialize = tf.global_variables_initializer()

            split = next(self.dataset_split)
            infer_split, infer_iterator = split, self.dataset_handler.iterators[split.name]

            self.session.run(initialize)

            self.saver = tf.train.Saver()
            self.saver.restore(sess=self.session, save_path=self.model_save_path)

            # todo: Prathyush SP - Restore here!!

            # Create file pointers
            file_pointers = self.open_file_pointers()

            # Initialize Training Iterator
            self.session.run(infer_iterator.initializer,
                             feed_dict={self.dataset_handler.batch_placeholder: self.batch_size})
            global_step = 0
            try:
                # Batch For Loop
                while True:
                    tensors_to_log = self.session.run(
                        {c_names: RZTDL_STORE.get_component_output_as_tensor(model_name=model.name,
                                                                             component_name=c_names).name for c_names in
                         self.component_list}, feed_dict={
                            self.dataset_handler.dataset_handle: self.session.run(infer_iterator.string_handle())})
                    self.write_to_file(global_step=global_step, file_pointers=file_pointers,
                                       tensors_to_log=tensors_to_log)
                    global_step += 1
            except tf.errors.OutOfRangeError:
                print('Inference Completed')

            # Run Flow hook for TrainEndHook Position

            # Wait for splits run, if threads enabled
            # if len(self.threads) > 0:
            #     [t.join() for t in self.threads]

            # Close File Pointers
            self.close_file_pointers(file_pointers=file_pointers)

            # Close Session
            self.close_session()

        return self

    def open_file_pointers(self):
        """
        | **@author:** Prathyush SP
        |
        | Open File pointers for write
        :return: Dictionary of file pointers - {Component Name: File Pointer}
        """
        # todo: Prathyush SP - Replace file pointers with OutBuffers
        return {
            comp_name: open((self.data_save_path or self.directory_structure.data_path) + '/' + comp_name + '.csv', 'a')
            for
            comp_name in self.component_list}

    def close_file_pointers(self, file_pointers: typing.Dict):
        """
        | **@author:** Prathyush SP
        |
        | Close File Pointers
        :param file_pointers: File Pointer Dictionary - {Component Name: File Pointer}
        """
        # todo: Prathyush SP - Replace file pointers with OutBuffers
        for k, fp in file_pointers.items():
            fp.close()

    def write_to_file(self, global_step: int, file_pointers: typing.Dict, tensors_to_log: typing.Dict):
        """
        | **@author:** Prathyush SP
        |
        | Write to File
        :param global_step: Global Step
        :param file_pointers: File Pointers
        :param tensors_to_log: Tensors to Save
        """
        for k, v in tensors_to_log.items():
            v = np.reshape(v, newshape=[self.batch_size, -1]).transpose()
            if global_step is 0:
                pd.DataFrame(data={**{k + '_' + str(e): i for e, i in enumerate(v)},
                                   **{'id': np.array(list(range(0 + (self.batch_size * global_step),
                                                                self.batch_size * (
                                                                        global_step + 1))))}}).set_index(
                    'id').to_csv(file_pointers[k], index=True, index_label='id',
                                 header=True if global_step is 0 else False, mode='a')

    def create_inference_split(self):
        split = DatasetSplit(name=self.name + '_inference_split_template', split_ratio=[100], split_metrics=set(),
                             reuse=False)
        split.add_split(InferenceSplit(self.name + '_inference_split_template'))
        return split.close()

    def close(self):
        """
        | **@author:** Prathyush SP
        |
        | Flow Cleanup Method
        """
        self.dataset_handler = None
        self.session = None
        del self.dataset_handler
        del self.session
        del self.model

    def __dict__(self):
        """
        | **@author:** Prathyush SP
        |
        | Method to return flow parameters
        :return: Flow parameters
        """
        return {'batch_size': self.batch_size}

    def __repr__(self):
        """
        | **@author:** Prathyush SP
        |
        | Method to return flow parameters in a stringified form
        :return: Stringified form of flow parameters
        """
        return self.__dict__().__str__()

    def validate(self, previous_flow: Flow):
        """
        | **@author:** Prathyush SP
        |
        | Validation Method
        """
        # Check if dataset handler is finalized
        if not self.dataset_handler.is_finalized:
            raise FlowException(component_name=self.name,
                                message="DatasetHandler [{}] is not finalized".format(self.dataset_handler.name))

        if self.model_checkpoint_path:
            self.model_save_path = self.model_checkpoint_path
        elif self.model_loader:
            self.model_save_path = save_handler.restore_model_using_loader(model_loader=self.model_loader)
        # elif self.model_meta_file:
        #     self.model_save_path = SaveHandler().restore_model_using_loader()
        else:
            raise FlowException(component_name=self.name,
                                message="Missing save path config. Provide atleast one among, model_checkpoint_path,model_loader, model_meta_file ")

        self.prepare_inference_graph()
