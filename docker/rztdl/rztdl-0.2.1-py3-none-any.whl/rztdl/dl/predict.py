# -*- coding: utf-8 -*-
"""
| **@created on:** 11/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
from rztdl import RZTDL_CONFIG
import tensorflow as tf
import logging
import rztdl.utils.string_constants as constants
from typing import List, Union
from numpy import ndarray
from rztdl.utils.dl_exception import SizeError, DataFeedException
from rztdl.utils.pyutils import File
from typeguard import typechecked
import os
import numpy as np
import glob

logger = logging.getLogger(__name__)


class Prediction(object):
    """
    | **@author:** Prathyush SP
    |
    | Prediction Class
    .. todo::
        Prathyush SP:
            1. Model Save Documentation
    """

    @typechecked
    def __init__(self, network_name: str, run_id: int = -1, model_save_path: str = None, checkpoint_step: int = -1):
        """
        :param network_name: Network Name
        :param run_id: Run ID
        :param model_save_path: Model Save Path
        :param epoch: Epoch to restore
        """
        self.name = network_name
        self.id = run_id
        self.metadata = None
        self.model_save_path = model_save_path
        self.checkpoint_step = checkpoint_step
        self._validate()
        self.session = None
        self._restore_session()
        self.feed_dict = {}
        self.model_name = None
        self.batches = None
        self.batch_size = None

    def _restore_session(self):
        """
        | **@author:** Prathyush SP
        |
        | Restore Session
        """
        self.session = tf.InteractiveSession(config=RZTDL_CONFIG.TensorflowConfig.CONFIG_PROTO)
        logger.info('Model Save Path: ' + self.model_save_path)
        self.saver = tf.train.import_meta_graph(self.model_save_path + '.model-{}.meta'.format(self.checkpoint_step),
                                                clear_devices=True)
        self.saver.restore(sess=self.session, save_path=self.model_save_path + '.model-{}'.format(self.checkpoint_step))

    def get_predict_save_path(self) -> str:
        """
        | **@author:** Prathyush SP
        |
        | Get Prediction Save Path
        :return: Prediction Save path in String
        """
        return RZTDL_CONFIG.CommonConfig.PATH_RZTDL + '/' + self.name + '/' + self.metadata['timestamp'] + '/'

    def close(self):
        """
        | **@author:** Prathyush SP
        |
        | Close Interactive Session
        """
        self.session.close()

    @typechecked
    def _extract_checkpoint(self, filename: str) -> int:
        """
        | **@author:** Prathyush SP
        |
        | Extract checkpoint
        :param filename: Filename
        :return: checkpoint
        """
        return int(filename.split('.')[-2].split('-')[-1])

    @typechecked
    def _validate_checkpoint(self, file_list: list) -> int:
        """
        | **@author:** Prathyush SP
        |
        | Validate checkpoint
        :param file_list: File List
        :return: Existing checkpoint
        """
        checkpoint_file_dict = {}
        for f in file_list:
            checkp = self._extract_checkpoint(f)
            checkpoint_file_dict[checkp] = f
            if self.checkpoint_step == checkp:
                logger.debug('Checkpoint Found: {}'.format(f))
                return checkp
        logger.debug('Checkpoint not found. Using latest checkpoint: {}'.format(
            checkpoint_file_dict[max(list(checkpoint_file_dict.keys()))]))
        return max(list(checkpoint_file_dict.keys()))

    def _validate(self):
        """
        | **@author:** Prathyush SP
        |
        | Prediction Validation
        """
        tf.reset_default_graph()
        self.model_save_path = self.model_save_path if self.model_save_path and not self.model_save_path == '' else RZTDL_CONFIG.CommonConfig.PATH_RZTDL
        # todo:: Prathyush SP: Production vs Development Error
        # File.is_exist(path=self.model_save_path+ '/' + self.name + '/model.meta'):
        if os.path.exists(path=self.model_save_path + '/' + self.name + '/model.meta'):
            self.metadata = File.read_json(path=self.model_save_path + '/' + self.name + '/model.meta')
            try:
                self.model_save_path += '/' + self.metadata[constants.ModelMetaConstant.NETWORK_NAME] + '/' + \
                                        self.metadata[
                                            constants.ModelMetaConstant.TIMESTAMP] + '/' + \
                                        self.metadata[constants.ModelMetaConstant.PATH][
                                            constants.ModelMetaConstant.PATH_OPTIONS.DL_SAVE_PATH]
                list_of_files = glob.glob(self.model_save_path + '/*.meta')
                self.checkpoint_step = self._validate_checkpoint(file_list=list_of_files)
                self.model_save_path += self.name
            except KeyError:
                keys = [int(k) for k in self.metadata.keys()]
                self.metadata = self.metadata[str(self.id)] if self.id in keys else self.metadata[str(max(keys))]
                self.model_save_path += '/' + self.metadata[constants.ModelMetaConstant.NETWORK_NAME] + '/' + \
                                        self.metadata[
                                            constants.ModelMetaConstant.TIMESTAMP] + '/' + \
                                        self.metadata[constants.ModelMetaConstant.PATH][
                                            constants.ModelMetaConstant.PATH_OPTIONS.DL_SAVE_PATH]
                list_of_files = glob.glob(self.model_save_path + '/*.meta')
                self.checkpoint_step = self._validate_checkpoint(file_list=list_of_files)
                self.model_save_path += self.name
            self.model_name = self.metadata[constants.ModelMetaConstant.MODEL_NAME]
        else:
            raise FileExistsError(
                'Model meta file / Network not found : {} in path: {}'.format(self.name, self.model_save_path))

    @typechecked
    def get_weights(self, layer_name: Union[str, List[str]]):
        """
        | **@author:** Prathyush SP
        |
        | Read Weights of a Layer from saved model
        :param layer_name: Layer Name
        :return: Layer Weights
        """
        weights = []
        if isinstance(layer_name, str):
            if layer_name in self.metadata[constants.ModelMetaConstant.WEIGHTS]:
                try:
                    return self.session.run(
                        self.session.graph.get_tensor_by_name(
                            self.metadata[constants.ModelMetaConstant.WEIGHTS][layer_name]))
                except Exception:
                    raise Exception('Failed to load dl_layer weights: {}'.format(layer_name))
            else:
                raise Exception('Layer not found: {}'.format(layer_name))
        else:
            for layer in layer_name:
                if layer in self.metadata[constants.ModelMetaConstant.WEIGHTS]:
                    try:
                        weights.append(
                            self.session.graph.get_tensor_by_name(
                                self.metadata[constants.ModelMetaConstant.WEIGHTS][layer]))
                    except Exception:
                        raise Exception('Failed to load dl_layer weights: {}'.format(layer))
                else:
                    raise Exception('Layer not found: {}'.format(layer))
            return {k: v for k, v in zip(layer_name, self.session.run(weights))}

    @typechecked
    def set_weights(self, layer_name: str, layer_weights: ndarray):
        """
        | **@author:** Prathyush SP
        |
        | Set Weights of previously trained variable
        :param layer_name: Layer Name
        :param layer_weights: New Weights
        """
        weight_exists = False
        if isinstance(layer_name, str):
            if layer_name in self.metadata[constants.ModelMetaConstant.WEIGHTS]:
                try:
                    for i in tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES):
                        if i.name == self.metadata[constants.ModelMetaConstant.WEIGHTS][layer_name]:
                            weight_exists = True
                            self.session.run(i.assign(layer_weights))
                    if not weight_exists:
                        raise Exception()
                except Exception:
                    raise Exception('Failed to set dl_layer weights: {}'.format(layer_name))
            else:
                raise Exception('Layer not found: {}'.format(layer_name))

    @typechecked
    def get_bias(self, layer_name: Union[str, List[str]]):
        """
        | **@author:** Prathyush SP
        |
        | Read Bias of a Layer from saved model
        :param layer_name: Layer Name
        :return: Layer Bias
        """
        bias = []
        if isinstance(layer_name, str):
            if layer_name in self.metadata[constants.ModelMetaConstant.BIAS]:
                try:
                    return self.session.run(
                        self.session.graph.get_tensor_by_name(
                            self.metadata[constants.ModelMetaConstant.BIAS][layer_name]))
                except Exception:
                    raise Exception('Failed to load dl_layer bias: {}'.format(layer_name))
            else:
                raise Exception('Layer not found: {}'.format(layer_name))
        else:
            for layer in layer_name:
                if layer in self.metadata[constants.ModelMetaConstant.BIAS]:
                    try:
                        bias.append(self.session.graph.get_tensor_by_name(
                            self.metadata[constants.ModelMetaConstant.BIAS][layer]))
                    except Exception:
                        raise Exception('Failed to load dl_layer bias: {}'.format(layer))
                else:
                    raise Exception('Layer not found: {}'.format(layer))
            return {k: v for k, v in zip(layer_name, self.session.run(bias))}

    @typechecked
    def set_bias(self, layer_name: str, layer_bias: ndarray):
        """
        | **@author:** Prathyush SP
        |
        | Set Bias of previously trained variable
        :param layer_name: Layer Name
        :param layer_bias: New Bias
        """
        bias_exists = False
        if isinstance(layer_name, str):
            if layer_name in self.metadata[constants.ModelMetaConstant.BIAS]:
                try:
                    for i in tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES):
                        if i.name == self.metadata[constants.ModelMetaConstant.BIAS][layer_name]:
                            bias_exists = True
                            self.session.run(i.assign(layer_bias))
                    if not bias_exists:
                        raise Exception()
                except Exception:
                    raise Exception('Failed to set dl_layer bias: {}'.format(layer_name))
            else:
                raise Exception('Layer not found: {}'.format(layer_name))

    @typechecked
    def _get_placeholder(self, placeholder_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Get Placeholders from the saved model
        :param placeholder_name: Placeholder Name
        :return: Tensor from TF Collection
        """
        if placeholder_name in self.metadata[constants.ModelMetaConstant.PREDICTION_PLACEHOLDERS]:
            try:
                return self.session.graph.get_tensor_by_name(
                    self.metadata[constants.ModelMetaConstant.PREDICTION_PLACEHOLDERS][placeholder_name])
            except Exception:
                raise Exception('Failed to load placeholder: {}'.format(placeholder_name))
        else:
            raise Exception('Data feed for Layer not found: {}'.format(placeholder_name))

    def _get_dropout_placeholders(self):
        """
        | **@author:** Prathyush SP
        |
        | Get Dropout Placeholders from saved model
        :return: Dictionary of Placeholders in format:  {<Tensor Placeholder>: 1.0}
        """
        dp_placeholders = {}
        for placeholder_name, tensor_name in self.metadata[constants.ModelMetaConstant.DROPOUT_PLACEHOLDERS].items():
            try:
                dp_placeholders[placeholder_name] = 1.0
            except Exception:
                raise Exception('Failed to load placeholder: {}'.format(placeholder_name))
        return dp_placeholders

    @typechecked
    def _get_layer(self, layer_name: Union[str, List[str]]):
        """
        | **@author:** Prathyush SP
        |
        | Get Layer from the saved model
        :param layer_name: Layer Name
        :return: Tensor from TF Collection
        """
        layers = []
        if isinstance(layer_name, str):
            if layer_name in self.metadata[constants.ModelMetaConstant.LAYERS]:
                try:
                    return self.session.graph.get_tensor_by_name(
                        self.metadata[constants.ModelMetaConstant.LAYERS][layer_name])
                except Exception:
                    raise Exception('Failed to load dl_layer : {}'.format(layer_name))
            else:
                raise Exception('Layer not found: {}'.format(layer_name))
        else:
            for layer in layer_name:
                if layer in self.metadata[constants.ModelMetaConstant.LAYERS]:
                    try:
                        layers.append(
                            self.session.graph.get_tensor_by_name(
                                self.metadata[constants.ModelMetaConstant.LAYERS][layer]))
                    except Exception:
                        raise Exception('Failed to load dl_layer : {}'.format(layer))
                else:
                    raise Exception('Layer not found: {}'.format(layer))
            return {k: v for k, v in zip(layer_name, layers)}

    @typechecked
    def predict(self, layer_name: str, data: dict, batches: int = 1, batch_size: int = 0):
        """
        | **@author:** Prathyush SP
        |
        | Model Prediction
        :param layer_name: Layer Name
        :param data: Model Data
        :param batches: Prediction train_batches
        :param batch_size: Batch Size
        :return: List of NdArray
        """
        result, feed_dict = [], {}
        for key, val in data.items():
            if np.isnan(val).any():
                raise ValueError('Dataset contains Nan. Use pd.fillna() or pd.dropna() . . .')
        if len(data) == 0:
            raise SizeError('Missing feed data for Prediction . . .')
        for key in self.metadata[constants.ModelMetaConstant.PREDICTION_PLACEHOLDERS].keys():
            if key not in data.keys():
                raise DataFeedException('Missing feed data for Layer "{}"'.format(key))
        samples = len(data[next(iter(data))])
        if batches > 1:
            if batches > samples:
                raise SizeError("Batches can't be greater than total samples")
            self.batches = batches
            self.batch_size = int(samples / batches)
        elif batch_size:
            if batch_size > samples:
                raise SizeError("Batch_size can't be greater than total samples")
            self.batches = int(samples / batch_size)
            self.batch_size = batch_size
        else:
            self.batches = batches
            self.batch_size = samples
        layer = self._get_layer(layer_name=layer_name)
        for k, v in data.items():
            key = self._get_placeholder(placeholder_name=k)
            feed_dict[key] = v
        feed_dict = [feed_dict] if feed_dict == 0 else [
            {key: v[k:k + self.batch_size] for key, v in feed_dict.items()} for k in
            range(0, samples, self.batch_size)]
        for batch_data in feed_dict:
            result.append(self.session.run(layer, feed_dict={**batch_data, **self._get_dropout_placeholders()}))
        return result
