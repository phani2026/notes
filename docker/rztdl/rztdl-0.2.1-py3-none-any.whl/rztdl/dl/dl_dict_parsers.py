# -*- coding: utf-8 -*-
"""
| **@created on:** 17/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Validation Class
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
from typing import Union
from numpy import ndarray
from tensorflow import Tensor
from rztdl.dl.helpers.tfhelpers import Initialization, Cost, Morpher
from rztdl.utils.string_constants import PARAMETERS, InitializerType, MORPHER, CostType
from rztdl.utils.dl_exception import keyexception


# noinspection PyProtectedMember
@keyexception
def parse_initialization_dict(initialization_dict: dict, shape: Union[list, ndarray]) -> Tensor:
    """
    | **@author:** Prathyush SP
    |
    | Parse Initialization Dictionary - Wrapper for Initialization class of TFHelpers
    :param initialization_dict: Initialization Dictionary
    :param shape: Tensor Shape
    :return: Initialization Tensor
    .. todo::
        Prathyush SP:
            1. Replace elif with Lambda Dict
            2. Move the function to tfhelpers
    """
    # todo: Prathyush SP: Replace elif with Lambda Dict
    # todo: Prathyush SP: Move the function to tfhelpers

    initializer = Initialization(shape=shape,
                                 seed=initialization_dict[InitializerType._Parameters.SEED.name],
                                 dtype=initialization_dict[InitializerType._Parameters.DTYPE.name])
    if initialization_dict[
        InitializerType._Parameters.INITIALIZER_TYPE.name] == InitializerType._Parameters.RANDOM_UNIFORM.name:
        return initializer.random_uniform(
            min_val=initialization_dict[InitializerType._Parameters.MIN_VAL.name],
            max_val=initialization_dict[InitializerType._Parameters.MAX_VAL.name])
    elif initialization_dict[
        InitializerType._Parameters.INITIALIZER_TYPE.name] == InitializerType._Parameters.RANDOM_NORMAL.name:
        return initializer.random_normal(
            std_dev=initialization_dict[InitializerType._Parameters.STD_DEV.name],
            mean=initialization_dict[InitializerType._Parameters.MEAN.name])
    elif initialization_dict[
        InitializerType._Parameters.INITIALIZER_TYPE.name] == InitializerType._Parameters.ZEROS.name:
        return initializer.zeros()
    elif initialization_dict[
        InitializerType._Parameters.INITIALIZER_TYPE.name] == InitializerType._Parameters.ONES.name:
        return initializer.ones()
    elif initialization_dict[
        InitializerType._Parameters.INITIALIZER_TYPE.name] == InitializerType._Parameters.CONSTANT.name:
        return initializer.constant(constant=initialization_dict[InitializerType._Parameters.CONSTANT.name])
    elif initialization_dict[
        InitializerType._Parameters.INITIALIZER_TYPE.name] == InitializerType._Parameters.ORTHOGONAL.name:
        return initializer.orthogonal(gain=initialization_dict[InitializerType._Parameters.GAIN.name])
    elif initialization_dict[
        InitializerType._Parameters.INITIALIZER_TYPE.name] == InitializerType._Parameters.XAVIER.name:
        return initializer.xavier(uniform=InitializerType._Parameters.XAVIER)
    elif initialization_dict[
        InitializerType._Parameters.INITIALIZER_TYPE.name] == InitializerType._Parameters.TRUNCATED_NORMAL.name:
        return initializer.truncated_normal(
            std_dev=initialization_dict[InitializerType._Parameters.STD_DEV.name],
            mean=initialization_dict[InitializerType._Parameters.MEAN.name])
    else:
        raise Exception('Unknown Initializer Type: {}'.format(
            initialization_dict[InitializerType._Parameters.INITIALIZER_TYPE.name]))


@keyexception
def parse_cost_dict(actual_output, predicted_output, cost_dict: dict):
    if cost_dict[PARAMETERS.COST_TYPE] == CostType._WEIGHTED_CROSS_ENTOPY:
        return Cost(actual_output=actual_output, predicted_output=predicted_output).weighted_cross_entropy(
            pos_weight=cost_dict[PARAMETERS.POS_WEIGHT])