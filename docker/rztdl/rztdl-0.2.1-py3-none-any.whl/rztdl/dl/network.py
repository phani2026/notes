# -*- coding: utf-8 -*-
"""
| **@created on:** 31/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
|
| **Sphinx Documentation Status:**
|
|..todo::
|
|**Custom Stop Criteria Function:**
|.. code-block:: python
    def stop_criteria_fn(epoch: int, current_epoch: int, cost: float, accuracy: float, gini: Union[float, None]):
    # condition1
    # return True, "Stopped due to Condition 1" # - Stop the training

    # condition2
    # return True, "Stopped due to Condition 2" - Stop the training

    # Continue Training
    return False, "Continue Training"
"""

import logging
import glob
import os
from collections import OrderedDict
from functools import reduce
from typing import Union, Callable
import rztdl.utils.string_constants as constant
import tensorflow as tf
from rztdl import RZTDL_STORE, RZTDL_CONFIG
from rztdl.dl import tf_summary, tf_timeline, Model
from rztdl.dl.components.dl_layer import Layer
from rztdl.dl.helpers.tfhelpers import Optimizer
from rztdl.dl.result import Result
from rztdl.meta.network_meta import NetworkMeta
from rztdl.metrics.dl import CostMetric
from rztdl.metrics.dl.evaluate_metric_runner import EvaluationMetricRunner
from rztdl.statistic.algorithms import calculate_mean
from rztdl.utils.dl_exception import SizeError, DataFeedException, InsufficientData
from rztdl.utils.parser_utils import call_parser
from rztdl.utils.pyutils import DLTimer
from rztdl.utils.pyutils import Directories, File, raise_exception
from rztdl.utils.pyutils import generate_timestamp
from rztdl.utils.string_constants import OptimizerTypes, STOP_CRITERIA, ModelMetaConstant, NETWORK_MODE
from rztdl.utils.validations import validate_name
from tensorflow import Operation
from tensorflow import Tensor
from typeguard import typechecked

logger = logging.getLogger(__name__)


class Network(object):
    """
    | **@author:** Prathyush SP
    |
    | Network Class
    .. todo::
        Prathyush SP:
            1. Model Save Documentation
    """

    # todo: Prathyush SP - Model Save Documentation
    @typechecked
    def __init__(self, name: str):
        """
        :param name: Network Name
        .. todo::
            Prathyush SP:
                1. Move train variables to train method
        """
        self.name = validate_name(name)
        self.cost = None
        self.optimizer = None
        self.model = None
        self.model_name = None
        self.id = None
        self.saver = None
        self.metadata = None
        self.model_meta = OrderedDict()
        self.timestamp = generate_timestamp()
        self.save_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL
        self.regularisation = False
        self.regularisation_params = None
        self.cost_placeholder = None
        self.cost_tensor = None
        self.network_params = OrderedDict()
        self.network_meta = None
        self.train_batches = None
        self.train_batch_size = None
        self.evaluation_metric_runner = None
        self.checkpoint_step = -1

    @typechecked
    def _create_directories(self, save_path: str = RZTDL_CONFIG.CommonConfig.PATH_RZTDL):
        """
        | **@author:** Prathyush SP
        |
        | Create required directories for the Network
        :param save_path: Save Path [Default: '/tmp/rztdl_logs/' ]
        .. todo::
            Prathyush SP:
                1. Complete Model Meta
                2. Move Model Metadata to RZTDL_DAG Metadata
        """
        # todo:: Prathyush SP: Move Model Metadata to RZTDL_DAG Metadata
        RZTDL_STORE.add_meta_data(self.model_name, 'timestamp', self.timestamp)
        init_path = save_path + '/' + self.name + '/' + RZTDL_STORE.get_meta_data_by_key(self.model_name,
                                                                                       'timestamp') + '/'
        if not RZTDL_CONFIG.CommonConfig.DRY_RUN:
            [Directories.mkdir(init_path + path, force=False) for path in
             [RZTDL_CONFIG.CommonConfig.PATH_LOG, RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_DL,
              RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_ML, RZTDL_CONFIG.CommonConfig.PATH_GRAPH,
              RZTDL_CONFIG.CommonConfig.PATH_DATA, RZTDL_CONFIG.CommonConfig.PATH_BENCHMARK]]
            RZTDL_STORE.add_logs_to_tmp(path=init_path + RZTDL_CONFIG.CommonConfig.PATH_LOG)

    # noinspection PyShadowingNames
    @typechecked
    def train(self, epoch: int, learning_rate: Union[int, float], model: Model, cost: Union[str, dict, Tensor],
              optimizer: Union[constant.OptimizerTypes, Operation], train_data: dict,
              evaluation_metrics: list = None, valid_data: dict = None, test_data: dict = None, init=True,
              sess=None, display_step: int = 10, train_batches: int = 1, train_batch_size: int = 0,
              valid_batches: int = 1, valid_batch_size: int = 0, test_batches: int = 1, test_batch_size: int = 0,
              batch_display_step: int = 0, saver: tf.train.Saver = None, tf_tracing: bool = False,
              print_json=False, save_path: str = None,
              stop_criteria_fn: Callable = None, regularisation: bool = False, regularisation_params: dict = None):
        """
        | **@author:** Prathyush SP
        |
        | Train the Network
        :param evaluation_metrics: which metrics should calculate
        :param regularisation_params: Parameters of regularisation
        :param regularisation: whether regularisation is required or not.
        :param epoch: Epoch
        :param learning_rate: Learning Rate
        :param model: Model
        :param cost: Cost
        :param optimizer: Optimizer
        :param train_data: Train Data
        :param valid_data: Valid Data
        :param test_data: Test Data
        :param init: Initialize Variables Operation
        :param sess: Session
        :param display_step: Epoch Display Step
        :param train_batches: Training train_batches
        :param train_batch_size: train Data Batch Size
        :param valid_batches: Valid Data train_batches
        :param valid_batch_size: Valid Data Batch Size
        :param test_batches: Test Data Batches
        :param test_batch_size: Test Batch Size
        :param batch_display_step: Display Step for train_batches
        :param saver: Tensorflow Saver Object
        :param tf_tracing: Run Tensorflow timeline - Useful for debugging
        :param print_json: Print in JSON Format
        :param save_path: Model Save path
        :param stop_criteria: Stop Criteria Dict {STOP_CRITERIA.<>:value}
        :param stop_criteria_fn: Custom Stop Criteria Function
        .. todo::
            Prathyush SP:
                1. Train based on tf.import_graph_def()
                2. Create Result class for logging model results
                3. Complete Model Meta
                4. Move save paths to config
                5. Untested Temporary Code - Model Parser
       """
        # todo: Prathyush SP: Train based on tf.import_graph_def()
        self.model_name = model.name
        evaluation_metrics = evaluation_metrics if evaluation_metrics else []
        self.regularisation, self.regularisation_params = regularisation, regularisation_params
        self.save_path = save_path if save_path else self.save_path
        meta_data_save_path = save_path if save_path else self.save_path
        self.cost, self.optimizer = cost, optimizer
        self.model = model.final_component if model.final_component else raise_exception('Model is not closed')
        cost_metric = CostMetric(cost_type=self.cost, regularisation=self.regularisation,
                                 regularisation_params=self.regularisation_params, model_name=self.model_name)
        evaluation_metrics += [cost_metric]
        result = Result(model_name=self.model_name, network_name=self.name, model_complexity=model._model_complexity,
                        epoch=epoch, epoch_step=display_step, evaluation_metrics=evaluation_metrics,
                        learning_rate=learning_rate, cost=cost, optimizer=optimizer,
                        train_batch_size=train_batch_size, train_batches=train_batches, valid_batch_size=None,
                        valid_batches=None, test_batch_size=None, test_batches=None, timestamp=self.timestamp)
        self.evaluation_metric_runner = EvaluationMetricRunner().initialise_variables(
            evaluation_metrics=evaluation_metrics, cost=cost,
            batch_display_step=batch_display_step,
            display_step=display_step,
            actual_output=self.model.get_tensor(name=self.model.layer_output_placeholder),
            predicted_output=self.model.get_tensor(name=self.model.component_output), result=result,
            model_name=self.model_name,
            regularisation=regularisation,
            regularisation_params=regularisation_params,
            metadata=self.metadata, init=init)

        # Validate and Create Batches
        train_dict, valid_dict, test_dict = self._train_validation(train_data=train_data, valid_data=valid_data,
                                                                   test_data=test_data, learning_rate=learning_rate,
                                                                   placeholders=RZTDL_STORE.get_all_placeholders(
                                                                       model_name=self.model_name).items(),
                                                                   train_batches=train_batches,
                                                                   train_batch_size=train_batch_size,
                                                                   valid_batches=valid_batches,
                                                                   valid_batch_size=valid_batch_size,
                                                                   test_batches=test_batches,
                                                                   test_batch_size=test_batch_size,
                                                                   save_path=self.save_path)
        init = tf.group(tf.global_variables_initializer(), tf.local_variables_initializer()) if init else init
        sess = sess if isinstance(sess, tf.Session) else tf.Session(config=RZTDL_CONFIG.TensorflowConfig.CONFIG_PROTO)
        uninitialised_vars_init = tf.variables_initializer(
            self.evaluation_metric_runner.uninitialised_vars) if self.evaluation_metric_runner.uninitialised_vars else None
        summary_op = tf_summary.create_summary_op()
        self.saver = saver if saver else tf.train.Saver(max_to_keep=RZTDL_CONFIG.TensorflowConfig.CHECKPOINT_MAX_SAVES,
                                                        keep_checkpoint_every_n_hours=RZTDL_CONFIG.TensorflowConfig.CHECKPOINT_HOUR)
        self.save_path += '/' + self.name + '/' + self.timestamp + '/'
        RZTDL_STORE.add_meta_data(model_name=self.model_name, key=constant.ModelMetaConstant.EVALUATION_METRICS,
                                  value=EvaluationMetricRunner.set_evaluation_metrics(evaluation_metrics))
        if not RZTDL_CONFIG.CommonConfig.DRY_RUN:
            tf_summary.create_file_writer(name='train_writer',
                                          save_path=self.save_path + RZTDL_CONFIG.CommonConfig.PATH_GRAPH + '/train/',
                                          graph=sess.graph)
            tf_summary.create_file_writer(name='valid_writer',
                                          save_path=self.save_path + RZTDL_CONFIG.CommonConfig.PATH_GRAPH + '/valid/',
                                          graph=sess.graph)
        logger.info('Initializing Tensors . . .')
        sess.run(init) if init else None
        if not init and uninitialised_vars_init:
            sess.run(uninitialised_vars_init)
        # Session Training
        m, c, i, summary = None, None, None, None
        # todo: Prathyush SP - Work on Graph Finalization
        # tf.get_default_graph().finalize()
        output_layer_name = tf.get_default_graph().get_tensor_by_name(
            list(RZTDL_STORE.dag[self.model_name][ModelMetaConstant.PLACEHOLDERS].values())[-1])
        train_time = DLTimer().set_time()
        for i in range(epoch):
            for batch_id, batch_data in enumerate(train_dict):
                # Training
                if tf_tracing:
                    logger.info('Running Tensorflow Tracing . . .')
                    tf_timeline.run(session=sess, optimizer_op=self.optimizer,
                                    feed_dict={**batch_data, **self.network_params,
                                               **RZTDL_STORE.get_all_dropout_placeholders(model_name=self.model_name,
                                                                                          mode=NETWORK_MODE.TRAIN)}).save(
                        save_path=self.save_path + '/graphs/timeline_' + str(i) + '_' + str(batch_id) + '.json')
                _, m = sess.run([self.optimizer, self.model.component_output],
                                feed_dict={**batch_data, **self.network_params,
                                           **RZTDL_STORE.get_all_dropout_placeholders(model_name=self.model_name,
                                                                                      mode=NETWORK_MODE.TRAIN)})
                self.evaluation_metric_runner.calculate_batch_result(batch_data=batch_data,
                                                                     output_layer_name=output_layer_name,
                                                                     layer_output=m, session=sess,
                                                                     feed_dict={**batch_data,
                                                                                **RZTDL_STORE.get_all_dropout_placeholders(
                                                                                    model_name=self.model_name,
                                                                                    mode=NETWORK_MODE.TRAIN)},
                                                                     batch_id=batch_id, batches=train_batches,
                                                                     train_time=train_time, json_type=print_json,
                                                                     mode=constant.ModelMetaConstant.TRAIN_META)

                # Run only when batch is last batch
                if not RZTDL_CONFIG.CommonConfig.DRY_RUN and RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY \
                        and batch_id == len(train_dict) - 1 and evaluation_metrics:
                    summary = self._create_tensor_metrics(sess, summary_op,
                                                          batch_data, mode=NETWORK_MODE.TRAIN,
                                                          batches=len(train_dict))

            if not RZTDL_CONFIG.CommonConfig.DRY_RUN and RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY:
                tf_summary.add_summary(file_writer_name='train_writer', summary_op=summary, step=i)

            # Epoch Display step - Validation
            if i % display_step == 0 or i == epoch - 1:
                if valid_data:
                    for batch_id, batch_data in enumerate(valid_dict):
                        m = sess.run(self.model.component_output, feed_dict={**batch_data,
                                                                         **RZTDL_STORE.get_all_dropout_placeholders(
                                                                             model_name=self.model_name,
                                                                             mode=NETWORK_MODE.PREDICTION)})
                        self.evaluation_metric_runner.calculate_batch_result(
                            batch_data=batch_data, layer_output=m, session=sess,
                            feed_dict={**batch_data, **RZTDL_STORE.get_all_dropout_placeholders(
                                model_name=self.model_name, mode=NETWORK_MODE.PREDICTION)},
                            mode=constant.ModelMetaConstant.VALID_META,
                            batches=valid_batches,
                            json_type=print_json,
                            train_time=train_time, batch_id=batch_id, output_layer_name=output_layer_name)
                        if not RZTDL_CONFIG.CommonConfig.DRY_RUN and RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY \
                                and batch_id == len(valid_dict) - 1 and evaluation_metrics:
                            summary = self._create_tensor_metrics(sess, summary_op, batch_data,
                                                                  mode=NETWORK_MODE.PREDICTION,
                                                                  batches=len(valid_dict))
                    self.evaluation_metric_runner.calculate_epoch_result(each_epoch=i, train_time=train_time,
                                                                         epoch=epoch,
                                                                         json_type=print_json, log=True)
                    if not RZTDL_CONFIG.CommonConfig.DRY_RUN:
                        tf_summary.add_summary(file_writer_name='valid_writer', summary_op=summary, step=i)
                else:
                    self.evaluation_metric_runner.calculate_epoch_result(each_epoch=i, train_time=train_time,
                                                                         epoch=epoch,
                                                                         json_type=print_json, log=True)
                if not RZTDL_CONFIG.CommonConfig.DRY_RUN:
                    RZTDL_STORE.save_metadata(path=meta_data_save_path, name=self.name, model_name=self.model_name)
            else:
                self.evaluation_metric_runner.calculate_epoch_result(each_epoch=i, train_time=train_time, epoch=epoch,
                                                                     json_type=print_json, log=True)
            if not RZTDL_CONFIG.CommonConfig.DRY_RUN and i % RZTDL_CONFIG.TensorflowConfig.CHECKPOINT_EPOCH == 0:
                self.saver.save(sess=sess, global_step=i,
                                save_path=self.save_path + RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_DL + self.name + '.model')

            #todo: Prathyush SP - Stop Criteria Custom Function is deprecated due to EM Architecture
            # if isinstance(stop_criteria_fn, Callable):
            #     try:
            #         # noinspection PyCallingNonCallable
            #         sp_cond, sp_message = stop_criteria_fn(epoch=epoch, current_epoch=i,
            #                                                cost=calculate_mean(train_result_metrics['cost']),
            #                                                accuracy=calculate_mean(train_result_metrics['accuracy']),
            #                                                gini=calculate_mean(train_result_metrics['gini']))
            #         if sp_cond:
            #             logger.info("Training Stopped due to custom stop function - {}".format(sp_message))
            #             break
            #     except Exception as e:
            #         logger.error('Custom Stop Function failure . . . Pls check the documentation', e)

        if not RZTDL_CONFIG.CommonConfig.DRY_RUN and i % RZTDL_CONFIG.TensorflowConfig.CHECKPOINT_EPOCH == 0:
            self.saver.save(sess=sess, global_step=i,
                            save_path=self.save_path + RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_DL + self.name + '.model')

        # Test Data
        if test_data:
            test_time = DLTimer().set_time()
            for batch_id, batch_data in enumerate(test_dict):
                m = sess.run(self.model.component_output, feed_dict={**batch_data,
                                                                 **RZTDL_STORE.get_all_dropout_placeholders(
                                                                     model_name=self.model_name,
                                                                     mode=NETWORK_MODE.PREDICTION)})
                self.evaluation_metric_runner.calculate_batch_result(
                    batch_data=batch_data, layer_output=m, session=sess,
                    feed_dict={**batch_data, **RZTDL_STORE.get_all_dropout_placeholders(
                        model_name=self.model_name, mode=NETWORK_MODE.PREDICTION)},
                    mode=constant.ModelMetaConstant.TEST_META,
                    batches=test_batches,
                    json_type=print_json,
                    train_time=test_time, batch_id=batch_id, output_layer_name=output_layer_name)
            self.evaluation_metric_runner.calculate_test_result(session=sess, test_time=test_time, json_type=print_json,
                                                                log=True)
        sess.close()
        if not RZTDL_CONFIG.CommonConfig.DRY_RUN:
            self.network_meta = NetworkMeta().load_meta(network_name=self.name,
                                                        load_path='/'.join(self.save_path.split('/')[:-3]) + '/')
            tf_summary.close_file_writer(file_writer_name=['train_writer', 'valid_writer'])
            RZTDL_STORE.save_metadata(path=meta_data_save_path, name=self.name,
                                      model_name=self.model_name)
            self.network_meta.update_meta(name=self.name, save_path='/'.join(self.save_path.split('/')[:-3]) + '/')
            self.network_meta.save_meta(save_path='/'.join(self.save_path.split('/')[:-3]))
            RZTDL_STORE.meta_data = OrderedDict()

    def _generate_batches(self, placeholders, data, batches, batch_size, mode):
        """
        | **@author:** Prathyush SP
        |
        | Generate Batches based on placeholders , data and batch parameters
        :param placeholders: Placeholders
        :param data: Data
        :param batches: Batches
        :param batch_size: Batch Size
        :return: Feed Dictionary for Session
        """
        feed_dict = OrderedDict()
        samples = len(data[[k for k in data.keys()][0]])
        if batches > 1:
            if batches > samples:
                raise SizeError("Batches can't be greater than total samples")
            batch_size = int(samples / batches)
        elif batch_size:
            if batch_size > samples:
                raise SizeError("Batch_size can't be greater than total samples")
            batches = int(samples / batch_size)
        else:
            batch_size = samples
        if mode == 'train':
            self.train_batch_size = batch_size
            self.train_batches = batches
        RZTDL_STORE.update_value_of_result_key(self.model_name, mode + "_batches", batches)
        RZTDL_STORE.update_value_of_result_key(self.model_name, mode + "_batch_size", batch_size)
        for holder in placeholders:
            feed_dict[holder[1]] = data[holder[0]]
        feed_dict = [feed_dict] if feed_dict == 0 else [
            {key: v[k:k + batch_size] for key, v in feed_dict.items()} for k in range(0, samples, batch_size)]
        return feed_dict

    def _create_tensor_metrics(self, sess, summary_op, batch_data, mode, batches):
        """
        | **@author:** Umesh Kumar
        |
        | Create tensor for all metrics

        :param sess:
        :param summary_op:
        :param batch_data:
        :return:
        """
        self.evaluation_metric_runner.run_metrics_for_epoch(session=sess, mode=mode, batches=batches)
        if mode == NETWORK_MODE.TRAIN:
            summary = sess.run(summary_op, feed_dict={**batch_data, **self.network_params,
                                                      **RZTDL_STORE.get_all_dropout_placeholders(
                                                          model_name=self.model_name,
                                                          mode=NETWORK_MODE.TRAIN)})
        else:
            summary = sess.run(summary_op, feed_dict={**batch_data, **self.network_params,
                                                      **RZTDL_STORE.get_all_dropout_placeholders(
                                                          model_name=self.model_name,
                                                          mode=NETWORK_MODE.PREDICTION)})
        return summary

    @staticmethod
    def create_model(json_path: str, model_params: Union[dict, OrderedDict]) -> Model:
        """
        | **@author:** Himaprasoon PT
        |
        | Get Model from JSON
        :json_path: JSON Path
        :model_params: Model Parameters
        :return: Model
        """
        prefix, suffix = "{", "}"
        # model = None
        global model
        code_from_parser = "import rztdl.dl\nglobal model" + call_parser(json_path)
        code_to_exec = reduce(lambda x, y: x.replace(prefix + y + suffix, str(model_params[y])), model_params,
                              code_from_parser)
        logger.info("Generated Code: \n{}".format(code_to_exec))
        exec(code_to_exec)
        # noinspection PyUnresolvedReferences
        return model

    # noinspection PyUnresolvedReferences
    def _train_validation(self, train_data, valid_data, test_data, learning_rate, placeholders, train_batches,
                          train_batch_size, valid_batches, valid_batch_size, test_batches, test_batch_size, save_path):
        """
        | **@author:** Prathyush SP
        |
        | Network Train Validation
        :param train_data: Train Data
        :param valid_data: Valid Data
        :param test_data: Test Data
        :param learning_rate: Learning Reate
        :param placeholders: Placeholders
        :param train_batches: Train Batches
        :param train_batch_size: Train Batch Size
        :param valid_batches: Valid Batches
        :param valid_batch_size: Valid Batch Size
        :param test_batches: Test Batches
        :param test_batch_size: Test Batch Size
        :param save_path: Save Path
        :return: Feed Dictionaries - [Train, Valid and Test (Batched Data) ]
        """
        self._create_directories(save_path=save_path)
        if isinstance(self.optimizer, str):
            if self.optimizer not in OptimizerTypes.__dict__.values():
                raise Exception("Not a valid Optimzier. Usage: OPTIMIZER.<>")
            lr_placeholder = tf.placeholder(dtype=tf.float32)
            tf.add_to_collection(lr_placeholder.name, lr_placeholder)
            # noinspection PyTypeChecker
            self.optimizer = Optimizer(cost=self.evaluation_metric_runner.evaluation_metrics_batch_tensors["cost"],
                                       learning_rate=lr_placeholder).switch(optimizer=self.optimizer)
            self.network_params[lr_placeholder] = learning_rate
            RZTDL_STORE.add_meta_data(model_name=self.model_name, key=ModelMetaConstant.TRAIN_OP,
                                      value=OrderedDict([('optimizer', self.optimizer.name),
                                                       ('lr_placeholder', lr_placeholder.name)]))
            tf.add_to_collection(self.optimizer.name, self.optimizer)

        # Train Placeholder - Feed Data Validation
        placeholder_keys = [placeholder[0] for placeholder in placeholders]
        if not len(placeholders) == len(train_data):
            for key in placeholder_keys:
                if key not in train_data.keys():
                    raise DataFeedException('Feed train data for "{}" Layer'.format(key))
            raise InsufficientData(
                'Insufficient data for the placeholders.  ' + str(len(train_data)) + ' : ' + str(len(placeholders)))
        if len(set([len(val) for val in train_data.values()])) > 1:
            initial_placeholder = next(iter(train_data))
            initial_length = len(train_data[initial_placeholder])
            for placeholder_name, values in train_data.items():
                if not initial_length == len(values):
                    raise SizeError("Size of {} {} doesn't match with Size of {} {} ".format(initial_placeholder,
                                                                                             train_data[
                                                                                                 initial_placeholder].shape,
                                                                                             placeholder_name,
                                                                                             values.shape))
        logger.info('Fetching Placeholders . . .')
        for key in train_data.keys():
            if key not in placeholder_keys:
                raise DataFeedException('Layer does not have a feed: "{}"'.format(key))
        logger.info('Creating Train Batches . . .')
        return_feeds = [self._generate_batches(data=train_data, placeholders=placeholders,
                                               batches=train_batches, batch_size=train_batch_size, mode="train")]

        # Valid Placeholder - Feed Data Validation
        if valid_data:
            for key in train_data.keys():
                if key not in valid_data.keys():
                    raise DataFeedException('Feed valid data for "{}" Layer'.format(key))
            for key in valid_data.keys():
                if key not in placeholder_keys:
                    raise DataFeedException('Layer does not have a feed: "{}"'.format(key))
            if len(set([len(val) for val in valid_data.values()])) > 1:
                raise SizeError("Size of {} {} doesn't match with Size Of {} {} ".format(placeholder_keys[0],
                                                                                         valid_data[
                                                                                             placeholder_keys[0]].shape,
                                                                                         placeholder_keys[1],
                                                                                         valid_data[placeholder_keys[
                                                                                             1]].shape))
            logger.info('Creating Valid Batches . . .')
            return_feeds.append(
                self._generate_batches(data=valid_data, placeholders=placeholders, batches=valid_batches,
                                       batch_size=valid_batch_size, mode="valid"))
        else:
            return_feeds.append([])

        # Test Placeholder - Feed Data Validation
        if test_data:
            for key in train_data.keys():
                if key not in test_data.keys():
                    raise DataFeedException('Feed valid data for "{}" Layer'.format(key))
            for key in test_data.keys():
                if key not in placeholder_keys:
                    raise DataFeedException('Layer does not have a feed: "{}"'.format(key))
            if len(set([len(val) for val in test_data.values()])) > 1:
                raise SizeError("Size of {} {} doesn't match with Size Of {} {} ".format(placeholder_keys[0],
                                                                                         test_data[
                                                                                             placeholder_keys[0]].shape,
                                                                                         placeholder_keys[1],
                                                                                         test_data[placeholder_keys[
                                                                                             1]].shape))
            logger.info('Creating Test Batches . . .')
            return_feeds.append(self._generate_batches(data=test_data, placeholders=placeholders, batches=test_batches,
                                                       batch_size=test_batch_size, mode="test"))
        else:
            return_feeds.append([])
        return return_feeds

    def get_network_save_path(self) -> str:
        """
        | **@author:** Prathyush SP
        |
        | Get Network Save Path
        :return: Network Save Path
        """
        return self.save_path

    @typechecked
    def _extract_checkpoint(self, filename: str) -> int:
        """
        | **@author:** Prathyush SP
        |
        | Extract checkpoint
        :param filename: Filename
        :return: checkpoint
        """
        return int(filename.split('.')[-2].split('-')[-1])

    @typechecked
    def _validate_checkpoint(self, file_list: list) -> int:
        """
        | **@author:** Prathyush SP
        |
        | Validate checkpoint
        :param file_list: File List
        :return: Existing checkpoint
        """
        checkpoint_file_dict = {}
        for f in file_list:
            checkp = self._extract_checkpoint(f)
            checkpoint_file_dict[checkp] = f
            if self.checkpoint_step == checkp:
                logger.debug('Checkpoint Found: {}'.format(f))
                return checkp
        logger.debug('Checkpoint not found. Using latest checkpoint: {}'.format(
            checkpoint_file_dict[max(list(checkpoint_file_dict.keys()))]))
        return max(list(checkpoint_file_dict.keys()))

    def persist_training(self, epoch: int, learning_rate: Union[int, float],
                         train_data: dict, evaluation_metrics: list = [], valid_data: dict = None,
                         test_data: dict = None, display_step: int = 10, train_batches: int = 1,
                         train_batch_size: int = 0, valid_batches: int = 1, valid_batch_size: int = 0,
                         test_batches: int = 1, test_batch_size: int = 0, batch_display_step: int = 0,
                         checkpoint_step: int = -1, run_id: int = -1,
                         print_json=False, load_path: str = None, save_path: str = None, tf_tracing: bool = False):
        """
        | **@author:** Prathyush SP
        |
        | Continuous Training
        :param checkpoint_step:
        :param evaluation_metrics: What metrics we have to calculate
        :param epoch: Epochs
        :param learning_rate: Learning Rate
        :param train_data: Train Data
        :param valid_data: Valid Data
        :param test_data: Test Data
        :param display_step: Display Step
        :param train_batches: Train Batches
        :param train_batch_size: Train Batch Size
        :param valid_batches: Valid Batches
        :param valid_batch_size: Valid Batch Size
        :param test_batches: Test Batches
        :param test_batch_size: Test Batch Size
        :param batch_display_step: Batch Display Step
        :param run_id: Run ID
        :param print_json: Print JSON
        :param load_path: Model Load Path
        :param save_path: Model Save Path
        :param tf_tracing: Tensorflow Tracing
        """
        self.name = self.name
        self.id = run_id
        self.checkpoint_step = checkpoint_step
        self.metadata, model_save_path = self._persist_training_validation(model_save_path=load_path, run_id=self.id)
        RZTDL_STORE.initialize()
        tf.reset_default_graph()
        model = Model(self.metadata[ModelMetaConstant.MODEL_NAME])
        session = tf.Session()
        logger.info('Model Save Path: ' + model_save_path)
        saver = tf.train.import_meta_graph(model_save_path + '.model-{}.meta'.format(self.checkpoint_step),
                                           clear_devices=True)
        saver.restore(sess=session, save_path=model_save_path + '.model-{}'.format(self.checkpoint_step))
        model = self._persist_training_model_build(model=model, metadata=self.metadata)
        self.network_params = OrderedDict()
        self.network_params[
            tf.get_collection(
                self.metadata[ModelMetaConstant.TRAIN_OP][ModelMetaConstant.TRAIN_OP_OPTIONS.LR_PLACEHOLDER])[
                0]] = learning_rate
        for k, v in self.metadata[ModelMetaConstant.DROPOUT_PLACEHOLDERS].items():
            RZTDL_STORE.add_dropout_placeholder(model_name=self.metadata[ModelMetaConstant.MODEL_NAME],
                                                placeholder_name=k, value=v)
        cost, optimizer = self._persist_training_train_op(self.metadata)
        self.train(epoch=epoch, learning_rate=learning_rate, model=model, cost=cost, optimizer=optimizer, sess=session,
                   saver=saver, train_data=train_data, valid_data=valid_data, test_data=test_data,
                   evaluation_metrics=evaluation_metrics, display_step=display_step, train_batches=train_batches,
                   train_batch_size=train_batch_size, valid_batches=valid_batches, valid_batch_size=valid_batch_size,
                   test_batches=test_batches, test_batch_size=test_batch_size, batch_display_step=batch_display_step,
                   print_json=print_json, save_path=save_path, init=False, tf_tracing=tf_tracing)

    def _persist_training_validation(self, model_save_path, run_id):
        """
        | **@author:** Prathyush SP
        |
        | Persist Train Validation
        :param model_save_path: Model Save Path
        :param run_id: Run ID
        :return: Metadata and Model Save Path
        """
        model_save_path = model_save_path if model_save_path and not model_save_path == '' else RZTDL_CONFIG.CommonConfig.PATH_RZTDL
        # todo:: Prathyush SP: Production vs Development Error
        if os.path.exists(path=model_save_path + '/' + self.name + '/model.meta'):
            metadata = File.read_json(path=model_save_path + '/' + self.name + '/model.meta',
                                      object_pairs_hook=OrderedDict)
            try:
                model_save_path += '/' + metadata[ModelMetaConstant.NETWORK_NAME] + '/' + metadata[
                    ModelMetaConstant.TIMESTAMP] + '/' + metadata[ModelMetaConstant.PATH][
                                       ModelMetaConstant.PATH_OPTIONS.DL_SAVE_PATH] + self.name
                list_of_files = glob.glob(model_save_path + '/*.meta')
                self.checkpoint_step = self._validate_checkpoint(file_list=list_of_files)
                model_save_path += self.name
            except KeyError:
                keys = [int(k) for k in metadata.keys()]
                metadata = metadata[str(run_id)] if run_id in keys else metadata[str(max(keys))]
                model_save_path += '/' + metadata[ModelMetaConstant.NETWORK_NAME] + '/' + metadata[
                    ModelMetaConstant.TIMESTAMP] + '/' + metadata[ModelMetaConstant.PATH][
                                       ModelMetaConstant.PATH_OPTIONS.DL_SAVE_PATH]
                list_of_files = glob.glob(model_save_path + '/*.meta')
                self.checkpoint_step = self._validate_checkpoint(file_list=list_of_files)
                model_save_path += self.name
        else:
            raise FileExistsError('Model meta file / Network not found')
        return metadata, model_save_path

    @staticmethod
    def _persist_training_model_build(model, metadata):
        """
        | **@author:** Prathyush SP
        |
        | Persist Training - Build Model from saves
        :param model: Model
        :param metadata: Metadata
        :return: Model
        """
        output_layer_name = list(metadata[ModelMetaConstant.LAYERS].keys())[-1]
        output_placeholder_name = list(metadata[ModelMetaConstant.PLACEHOLDERS].keys())[-1]
        model.final_layer = Layer
        model.final_layer.layer_output = metadata[ModelMetaConstant.LAYERS][output_layer_name]
        model.final_layer.layer_output_placeholder = \
            metadata[ModelMetaConstant.LAYERS][output_placeholder_name]
        model._model_complexity = metadata[ModelMetaConstant.MODEL_COMPLEXITY]
        model_name = metadata[ModelMetaConstant.MODEL_NAME]
        RZTDL_STORE.dag[model_name][ModelMetaConstant.PLACEHOLDERS] = metadata[ModelMetaConstant.PLACEHOLDERS]
        RZTDL_STORE.dag[model_name][ModelMetaConstant.PREDICTION_PLACEHOLDERS] = metadata[
            ModelMetaConstant.PREDICTION_PLACEHOLDERS]
        RZTDL_STORE.dag[model_name][ModelMetaConstant.DROPOUT_PLACEHOLDERS] = metadata[
            ModelMetaConstant.DROPOUT_PLACEHOLDERS]
        RZTDL_STORE.dag[model_name][ModelMetaConstant.MODEL_ARCHITECTURE] = metadata[
            ModelMetaConstant.MODEL_ARCHITECTURE]
        RZTDL_STORE.dag[model_name][ModelMetaConstant.METADATA][ModelMetaConstant.MODEL_COMPLEXITY] = metadata[
            ModelMetaConstant.MODEL_COMPLEXITY]
        RZTDL_STORE.dag[model_name][ModelMetaConstant.LAYERS] = metadata[ModelMetaConstant.LAYERS]
        RZTDL_STORE.dag[model_name][ModelMetaConstant.WEIGHTS] = metadata[ModelMetaConstant.WEIGHTS]
        RZTDL_STORE.dag[model_name][ModelMetaConstant.BIAS] = metadata[ModelMetaConstant.BIAS]
        RZTDL_STORE.dag[model_name][ModelMetaConstant.TRAIN_OP] = metadata[ModelMetaConstant.TRAIN_OP]
        RZTDL_STORE.dag[model_name][ModelMetaConstant.EVALUATION_METRICS_DICT] = metadata[
            ModelMetaConstant.EVALUATION_METRICS_DICT]
        RZTDL_STORE.dag[model_name][ModelMetaConstant.GRAPH] = tf.get_default_graph()
        return model

    @staticmethod
    def _persist_training_train_op(metadata):
        """
        | **@author:** Prathyush SP
        |
        | Persist Training Operation Loads
        :param metadata: Metadata
        :return: Cost, Optimizer
        """
        cost = metadata[ModelMetaConstant.COST]
        optimizer = \
            tf.get_collection(metadata[ModelMetaConstant.TRAIN_OP][ModelMetaConstant.TRAIN_OP_OPTIONS.OPTIMIZER])[0]
        return cost, optimizer
