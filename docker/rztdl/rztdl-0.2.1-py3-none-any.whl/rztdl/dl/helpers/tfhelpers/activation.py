# -*- coding: utf-8 -*-
"""
| **@created on**: 16/12/16,
| **@author**: Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Module contains various initializers
| 1. Zeros
| 2. Ones
| 3. Random Normal
| 4. Random Uniform
| 5. Constant
| 6. Orthogonal
| 7. Xavier
| 8. Truncated Normal
|
| **Sphinx Documentation Status:** Complete
|
| ..todo::
    --
"""

import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked
import rztdl.utils.string_constants as constants


class Activation(object):
    """
    | **@author**: Prathyush SP
    |
    | The class handles activation functions available in tensorflow
    | It consists of:
    | 1. Sigmoid Activation
    | 2. Softmax Activation
    | 3. Tanh Activation
    | 4. Relu Activation
    | 5. Relu6 Activation
    | 6. Elu Activation
    | 7. Softplus Activation
    | 8. Softsign Activation
    | 9. Identity Activation
    | 10. None Activation
    """

    @typechecked
    def __init__(self, input_tensor: Tensor):
        """
        :param input_tensor: Input Tensor
        """
        self.input_tensor = input_tensor
        pass

    def sigmoid(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Sigmoid Activation Function
        """
        return tf.nn.sigmoid(self.input_tensor)

    def softmax(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Softmax Activation Function
        """
        return tf.nn.softmax(self.input_tensor)

    def tanh(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Tanh Activation Function
        """
        return tf.nn.tanh(self.input_tensor)

    def relu(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Relu Activation Function
        """
        return tf.nn.relu(self.input_tensor)

    def crelu(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: CRelu Activation Function
        """
        return tf.nn.crelu(self.input_tensor)

    def relu6(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Relu6 Activation Function
        """
        return tf.nn.relu6(self.input_tensor)

    def elu(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Elu Activation Function
        """
        return tf.nn.elu(self.input_tensor)

    def softplus(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Softplus Activation Function
        """
        return tf.nn.softplus(self.input_tensor)

    def softsign(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Softsign Activation Function
        """
        return tf.nn.softsign(self.input_tensor)

    def identity(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Identity Activation Function
        """
        return tf.identity(self.input_tensor)

    def none(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        |This function is used for Layers which do not have activations
        :return: input
        """
        return self.input_tensor

    @typechecked
    def parse_activation(self, activation_type: constants.ActivationType):
        """
        | **@author**: Prathyush SP
        |
        | Parse Activations
        :param activation_type: Type of Activation
        :return: Tensor. Activation Function applied over a tensor
        """
        activation_switch = {
            constants.ActivationType.SIGMOID: self.sigmoid,
            constants.ActivationType.SOFTMAX: self.softmax,
            constants.ActivationType.TANH: self.tanh,
            constants.ActivationType.RELU: self.relu,
            constants.ActivationType.RELU6: self.relu6,
            constants.ActivationType.ELU: self.elu,
            constants.ActivationType.SOFT_PLUS: self.softplus,
            constants.ActivationType.SOFT_SIGN: self.softsign,
            constants.ActivationType.IDENTITY: self.identity,
            constants.ActivationType.CRELU: self.crelu,
            constants.ActivationType.NONE: self.none
        }
        return activation_switch[activation_type]()
