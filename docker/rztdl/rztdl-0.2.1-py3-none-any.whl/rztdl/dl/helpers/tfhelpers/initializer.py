# -*- coding: utf-8 -*-
"""
| **@created on**: 16/12/16,
| **@author**: Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Module contains various initializers
| 1. Zeros
| 2. Ones
| 3. Random Normal
| 4. Random Uniform
| 5. Constant
| 6. Orthogonal
| 7. Xavier
| 8. Truncated Normal
|
| **Sphinx Documentation Status:** Complete
|
| ..todo::
    --
"""
from typing import Union
from rztdl import RZTDL_CONFIG
import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked


class Initialization(object):
    """
    | **@author**: Prathyush SP
    |
    | The class handles initialization functions available in tensorflow
    | It consists of:
    | 1. Random Uniform Initialization
    | 2. Random Normal Initialization
    | 3. Zeros Initialization
    | 4. Ones Initialization
    | 5. Constant Initialization
    | 6. Orthogonal Initialization
    | 7. Truncated Normal Initialization
    | 8. Xavier Initialization
    """

    @typechecked
    def __init__(self, shape: list, seed: Union[int, None] = RZTDL_CONFIG.TensorflowConfig.GLOBAL_SEED,
                 dtype: Union[tf.DType, None] = RZTDL_CONFIG.TensorflowConfig.DTYPE):
        """
        :param shape: Matrix Shape
        :param seed: Seed
        :param dtype: Data Type
        """
        self.shape = shape
        self.seed = seed if seed else RZTDL_CONFIG.TensorflowConfig.GLOBAL_SEED
        self.dtype = dtype if dtype else RZTDL_CONFIG.TensorflowConfig.DTYPE

    def zeros(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        | Generate zeros for a given shape
        |
        :return: Zeros Function
        """
        return tf.initializers.zeros().__call__(shape=self.shape, dtype=self.dtype)

    def ones(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        | Generate ones for a given shape
        |
        :return: Ones Function
        """
        return tf.initializers.ones().__call__(shape=self.shape, dtype=self.dtype)

    def random_uniform(self, min_val: Union[float, int] = -1.0, max_val: Union[float, int] = 1.0) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Random Uniform Function
        """
        return tf.initializers.random_uniform(minval=min_val, maxval=max_val,
                                              seed=self.seed).__call__(shape=self.shape, dtype=self.dtype)

    def random_normal(self, mean: Union[float, int] = 0.0, std_dev: Union[float, int] = 1.0) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Random Normal Function
        """
        return tf.initializers.random_normal(mean=mean, stddev=std_dev,
                                             seed=self.seed).__call__(shape=self.shape, dtype=self.dtype)

    def constant(self, constant: float) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Constant Initializer
        """
        return tf.initializers.constant(value=constant).__call__(shape=self.shape, dtype=self.dtype)

    def orthogonal(self, gain: float = 1.0) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Orthogonal Initializer
        """
        return tf.initializers.orthogonal(gain=gain, seed=self.seed).__call__(shape=self.shape, dtype=self.dtype)

    def xavier(self, uniform: bool = True) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Xavier Initializer
        """
        return tf.contrib.layers.xavier_initializer(uniform=uniform, seed=self.seed, dtype=self.dtype)(shape=self.shape)

    def truncated_normal(self, mean: Union[float, int] = 0.0, std_dev: Union[float, int] = 1.0) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Truncated Normal Initializer
        """
        return tf.initializers.truncated_normal(mean=mean, stddev=std_dev,
                                                seed=self.seed).__call__(shape=self.shape, dtype=self.dtype)
