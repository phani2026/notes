# -*- coding: utf-8 -*-
"""
| **@created on**: 16/12/16,
| **@author**: Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Module contains various initializers
| 1. Zeros
| 2. Ones
| 3. Random Normal
| 4. Random Uniform
| 5. Constant
| 6. Orthogonal
| 7. Xavier
| 8. Truncated Normal
|
| **Sphinx Documentation Status:** Complete
|
| ..todo::
    --
"""
import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked
import rztdl.utils.string_constants as constants
from rztdl import RZTDL_STORE


class Regularisation(object):
    """
    | **@author**: Umesh Kumar
    |
    | Tensorflow Regularisation Techniques
    """

    @typechecked
    def __init__(self, input_tensor: Tensor, model_name, regularisation_params: dict = None):
        """

        :param input_tensor:
        """
        self.input_tensor = input_tensor
        self.model_name = model_name
        self.regularisation_params = regularisation_params
        self.validate()

    def l2_regularisation(self):
        """
        | **@author**: Umesh Kumar
        |
        | This is the  l2_regularisation of cost
        :return:
        """
        regulariser = 0
        for param in self.regularisation_params[constants.PARAMETERS.REGULARISATION_WEIGHTS]:
            regulariser += tf.nn.l2_loss(param)
        return tf.reduce_mean(tf.add(self.input_tensor,
                                     tf.multiply(self.regularisation_params[constants.PARAMETERS.REGULARISATION_BETA],
                                                 regulariser)))

    def l1_regularisation(self):
        """
        | **@author**: Umesh Kumar
        |
        | This is the  l1_regularisation of cost

        :return:
        """
        regulariser = 0
        for param in self.regularisation_params[constants.PARAMETERS.REGULARISATION_WEIGHTS]:
            regulariser += tf.reduce_sum(tf.abs(param))
        return tf.reduce_mean(tf.add(self.input_tensor,
                                     tf.multiply(self.regularisation_params[constants.PARAMETERS.REGULARISATION_BETA],
                                                 regulariser)))

    @typechecked
    def select_regulariser(self, regulariser: str) -> Tensor:
        """
        | **@author**: Umesh Kumar
        |
        :param regulariser: Regularisation string
        :return:
        """
        regulariser_switch = {
            constants.REGULARISATION.L2_REGULARISATION: lambda: self.l2_regularisation(),
            constants.REGULARISATION.L1_REGULARISATION: lambda: self.l1_regularisation(),
        }
        return regulariser_switch[regulariser]()

    def validate(self):
        """
        | **@author**: Umesh Kumar
        |
        Validate the Regularisation Parameters
        :return:
        """

        if self.regularisation_params[constants.PARAMETERS.REGULARISATION_WEIGHTS]:
            if isinstance(self.regularisation_params[constants.PARAMETERS.REGULARISATION_WEIGHTS][0], str):
                weights = []
                for layer in self.regularisation_params[constants.PARAMETERS.REGULARISATION_WEIGHTS]:
                    weights.append(RZTDL_STORE.get_weights(model_name=self.model_name, layer_name=layer))
                self.regularisation_params[constants.PARAMETERS.REGULARISATION_WEIGHTS] = weights
        else:
            self.regularisation_params[constants.PARAMETERS.REGULARISATION_WEIGHTS] = list(RZTDL_STORE.get_all_weights(
                model_name=self.model_name).values())
