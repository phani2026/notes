# -*- coding: utf-8 -*-
"""
| **@created on**: 16/12/16,
| **@author**: Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Module contains various initializers
| 1. Zeros
| 2. Ones
| 3. Random Normal
| 4. Random Uniform
| 5. Constant
| 6. Orthogonal
| 7. Xavier
| 8. Truncated Normal
|
| **Sphinx Documentation Status:** Complete
|
| ..todo::
    --
"""
from typing import Union
import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked
import rztdl.utils.string_constants as constants
from tensorflow import Operation


class Optimizer(object):
    """
    | **@author**: Prathyush SP
    |
    | The class handles optimizers available in tensorflow
    | It consists of:
    |
    | 1. Adam Optimizer
    | 2. Adam Grad Optimizer
    | 3. Gradient Descent Optimizer
    | 4. Momentum Optimizer
    | 5. RMSProp Optimizer

    """

    @typechecked
    def __init__(self, learning_rate: Union[float, int, Tensor], cost: Tensor, momentum: float = 0.0,
                 decay: float = 0.9,
                 epsilon: float = 1e-10):
        """
        :param learning_rate: Learning Rate
        :param cost: Cost Function
        :param momentum: Momentum Parameter
        :param decay: Decay Parameter
        :param epsilon: Epsilon Parameter
        """
        if isinstance(learning_rate, Tensor):
            if not learning_rate.op.node_def.op == 'Placeholder':
                raise Exception(
                    'Learning rate should be a tensor of type placeholder. found:{}'.format(type(learning_rate)))
        self.learning_rate = learning_rate
        self.cost = cost
        self.momentum = float(momentum)
        self.decay = decay
        self.epsilon = epsilon

    def adam_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: Adam Optimizer Function
        """
        return tf.train.AdamOptimizer(self.learning_rate).minimize(self.cost)

    def ada_gradient_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: AdaGrad Optimizer Function
        """
        return tf.train.AdagradOptimizer(self.learning_rate).minimize(self.cost)

    def gradient_descent_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: Gradient Descent Optimizer Function
        """
        return tf.train.GradientDescentOptimizer(self.learning_rate).minimize(self.cost)

    def momentum_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: Momentum Optimizer Function
        """
        return tf.train.MomentumOptimizer(self.learning_rate, self.momentum).minimize(self.cost)

    def rms_prop_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: RMSProp Optimizer Function
        """
        return tf.train.RMSPropOptimizer(self.learning_rate, decay=self.decay, epsilon=self.epsilon).minimize(self.cost)

    def ftrl_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: Ftrl Optimizer Function
        """
        return tf.train.FtrlOptimizer(learning_rate=self.learning_rate).minimize(self.cost)

    def proximal_adagrad_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: ProximalAdagradOptimizer Optimizer Function
        """
        return tf.train.ProximalAdagradOptimizer(learning_rate=self.learning_rate).minimize(self.cost)

    def proximal_gradient_descent_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: ProximalGradientDescentOptimizer Optimizer Function
        """
        return tf.train.ProximalGradientDescentOptimizer(learning_rate=self.learning_rate).minimize(self.cost)

    def ada_delta_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: AdadeltaOptimizer Optimizer Function
        """
        return tf.train.AdadeltaOptimizer(learning_rate=self.learning_rate).minimize(self.cost)

    def switch(self, optimizer: str):
        """
        | **@author**: Prathyush SP
        |
        | Optimiser Switch
        :param optimizer: Optimiser
        :return: Optimiser Operation
        """
        optimizer_switch = {
            constants.OptimizerTypes.ADA_GRADIENT: lambda: self.ada_gradient_optimizer(),
            constants.OptimizerTypes.ADAM: lambda: self.adam_optimizer(),
            constants.OptimizerTypes.MOMENTUM: lambda: self.momentum_optimizer(),
            constants.OptimizerTypes.GRADIENT_DESCENT: lambda: self.gradient_descent_optimizer(),
            constants.OptimizerTypes.FTRL: lambda: self.ftrl_optimizer(),
            constants.OptimizerTypes.PROXIMAL_ADAGRAD: lambda: self.proximal_adagrad_optimizer(),
            constants.OptimizerTypes.PROXIMAL_GRADIENT_DESCENT: lambda: self.proximal_gradient_descent_optimizer(),
            constants.OptimizerTypes.ADA_DELTA: lambda: self.ada_delta_optimizer()
        }
        return optimizer_switch[optimizer]()
