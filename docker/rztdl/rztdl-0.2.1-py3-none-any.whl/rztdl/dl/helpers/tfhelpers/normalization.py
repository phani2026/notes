# -*- coding: utf-8 -*-
"""
| **@created on**: 16/12/16,
| **@author**: Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Normalization Module
|
| ..todo::
    --
"""

__all__ = ['NormalizationLayer']

import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked
import rztdl.utils.string_constants as constants


# noinspection PyProtectedMember
class NormalizationLayer(object):
    """
    | **@author**: Umesh Kumar
    |
    | Tensorflow Normalisation dl_layer
    """

    def __init__(self, input_tensor):
        """

        :param input_tensor:
        """
        self.input_tensor = input_tensor

    @typechecked
    def l2_norm(self, norm_parameters: constants.NormalizationType) -> Tensor:
        """
        | **@author**: Umesh Kumar
        |
        | This is the  l2_normalization of tensorflow
        :param norm_parameters: Normalization Parameters
        :return: Normalized Tensor
        """
        return tf.nn.l2_normalize(self.input_tensor, norm_parameters[constants.NormalizationType._Parameters.DIM.name],
                                  norm_parameters[constants.NormalizationType._Parameters.EPSILON.name])

    @typechecked
    def lrn_norm(self, norm_parameters: constants.NormalizationType) -> Tensor:
        """
        | **@author**: Umesh Kumar
        |
        | This is the lrn_normalization(local response normalization) of tensorflow
        :param norm_parameters:
        :return: Normalized Tensor
        """
        return tf.nn.lrn(self.input_tensor,
                         depth_radius=norm_parameters[constants.NormalizationType._Parameters.DEPTH_RADIUS.name],
                         bias=norm_parameters[constants.NormalizationType._Parameters.BIAS.name],
                         alpha=norm_parameters[constants.NormalizationType._Parameters.ALPHA.name],
                         beta=norm_parameters[constants.NormalizationType._Parameters.BETA.name])

    @typechecked
    def parse_norm(self, norm_type: constants.NormalizationType):
        """
        | **@author**: Prathyush SP
        |
        | Parse Normalization Function
        :param norm_type: Normalization type
        :return: Normalized Tensor
        """
        norm_dict = {
            constants.NormalizationType._Parameters.LRN_NORM: self.lrn_norm,
            constants.NormalizationType._Parameters.L2_NORM: self.l2_norm
        }
        return norm_dict[norm_type[constants.NormalizationType._Parameters.NORM_TYPE.name]](norm_type)
