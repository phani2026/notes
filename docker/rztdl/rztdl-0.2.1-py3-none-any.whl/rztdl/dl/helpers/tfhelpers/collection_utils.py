# -*- coding: utf-8 -*-
"""
| **@created on**: 16/12/16,
| **@author**: Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Module contains various initializers
| 1. Zeros
| 2. Ones
| 3. Random Normal
| 4. Random Uniform
| 5. Constant
| 6. Orthogonal
| 7. Xavier
| 8. Truncated Normal
|
| **Sphinx Documentation Status:** Complete
|
| ..todo::
    --
"""
from typing import List
import tensorflow as tf
from tensorflow import Tensor


class TFCollection(object):
    """
    | **@author**: Prathyush SP
    |
    TFCollection Class used for dl_layer tapping
    """

    @staticmethod
    def add_to_collection(variables: dict):
        """
        | **@author**: Prathyush SP
        |
        | Add Tensors to Tensorflow Collection
        :param variables: Variables
        """
        for var_name, var_val in variables.items():
            tf.add_to_collection(var_name, var_val)

    @staticmethod
    def get_from_collection(variables: dict) -> List[Tensor]:
        """
        | **@author**: Prathyush SP
        |
        | Get Tensors form Tensorflow Collection
        :param variables: Variable List
        :return: List of Tensors
        """
        items = []
        for var_name in variables:
            items.append(tf.get_collection(var_name)[0])
        return items
