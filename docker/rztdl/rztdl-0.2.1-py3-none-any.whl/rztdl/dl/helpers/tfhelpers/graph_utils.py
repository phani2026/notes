# -*- coding: utf-8 -*-
"""
| **@created on**: 16/12/16,
| **@author**: Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Module contains various initializers
| 1. Zeros
| 2. Ones
| 3. Random Normal
| 4. Random Uniform
| 5. Constant
| 6. Orthogonal
| 7. Xavier
| 8. Truncated Normal
|
| **Sphinx Documentation Status:** Complete
|
| ..todo::
    --
"""
import tensorflow as tf
import os
import logging

logger = logging.getLogger(__name__)


class GraphUtils(object):
    """
    | **@author**: Prathyush SP
    |
    | Tensorflow Graph Utils
    """

    def __init__(self, graph=None):
        self._save_path = None
        self.graph = tf.get_default_graph() if graph is None else graph
        self.graph_def = self.graph.as_graph_def()

    @staticmethod
    def get_tensor(name: str):
        """
        | **@author:** Prathyush SP
        |
        | Fetch tensor from graph
        :param name: Tensor name
        """
        return tf.get_default_graph().get_tensor_by_name(name)

    @staticmethod
    def get_operation(name: str):
        """
        | **@author:** Prathyush SP
        |
        | Fetch operation from graph
        :param name: Operation name
        """
        return tf.get_default_graph().get_operation_by_name(name)

    @staticmethod
    def get_variable(name: str):
        """
        | **@author:** Prathyush SP
        |
        | Fetch Variables from Graph
        :param name: Variable name
        """
        return tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name)[0]

    @staticmethod
    def get_global_component(name: str):
        try:
            return tf.get_default_graph().get_tensor_by_name(name)
        except Exception as e:
            try:
                return tf.get_default_graph().get_operation_by_name(name)
            except Exception as e:
                import traceback
                raise Exception('Component [{}] is not a type of tensor or operation. \nException:\n\n'.format(name,
                                                                                                               traceback.print_exc()))

    @staticmethod
    def parents(op):
        return set(input.op for input in op.inputs)

    @staticmethod
    def children(op):
        return set(op for out in op.outputs for op in out.consumers())

    def get_graph(self):
        """Creates dictionary {node: {child1, child2, ..},..} for current
        TensorFlow graph. Result is compatible with networkx/toposort"""

        ops = tf.get_default_graph().get_operations()
        return {op: self.children(op) for op in ops}

    @staticmethod
    def print_tf_graph(graph):
        """Prints tensorflow graph in dictionary form."""
        for node in graph:
            for child in graph[node]:
                print("%s -> %s" % (node.name, child.name))

    def get_as_protobuff(self):
        """
        | **@author**: Prathyush SP
        |
        | Get Graph as protobuff object
        :return: Tensorflow Graph Def Object
        """
        return self.graph_def

    def get_as_str(self):
        """
        | **@author**: Prathyush SP
        |
        | Get GraphDef as String
        :return: Tensorflow Graph Def Object as String
        """
        return str(self.graph_def)

    def save_graph(self, save_path: str):
        """
        | **@author**: Prathyush SP
        |
        | Save Graph as event and Protobuf String Object
        :param save_path: Save Path
        :return: GraphUtils Object
        """
        self._save_path = save_path
        os.system('mkdir -p ' + self._save_path)
        logger.info('Fetching default graph')
        with open(self._save_path + '/graph.pb', 'w') as f: f.write(str(self.graph_def))
        logger.info('Writing graph.pbtxt in {}'.format(self._save_path))
        train_writer = tf.summary.FileWriter(self._save_path)
        train_writer.add_graph(self.graph)
        logger.info('Writing tensorflow event in {}'.format(self._save_path))
        return self

    def run_tensorboard(self, port: int = 6006):
        """
        | **@author**: Prathyush SP
        |
        | Run Tensorboard on saved event
        :param port: TCP Port
        """
        if self._save_path:
            logger.info('Launching tensorboard in {}'.format(self._save_path))
            os.system('tensorboard --logdir=' + self._save_path + ' --port=' + str(port))
        else:
            raise FileNotFoundError('Graph utils supports custom graph save and loading. . .')
