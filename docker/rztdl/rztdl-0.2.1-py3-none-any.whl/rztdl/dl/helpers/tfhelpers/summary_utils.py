# -*- coding: utf-8 -*-
"""
| **@created on**: 16/12/16,
| **@author**: Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Module contains various initializers
| 1. Zeros
| 2. Ones
| 3. Random Normal
| 4. Random Uniform
| 5. Constant
| 6. Orthogonal
| 7. Xavier
| 8. Truncated Normal
|
| **Sphinx Documentation Status:** Complete
|
| ..todo::
    --
"""
from typing import Union
import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked
from tensorflow import Variable


class TFSummaries(object):
    """
    | **@author**: Prathyush SP
    |
    | Tensorflow Summaries Class, used to create summaries in Tensorboard
    """

    def __init__(self):
        self.file_writers = {}

    @staticmethod
    def create_summary_op() -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        | Create a Summary operation
        :return: Tensorflow merged summaries
        """
        return tf.summary.merge_all()

    def create_file_writer(self, name: str, save_path: str, graph: tf.Graph):
        """
        | **@author**: Prathyush SP
        |
        | Create Tensorflow File Writer
        :param name: File Writer Name
        :param save_path: File save path
        :param graph: Session graph
        """
        self.file_writers[name] = tf.summary.FileWriter(logdir=save_path, graph=graph)

    @typechecked
    def close_file_writer(self, file_writer_name: Union[str, list]):
        """
        | **@author**: Prathyush SP
        |
        | Close file writer
        :param file_writer_name: File Writer
        :return:
        """
        if isinstance(file_writer_name, list):
            for fw in file_writer_name:
                self.file_writers[fw].close()
        else:
            self.file_writers[file_writer_name].close()

    def get_file_writer(self, file_writer_name: str) -> tf.summary.FileWriter:
        """
        | **@author**: Prathyush SP
        |
        | Get file writer
        :param file_writer_name: File Writer
        :return: Tensorflow File Writer
        """
        return self.file_writers[file_writer_name]

    @typechecked
    def add_run_metadata(self, file_writer_name: str, run_metadata, step: int):
        """
        | **@author**: Prathyush SP
        |
        | Add run metadata to a file writer
        :param file_writer_name: File Writer Name
        :param run_metadata: Run Metadata
        :param step: Global Step
        """
        self.file_writers[file_writer_name].add_run_metadata(run_metadata, 'step%03d' % step)

    @typechecked
    def add_summary(self, file_writer_name: str, summary_op, step: int):
        """
        | **@author**: Prathyush SP
        |
        | Add summary to a file writer
        :param file_writer_name: File Writer Name
        :param summary_op: Summary Operation
        :param step: Global Step
        """
        self.file_writers[file_writer_name].add_summary(summary_op, step)

    @typechecked
    def add_scalar_summary(self, name: str, tensor: Union[Tensor, Variable]):
        """
        | **@author**: Prathyush SP
        |
        | Add scalar summary
        :param name: Summary Name
        :param tensor: Tensor
        """
        tf.summary.scalar(name=name, tensor=tensor)

    @typechecked
    def create_variable_summaries(self, tensor: Union[Tensor, tf.Variable]):
        """
        | **@author**: Prathyush SP
        |
        | Attach Variable Summaries for Visualization using Tensorboard
        :param tensor: Tensor
        """
        with tf.name_scope('summaries'):
            mean = tf.reduce_mean(tensor)
            tf.summary.scalar('mean', mean)
            with tf.name_scope('stddev'):
                # noinspection PyUnresolvedReferences
                stddev = tf.sqrt(tf.reduce_mean(tf.square(tensor - mean)))
            tf.summary.scalar('stddev', stddev)
            tf.summary.scalar('max', tf.reduce_max(tensor))
            tf.summary.scalar('min', tf.reduce_min(tensor))
            tf.summary.histogram('histogram', tensor)
