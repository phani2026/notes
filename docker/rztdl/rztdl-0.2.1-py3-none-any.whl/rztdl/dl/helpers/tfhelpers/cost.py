# -*- coding: utf-8 -*-
"""
| **@created on**: 16/12/16,
| **@author**: Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Module contains various initializers
| 1. Zeros
| 2. Ones
| 3. Random Normal
| 4. Random Uniform
| 5. Constant
| 6. Orthogonal
| 7. Xavier
| 8. Truncated Normal
|
| **Sphinx Documentation Status:** Complete
|
| ..todo::
    --
"""
from typing import Union
import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked
import rztdl.utils.string_constants as constants
from numpy import ndarray


class Cost(object):
    """
    | **@author**: Prathyush SP
    |
    | The class handles cost methodologies available in tensorflow
    | It consists of:
    | 1. Cross Entropy
    | 2. Mean Square Error
    | 3. Simple Cross Entropy
    | 4. Softmax Cross Entropy

    """

    @typechecked
    def __init__(self, actual_output: Union[Tensor, list, ndarray], predicted_output: Union[Tensor, list, ndarray]):
        """

        :param actual_output: Labelled Output
        :param predicted_output: Predicted Output
        """
        self.y = actual_output
        self.yhat = predicted_output

    def cross_entropy(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: cross entropy cost function
        """
        # noinspection PyTypeChecker,PyUnresolvedReferences
        with tf.name_scope('cost'):
            return tf.reduce_mean(((self.y * tf.log(self.yhat)) + ((1 - self.y) * tf.log(1.0 - self.yhat))) * -1)

    def mean_square_error(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: mean square error cost function
        """
        with tf.name_scope('cost'):
            return tf.reduce_mean(tf.square(self.y - self.yhat))

    @typechecked
    def simple_cross_entropy(self, reduction_indices: int = 1) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :param reduction_indices: Reduction Indices
        :return: simple cross entropy cost function
        """
        # noinspection PyUnresolvedReferences
        with tf.name_scope('cost'):
            return tf.reduce_mean(-tf.reduce_sum(self.y * tf.log(self.yhat), reduction_indices=reduction_indices))

    def softmax_cross_entropy(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: softmax cost function
        """
        with tf.name_scope('cost'):
            return tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=self.yhat, labels=self.y))

    def sigmoid_cross_entropy(self):
        """
        | **@author**: Prathyush SP
        |
        :return: Simple cost function
        """
        with tf.name_scope('cost'):
            return tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=self.yhat, labels=self.y))

    def weighted_cross_entropy(self, pos_weight: float):
        """
        | **@author**: Prathyush SP
        |
        :return: Weighted cross entopy cost function
        """
        # todo: Prathyush SP - Support for dynamic pos_weights
        with tf.name_scope('cost'):
            return tf.reduce_mean(
                tf.nn.weighted_cross_entropy_with_logits(logits=self.yhat, targets=self.y, pos_weight=pos_weight))

    def switch(self, cost: str) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :param cost: Cost String
        :return:
        """
        cost_switch = {
            constants.CostType.MEAN_SQUARE_ERROR: lambda: self.mean_square_error(),
            constants.CostType.CROSS_ENTROPY: lambda: self.cross_entropy(),
            constants.CostType.SIMPLE_CROSS_ENTROPY: lambda: self.simple_cross_entropy(),
            constants.CostType.SOFTMAX_CROSS_ENTROPY: lambda: self.softmax_cross_entropy(),
            constants.CostType.SIGMOID_CROSS_ENTROPY: lambda: self.sigmoid_cross_entropy()
        }
        return cost_switch[cost]()
