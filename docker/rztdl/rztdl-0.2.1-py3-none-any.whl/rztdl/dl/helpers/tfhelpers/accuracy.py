# -*- coding: utf-8 -*-
"""
| **@created on**: 16/12/16,
| **@author**: Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Module contains various accuracy functions
| 1. Simple
| 2. Binary
| 3. Softmax
| 4. Regression
|
| **Sphinx Documentation Status:** Complete
|
| ..todo::
    --
"""
from typeguard import typechecked
import rztdl.utils.string_constants as constants
from numpy import ndarray
from collections import OrderedDict
import numpy as np


class Accuracy(object):
    """
    | **@author**: Prathyush SP
    |
    | The class handles initialization functions available in tensorflow
    | It consists of:
    | 1. Simple Accuracy - Uses Threshold to map between 0 - 1 and compares with labelled data
    | 2. Binary Accuracy - Used to test the accuracy of a particular output label
    .. todo::
        Prathyush SP
            * Modify Accuracy functions to return unified output
            * Implement Accuracy Function for Regression
    """

    # todo :: Prathyush SP - Modify Accuracy functions to return unified output
    # todo :: Prathyush SP - Implement Accuracy Function for Regression
    @typechecked
    def __init__(self, predicted_data: ndarray, labelled_data: ndarray, threshold: float = 0.5):
        """
        :param predicted_data: Predicted Data
        :param labelled_data: Labelled Data
        :param threshold: Threshold value
        """
        self.predicted_data = predicted_data
        self.labelled_data = labelled_data
        self.threshold = threshold

    # noinspection PyTypeChecker
    def simple(self) -> OrderedDict:
        """
        | @author: Prathyush SP
        |
        | The function is used to calculate simple accuracy with the help of threshold and simple list comparison
        |
        :return: accuracy in percentage, accuracy count, error count
        """
        accurate_count = 0.0
        self.predicted_data = np.reshape(self.predicted_data, newshape=[-1, ]).tolist()
        self.labelled_data = np.reshape(self.labelled_data, newshape=[-1, ]).tolist()
        if not len(self.predicted_data) == len(self.labelled_data):
            raise Exception("Exception: length of predicted_data and labelled_data are not similar. {}:{}".format(
                len(self.predicted_data), len(self.labelled_data)))
        for p, l in zip(self.predicted_data, self.labelled_data):
            if (1 if p >= self.threshold else 0) == (1 if l >= self.threshold else 0):
                accurate_count += 1
        accuracy = float(accurate_count / float(len(self.predicted_data)) * 100)
        error_count = len(self.predicted_data) - accurate_count
        return OrderedDict([('accuracy', "{0:.2f}".format(accuracy)), ('accurate_samples', accurate_count),
                            ('error_samples', error_count)])

    @typechecked
    def binary(self, value: float = 0.0) -> OrderedDict:
        """
        | **@author**: Prathyush SP
        |
        | Method used to test the accuracy of a particular output label
        |
        :param value: Label to be tested
        :return: accuracy in percentage, accuracy count, error count
        """
        if not isinstance(value, float):
            raise Exception("Binary Value should be an instance of float. Found:", type(value))
        accurate_count = 0.0
        if not len(self.predicted_data) == len(self.labelled_data):
            raise Exception("Exception: length of predicted_data and labelled_data are not similar")
        data_count = 0
        for p, l in zip(self.predicted_data, self.labelled_data):
            ret_value = [1] if p > [self.threshold] else [0]
            if ret_value == [value]:
                data_count += 1
                if ret_value == ([1] if l > [self.threshold] else [0]):
                    accurate_count += 1
        accuracy = float(accurate_count / float(data_count) * 100) if not float(data_count) == 0 else 0
        error_count = data_count - accurate_count
        return OrderedDict([('accuracy', "{0:.2f}".format(accuracy)), ('accurate_samples', accurate_count),
                            ('error_samples', error_count)])

    def softmax(self) -> OrderedDict:
        """
        | **@author**: Prathyush SP
        |
        | Method used to calculate accuracy of a multi-variate output
        |
        :return: accuracy in percentage, accuracy count, error count
        """
        accurate_count = 0.0

        if np.isnan(self.predicted_data).any() is None:
            raise Exception("Predicted data is None")
        if np.isnan(self.labelled_data).any() is None:
            raise Exception("Labelled data is None")
        if not isinstance(self.predicted_data, np.ndarray):
            raise Exception("Predicted Data is not an Numpy Array object")
        if not isinstance(self.labelled_data, np.ndarray):
            raise Exception("Labelled Data is not an Numpy Array object")
        if not len(self.predicted_data) == len(self.labelled_data):
            raise Exception("Exception: length of predicted_data and labelled_data are not similar")
        for p, l in list(zip(self.predicted_data, self.labelled_data)):
            if np.argmax(p) == np.argmax(l):
                accurate_count += 1
        accuracy = float(accurate_count / float(len(self.predicted_data)) * 100)
        error_count = len(self.predicted_data) - accurate_count
        return OrderedDict([('accuracy', "{0:.2f}".format(accuracy)), ('accurate_samples', accurate_count),
                            ('error_samples', error_count)])

    # noinspection PyTypeChecker
    def regression(self) -> OrderedDict:
        """
        | **@author**: Prathyush SP
        |
        | Accuracy function for regression problem
        |
        :return:
        """
        self.predicted_data = np.reshape(self.predicted_data, newshape=[-1, ]).tolist()
        self.labelled_data = np.reshape(self.labelled_data, newshape=[-1, ]).tolist()
        accurate_count = sum([1 if int(i) in range(int(j - self.threshold), int(j + self.threshold)) else 0 for i, j in
                              (zip(self.predicted_data, self.labelled_data))])
        accuracy = float(accurate_count / float(len(self.predicted_data)) * 100)
        error_count = len(self.predicted_data) - accurate_count
        return OrderedDict([('accuracy', "{0:.2f}".format(accuracy)), ('accurate_samples', accurate_count),
                            ('error_samples', error_count)])

    @typechecked
    def switch(self, accuracy: str) -> OrderedDict:
        """
        | **@author**: Prathyush SP
        |
        :param accuracy: Accuracy String
        :return:
        """
        accuracy_switch = {
            constants.ACCURACY.SIMPLE: lambda: self.simple(),
            constants.ACCURACY.BINARY: lambda: self.binary(),
            constants.ACCURACY.SOFTMAX: lambda: self.softmax(),
            constants.ACCURACY.REGRESSION: lambda: self.regression()
        }
        return accuracy_switch[accuracy]()
