# -*- coding: utf-8 -*-
"""
| **@created on**: 16/12/16,
| **@author**: Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Module contains various initializers
| 1. Zeros
| 2. Ones
| 3. Random Normal
| 4. Random Uniform
| 5. Constant
| 6. Orthogonal
| 7. Xavier
| 8. Truncated Normal
|
| **Sphinx Documentation Status:** Complete
|
| ..todo::
    --
"""
from typing import Union
import tensorflow as tf
from typeguard import typechecked
from tensorflow import Operation
from tensorflow.python.training import optimizer as tfoptimizer
from tensorflow.python.client import timeline


class TFTimeline(object):
    """
    | **@author**: Prathyush SP
    |
    | Timeline Class used to create Timeline object for Chrome Tracing
    """

    def __init__(self):
        self.run_options = tf.RunOptions(trace_level=tf.RunOptions.FULL_TRACE)
        self.run_metadata = tf.RunMetadata()
        self._timeline = None

    @typechecked
    def run(self, session: Union[tf.InteractiveSession, tf.Session],
            optimizer_op: Union[Operation, tfoptimizer.Optimizer, str], feed_dict: dict, return_json: bool = False):
        """
        | **@author**: Prathyush SP
        |
        | Run Time line operation
        :param session: Tensorflow Session Object
        :param optimizer_op: Optimizer Operation
        :param feed_dict: Feed Dictionary for Optimizer
        :param return_json: Bool
        :return: Union[dict, Timeline]
        """
        session.run(optimizer_op, feed_dict=feed_dict, options=self.run_options, run_metadata=self.run_metadata)
        self._timeline = timeline.Timeline(self.run_metadata.step_stats).generate_chrome_trace_format()
        if return_json:
            return self._timeline
        else:
            return self

    def get_run_options(self):
        """
        | **@author**: Prathyush SP
        |
        | Get RunOptions
        :return: Tensorfow RunOptions
        """
        return self.run_options

    def get_run_metadata(self):
        """
        | **@author**: Prathyush SP
        |
        | Get RunMeradata
        :return: Tensorflow RunMetadata
        """
        return self.run_metadata

    @typechecked
    def save(self, save_path: str):
        """
        | **@author**: Prathyush SP
        |
        | Save Timeline json
        :param save_path: Save Path
        """
        open(r'' + save_path, 'w').write(self._timeline)
