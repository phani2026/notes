# -*- coding: utf-8 -*-
"""
| **@created on**: 03/05/18,
| **@author**: Umesh Kumar,
| **@version:** v0.1.9
|
| **Description:**
| RNN Cell Module contains different rnn cells like
| 1. BasicRNN cell
| 2. BasicLSTM cell
| 3. LSTM cell
| 4. GRU cell
| 5. MultiRNN cell
|
| **Sphinx Documentation Status:** Complete
|
| ..todo::
    --
"""
import tensorflow as tf
from typeguard import typechecked

import rztdl.utils.string_constants as constants


# noinspection PyProtectedMember
class RNNCells(object):
    """
    | **@author**: Umesh Kumar
    |
    | The class handles rnn cells of tensorflow
    | It consists of:
    | 1. BasicLSTM cell
    | 2. BasicRNN cell
    | 3. LSTM cell
    | 4. GRU cell
    | 5. MultiRNN cell

    """

    def __init__(self):
        """
        | **@author**: Umesh Kumar
        |
        """
        pass

    @staticmethod
    @typechecked
    def basic_lstm_cell(cell_parameters: dict):
        """
        | **@author**: Umesh Kumar
        |
        :param cell_parameters : Cell Parameters in a dictionary
        :return: tensorflow basiclstm cell object
        """
        with tf.name_scope('basic_lstm_cell'):
            return tf.nn.rnn_cell.BasicLSTMCell(num_units=cell_parameters[constants.RNNCell._Parameters.NUM_UNITS.name],
                                                reuse=None,
                                                activation=activation_switch(
                                                    cell_parameters[constants.RNNCell._Parameters.ACTIVATION.name]),
                                                forget_bias=cell_parameters[
                                                    constants.RNNCell._Parameters.FORGET_BIAS.name])

    @staticmethod
    @typechecked
    def basic_rnn_cell(cell_parameters: dict):
        """
        | **@author**: Umesh Kumar
        |
        :param cell_parameters : Cell Parameters in a dictionary
        :return: tensorflow basicrnn cell object
        """
        with tf.name_scope('basic_rnn_cell'):
            return tf.nn.rnn_cell.BasicRNNCell(num_units=cell_parameters[constants.RNNCell._Parameters.NUM_UNITS.name],
                                               activation=activation_switch(
                                                   cell_parameters[constants.RNNCell._Parameters.ACTIVATION.name]),
                                               reuse=None)

    @staticmethod
    @typechecked
    def lstm_cell(cell_parameters: dict):
        """
        | **@author**: Umesh Kumar
        |
        :param cell_parameters : Cell Parameters in a dictionary
        :return: tensorflow lstm cell object
        """
        with tf.name_scope('lstm_cell'):
            return tf.nn.rnn_cell.LSTMCell(num_units=cell_parameters[constants.RNNCell._Parameters.NUM_UNITS.name],
                                           use_peepholes=cell_parameters[
                                               constants.RNNCell._Parameters.USE_PEEPHOLES.name],
                                           cell_clip=cell_parameters[constants.RNNCell._Parameters.CELL_CLIP.name],
                                           initializer=cell_parameters[constants.RNNCell._Parameters.INITIALIZER.name],
                                           num_proj=cell_parameters[constants.RNNCell._Parameters.NUM_PROJ.name],
                                           proj_clip=cell_parameters[constants.RNNCell._Parameters.PROJ_CLIP.name],
                                           num_unit_shards=cell_parameters[
                                               constants.RNNCell._Parameters.NUM_UNIT_SHARDS.name],
                                           num_proj_shards=cell_parameters[
                                               constants.RNNCell._Parameters.NUM_PROJ_SHARDS.name],
                                           forget_bias=cell_parameters[constants.RNNCell._Parameters.FORGET_BIAS.name],
                                           activation=activation_switch(
                                               cell_parameters[constants.RNNCell._Parameters.ACTIVATION.name]),
                                           reuse=None)

    # noinspection PyProtectedMember
    @staticmethod
    @typechecked
    def gru_cell(cell_parameters: dict):
        """
        | **@author**: Umesh Kumar
        |
        :param cell_parameters : Cell Parameters in a dictionary
        :return: tensorflow gru cell object
        """
        with tf.name_scope('gru_cell'):
            return tf.nn.rnn_cell.GRUCell(num_units=cell_parameters[constants.RNNCell._Parameters.NUM_UNITS.name],
                                          activation=activation_switch(
                                              cell_parameters[constants.RNNCell._Parameters.ACTIVATION.name]),
                                          reuse=None,
                                          kernel_initializer=cell_parameters[
                                              constants.RNNCell._Parameters.KERNEL_INITIALIZER.name],
                                          bias_initializer=cell_parameters[
                                              constants.RNNCell._Parameters.BIAS_INITIALIZER.name])

    @staticmethod
    @typechecked
    def multi_rnn_cell(cells: list):
        """
        | **@author**: Umesh Kumar
        |
        :param cells : RNN cells for Multicell
        :return: tensorflow multi rnn cell
        """
        with tf.name_scope('multi_rnn_cell'):
            return tf.nn.rnn_cell.MultiRNNCell(cells=cells)

    # noinspection PyProtectedMember
    @typechecked
    def switch(self, rnn_cell: str, cell_parameters: dict):
        """
        | **@author**: Umesh Kumar
        |
        :param rnn_cell: RNN cell type
        :param cell_parameters:  Cell Parameters in a dictionary

        :return:
        """
        rnn_cell_switch = {
            constants.RNNCell._Parameters.BASIC_LSTM_CELL.name: lambda: self.basic_lstm_cell(
                cell_parameters=cell_parameters),
            constants.RNNCell._Parameters.BASIC_RNN_CELL.name: lambda: self.basic_rnn_cell(
                cell_parameters=cell_parameters),
            constants.RNNCell._Parameters.LSTMCELL.name: lambda: self.lstm_cell(cell_parameters=cell_parameters),
            constants.RNNCell._Parameters.GRUCELL.name: lambda: self.gru_cell(cell_parameters=cell_parameters)
        }
        return rnn_cell_switch[rnn_cell]()


@typechecked
def activation_switch(activation: constants.ActivationType):
    """
    | **@author**: Umesh Kumar
    |
    :param activation: Activation Function
    :return:
    """
    activation_dict = {
        constants.ActivationType.SIGMOID: tf.nn.sigmoid,
        constants.ActivationType.SOFTMAX: tf.nn.softmax,
        constants.ActivationType.TANH: tf.nn.tanh,
        constants.ActivationType.RELU: tf.nn.relu,
        constants.ActivationType.RELU6: tf.nn.relu6,
        constants.ActivationType.ELU: tf.nn.elu,
        constants.ActivationType.SOFT_PLUS: tf.nn.softplus,
        constants.ActivationType.SOFT_SIGN: tf.nn.softsign,
        constants.ActivationType.CRELU: tf.nn.crelu,
        constants.ActivationType.IDENTITY: tf.identity,
        constants.ActivationType.NONE: tf.identity,
    }
    return activation_dict[activation]
