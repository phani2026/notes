# -*- coding: utf-8 -*-
"""
| **@created on**: 10/05/18,
| **@author**: Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Module contains various initializers
| 1. Zeros
| 2. Ones
| 3. Random Normal
| 4. Random Uniform
| 5. Constant
| 6. Orthogonal
| 7. Xavier
| 8. Truncated Normal
|
| **Sphinx Documentation Status:** Complete
|
| ..todo::
    --
"""
from typing import Union
from rztdl import RZTDL_CONFIG
import tensorflow as tf
from tensorflow import Tensor
from typeguard import typechecked
import rztdl.utils.string_constants as constants


class Morpher(object):
    """
    | **@author**: Prathyush SP
    |
    | The class handles initialization functions available in tensorflow
    | It consists of:
    | 1. Ones Like Generator
    | 2. Zeros Like Generator
    """

    @typechecked
    def __init__(self, input_tensor: Tensor):
        """
        :param input_tensor: Input Tensor        
        """
        self.input_tensor = input_tensor

    def zeros_like(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        | Generate zeros for a given tensor
        |
        :return: Zeros Function
        """
        return tf.zeros_like(tensor=self.input_tensor)

    def ones_like(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        | Generate ones for a given tensor
        |
        :return: Ones Function
        """
        return tf.ones_like(tensor=self.input_tensor)

    def parse_morph(self, morph_type: constants.MorphType):
        """
        | **@author**: Prathyush SP
        |
        | Parse Type
        |
        :param morph_type:
        :return: Morph Tensor
        """
        morph_dict = {
            constants.MorphType.ONES_LIKE: self.ones_like,
            constants.MorphType.ZEROS_LIKE: self.zeros_like
        }
        return morph_dict[morph_type]()
