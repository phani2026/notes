# -*- coding: utf-8 -*-
"""
| **@created on**: 16/12/16,
| **@author**: Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Module contains various initializers
| 1. Zeros
| 2. Ones
| 3. Random Normal
| 4. Random Uniform
| 5. Constant
| 6. Orthogonal
| 7. Xavier
| 8. Truncated Normal
|
| **Sphinx Documentation Status:** Complete
|
| ..todo::
    --
"""
from typeguard import typechecked
import rztdl.utils.string_constants as constants
from rztdl import RZTDL_CONFIG
import logging
import os
from rztdl.utils.pyutils import File

logger = logging.getLogger(__name__)


class TensorBoard(object):
    """
    | **@author**: Prathyush SP
    |
    | Tensorboard Util
    """

    @typechecked
    def __init__(self, network_name: str = None, logdir: str = None, port: int = 6006, run_id=-1):
        """
        :param logdir: used to specify the log directory defined by the SummaryWriter
        :param port: port configuration [default: 6006]
        """
        self._network_name = network_name
        self._log_dir = logdir
        self._port = port
        self.id = run_id
        self.validate()

    def start_tensorboard(self):
        """
        | **@author**: Prathyush SP
        |
        | The function starts the tensorboard using specified parameters
        """
        if not os.path.exists(self._log_dir):
            os.system("mkdir -p " + self._log_dir)
        os.system("cd " + self._log_dir + " && ls -tp | grep -v '/$' | tail -n +2 | xargs -I {} rm -- {}")
        os.system("tensorboard --logdir " + self._log_dir + " --port " + str(self._port))

    def validate(self):
        if self._network_name is None and self._log_dir is None:
            raise Exception('Network Name / Log Dir is not specified')
        if self._network_name:
            if File.is_exist(path=RZTDL_CONFIG.CommonConfig.PATH_RZTDL + '/' + self._network_name + '/model.meta'):
                metadata = File.read_json(
                    path=RZTDL_CONFIG.CommonConfig.PATH_RZTDL + '/' + self._network_name + '/model.meta')
                if self.id in metadata:
                    metadata = metadata[self.id]
                else:
                    logger.error('Run id not found in model metadata. Fetching the latest id')
                    metadata = metadata[sorted(metadata.keys())[-1]]
                self._log_dir = RZTDL_CONFIG.CommonConfig.PATH_RZTDL + metadata[
                    constants.ModelMetaConstant.NETWORK_NAME] + '/' + \
                                metadata[constants.ModelMetaConstant.TIMESTAMP] + \
                                metadata[constants.ModelMetaConstant.PATH][
                                    constants.ModelMetaConstant.PATH_OPTIONS.GRAPH_SAVE_PATH]
            else:
                raise FileExistsError('Model meta file / Network not found')
