# -*- coding: utf-8 -*-
"""
| **@created on**: 16/12/16,
| **@author**: Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Module contains various utilities required to build a deeplearning network using *Tensorflow*
| 1. Cost Utils
| 2. Initialization Utils
| 3. Optimizer Utils
| 4. Activation Utils
| 5. TFCollection
| 6. Switch [Cost and Optimizer Switches]
| 7. Accuracy Utils
| 8. Tensorflow Timeline
| 9. Tensorflow Summaries
| 10. Tensorboard Utils
| 11. Pool Utils
|
| **Sphinx Documentation Status:** Complete
|
| ..todo::
    --
"""

import logging
import os
from collections import OrderedDict
from typing import Union, List
import numpy as np
import tensorflow as tf
from rztdl import RZTDL_CONFIG, RZTDL_DAG
from tensorflow import Tensor
from numpy import ndarray
from rztdl.utils.pyutils import File
import rztdl.utils.string_constants as constants
from tensorflow.python.client import timeline
from tensorflow.python.framework.ops import Operation
from tensorflow.python.ops.variables import Variable
from tensorflow.python.training import optimizer as tfoptimizer
from typeguard import typechecked

logger = logging.getLogger(__name__)


class Cost(object):
    """
    | **@author**: Prathyush SP
    |
    | The class handles cost methodologies available in tensorflow
    | It consists of:
    | 1. Cross Entropy
    | 2. Mean Square Error
    | 3. Simple Cross Entropy
    | 4. Softmax Cross Entropy

    """

    @typechecked
    def __init__(self, actual_output: Tensor, predicted_output: Union[Tensor, list, ndarray]):
        """

        :param actual_output: Labelled Output
        :param predicted_output: Predicted Output
        """
        self.y = actual_output
        self.yhat = predicted_output

    def cross_entropy(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: cross entropy cost function
        """
        # noinspection PyTypeChecker,PyUnresolvedReferences
        with tf.name_scope('cost'):
            return tf.reduce_mean(((self.y * tf.log(self.yhat)) + ((1 - self.y) * tf.log(1.0 - self.yhat))) * -1)

    def mean_square_error(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: mean square error cost function
        """
        with tf.name_scope('cost'):
            return tf.reduce_mean(tf.square(self.y - self.yhat))

    @typechecked
    def simple_cross_entropy(self, reduction_indices: int = 1) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :param reduction_indices: Reduction Indices
        :return: simple cross entropy cost function
        """
        # noinspection PyUnresolvedReferences
        with tf.name_scope('cost'):
            return tf.reduce_mean(-tf.reduce_sum(self.y * tf.log(self.yhat), reduction_indices=reduction_indices))

    def softmax_cross_entropy(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: softmax cost function
        """
        with tf.name_scope('cost'):
            return tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=self.yhat, labels=self.y))

    def sigmoid_cross_entropy(self):
        """
        | **@author**: Prathyush SP
        |
        :return: Simple cost function
        """
        with tf.name_scope('cost'):
            return tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=self.yhat, labels=self.y))

    def weighted_cross_entropy(self):
        """
        | **@author**: Prathyush SP
        |
        :return: Weighted cross entopy cost function
        """
        # todo: Prathyush SP - Support for dynamic pos_weights
        with tf.name_scope('cost'):
            return tf.reduce_mean(
                tf.nn.weighted_cross_entropy_with_logits(logits=self.yhat, targets=self.y, pos_weight=10))

    def switch(self, cost: str) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :param cost: Cost String
        :return:
        """
        cost_switch = {
            constants.COST.MEAN_SQUARE_ERROR: lambda: self.mean_square_error(),
            constants.COST.CROSS_ENTROPY: lambda: self.cross_entropy(),
            constants.COST.SIMPLE_CROSS_ENTROPY: lambda: self.simple_cross_entropy(),
            constants.COST.SOFTMAX_CROSS_ENTROPY: lambda: self.softmax_cross_entropy(),
            constants.COST.SIGMOID_CROSS_ENTROPY: lambda: self.sigmoid_cross_entropy(),
            constants.COST.WEIGHTED_CROSS_ENTOPY: lambda: self.weighted_cross_entropy()
        }
        return cost_switch[cost]()


class Initialization(object):
    """
    | **@author**: Prathyush SP
    |
    | The class handles initialization functions available in tensorflow
    | It consists of:
    | 1. Random Uniform Initialization
    | 2. Random Normal Initialization
    | 3. Zeros Initialization
    | 4. Ones Initialization
    """

    @typechecked
    def __init__(self, shape: list, min_val: Union[float, int] = -1.0, max_val: Union[float, int] = 1.0,
                 std_dev: Union[float, int] = 1.0,
                 mean: Union[float, int] = 0.0, seed: int = None):
        """
        :param shape: Matrix Shape
        :param min_val: Minimum Value [Default: -1]
        :param max_val: Maximum Value [Default: 1]
        :param std_dev: Standard Deviation [Default: 1.0]
        :param mean: Mean [Default: 0.0]
        """
        self.shape = shape
        self.min_val = min_val
        self.max_val = max_val
        self.std_dev = std_dev
        self.mean = mean
        self.seed = seed

    def zeros(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        | Generate zeros for a given shape
        |
        :return: Zeros Function
        """
        return tf.zeros(shape=self.shape, dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE)

    def ones(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        | Generate ones for a given shape
        |
        :return: Ones Function
        """
        return tf.ones(shape=self.shape, dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE)

    def random_uniform(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Random Uniform Function
        """
        return tf.random_uniform(shape=self.shape, dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE,
                                 minval=self.min_val, maxval=self.max_val,
                                 seed=RZTDL_CONFIG.TensorflowConfig.SEED)

    def random_normal(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Random Normal Function
        """
        return tf.random_normal(shape=self.shape, mean=self.mean, stddev=self.std_dev,
                                dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE,
                                seed=RZTDL_CONFIG.TensorflowConfig.SEED)


class Activation(object):
    """
    | **@author**: Prathyush SP
    |
    | The class handles activation functions available in tensorflow
    | It consists of:
    | 1. Sigmoid Activation
    | 2. Softmax Activation
    | 3. Tanh Activation
    | 4. Relu Activation
    | 5. Relu6 Activation
    | 6. Elu Activation
    | 7. Softplus Activation
    | 8. Softsign Activation
    | 9. Identity Activation
    | 10. None Activation
    """

    @typechecked
    def __init__(self, input_tensor: Tensor):
        """
        :param input_tensor: Input Tensor
        """
        self.input_tensor = input_tensor
        pass

    def sigmoid(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Sigmoid Activation Function
        """
        return tf.nn.sigmoid(self.input_tensor)

    def softmax(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Softmax Activation Function
        """
        return tf.nn.softmax(self.input_tensor)

    def tanh(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Tanh Activation Function
        """
        return tf.nn.tanh(self.input_tensor)

    def relu(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Relu Activation Function
        """
        return tf.nn.relu(self.input_tensor)

    def crelu(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: CRelu Activation Function
        """
        return tf.nn.crelu(self.input_tensor)

    def relu6(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Relu6 Activation Function
        """
        return tf.nn.relu6(self.input_tensor)

    def elu(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Elu Activation Function
        """
        return tf.nn.elu(self.input_tensor)

    def softplus(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Softplus Activation Function
        """
        return tf.nn.softplus(self.input_tensor)

    def softsign(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Softsign Activation Function
        """
        return tf.nn.softsign(self.input_tensor)

    def identity(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Identity Activation Function
        """
        return tf.identity(self.input_tensor)

    def none(self) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        |This function is used for Layers which do not have activations
        :return: input
        """
        return self.input_tensor

    @typechecked
    def parse_activation(self, activation_type: str):
        """
        | **@author**: Prathyush SP
        |
        | Parse Activations
        :param activation_type: Type of Activation
        :return: Tensor. Activation Function applied over a tensor
        """
        activation_switch = {
            constants.ACTIVATION.SIGMOID: self.sigmoid,
            constants.ACTIVATION.SOFTMAX: self.softmax,
            constants.ACTIVATION.TANH: self.tanh,
            constants.ACTIVATION.RELU: self.relu,
            constants.ACTIVATION.RELU6: self.relu6,
            constants.ACTIVATION.ELU: self.elu,
            constants.ACTIVATION.SOFT_PLUS: self.softplus,
            constants.ACTIVATION.SOFT_SIGN: self.softsign,
            constants.ACTIVATION.IDENTITY: self.identity,
            constants.ACTIVATION.CRELU: self.crelu,
            constants.ACTIVATION.NONE: self.none
        }
        return activation_switch[activation_type]()


class Pool(object):
    """
    | **@author**: Prathyush SP
    |
    | The class handles pool functions available in tensorflow
    | It consists of:
    | 1. Max Pool
    | 2. Average Pool
    """

    @typechecked
    def __init__(self, input_tensor: Tensor):
        """
        :param input_tensor: Input Tensor
        """
        self.input_tensor = input_tensor
        pass

    def max_pool(self, ksize: list, strides: list, padding: str) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Max Pool
        """
        return tf.nn.max_pool(self.input_tensor, ksize=ksize, strides=strides, padding=padding)

    def avg_pool(self, ksize: list, strides: list, padding: str) -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        :return: Average Pool
        """
        return tf.nn.avg_pool(self.input_tensor, ksize=ksize, strides=strides, padding=padding)

    @typechecked
    def parse_pool(self, pool_type: str, ksize: list, strides: list, padding: str):
        """
        | **@author**: Prathyush SP
        |
        | Parse Activations
        :param pool_type: Type of Pool
        :param ksize: Pool Size
        :param strides: Pool strides
        :param padding: Pool Padding
        :return: Tensor. Activation Function applied over a tensor
        """
        activation_switch = {
            constants.POOL.MAX_POOL: self.max_pool,
            constants.POOL.AVG_POOL: self.avg_pool,
        }
        return activation_switch[pool_type](ksize, strides, padding)


class Optimizer(object):
    """
    | **@author**: Prathyush SP
    |
    | The class handles optimizers available in tensorflow
    | It consists of:
    |
    | 1. Adam Optimizer
    | 2. Adam Grad Optimizer
    | 3. Gradient Descent Optimizer
    | 4. Momentum Optimizer
    | 5. RMSProp Optimizer

    """

    @typechecked
    def __init__(self, learning_rate: Union[float, int, Tensor], cost: Tensor, momentum: float = 0.0,
                 decay: float = 0.9,
                 epsilon: float = 1e-10):
        """
        :param learning_rate: Learning Rate
        :param cost: Cost Function
        :param momentum: Momentum Parameter
        :param decay: Decay Parameter
        :param epsilon: Epsilon Parameter
        """
        if isinstance(learning_rate, Tensor):
            if not learning_rate.op.node_def.op == 'Placeholder':
                raise Exception(
                    'Learning rate should be a tensor of type placeholder. found:{}'.format(type(learning_rate)))
        self.learning_rate = learning_rate
        self.cost = cost
        self.momentum = float(momentum)
        self.decay = decay
        self.epsilon = epsilon

    def adam_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: Adam Optimizer Function
        """
        return tf.train.AdamOptimizer(self.learning_rate).minimize(self.cost)

    def ada_gradient_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: AdaGrad Optimizer Function
        """
        return tf.train.AdagradOptimizer(self.learning_rate).minimize(self.cost)

    def gradient_descent_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: Gradient Descent Optimizer Function
        """
        return tf.train.GradientDescentOptimizer(self.learning_rate).minimize(self.cost)

    def momentum_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: Momentum Optimizer Function
        """
        return tf.train.MomentumOptimizer(self.learning_rate, self.momentum).minimize(self.cost)

    def rms_prop_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: RMSProp Optimizer Function
        """
        return tf.train.RMSPropOptimizer(self.learning_rate, decay=self.decay, epsilon=self.epsilon).minimize(self.cost)

    def ftrl_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: Ftrl Optimizer Function
        """
        return tf.train.FtrlOptimizer(learning_rate=self.learning_rate).minimize(self.cost)

    def proximal_adagrad_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: ProximalAdagradOptimizer Optimizer Function
        """
        return tf.train.ProximalAdagradOptimizer(learning_rate=self.learning_rate).minimize(self.cost)

    def proximal_gradient_descent_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: ProximalGradientDescentOptimizer Optimizer Function
        """
        return tf.train.ProximalGradientDescentOptimizer(learning_rate=self.learning_rate).minimize(self.cost)

    def ada_delta_optimizer(self) -> Operation:
        """
        | **@author**: Prathyush SP
        |
        :return: AdadeltaOptimizer Optimizer Function
        """
        return tf.train.AdadeltaOptimizer(learning_rate=self.learning_rate).minimize(self.cost)

    def switch(self, optimizer: str):
        """
        | **@author**: Prathyush SP
        |
        | Optimiser Switch
        :param optimizer: Optimiser
        :return: Optimiser Operation
        """
        optimizer_switch = {
            constants.OPTIMIZER.ADA_GRADIENT: lambda: self.ada_gradient_optimizer(),
            constants.OPTIMIZER.ADAM: lambda: self.adam_optimizer(),
            constants.OPTIMIZER.MOMENTUM: lambda: self.momentum_optimizer(),
            constants.OPTIMIZER.GRADIENT_DESCENT: lambda: self.gradient_descent_optimizer(),
            constants.OPTIMIZER.FTRL: lambda: self.ftrl_optimizer(),
            constants.OPTIMIZER.PROXIMAL_ADAGRAD: lambda: self.proximal_adagrad_optimizer(),
            constants.OPTIMIZER.PROXIMAL_GRADIENT_DESCENT: lambda: self.proximal_gradient_descent_optimizer(),
            constants.OPTIMIZER.ADA_DELTA: lambda: self.ada_delta_optimizer()
        }
        return optimizer_switch[optimizer]()


class ReduceOp(object):
    """
       | **@author**: Thebzeera V
       |
       | The class handles reduce  operation available in tensorflow
       | It consists of:
       |
       | 1. Reduce Max
       | 2. Reduce Min
       | 3. Reduce Mean
    """

    @typechecked
    def __init__(self, input_tensor: Union[str, Tensor], axis: int, keep_dims: bool):
        """

        :param input_tensor: Input Tensor
        :param axis: Axis
        :param keep_dims: Keep Dimension
        """
        self.input_tensor = input_tensor
        self.axis = axis
        self.keep_dimension = keep_dims

    def reduce_max(self):
        """

        :return: Reduce Max
        """
        return tf.reduce_max(input_tensor=self.input_tensor, axis=self.axis, keep_dims=self.keep_dimension)

    def reduce_min(self):
        """

        :return: Reduce Min
        """

        return tf.reduce_min(input_tensor=self.input_tensor, axis=self.axis, keep_dims=self.keep_dimension)

    def reduce_mean(self):
        """

        :return: Reduce Mean
        """

        return tf.reduce_mean(input_tensor=self.input_tensor, axis=self.axis, keep_dims=self.keep_dimension)

    @typechecked
    def parse_reduce_operator(self, type: str):
        """

        :param type:
        :param input_tensor:
        :param axis:
        :param keep_dims:
        :return:
        """
        switch = {
            constants.REDUCE_OPERATOR.MAX: self.reduce_max,
            constants.REDUCE_OPERATOR.MIN: self.reduce_min,
            constants.REDUCE_OPERATOR.MEAN: self.reduce_mean
        }
        return switch[type]()


class TFCollection(object):
    """
    | **@author**: Prathyush SP
    |
    TFCollection Class used for dl_layer tapping
    """

    @staticmethod
    def add_to_collection(variables: dict):
        """
        | **@author**: Prathyush SP
        |
        | Add Tensors to Tensorflow Collection
        :param variables: Variables
        """
        for var_name, var_val in variables.items():
            tf.add_to_collection(var_name, var_val)

    @staticmethod
    def get_from_collection(variables: dict) -> List[Tensor]:
        """
        | **@author**: Prathyush SP
        |
        | Get Tensors form Tensorflow Collection
        :param variables: Variable List
        :return: List of Tensors
        """
        items = []
        for var_name in variables:
            items.append(tf.get_collection(var_name)[0])
        return items


class Accuracy(object):
    """
    | **@author**: Prathyush SP
    |
    | The class handles initialization functions available in tensorflow
    | It consists of:
    | 1. Simple Accuracy - Uses Threshold to map between 0 - 1 and compares with labelled data
    | 2. Binary Accuracy - Used to test the accuracy of a particular output label
    .. todo::
        Prathyush SP
            * Modify Accuracy functions to return unified output
            * Implement Accuracy Function for Regression
    """

    # todo :: Prathyush SP - Modify Accuracy functions to return unified output
    # todo :: Prathyush SP - Implement Accuracy Function for Regression
    @typechecked
    def __init__(self, predicted_data: ndarray, labelled_data: ndarray, threshold: float = 0.5):
        """
        :param predicted_data: Predicted Data
        :param labelled_data: Labelled Data
        :param threshold: Threshold value
        """
        self.predicted_data = predicted_data
        self.labelled_data = labelled_data
        self.threshold = threshold

    # noinspection PyTypeChecker
    def simple(self) -> OrderedDict:
        """
        | @author: Prathyush SP
        |
        | The function is used to calculate simple accuracy with the help of threshold and simple list comparison
        |
        :return: accuracy in percentage, accuracy count, error count
        """
        accurate_count = 0.0
        self.predicted_data = np.reshape(self.predicted_data, newshape=[-1, ]).tolist()
        self.labelled_data = np.reshape(self.labelled_data, newshape=[-1, ]).tolist()
        if not len(self.predicted_data) == len(self.labelled_data):
            raise Exception("Exception: length of predicted_data and labelled_data are not similar. {}:{}".format(
                len(self.predicted_data), len(self.labelled_data)))
        for p, l in zip(self.predicted_data, self.labelled_data):
            if (1 if p >= self.threshold else 0) == (1 if l >= self.threshold else 0):
                accurate_count += 1
        accuracy = float(accurate_count / float(len(self.predicted_data)) * 100)
        error_count = len(self.predicted_data) - accurate_count
        return OrderedDict([('accuracy', "{0:.2f}".format(accuracy)), ('accurate_samples', accurate_count),
                            ('error_samples', error_count)])

    @typechecked
    def binary(self, value: float = 0.0) -> OrderedDict:
        """
        | **@author**: Prathyush SP
        |
        | Method used to test the accuracy of a particular output label
        |
        :param value: Label to be tested
        :return: accuracy in percentage, accuracy count, error count
        """
        if not isinstance(value, float):
            raise Exception("Binary Value should be an instance of float. Found:", type(value))
        accurate_count = 0.0
        if not len(self.predicted_data) == len(self.labelled_data):
            raise Exception("Exception: length og predicted_data and labelled_data are not similar")
        data_count = 0
        for p, l in zip(self.predicted_data, self.labelled_data):
            ret_value = [1] if p > [self.threshold] else [0]
            if ret_value == [value]:
                data_count += 1
                if ret_value == ([1] if l > [self.threshold] else [0]):
                    accurate_count += 1
        accuracy = float(accurate_count / float(data_count) * 100) if not float(data_count) == 0 else 0
        error_count = data_count - accurate_count
        return OrderedDict([('accuracy', "{0:.2f}".format(accuracy)), ('accurate_samples', accurate_count),
                            ('error_samples', error_count)])

    def softmax(self) -> OrderedDict:
        """
        | **@author**: Prathyush SP
        |
        | Method used to calculate accuracy of a multi-variate output
        |
        :return: accuracy in percentage, accuracy count, error count
        """
        accurate_count = 0.0

        if np.isnan(self.predicted_data).any() is None:
            raise Exception("Predicted data is None")
        if np.isnan(self.labelled_data).any() is None:
            raise Exception("Labelled data is None")
        if not isinstance(self.predicted_data, np.ndarray):
            raise Exception("Predicted Data is not an Numpy Array object")
        if not isinstance(self.labelled_data, np.ndarray):
            raise Exception("Labelled Data is not an Numpy Array object")
        if not len(self.predicted_data) == len(self.labelled_data):
            raise Exception("Exception: length of predicted_data and labelled_data are not similar")
        for p, l in list(zip(self.predicted_data, self.labelled_data)):
            if np.argmax(p) == np.argmax(l):
                accurate_count += 1
        accuracy = float(accurate_count / float(len(self.predicted_data)) * 100)
        error_count = len(self.predicted_data) - accurate_count
        return OrderedDict([('accuracy', "{0:.2f}".format(accuracy)), ('accurate_samples', accurate_count),
                            ('error_samples', error_count)])

    # noinspection PyTypeChecker
    def regression(self) -> OrderedDict:
        """
        | **@author**: Prathyush SP
        |
        | Accuracy function for regression problem
        |
        :return:
        """
        self.predicted_data = np.reshape(self.predicted_data, newshape=[-1, ]).tolist()
        self.labelled_data = np.reshape(self.labelled_data, newshape=[-1, ]).tolist()
        accurate_count = sum([1 if int(i) in range(int(j - self.threshold), int(j + self.threshold)) else 0 for i, j in
                              (zip(self.predicted_data, self.labelled_data))])
        accuracy = float(accurate_count / float(len(self.predicted_data)) * 100)
        error_count = len(self.predicted_data) - accurate_count
        return OrderedDict([('accuracy', "{0:.2f}".format(accuracy)), ('accurate_samples', accurate_count),
                            ('error_samples', error_count)])

    @typechecked
    def switch(self, accuracy: str) -> OrderedDict:
        """
        | **@author**: Prathyush SP
        |
        :param accuracy: Accuracy String
        :return:
        """
        accuracy_switch = {
            constants.ACCURACY.SIMPLE: lambda: self.simple(),
            constants.ACCURACY.BINARY: lambda: self.binary(),
            constants.ACCURACY.SOFTMAX: lambda: self.softmax(),
            constants.ACCURACY.REGRESSION: lambda: self.regression()
        }
        return accuracy_switch[accuracy]()


class TFTimeline(object):
    """
    | **@author**: Prathyush SP
    |
    | Timeline Class used to create Timeline object for Chrome Tracing
    """

    def __init__(self):
        self.run_options = tf.RunOptions(trace_level=tf.RunOptions.FULL_TRACE)
        self.run_metadata = tf.RunMetadata()
        self._timeline = None

    @typechecked
    def run(self, session: Union[tf.InteractiveSession, tf.Session],
            optimizer_op: Union[Operation, tfoptimizer.Optimizer], feed_dict: dict, return_json: bool = False):
        """
        | **@author**: Prathyush SP
        |
        | Run Time line operation
        :param session: Tensorflow Session Object
        :param optimizer_op: Optimizer Operation
        :param feed_dict: Feed Dictionary for Optimizer
        :param return_json: Bool
        :return: Union[dict, Timeline]
        """
        session.run(optimizer_op, feed_dict=feed_dict, options=self.run_options, run_metadata=self.run_metadata)
        self._timeline = timeline.Timeline(self.run_metadata.step_stats).generate_chrome_trace_format()
        if return_json:
            return self._timeline
        else:
            return self

    def get_run_options(self):
        """
        | **@author**: Prathyush SP
        |
        | Get RunOptions
        :return: Tensorfow RunOptions
        """
        return self.run_options

    def get_run_metadata(self):
        """
        | **@author**: Prathyush SP
        |
        | Get RunMeradata
        :return: Tensorflow RunMetadata
        """
        return self.run_metadata

    @typechecked
    def save(self, save_path: str):
        """
        | **@author**: Prathyush SP
        |
        | Save Timeline json
        :param save_path: Save Path
        """
        open(r'' + save_path, 'w').write(self._timeline)


class TFSummaries(object):
    """
    | **@author**: Prathyush SP
    |
    | Tensorflow Summaries Class, used to create summaries in Tensorboard
    """

    def __init__(self):
        self.file_writers = {}

    @staticmethod
    def create_summary_op() -> Tensor:
        """
        | **@author**: Prathyush SP
        |
        | Create a Summary operation
        :return: Tensorflow merged summaries
        """
        return tf.summary.merge_all()

    def create_file_writer(self, name: str, save_path: str, graph: tf.Graph):
        """
        | **@author**: Prathyush SP
        |
        | Create Tensorflow File Writer
        :param name: File Writer Name
        :param save_path: File save path
        :param graph: Session graph
        """
        self.file_writers[name] = tf.summary.FileWriter(logdir=save_path, graph=graph)

    @typechecked
    def close_file_writer(self, file_writer_name: Union[str, list]):
        """
        | **@author**: Prathyush SP
        |
        | Close file writer
        :param file_writer_name: File Writer
        :return:
        """
        if isinstance(file_writer_name, list):
            for fw in file_writer_name:
                self.file_writers[fw].close()
        else:
            self.file_writers[file_writer_name].close()

    def get_file_writer(self, file_writer_name: str) -> tf.summary.FileWriter:
        """
        | **@author**: Prathyush SP
        |
        | Get file writer
        :param file_writer_name: File Writer
        :return: Tensorflow File Writer
        """
        return self.file_writers[file_writer_name]

    @typechecked
    def add_run_metadata(self, file_writer_name: str, run_metadata, step: int):
        """
        | **@author**: Prathyush SP
        |
        | Add run metadata to a file writer
        :param file_writer_name: File Writer Name
        :param run_metadata: Run Metadata
        :param step: Global Step
        """
        self.file_writers[file_writer_name].add_run_metadata(run_metadata, 'step%03d' % step)

    @typechecked
    def add_summary(self, file_writer_name: str, summary_op, step: int):
        """
        | **@author**: Prathyush SP
        |
        | Add summary to a file writer
        :param file_writer_name: File Writer Name
        :param summary_op: Summary Operation
        :param step: Global Step
        """
        self.file_writers[file_writer_name].add_summary(summary_op, step)

    @typechecked
    def add_scalar_summary(self, name: str, tensor: Union[Tensor, Variable]):
        """
        | **@author**: Prathyush SP
        |
        | Add scalar summary
        :param name: Summary Name
        :param tensor: Tensor
        """
        tf.summary.scalar(name=name, tensor=tensor)

    @typechecked
    def create_variable_summaries(self, tensor: Union[Tensor, tf.Variable]):
        """
        | **@author**: Prathyush SP
        |
        | Attach Variable Summaries for Visualization using Tensorboard
        :param tensor: Tensor
        """
        with tf.name_scope('summaries'):
            mean = tf.reduce_mean(tensor)
            tf.summary.scalar('mean', mean)
            with tf.name_scope('stddev'):
                # noinspection PyUnresolvedReferences
                stddev = tf.sqrt(tf.reduce_mean(tf.square(tensor - mean)))
            tf.summary.scalar('stddev', stddev)
            tf.summary.scalar('max', tf.reduce_max(tensor))
            tf.summary.scalar('min', tf.reduce_min(tensor))
            tf.summary.histogram('histogram', tensor)


class TensorBoard(object):
    """
    | **@author**: Prathyush SP
    |
    | Tensorboard Util
    """

    @typechecked
    def __init__(self, network_name: str = None, logdir: str = None, port: int = 6006, run_id=-1):
        """
        :param logdir: used to specify the log directory defined by the SummaryWriter
        :param port: port configuration [default: 6006]
        """
        self._network_name = network_name
        self._log_dir = logdir
        self._port = port
        self.id = run_id
        self.validate()

    def start_tensorboard(self):
        """
        | **@author**: Prathyush SP
        |
        | The function starts the tensorboard using specified parameters
        """
        if not os.path.exists(self._log_dir):
            os.system("mkdir -p " + self._log_dir)
        os.system("cd " + self._log_dir + " && ls -tp | grep -v '/$' | tail -n +2 | xargs -I {} rm -- {}")
        os.system("tensorboard --logdir " + self._log_dir + " --port " + str(self._port))

    def validate(self):
        if self._network_name is None and self._log_dir is None:
            raise Exception('Network Name / Log Dir is not specified')
        if self._network_name:
            if File.is_exist(path=RZTDL_CONFIG.CommonConfig.PATH_RZTDL + '/' + self._network_name + '/model.meta'):
                metadata = File.read_json(
                    path=RZTDL_CONFIG.CommonConfig.PATH_RZTDL + '/' + self._network_name + '/model.meta')
                if self.id in metadata:
                    metadata = metadata[self.id]
                else:
                    logger.error('Run id not found in model metadata. Fetching the latest id')
                    metadata = metadata[sorted(metadata.keys())[-1]]
                self._log_dir = RZTDL_CONFIG.CommonConfig.PATH_RZTDL + metadata[
                    constants.ModelMetaConstant.NETWORK_NAME] + '/' + \
                                metadata[constants.ModelMetaConstant.TIMESTAMP] + \
                                metadata[constants.ModelMetaConstant.PATH][
                                    constants.ModelMetaConstant.PATH_OPTIONS.GRAPH_SAVE_PATH]
            else:
                raise FileExistsError('Model meta file / Network not found')


class NormalizationLayer(object):
    """
    | **@author**: Umesh Kumar
    |
    | Tensorflow Normalisation dl_layer
    """

    def __init__(self, input_tensor):
        """

        :param input_tensor:
        """
        self.input_tensor = input_tensor

    @typechecked
    def l2_norm(self, norm_parameters: dict) -> Tensor:
        """
        | **@author**: Umesh Kumar
        |
        | This is the  l2_normalization of tensorflow
        :param norm_parameters:
        :return:
        """
        return tf.nn.l2_normalize(self.input_tensor, norm_parameters[constants.PARAMETERS.NORM_DIM],
                                  norm_parameters[constants.PARAMETERS.NORM_EPSILON], name='l2_norm')

    @typechecked
    def lrn_norm(self, norm_parameters: dict) -> Tensor:
        """
        | **@author**: Umesh Kumar
        |
        | This is the lrn_normalization(local response normalization) of tensorflow
        :param norm_parameters:
        :return:
        """
        return tf.nn.lrn(self.input_tensor, depth_radius=norm_parameters[constants.PARAMETERS.DEPTH_RADIUS],
                         bias=norm_parameters[constants.PARAMETERS.NORM_BIAS],
                         alpha=norm_parameters[constants.PARAMETERS.NORM_ALPHA],
                         beta=norm_parameters[constants.PARAMETERS.NORM_BETA], name='lrn')

    @typechecked
    def parse_norm(self, norm_type: str, norm_parameters: dict):
        """
        | **@author**: Prathyush SP
        |
        | Parse Normalization Function
        :param norm_type: Normalization type
        :param norm_parameters: Normalization Parameters
        :return: Normalized Tensor
        """
        norm_dict = {
            constants.NORMALIZATION.LRN_NORM: self.lrn_norm,
            constants.NORMALIZATION.L2_NORM: self.l2_norm
        }
        return norm_dict[norm_type](norm_parameters)


class Regularisation(object):
    """
    | **@author**: Umesh Kumar
    |
    | Tensorflow Regularisation Techniques
    """

    @typechecked
    def __init__(self, input_tensor: Tensor, model_name, regularisation_params: dict = None):
        """

        :param input_tensor:
        """
        self.input_tensor = input_tensor
        self.model_name = model_name
        self.regularisation_params = regularisation_params
        self.validate()

    def l2_regularisation(self):
        """
        | **@author**: Umesh Kumar
        |
        | This is the  l2_regularisation of cost
        :return:
        """
        regulariser = 0
        for param in self.regularisation_params[constants.PARAMETERS.REGULARISATION_WEIGHTS]:
            regulariser += tf.nn.l2_loss(param)
        return tf.reduce_mean(tf.add(self.input_tensor,
                                     tf.multiply(self.regularisation_params[constants.PARAMETERS.REGULARISATION_BETA],
                                                 regulariser)))

    def l1_regularisation(self):
        """
        | **@author**: Umesh Kumar
        |
        | This is the  l1_regularisation of cost

        :return:
        """
        regulariser = 0
        for param in self.regularisation_params[constants.PARAMETERS.REGULARISATION_WEIGHTS]:
            regulariser += tf.reduce_sum(tf.abs(param))
        return tf.reduce_mean(tf.add(self.input_tensor,
                                     tf.multiply(self.regularisation_params[constants.PARAMETERS.REGULARISATION_BETA],
                                                 regulariser)))

    @typechecked
    def select_regulariser(self, regulariser: str) -> Tensor:
        """
        | **@author**: Umesh Kumar
        |
        :param regulariser: Regularisation string
        :return:
        """
        regulariser_switch = {
            constants.REGULARISATION.L2_REGULARISATION: lambda: self.l2_regularisation(),
            constants.REGULARISATION.L1_REGULARISATION: lambda: self.l1_regularisation(),
        }
        return regulariser_switch[regulariser]()

    def validate(self):
        """
        | **@author**: Umesh Kumar
        |
        Validate the Regularisation Parameters
        :return:
        """

        if self.regularisation_params[constants.PARAMETERS.REGULARISATION_WEIGHTS]:
            if isinstance(self.regularisation_params[constants.PARAMETERS.REGULARISATION_WEIGHTS][0], str):
                weights = []
                for layer in self.regularisation_params[constants.PARAMETERS.REGULARISATION_WEIGHTS]:
                    weights.append(RZTDL_DAG.get_weights(model_name=self.model_name, layer_name=layer))
                self.regularisation_params[constants.PARAMETERS.REGULARISATION_WEIGHTS] = weights
        else:
            self.regularisation_params[constants.PARAMETERS.REGULARISATION_WEIGHTS] = list(RZTDL_DAG.get_all_weights(
                model_name=self.model_name).values())


class GraphUtils(object):
    """
    | **@author**: Prathyush SP
    |
    | Tensorflow Graph Utils
    """

    def __init__(self):
        self._save_path = None
        self.graph = tf.get_default_graph()
        self.graph_def = self.graph.as_graph_def()

    def get_as_protobuff(self):
        """
        | **@author**: Prathyush SP
        |
        | Get Graph as protobuff object
        :return: Tensorflow Graph Def Object
        """
        return self.graph_def

    def get_as_str(self):
        """
        | **@author**: Prathyush SP
        |
        | Get GraphDef as String
        :return: Tensorflow Graph Def Object as String
        """
        return str(self.graph_def)

    def save_graph(self, save_path: str):
        """
        | **@author**: Prathyush SP
        |
        | Save Graph as event and Protobuf String Object
        :param save_path: Save Path
        :return: GraphUtils Object
        """
        self._save_path = save_path
        os.system('mkdir -p ' + self._save_path)
        logger.info('Fetching default graph')
        with open(self._save_path + '/graph.pb', 'w') as f: f.write(str(self.graph_def))
        logger.info('Writing graph.pbtxt in {}'.format(self._save_path))
        train_writer = tf.summary.FileWriter(self._save_path)
        train_writer.add_graph(self.graph)
        logger.info('Writing tensorflow event in {}'.format(self._save_path))
        return self

    def run_tensorboard(self):
        """
        | **@author**: Prathyush SP
        |
        | Run Tensorboard on saved event
        """
        if self._save_path:
            logger.info('Launching tensorboard in {}'.format(self._save_path))
            os.system('tensorboard --logdir=' + self._save_path)
        else:
            raise FileNotFoundError('Graph utils supports custom graph save and loading. . .')
