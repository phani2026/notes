# -*- coding: utf-8 -*-
"""
| *@created on:* 12/06/18,
| *@author:* Umesh Kumar,
| *@version:* v0.0.1
|
| *Description:*
|
| *Sphinx Documentation Status:* Complete
|
"""
import json
import logging
from collections import OrderedDict

from rztdl.utils.pyutils import DLTimer

logger = logging.getLogger(__name__)


class MetricStore(object):
    """
    | **@author:** Umesh Kumar
    |
    | Metric Store Class
    """

    def __init__(self, total_epochs: int):
        """

        :param total_epochs:
        """
        self.total_epochs = total_epochs
        self.eta = 0
        self.batch_eta = 0
        self.time_for_one_epoch = 0
        self.time_for_one_batch = 0

        pass

    # noinspection PyTypeChecker
    def epoch_result(self, current_epoch: int, train_time: DLTimer, template: str, metrics: dict,
                     print_json: bool = False):
        """

        :param current_epoch:
        :param train_time:
        :param template:
        :param metrics:
        :param print_json:
        :return:
        """
        if current_epoch == 0:
            self.time_for_one_epoch = train_time.get_elapsed_time()
            self.eta = train_time.get_elapsed_time() * self.total_epochs
        if self.eta < train_time.get_elapsed_time():
            self.eta += (self.time_for_one_epoch * (self.total_epochs - current_epoch))
        eta = str(self.eta - train_time.get_elapsed_time())
        epoch_item = OrderedDict(
            [('epoch', current_epoch)] + [(k, v) for k, v in metrics.items()] +
            [('epoch_progress', current_epoch / (self.total_epochs - (1 if self.total_epochs > 1 else 0)) * 100),
             ('epoch_eta', eta), ('epoch_time_elapsed', str(train_time.get_elapsed_time()))])
        print_item = ['Epoch'] + [x for x, v in metrics.items()] + ['Progress', 'ETA', 'Time Elapsed']
        if print_json:
            logger.info(json.dumps(OrderedDict([((k, v) for k, v in epoch_item.items())])))
        else:
            logger.info(', '.join(
                [": ".join([print_item[e], '{0:.2f}'.format(i[1]) if isinstance(i[1], float) else str(i[1])]) for
                 e, i in enumerate(epoch_item.items()) if i[1] is not None]))

    # noinspection PyTypeChecker
    def batch_result(self, current_batch: int, train_time: DLTimer, batches: int, template: str, metrics: dict,
                     print_json: bool = False):
        """"""
        if current_batch == 0:
            self.time_for_one_batch = train_time.get_elapsed_time()
            self.batch_eta = train_time.get_elapsed_time() * batches
        if self.batch_eta < train_time.get_elapsed_time():
            self.batch_eta += (self.time_for_one_epoch * (batches - current_batch))
        eta = str(self.eta - train_time.get_elapsed_time())
        epoch_item = OrderedDict(
            [('batch', current_batch)] + [(k, v) for k, v in metrics.items()] +
            [('batch_progress', current_batch / (
                    batches * self.total_epochs - (1 if batches > 1 else 0)) * 100),
             ('batch_eta', eta), ('batch_time_elapsed', str(train_time.get_elapsed_time()))])
        print_item = ['Batch'] + [x for x, v in metrics.items()] + ['Progress', 'ETA', 'Time Elapsed']
        if print_json:
            logger.info(json.dumps(OrderedDict([((k, v) for k, v in epoch_item.items())])))
        else:
            logger.info(', '.join(
                [": ".join([print_item[e], '{0:.2f}'.format(i[1]) if isinstance(i[1], float) else str(i[1])]) for
                 e, i in enumerate(epoch_item.items()) if i[1] is not None]))
