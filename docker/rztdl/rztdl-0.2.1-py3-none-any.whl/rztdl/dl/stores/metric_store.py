# -*- coding: utf-8 -*-
"""
| **@created on:** 20/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
| Metric Store Module
| **Sphinx Documentation Status:** --
|
..todo::
"""
import json
import logging
from collections import OrderedDict
import typing
from typeguard import typechecked
from rztdl.dl.dataset import Split
from rztdl.utils.pyutils import ROrderedDict
from munch import Munch
import datetime
from rztdl.dl.handlers.display_handler import global_display_handler
from rztdl.utils.singleton import Singleton

logger = logging.getLogger(__name__)

import numpy as np


class NumpyEncoder(json.JSONEncoder):
    """ Special json encoder for numpy types """

    def default(self, obj):
        if isinstance(obj, (np.int_, np.intc, np.intp, np.int8,
                            np.int16, np.int32, np.int64, np.uint8,
                            np.uint16, np.uint32, np.uint64)):
            return int(obj)
        elif isinstance(obj, (np.float_, np.float16, np.float32,
                              np.float64)):
            return float(obj)
        elif isinstance(obj, (np.ndarray,)):  #### This is the fix
            return obj.tolist()
        return json.JSONEncoder.default(self, obj)


class Metric(Munch):
    def __init__(self, name, interval, interval_type, value):
        super().__init__()
        self.name = name
        self.interval = interval
        self.interval_type = interval_type
        self.value = value
        self.timestamp = datetime.datetime.now().__str__()


class _MetricStore(metaclass=Singleton):
    """
    | **@author:** Prathyush SP
    |
    | Metric Store Class
    """

    @typechecked
    def __init__(self, name: str):
        """

        :param name: Store Name
        """
        self.name = name
        self.run_parameters = None
        self.store = ROrderedDict()

    def add_model_runner(self, model_name: str, model_runner_name: str):
        """

        :param model_name:
        :param model_runner_name:
        :return:
        """
        if model_name in self.store:
            self.store[model_name][model_runner_name]= ROrderedDict()
        else:
            self.store[model_name] = ROrderedDict([(model_runner_name, ROrderedDict())])

    @typechecked
    def add_flow(self, model_name: str, model_runner_name: str, flow_name: str, splits: typing.List[Split],
                 run_parameters: typing.Dict[str, typing.Union[str, int, float]]):
        """
        | **@author:** Prathyush SP
        |
        | Add Flow to the metric store
        :param model_name: Model Name
        :param flow_name: Flow Name
        :param splits: Splits
        :param run_parameters: Run Parameters

        """
        self.run_parameters = run_parameters
        self.store[model_name][model_runner_name][flow_name] = ROrderedDict()
        for split in splits:
            self.store[model_name][model_runner_name][flow_name][split.name] = OrderedDict(
                [("meta", split.__dict__()), ("metrics", [])])

    @typechecked
    @global_display_handler.display
    def update_store(self, model_name: str, model_runner_name: str, flow_name: str, split_name: str,
                     metrics: typing.Dict, interval: int = None,
                     interval_type: str = None):
        """
        | **@author:** Prathyush SP
        |
        | Update store for new metrics
        :param model_name: Model Name
        :param flow_name: Flow Name
        :param split_name: Split Name
        :param metrics: Metrics
        :param interval: Interval
        :param interval_type: Interval Type
        """
        for m_name, m_value in metrics.items():
            self.store[model_name][model_runner_name][flow_name][split_name]['metrics'].append(
                Metric(name=m_name, value=m_value, interval=interval, interval_type=interval_type))
        # import json
        # json.dump(self.store[model_name][flow_name]['train_sp']['metrics'], fp=open('/tmp/np.txt', 'w'),
        #           cls=NumpyEncoder)


METRIC_STORE = _MetricStore(name='global_metric_store')
