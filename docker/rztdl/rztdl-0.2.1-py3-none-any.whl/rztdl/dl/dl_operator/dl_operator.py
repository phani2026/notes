# -*- coding: utf-8 -*-
"""
| **@created on:** 10/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
from abc import ABCMeta, abstractmethod
from rztdl.utils.validations import validate_name
from typeguard import typechecked

class Operator(metaclass=ABCMeta):
    """
    | **@author:** Prathyush SP
    |
    | Operator Parent Class
    """

    @typechecked
    def __init__(self, name: str):
        """
        :param name: Operator Name
        """
        self.name = validate_name(name)
        self.Addname = validate_name(name)
        self.operator_id = None
        self.operator_input = None
        self.operator_output = None
        self.model_name = None

    @abstractmethod
    def create_operator(self, model_name: str, operator_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Creates Operator
        :param model_name: Model Name
        :param operator_id: Operator ID
        :return: Operator
        """
        pass  # pragma: no cover

    @abstractmethod
    def validate(self):
        """
        | **@author:** Prathyush SP
        |
        | Operator Validation
        """
        pass  # pragma: no cover
