# -*- coding: utf-8 -*-
"""
| **@created on:** 10/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
from rztdl.dl.dl_operator import Operator
from typing import Union
from tensorflow import Tensor
from typeguard import typechecked
from rztdl import RZTDL_DAG
import tensorflow as tf
import rztdl.utils.string_constants as constants
from collections import OrderedDict
from rztdl.utils.dl_exception import ShapeError


class SliceOperator(Operator):
    """
    | **@author:** Thebzeera V
    |
    |Slice Operator
    """

    @typechecked
    def __init__(self, name: str, operator_input: Union[str, Tensor], begin: list, size: list, operator_output: str):
        """
        | **@author:** Thebzeera V
        |
        | Slice Operator Constructor
        :param name: Operator Name
        :param operator_input: Operator Input
        :param begin: Begin
        :param size: Size
        """
        super().__init__(name=name)
        self.operator_input = operator_input
        self.begin = begin
        self.slice_size = size
        self.operator_name = name
        self.slice_name = operator_output

    @typechecked
    def create_operator(self, model_name: str, operator_id: int):
        """
        | **@author:** Thebzeera V
        |
        | Creates Slice dl_operator
        :param model_name: Model Name
        :param operator_id: Operator ID
        :return: Slice Operator
        """
        self.model_name = model_name
        self.operator_id = operator_id
        self.validate()
        with tf.name_scope(self.name + '/'):
            self.operator_output = tf.slice(input_=self.operator_input, begin=self.begin, size=self.slice_size)
        tf.add_to_collection(self.operator_output.name, self.operator_output)
        operator_details = OrderedDict(
            [(constants.MODEL_ARCHITECTURE.OPERATOR_INPUT, self.operator_input.get_shape().as_list().__str__()),
             (constants.MODEL_ARCHITECTURE.SLICE_BEGIN, self.begin),
             (constants.MODEL_ARCHITECTURE.SLICE_SIZE, self.slice_size),
             (constants.MODEL_ARCHITECTURE.OPERATOR_OUTPUT, self.operator_output.get_shape().as_list().__str__())])
        RZTDL_DAG.add_layer(model_name=self.model_name, layer_name=self.slice_name,
                            tensor_name=self.operator_output.name)
        RZTDL_DAG.update_model_operator_architecture(model_name=self.model_name, operator_name=self.name,
                                                     operator_details=operator_details)

        return self

    def validate(self):
        """
        | **@author:** Thebzeera V
        |
        | Slice Operator validation
        """
        if isinstance(self.operator_input, str):
            self.operator_input = RZTDL_DAG.get_layer(self.model_name, self.operator_input)
        if not (len(self.operator_input.get_shape())) == len(self.begin):
            raise ShapeError("Shapes of 'input' and 'begin' must be equal ")
        if not (len(self.operator_input.get_shape()) == len(self.slice_size)):
            raise ShapeError("Shapes of 'input' and 'size' must be equal")
