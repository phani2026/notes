# -*- coding: utf-8 -*-
"""
| **@created on:** 10/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
from rztdl.dl.dl_operator import Operator
from typing import Union, List
from tensorflow import Tensor
from typeguard import typechecked
from rztdl import RZTDL_DAG
import tensorflow as tf
import rztdl.utils.string_constants as constants
from collections import OrderedDict

from rztdl.utils.dl_exception import ShapeError


class AddOperator(Operator):
    """
    | **@author:** Prathyush SP
    |
    | Addition Operator
    """

    @typechecked
    def __init__(self, name: str, operator_input: Union[List[str], List[Tensor]], operator_output: str):
        """
        :param name: Operator Name
        :param operator_input: Operator Input
        :param operator_output: Operator Output
        """
        super().__init__(name=name)
        self.operator_input = operator_input
        self.add_name = operator_output
        self.operator_output = operator_output

    @typechecked
    def create_operator(self, model_name: str, operator_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Creates Addition dl_operator
        :param model_name: Model Name
        :param operator_id: Operator ID
        :return: Reshape Operator
        """
        self.model_name = model_name
        self.operator_id = operator_id
        self.validate()
        with tf.name_scope(self.name + '/'):
            self.operator_output = self.operator_input[0]

            for tensors in self.operator_input[1:]:
                self.operator_output = tf.add(self.operator_output, tensors)

            operator_details = OrderedDict([
                (constants.MODEL_ARCHITECTURE.OPERATOR_INPUT,
                 [y.get_shape().as_list().__str__() for y in self.operator_input]),
                (constants.MODEL_ARCHITECTURE.OPERATOR_OUTPUT, self.operator_output.get_shape().as_list().__str__())])
        RZTDL_DAG.add_layer(model_name=self.model_name, layer_name=self.add_name, tensor_name=self.operator_output.name)

        tf.add_to_collection(self.operator_output.name, self.operator_output)
        RZTDL_DAG.update_model_operator_architecture(model_name=self.model_name, operator_name=self.name,
                                                     operator_details=operator_details)
        return self

    def validate(self):
        """
        | **@author:** Prathyush SP
        |
        | Addition Operator validation
        """
        temp_list = []
        shape = None
        for tensors in self.operator_input:
            if not isinstance(tensors, Tensor):
                tensors = RZTDL_DAG.get_layer(self.model_name, tensors)
            if not shape:
                shape = tensors.get_shape()
                temp_list.append(tensors)
                continue
            if tensors.get_shape().as_list() == shape.as_list():
                temp_list.append(tensors)
            else:
                raise ShapeError('Tensor Shapes do not Match {}:{}'.format(tensors.get_shape(), shape))
        self.operator_input = temp_list
