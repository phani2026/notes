# -*- coding: utf-8 -*-
"""
| **@created on:** 10/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

from rztdl.dl.dl_operator import Operator
from typing import Union, List
from tensorflow import Tensor
from typeguard import typechecked
from rztdl import RZTDL_DAG
import tensorflow as tf
import rztdl.utils.string_constants as constants
from collections import OrderedDict

from rztdl.utils.dl_exception import OperatorException


class SplitOperator(Operator):
    """
    | **@author:** Prathyush SP
    |
    | Split Operator
    """

    @typechecked
    def __init__(self, name: str, operator_input: Union[str, Tensor], operator_output: List[str], dimension: int):
        """
        :param name: Operator Name
        :param operator_input: Operator Input
        :param operator_output: Operator Output
        :param dimension: Dimension
        """
        super().__init__(name=name)
        self.operator_input = operator_input
        self.dimension = dimension
        self.split_names = operator_output
        self.operator_output = []

    @typechecked
    def create_operator(self, model_name: str, operator_id: int):
        """
        | **@author:** Prathyush SP
        |
        | Create Split Operator
        :param model_name: Model Name
        :param operator_id: Operator Id
        :return: Split Operator
        """
        self.model_name = model_name
        self.operator_id = operator_id
        self.validate()
        with tf.name_scope(self.name + '/'):
            split_tensors = tf.split(value=self.operator_input, num_or_size_splits=len(self.split_names),
                                     axis=self.dimension)
            operator_details = OrderedDict(
                [
                    (constants.MODEL_ARCHITECTURE.OPERATOR_INPUT, self.operator_input.get_shape().as_list().__str__()),
                    (constants.MODEL_ARCHITECTURE.SPLIT_SIZE, len(self.split_names)),
                    (constants.MODEL_ARCHITECTURE.SPLIT_DIMENSION, self.dimension),
                    (constants.MODEL_ARCHITECTURE.OPERATOR_OUTPUT,
                     [y.get_shape().as_list().__str__() for y in split_tensors])
                ])
        for name, tensor in list(zip(self.split_names, split_tensors)):
            RZTDL_DAG.add_layer(model_name=self.model_name, layer_name=name, tensor_name=tensor.name)

            tf.add_to_collection(tensor.name, tensor)
        RZTDL_DAG.update_model_operator_architecture(model_name=self.model_name, operator_name=self.name,
                                                     operator_details=operator_details)
        self.operator_output = split_tensors
        return self

    def validate(self):
        """
        | **@author:** Prathyush SP
        |
        | Split Operator Validation
        """
        if not all(isinstance(var, str) for var in self.operator_output):
            raise OperatorException('Operator Output should be a List[str]')
        if isinstance(self.operator_input, str):
            self.operator_input = RZTDL_DAG.get_layer(self.model_name, self.operator_input)
