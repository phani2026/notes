# -*- coding: utf-8 -*-
"""
| **@created on:** 10/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
from rztdl.dl.dl_operator import Operator
from typing import Union
from tensorflow import Tensor
from typeguard import typechecked
from rztdl import RZTDL_DAG
import tensorflow as tf
import rztdl.utils.string_constants as constants
from collections import OrderedDict
from  rztdl.dl.helpers import tfhelpers


class ReduceOperator(Operator):
    """
    | **@author:** Thebzeera V
    |
    | Reduce  Operator Constructor
    """

    @typechecked
    def __init__(self, name: str, operator_input: Union[str, Tensor], dimension: int,
                 operator_output: str, operator_type: str = constants.REDUCE_OPERATOR.MAX,
                 keep_dimension: bool = False):
        """

        :param name: Operator name
        :param operator_input: Operator input
        :param dimension:  Dimension
        :param keep_dimension: Keep dimension
        :param operator_output: Operator output
        :param operator_type: Reduce Operator type
        """
        super().__init__(name=name)
        self.operator_input = operator_input
        self.keep_dimension = keep_dimension
        self.dimension = dimension
        self.reduce_max_name = operator_output
        self.operator_type = operator_type

    @typechecked
    def create_operator(self, model_name: str, operator_id: int):
        """
        | **@author:** Thebzeera V
        |
        | Creates Reduce  dl_operator
        :param model_name: Model Name
        :param operator_id: Operator ID
        :return: reduce Operator
        """

        self.model_name = model_name
        self.operator_id = operator_id
        self.validate()
        with tf.name_scope(self.name + '/'):
            self.operator_output = tfhelpers.ReduceOp(input_tensor=self.operator_input,
                                                      axis=self.dimension,
                                                      keep_dims=self.keep_dimension).parse_reduce_operator(
                type=self.operator_type)
            operator_details = OrderedDict(
                [(constants.MODEL_ARCHITECTURE.OPERATOR_INPUT, self.operator_input.get_shape().as_list().__str__()),
                 (constants.MODEL_ARCHITECTURE.REDUCE_OPERATOR_DIMENSION, self.dimension),
                 (constants.MODEL_ARCHITECTURE.KEEP_DIMENSION, self.keep_dimension),
                 (constants.MODEL_ARCHITECTURE.OPERATOR_OUTPUT,
                  self.operator_output.get_shape().as_list().__str__())
                 ])
        tf.add_to_collection(self.operator_output.name, self.operator_output)
        RZTDL_DAG.add_layer(model_name=self.model_name, layer_name=self.reduce_max_name,
                            tensor_name=self.operator_output.name)
        RZTDL_DAG.update_model_operator_architecture(model_name=self.model_name, operator_name=self.name,
                                                     operator_details=operator_details)

        return self

    def validate(self):
        """
        | **@author:** Thebzeera V
        |
        | Reduce  Operator validation
        """
        if isinstance(self.operator_input, str):
            self.operator_input = RZTDL_DAG.get_layer(self.model_name, self.operator_input)
        if not self.dimension < len(self.operator_input.get_shape()):
            raise Exception("Dimension should be less than {}".format(len(self.operator_input.get_shape())))
        if isinstance(self.operator_type, str):
            if self.operator_type not in constants.REDUCE_OPERATOR.__dict__.values():
                raise Exception("Not a valid Reduce dl_operator. Usage: REDUCEOPERATOR.<>")
