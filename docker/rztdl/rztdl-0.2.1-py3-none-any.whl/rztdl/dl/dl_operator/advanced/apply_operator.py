# -*- coding: utf-8 -*-
"""
| **@created on:** 10/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

from rztdl.dl.dl_operator import Operator
from typing import Union, Callable
from tensorflow import Tensor
from typeguard import typechecked
from rztdl import RZTDL_DAG
import tensorflow as tf
import rztdl.utils.string_constants as constants
from collections import OrderedDict


class ApplyOperator(Operator):
    """
    | **@author:** Thebzeera V
    |
    | Apply Operator Constructor
    """

    @typechecked
    def __init__(self, name: str, operator_input: Union[str, Tensor], function: Callable,
                 operator_output: Union[str, Tensor]):
        """
        :param name: Operator name
        :param operator_input: Operator input
        :param operator_output: Operator output
        :param function: Function can be any tensorflow operations
        """
        super().__init__(name=name)
        self.operator_input = operator_input
        self.function = function
        self.apply_operator_name = operator_output

    @typechecked
    def create_operator(self, model_name: str, operator_id: int):
        """
        | **@author:** Thebzeera V
        |
        | Create Apply dl_operator
        :param model_name: Model Name
        :param operator_id: Operator Id
        :return:
        """
        self.model_name = model_name
        self.operator_id = operator_id
        self.validate()
        with tf.name_scope(self.name + '/'):
            # noinspection PyCallingNonCallable
            self.operator_output = self.function(self.operator_input)
            operator_name = self.operator_output.name
            operator_details = OrderedDict(
                [(constants.MODEL_ARCHITECTURE.OPERATOR_TYPE, operator_name[len(self.name) + 1:-2]),
                 (constants.MODEL_ARCHITECTURE.OPERATOR_INPUT, self.operator_input.get_shape().as_list().__str__()),
                 (constants.MODEL_ARCHITECTURE.OPERATOR_OUTPUT,
                  self.operator_output.get_shape().as_list().__str__())
                 ])

            tf.add_to_collection(self.operator_output.name, self.operator_output)
            RZTDL_DAG.add_layer(model_name=self.model_name, layer_name=self.apply_operator_name,
                                tensor_name=self.operator_output.name)
            RZTDL_DAG.update_model_operator_architecture(model_name=self.model_name, operator_name=self.name,
                                                         operator_details=operator_details)
        return self

    def validate(self):
        """
        | **@author:** Thebzeera V
        |
        | Apply Operator validation
        """
        if isinstance(self.operator_input, str):
            self.operator_input = RZTDL_DAG.get_layer(self.model_name, self.operator_input)
        if not isinstance(self.function, Callable):
            raise Exception("Function should be a type of Callable.")
