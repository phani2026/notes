# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Model Class
| **Sphinx Documentation Status:** Complete
|
..todo::
    
"""

__all__ = ['Model']

from rztdl.dl.components.dl_layer import Layer
from rztdl.dl.components.dl_operator import Operator
from rztdl.dl.components.component import Component
from rztdl.dl.components.dl_cost import Cost
from rztdl.dl.components.dl_optimizer import Optimizer
from rztdl.dl.components.dl_buffer import Buffer
from rztdl.dl.components.dl_metric import Metric
from rztdl.utils.validations import validate_name
from rztdl.utils.dl_exception import ComponentException, ModelException
from operator import mul
from functools import reduce
from tensorflow import Tensor
from rztdl import RZTDL_STORE, RZTDL_CONFIG
import tensorflow as tf
from typeguard import typechecked
import logging
from rztdl.dl.dl_hooks.dl_hook_runners.component_hooks_runner import component_hooks_runner
from rztdl.dl.dl_hooks.dl_hook_runners.model_hooks_runner import model_hooks_runner
from rztdl.hooks.hooks_manager import hooks_manager
from rztdl.utils.string_constants import Hook
from typing import Union
from collections import OrderedDict
from rztdl.dl.helpers.tfhelpers import GraphUtils
from typing import List
import rztdl.utils.string_constants as constants
from rztdl.utils.pyutils import ROrderedDict

logger = logging.getLogger(__name__)


class Model(object):
    """
    | **@author:** Prathyush SP
    | 
    | Used to define a deeplearning Model
    """

    __slots__ = ['name', 'component_id', '_component', '_model_complexity', 'final_component', 'component_dict',
                 'scopes', 'model_meta_graph']

    @typechecked
    def __init__(self, name: str, scopes: List[str] = []):
        """
        :param name: Model Name
        """
        self.name = validate_name(name)
        self.component_id = 0
        self._component = Component
        self._model_complexity = 0
        self.final_component = None
        self.component_dict = ROrderedDict()
        self.scopes = set([validate_name(scope) for scope in scopes])
        self.model_meta_graph = None
        self.validate()

        # Add model scope
        RZTDL_STORE.add_model_scopes(model_name=self.name, scopes=self.scopes)

        # Model begin hook runner
        model_hooks_runner.run(hook_with_conditions=hooks_manager.fetch_hook(hook_type=Hook.HookType.ModelHook,
                                                                             hook_pos=Hook.HookPosition.BeginHook),
                               hook_argument=self)

    def add_component(self, component: Union[Layer, Operator, Cost, Optimizer, Buffer, Metric]):
        """
        | **@author:** Prathyush SP
        |
        | Add Component
        :param component: Operator
        :returns: Component Output
        """
        if self.final_component is None:
            self.component_id += 1
            component.model_name = self.name

            # Component begin hook runner
            component_hooks_runner.run(
                hook_with_conditions=hooks_manager.fetch_hook(hook_type=Hook.HookType.ComponentHook,
                                                              hook_pos=Hook.HookPosition.BeginHook),
                hook_argument=component)
            RZTDL_STORE.register_component(model_name=self.name, component_name=component.name,
                                           component=component)
            self._component = component.create_component(model_name=self.name, previous_component=self._component,
                                                         component_id=self.component_id)
            # Component end hook runner
            component_hooks_runner.run(
                hook_with_conditions=hooks_manager.fetch_hook(hook_type=Hook.HookType.ComponentHook,
                                                              hook_pos=Hook.HookPosition.EndHook),
                hook_argument=self._component)
            self.component_dict[self._component.name] = self._component

            RZTDL_STORE.update_graph(model_name=self.name, graph=tf.get_default_graph())

            # Model update hook runner
            model_hooks_runner.run(hook_with_conditions=hooks_manager.fetch_hook(hook_type=Hook.HookType.ModelHook,
                                                                                 hook_pos=Hook.HookPosition.UpdateHook),
                                   hook_argument=self)
            if isinstance(self._component.component_output, list):
                return [GraphUtils.get_global_component(op) for op in self._component.component_output]
            elif isinstance(self._component.component_output, str):
                return GraphUtils.get_global_component(self._component.component_output)
            else:
                raise ModelException(model_name=self.name,
                                     message='Supported types of Component Output is List[str], str where str represents tensornames. Given: {}'.format(
                                         type(self._component.component_output)))
        else:
            raise ModelException(model_name=self.name, message='Attempt to add Operator after model is closed.')

    @typechecked
    def get_component(self, component_name: str) -> Component:
        """
        | **@author:** Prathyush SP
        |
        | Get Component object        
        :param component_name: Component Name
        :return: Component Object
        """
        try:
            return self.component_dict[component_name]
        except AttributeError as e:
            logger.error('Cannot use get_component after model.close: {}'.format(e))
        except KeyError as e:
            raise Exception('Given component [{}] not present'.format(component_name))

    @typechecked
    def get_components_based_on_type(self, component_type: constants.ComponentType):
        """
        | **@author:** Prathyush SP
        |
        | Get Component objects based on type
        :param component_type: Component Name
        :return: Component Object
        """
        return [component for component_name, component in self.component_dict.items() if
                component.component_type == component_type]

    def clear_components(self):
        """
        | **@author:** Prathyush SP
        |
        | Clear all component from the model
        """
        RZTDL_STORE.remove_model(model_name=self.name)
        self.__init__(name=self.name, scopes=list(self.scopes))

    def close(self) -> Tensor:
        """
        | **@author:** Prathyush SP
        |
        | Finalize / Close Model
        :return: Last dl_layer output
        """
        # todo:: Prathyush SP - Check Graph Finalization
        self.final_component = self._component
        # tf.get_default_graph().finalize()
        RZTDL_STORE.update_graph(model_name=self.name, graph=tf.get_default_graph())
        # Calculate Model Complexity after model is finalized
        for tensor in RZTDL_STORE.get_all_weights(model_name=self.name).values():
            self._model_complexity += reduce(mul, tensor.get_shape().as_list())
        # Model close hook runner
        model_hooks_runner.run(hook_with_conditions=hooks_manager.fetch_hook(hook_type=Hook.HookType.ModelHook,
                                                                             hook_pos=Hook.HookPosition.CloseHook),
                               hook_argument=self)
        self.model_meta_graph = tf.train.export_meta_graph()
        # noinspection PyUnresolvedReferences
        return self

    def validate(self):
        """
        | **@author:** Prathyush SP
        |
        | Model Validation
        """
        tf.reset_default_graph()
        RZTDL_STORE.add_model(model_name=self.name)
        RZTDL_STORE.add_graph(model_name=self.name, graph=tf.get_default_graph())
        tf.Graph().__init__()
        tf.Graph().as_default()
        if RZTDL_CONFIG.TensorflowConfig.ENABLE_GLOBAL_SEED:
            tf.set_random_seed(RZTDL_CONFIG.TensorflowConfig.GLOBAL_SEED)
