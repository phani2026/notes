# -*- coding: utf-8 -*-
"""
@created on: 16/12/16,
@author: Prathyush SP,
@version: v0.0.1

Description:

Sphinx Documentation Status:

..todo::
    
"""
import operator
from sklearn.metrics import roc_auc_score
import numpy as np
import pandas as pd
import math
from typing import Union


def softmax_fn(input_array):
    """
    | **@author**: Prathyush SP
    |
    | Calculate Softmax for a given array
    :param y_true: Actual Label
    :param y_pred: Predicted Label
    :return: Gini Score
    """
    e_x = np.exp(input_array - np.max(input_array))
    return e_x / e_x.sum(axis=0)  # only difference


class NumpyVectorFunction(object):
    sigmoid = np.vectorize(lambda x: 1 / (1 + math.exp(-x)))
    apply_threshold = np.vectorize(lambda x, threshold: 1 if x >= threshold else 0)
    softmax = lambda x: softmax_fn(input_array=x)


def calculate_gini_score_manual(y_true, y_pred):
    """
    | **@author**: Prathyush SP
    |
    | Calculate Gini Score
    :param y_true: Actual Label
    :param y_pred: Predicted Label
    :return: Gini Score
    """
    assert y_true.shape == y_pred.shape
    n_samples = y_true.shape[0]
    arr = np.array([y_true, y_pred]).transpose()
    true_order, pred_order = arr[arr[:, 0].argsort()][::-1, 0], arr[arr[:, 1].argsort()][::-1, 0]
    l_true, l_pred, l_ones = np.cumsum(true_order) / np.sum(true_order), np.cumsum(pred_order) / np.sum(
        pred_order), np.linspace(1 / n_samples, 1, n_samples)
    g_true, g_pred = np.sum(l_ones - l_true), np.sum(l_ones - l_pred)
    return g_pred / g_true


def calculate_gini_score(y_pred, y_true, force_sigmoid=False):
    """
    | **@author:** Prathyush SP
    |
    | Calculate Gini Score - Utilizes 2*roc_suc - 1 Formula
    :param y_pred: Prediction Values
    :param y_true: True Values
    :return: Gini Score
    """
    y_true_t = np.reshape(y_true, newshape=[-1, ])
    try:
        if len(set(y_true_t)) < 2 or len(set(y_true_t)) > 2:
            return -1
        else:
            if force_sigmoid and max(abs(y_pred)) > 1:
                y_pred = NumpyVectorFunction.sigmoid(y_pred)
            return (2 * roc_auc_score(y_true=y_true, y_score=y_pred)) - 1
    except Exception as e:
        print(y_pred.shape, type(y_pred), [set(type(j) for j in i) for i in y_pred])
        print(y_true.shape, type(y_true), [set(type(j) for j in i) for i in y_true])
        print(y_pred)
        print(y_true)
        raise Exception('Gini Score Calculation Error, {}'.format(e))


def calculate_mean(var):
    """
    | **@author:** Prathyush SP
    |
    | Calculate mean of a list
    :param var: Input List
    :return: Mean of the List
    """
    if len(var) == 0:
        return '--'
    else:
        return sum(var) / len(var)


def calculate_slope(a: list, b: list):
    """
    | **@author**: Prathyush SP
    |
    | Calculate slope
    :param a: initial (x,y)
    :param b: final (x,y)
    :return: slope
    """
    return (float(a[1]) - float(b[1])) / (float(a[0]) - float(b[0]))


def calculate_distance(a, b):
    """
    | **@author**: Prathyush SP
    |
    | Simple Euclidean Distance Calculator
    :param a: List A
    :param b: List B
    :return: Euclidean Distance between A and B
    """
    # todo: Perform Validation
    return (sum((x - y) ** 2 for x, y in zip(a, b))) ** 0.5


def calculate_cluster_error(cluster):
    """
    | **@author**: Prathyush SP
    |
    | Calculated Cluster Errors
    :param cluster: Clusters
    :return: Cluster Errors and Cluster Centroids
    """
    # todo: Perform Validations
    cluster_centroid = np.average([customer for customer in cluster], 0).tolist()[0]
    return sum([calculate_distance(customer, cluster_centroid) for customer in cluster]) / len(
        cluster), cluster_centroid


def calculate_iv_score(data_path, output_label, one_hot=False, one_hot_range=None, apply_threshold=None,
                       fraction_column=()):
    """
    | **@author**: Prathyush SP
    |
    | Calculate Information Values for Independent Variables
    :param data_path: Input File Path
    :param output_label: Output Labels
    :param one_hot: Boolean, True if the columns represent one hot vector
    :param one_hot_range: One Hot Vector Column Range
    :param apply_threshold: Apply Threshold for Columns
    :param fraction_column: List of Fraction Columns for creating custom buckets
    :return: List of Attributes with Information Values
    """
    # todo: Add support for dictionary for input
    # todo: Perform Validation
    csv_data, iv_list = pd.read_csv(data_path, skiprows=0, index_col=0, skip_blank_lines=True), {}
    if apply_threshold:
        if not isinstance(apply_threshold, float):
            raise Exception('Threshold value should be a float. It is ' + str(type(apply_threshold)))
        for column_name in csv_data.columns:
            if column_name not in fraction_column:
                csv_data[column_name] = csv_data[column_name].apply(lambda x: 1 if x >= apply_threshold else 0)

    if one_hot:
        if one_hot_range is None:
            raise Exception('Provide One Hot Columns. Ex: one_hot_range = { \'region\': [5, 10]}')
        for key, values in one_hot_range.items():
            csv_data[key] = csv_data[csv_data.columns[values[0] - 1]].map(str)
            csv_data.rename(columns={csv_data.columns[values[0] - 1]: 'NA-' + csv_data.columns[values[0] - 1]},
                            inplace=True)
            for column in csv_data.columns[values[0]:values[1]]:
                csv_data[key] += csv_data[column].map(str)
                csv_data.rename(columns={column: 'NA-' + column}, inplace=True)
        for key in csv_data.columns:
            if 'NA-' in key:
                csv_data = csv_data.drop([key], axis=1)
    for column_name in csv_data.columns:
        if column_name != output_label:
            data = csv_data[[column_name, output_label]]
            if column_name in fraction_column:
                group = data.groupby(np.round(data[column_name], decimals=1), axis=0)
                iv_table = group.sum()
                count = group.count()
                mean = group.mean()
                iv_table['count'] = count[output_label]
                iv_table['odds_ratio'] = mean[output_label]
            else:
                group = data.groupby(by=[column_name], axis=0)
                iv_table = group.sum()
                count = group.count()
                mean = group.mean()
                iv_table['count'] = count
                iv_table['odds_ratio'] = mean
            iv_table.rename(columns={output_label: 'events'}, inplace=True)
            iv_table['non_events'] = iv_table['count'] - iv_table['events']
            iv_table = iv_table[iv_table['events'] != 0]
            iv_table = iv_table[iv_table['non_events'] != 0]
            iv_table['de'] = iv_table['events'] / sum(iv_table['events'])
            iv_table['dne'] = iv_table['non_events'] / sum(iv_table['non_events'])
            iv_table['woe'] = (iv_table['de'] / iv_table['dne']).apply(np.log) * 100
            iv_table['iv'] = ((iv_table['de'] - iv_table['dne']) * iv_table['woe']) / 100
            iv_table = iv_table.append(iv_table.sum(numeric_only=True), ignore_index=True)
            iv_list[column_name] = iv_table['iv'].tail(1).tolist()[0]
    return [i for i in sorted(iv_list.items(), reverse=True, key=operator.itemgetter(1))]


def calculate_kld_score(cluster_column, file_name: Union[str, None] = None,
                        data: Union[list, np.ndarray, pd.DataFrame] = None, skip_columns=(), fractional_column=(),
                        write_path: str = None):
    """
    | **@author**: Prathyush SP
    |
    | Calculate KL Divergence Matrix
    :param file_name: Input File Path
    :param data: Pandas dataframe or numpy ndarray
    :param cluster_column: Cluster Column
    :param skip_columns: Skip Columns
    :param fractional_column: Fractional Columns
    :param write_path: File write path
    :return: KL Divergence analysis
    """
    # todo: Add support for dictionary for input
    # todo: Perform Validation
    kl_analysis = None
    if file_name:
        csv_data = pd.read_csv(file_name, index_col=0)
    elif data:
        csv_data = data
    else:
        raise Exception(
            'Filepath and Data are none. The function needs atleast one of these parameters to be initialized')
    csv_data.rename(columns=lambda x: str(x), inplace=True)
    for column in csv_data.columns:
        if column == cluster_column:
            continue
        else:
            if column in skip_columns:
                print('Skipping ' + column)
                continue
            print(column)
            data = csv_data[[column, cluster_column]]
            if column in fractional_column:
                print('Fractional ' + column)
                data = data.round({column: 1})
            group = data.groupby([cluster_column, column])
            kl_table = group.size().unstack(level=1, fill_value=1)
            kl_table = kl_table.append(kl_table.sum(numeric_only=True), ignore_index=True)
            kl_table['Total'] = kl_table.sum(axis=1)
            kl_table.rename(columns=lambda x: str(x), inplace=True)
            for kl_table_column in kl_table.columns[:-1]:
                kl_table[kl_table_column + '_DIV'] = kl_table[kl_table_column] / kl_table['Total']
            for kl_table_column in kl_table.columns:
                if '_DIV' in kl_table_column:
                    kl_table[kl_table_column.replace('_DIV', '_LOG')] = np.log10(
                        kl_table[kl_table_column].divide(float(kl_table[kl_table_column].tail(1))))
            for kl_table_column in kl_table.columns:
                if '_LOG' in kl_table_column:
                    kl_table[kl_table_column.replace('_LOG', '_KL1')] = kl_table[kl_table_column].mul(
                        float(kl_table[kl_table_column.replace('_LOG', '_DIV')].tail(1)))
            kld = kl_table.filter(regex=".*_KL1")
            kl_table['KLD'] = kld.sum(axis=1).mul(-1)
            kl_table = kl_table.drop(kl_table.index[len(kl_table) - 1])
            if kl_analysis is None:
                kl_analysis = pd.DataFrame(index=kl_table.index)
                kl_analysis.index.name = 'Segments'
            kl_analysis[column] = kl_table['KLD']
            for kl_table_column in kl_table.columns:
                if '_LOG' in kl_table_column or '_DIV' in kl_table_column:
                    kl_table = kl_table.drop(kl_table_column, axis=1)
            if write_path:
                kl_table.to_csv(write_path + '/kl' + column + '.csv')
    if write_path:
        kl_analysis.to_csv(write_path + '/kl_analysis.csv')
    return kl_analysis

# def calculate_kld_score_df(dataframe, cluster_column, skip_columns=(), fractional_column=()):
#     """
#     @author: Prathyush SP
#
#     :param dataframe: Input File Path
#     :param cluster_column: Cluster Column
#     :param skip_columns: Skip Columns
#     :param fractional_column: Fractional Columns
#     :return: KL Divergence analysis
#     """
#     # todo: Add support for dictionary for input
#     # todo: Perform Validation
#     kl_analysis = None
#     # csv_data = pd.read_csv(file_path, index_col=0)
#     # dataframe.rename(columns=lambda x: str(x), inplace=True)
#     for column in dataframe.columns:
#         if column == cluster_column:
#             continue
#         else:
#             if column in skip_columns:
#                 print('Skipping ' + column)
#                 continue
#             print(column)
#             data = dataframe[[column, cluster_column]]
#             if column in fractional_column:
#                 print('Fractional ' + column)
#                 data = data.round({column: 1})
#             group = data.groupby([cluster_column, column])
#             kl_table = group.size().unstack(level=1, fill_value=1)
#             kl_table = kl_table.append(kl_table.sum(numeric_only=True), ignore_index=True)
#             kl_table['Total'] = kl_table.sum(axis=1)
#             kl_table.rename(columns=lambda x: str(x), inplace=True)
#             for kl_table_column in kl_table.columns[:-1]:
#                 kl_table[kl_table_column + '_DIV'] = kl_table[kl_table_column] / kl_table['Total']
#             for kl_table_column in kl_table.columns:
#                 if '_DIV' in kl_table_column:
#                     kl_table[kl_table_column.replace('_DIV', '_LOG')] = np.log10(
#                         kl_table[kl_table_column].divide(float(kl_table[kl_table_column].tail(1))))
#             for kl_table_column in kl_table.columns:
#                 if '_LOG' in kl_table_column:
#                     kl_table[kl_table_column.replace('_LOG', '_KL1')] = kl_table[kl_table_column].mul(
#                         float(kl_table[kl_table_column.replace('_LOG', '_DIV')].tail(1)))
#             kld = kl_table.filter(regex=".*_KL1")
#             kl_table['KLD'] = kld.sum(axis=1).mul(-1)
#             kl_table = kl_table.drop(kl_table.index[len(kl_table) - 1])
#             if kl_analysis is None:
#                 kl_analysis = pd.DataFrame(index=kl_table.index)
#                 kl_analysis.index.name = 'Segments'
#             kl_analysis[column] = kl_table['KLD']
#             for kl_table_column in kl_table.columns:
#                 if '_LOG' in kl_table_column or '_DIV' in kl_table_column:
#                     kl_table = kl_table.drop(kl_table_column, axis=1)
#                     # kl_table.to_csv('kl/kl' + column + '.csv')
#     # kl_analysis.to_csv('kl_analysis.csv')
#     return kl_analysis
