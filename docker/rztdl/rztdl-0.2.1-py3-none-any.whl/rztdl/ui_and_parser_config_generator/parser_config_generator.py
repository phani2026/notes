# -*- coding: utf-8 -*-
"""
| *@created on:* 24/05/18,
| *@author:* Umesh Kumar,
| *@version:* v0.0.1
|
| *Description:*
| 
| *Sphinx Documentation Status:* Complete
|
..todo::
"""
import re
from typing import Union

from typeguard import typechecked

import rztdl.utils.string_constants as constants
from rztdl.utils.dl_exception import keyexception


class ParserGenerator:
    """
    @author: Umesh Kumar
    Blueprint Generator Class
    """

    def __init__(self):
        """
        @author: Umesh Kumar
        """
        pass

    @staticmethod
    @keyexception
    @typechecked
    def get_parser_json(component_json: dict):
        """

        :param component_json: Component JSON (each layer or operator)
        :return:
        """
        component_json["internal_name"] = component_json["name"]
        del component_json["name"]
        component_json["label"] = ParserGenerator.generate_label_from_name(
            name=str(component_json["internal_name"]).split('.')[-1])
        ParserGenerator.add_ui_componenets(component_json["inputs"])
        component_json["parameters"] = list(
            filter(lambda x: "name" not in x.values(), component_json["parameters"]))
        component_json["parameters"] = list(
            filter(lambda x: "layer_scopes" not in x.values(), component_json["parameters"]))
        ParserGenerator.add_ui_componenets(component_json["parameters"])
        ParserGenerator.add_ui_componenets(component_json["outputs"])
        return component_json

    @staticmethod
    @typechecked
    def add_ui_componenets(ui_parameters: Union[list, dict]):
        """

        :param ui_parameters: UI parameters
        :return:
        """
        if isinstance(ui_parameters, list):
            for component in ui_parameters:
                ParserGenerator.get_component_json(component_parameter=component)
        else:
            ParserGenerator.get_component_json(component_parameter=ui_parameters)
        return ui_parameters

    @staticmethod
    @typechecked
    def get_component_json(component_parameter: dict):
        """

        :param component_parameter: Each component parameter
        :return:
        """
        component = component_parameter
        if "name" in component.keys():
            component["internal_name"] = component["name"]
            del component["name"]
        component["label"] = ParserGenerator.generate_label_from_name(name=component["internal_name"])
        component["render_type"] = ParserGenerator.get_render_type(
            render_type=component[constants.BLUEPRINT_PARAMETERS.DataType])
        if component[
            constants.BLUEPRINT_PARAMETERS.DataType] == constants.BLUEPRINT_PARAMETERS.DataTypeOptions.ARRAYOFSTRING:
            component[constants.BLUEPRINT_PARAMETERS.DataType] = constants.BLUEPRINT_PARAMETERS.DataTypeOptions.STRING
        elif component[
            constants.BLUEPRINT_PARAMETERS.DataType] == constants.BLUEPRINT_PARAMETERS.DataTypeOptions.ARRAYOFINT:
            component[constants.BLUEPRINT_PARAMETERS.DataType] = constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER
        if component[
            constants.BLUEPRINT_PARAMETERS.DataType] == constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX:
            for each_component in component["properties"]:
                ParserGenerator.add_ui_componenets(each_component)
        if component[constants.BLUEPRINT_PARAMETERS.DataType] == constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST:
            for each_component in component["possible_values"]:
                if isinstance(each_component, list) or isinstance(each_component, dict):
                    ParserGenerator.add_ui_componenets(each_component)

    @staticmethod
    def get_render_type(render_type: str):
        """

        :param render_type: Render type of the component parameter
        :return:
        """
        if render_type == constants.BLUEPRINT_PARAMETERS.DataTypeOptions.BOOLEAN:
            return "Checkbox"
        elif render_type == constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX:
            return "Form"
        elif render_type == constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST:
            return "DropDown"
        elif render_type == constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE:
            return None
        elif render_type == constants.BLUEPRINT_PARAMETERS.DataTypeOptions.ARRAYOFSTRING \
                or render_type == constants.BLUEPRINT_PARAMETERS.DataTypeOptions.ARRAYOFINT:
            return "Matrix"
        else:
            return "Text"

    @staticmethod
    @typechecked
    def generate_label_from_name(name: str):
        """

        :param name: Name for which label has to be generate
        :return:
        """
        caps_split = re.findall('[A-Z][^A-Z][a-z]*', name)
        if "." in name:
            return name.split('.')[-1].title()
        elif '_' in name:
            return ' '.join(name.split('_')).title()
        elif ' ' not in name and len(caps_split) > 1:
            return ' '.join(caps_split)
        else:
            return name.title()
