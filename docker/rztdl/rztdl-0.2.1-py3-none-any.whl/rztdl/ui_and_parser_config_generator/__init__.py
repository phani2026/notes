# -*- coding: utf-8 -*-
"""
| *@created on:* 25/05/18,
| *@author:* Umesh Kumar,
| *@version:* v0.0.1
|
| *Description:*
| 
| *Sphinx Documentation Status:* Complete
|
..todo::
"""

from rztdl.ui_and_parser_config_generator.parser_config_generator import ParserGenerator
from rztdl.ui_and_parser_config_generator.ui_config_generator import UIConfigGenerator
