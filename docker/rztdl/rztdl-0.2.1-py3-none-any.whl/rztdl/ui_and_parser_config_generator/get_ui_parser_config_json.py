# -*- coding: utf-8 -*-
"""
| *@created on:* 25/05/18,
| *@author:* Umesh Kumar,
| *@version:* v0.0.1
|
| *Description:*
| 
| *Sphinx Documentation Status:* Complete
|
..todo::
"""

from copy import deepcopy

from rztdl.ui_and_parser_config_generator import ParserGenerator
from rztdl.ui_and_parser_config_generator import UIConfigGenerator


def get_ui_parser_config_json(blueprint_json: dict):
    """

    :return:
    """
    parser_config = deepcopy(blueprint_json)
    ui_config = deepcopy(blueprint_json)
    ui_json = UIConfigGenerator.get_ui_json(component_json=ui_config)
    parser_json = deepcopy(ParserGenerator.get_parser_json(component_json=parser_config))
    return ui_json, parser_json
