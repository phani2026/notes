# -*- coding: utf-8 -*-
"""
| **@created on:** 09/08/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| Configuration Manager Module for the library
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

from typeguard import typechecked
from collections import OrderedDict
import tensorflow as tf
import os
from typing import Union
import logging
import json
from . import setup_logging
from rztdl.utils.singleton import Singleton
from rztdl.utils import string_constants as constants
from logging import Logger

logger = logging.getLogger(__name__)


class CommonConfig(object):
    """
    | **@author:** Prathyush SP
    | Common Configuration
    """

    # todo: Prathyush SP: Convert keys to string constants
    @typechecked
    def __init__(self, common_config: dict):
        try:
            self.STRICT_TYPE = common_config['strict_type']
            self.LOG_LEVEL = common_config['log_level']
            self.PATH_RZTDL = common_config['path']['rztdl_path']
            self.PATH_LOG = common_config['path']['logs']
            self.PATH_MODEL_SAVE_ML = common_config['path']['model_save_ml']
            self.PATH_MODEL_SAVE_DL = common_config['path']['model_save_dl']
            self.PATH_TIMELINE = common_config['path']['timeline']
            self.PATH_GRAPH = common_config['path']['graph']
            self.PATH_DATA = common_config['path']['data']
            self.PATH_BENCHMARK = common_config['path']['benchmark']
            self.DRY_RUN = common_config['path']['dry_run']
            self.PARALLEL_MODELS = common_config['parallel_models']
            self.NETWORK_META_FILE_NAME = common_config['path']['network_meta_file_name']
            self._GLOBAL_LOGGING_CONFIG_FILE_PATH = os.path.join("/".join(__file__.split('/')[:-1]), 'config',
                                                                 'rztdl_logging.yaml')
            self.PYTHON_OPTIMISE = common_config['python_optimise']
            self.HOOKS_ENABLED = common_config['hooks_enabled']
            self.RUN_SPLITS_IN_THREADS = common_config['run_splits_in_threads']
            self.RUN_SAVES_IN_THREADS = common_config['run_saves_in_threads']
            os.environ['PYTHONOPTIMIZE'] = str(self.PYTHON_OPTIMISE)
        except KeyError as ke:
            raise Exception('Key Error. Config Error', ke)


class TensorflowConfig(object):
    """
    | **@author:** Prathyush SP
    |
    | Tensorflow Configuration
    |
    """

    # noinspection PyProtectedMember
    @typechecked
    def __init__(self, tensorflow_config_data: dict):
        dtype_dict = {'tf.float16': tf.float16, 'tf.float32': tf.float32, 'tf.float64': tf.float64}
        try:
            self.GLOBAL_SEED = tensorflow_config_data['global_seed']['value']
            self.ENABLE_GLOBAL_SEED = tensorflow_config_data['global_seed']['enabled']
            self.CHECKPOINT_EPOCH = tensorflow_config_data['checkpoint_every_n_epochs']
            self.CHECKPOINT_HOUR = tensorflow_config_data['checkpoint_every_n_hours']
            self.CHECKPOINT_MAX_SAVES = tensorflow_config_data['checkpoint_max_to_keep']
            self.LOGGING_LEVEL_PYTHON = tensorflow_config_data['logging_level_python']
            self.LOGGING_LEVEL_CPP = tensorflow_config_data['logging_level_cpp']
            self.AUTO_TENSOR_CONVERSION = tensorflow_config_data['auto_tensor_conversion']
            self.TENSORBOARD_SUMMARY = tensorflow_config_data['tensorboard_summary']
            self.XLA_ENABLED = tensorflow_config_data['xla_enabled']
            self.GPU_ENABLED = tensorflow_config_data['config_proto']['gpu_options']['enabled']

            # todo: Prathyush SP - Placeholder , replace it with system config based algorithm
            self.DEFAULT_VALID_BATCH_SIZE = tensorflow_config_data['default_valid_batch_size']
            self.DEFAULT_TEST_BATCH_SIZE = tensorflow_config_data['default_test_batch_size']
            # todo: Prathyush SP: Remove this check when xla is stable
            self.CONFIG_PROTO = tf.ConfigProto()
            if self.XLA_ENABLED:
                logger.warning(
                    'Experimental XLA Compiler Enabled.. If you are facing issues in Network.train() API, disable xla in config')
                self.CONFIG_PROTO.graph_options.optimizer_options.global_jit_level = \
                    tensorflow_config_data['config_proto']['optimizer_options']['global_jit_level']
            self.CONFIG_PROTO.log_device_placement = tensorflow_config_data['config_proto']['log_device_placement']
            self.CONFIG_PROTO.allow_soft_placement = tensorflow_config_data['config_proto']['allow_soft_placement']
            # todo: Prathyush SP: Disabled due to incorrect default values by tensorflow.
            # if not self.GPU_ENABLED:
            #     os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
            # self.CONFIG_PROTO.gpu_options.allow_growth = tensorflow_config_data['config_proto']['gpu_options'][
            #     'allow_growth']
            # self.CONFIG_PROTO.gpu_options.per_process_gpu_memory_fraction = \
            #     tensorflow_config_data['config_proto']['gpu_options'][
            #         'total_memory']
            # self.CONFIG_PROTO.operation_timeout_in_ms = tensorflow_config_data['config_proto'][
            #     'operation_timeout_in_ms']
            # self.CONFIG_PROTO.intra_op_parallelism_threads = tensorflow_config_data['config_proto'][
            #     'intra_op_parallelism_threads']
            # self.CONFIG_PROTO.inter_op_parallelism_threads = tensorflow_config_data['config_proto'][
            #     'inter_op_parallelism_threads']
            if tensorflow_config_data['dtype'] in dtype_dict:
                self.DTYPE = dtype_dict[tensorflow_config_data['dtype']]
            else:
                raise Exception(
                    'DType Error: {} Supported Types: [{}]'.format(tensorflow_config_data['dtype'], dtype_dict))
            # noinspection PyUnusedLocal

            default_random_function = {
                constants.InitializerType._Parameters.ONES: constants.InitializerType.ones,
                constants.InitializerType._Parameters.ZEROS: constants.InitializerType.zeros,
                constants.InitializerType._Parameters.RANDOM_NORMAL: constants.InitializerType.random_normal,
                constants.InitializerType._Parameters.RANDOM_UNIFORM: constants.InitializerType.random_uniform,
                constants.InitializerType._Parameters.XAVIER: constants.InitializerType.xavier,
                constants.InitializerType._Parameters.TRUNCATED_NORMAL: constants.InitializerType.truncated_normal,
                constants.InitializerType._Parameters.ORTHOGONAL: constants.InitializerType.orthogonal
            }
            self.DEFAULT_WEIGHT_FN = default_random_function[
                constants.InitializerType._Parameters[tensorflow_config_data['default_weight_fn']]]()
            self.DEFAULT_BIAS_FN = default_random_function[
                constants.InitializerType._Parameters[tensorflow_config_data['default_bias_fn']]]()

            logging_level_python = {
                constants.LOGGING_LEVEL.ERROR: lambda: tf.logging.set_verbosity(tf.logging.ERROR),
                constants.LOGGING_LEVEL.INFO: lambda: tf.logging.set_verbosity(tf.logging.INFO),
                constants.LOGGING_LEVEL.WARN: lambda: tf.logging.set_verbosity(tf.logging.WARN),
                constants.LOGGING_LEVEL.DEBUG: lambda: tf.logging.set_verbosity(tf.logging.DEBUG),
            }

            def set_cpp_logging_level(level: str):
                os.environ['TF_CPP_MIN_LOG_LEVEL'] = level

            # cpp log level setting: https://github.com/tensorflow/tensorflow/blob/master/tensorflow/core/platform/default/logging.h#L31
            logging_level_cpp = {
                'INFO': lambda: set_cpp_logging_level('0'),
                'WARN': lambda: set_cpp_logging_level('1'),
                'ERROR': lambda: set_cpp_logging_level('2'),
                'FATAL': lambda: set_cpp_logging_level('3'),
            }
            logging_level_cpp[self.LOGGING_LEVEL_CPP]()
            logging_level_python[self.LOGGING_LEVEL_PYTHON]()
        except KeyError as ke:
            raise Exception('Key Error. Invalid RZTDL Configuration', ke)


class ParserConfig(object):
    """
    | **@author:** Himaprasoon PT
    | Parser Configuration
    """

    @typechecked
    def __init__(self, parser_config: Union[dict, OrderedDict]):
        try:
            self.PARSER_CONFIG_URL = parser_config["rest_url"]
        except KeyError as ke:
            raise Exception('Key Error. Invalid RZTDL Configuration', ke)


class MetadataConfig(object):
    """
    | **@author:** Prathyush SP
    |
    | Metadata Configuration Manager
    """

    @typechecked
    def __init__(self, metadata_config: Union[dict, OrderedDict]):
        self.METADATA = metadata_config


class DLConfigManager(metaclass=Singleton):
    """
    | **@author:** Prathyush SP
    |
    | DL Configuration Manager
    """

    @typechecked
    def __init__(self, config_file_path: str):
        # todo: Test Support for multiple dl frameworks
        global RZTDL_CONFIG_DATA
        try:
            RZTDL_CONFIG_DATA = json.load(open(config_file_path), object_pairs_hook=OrderedDict)
        except Exception as e:
            logger.critical(
                'Configuration file path error. Please provide configuration file path: {}'.format(config_file_path))
            raise Exception(
                'Configuration file path error. Please provide configuration file path: ' + config_file_path, e)
        try:
            self.TensorflowConfig = TensorflowConfig(RZTDL_CONFIG_DATA['tensorflow_config'])
            self.CommonConfig = CommonConfig(RZTDL_CONFIG_DATA['common_config'])
            self.MetadataConfig = MetadataConfig(RZTDL_CONFIG_DATA['metadata_config'])
            self.ParserConfig = ParserConfig(RZTDL_CONFIG_DATA["parser_config"])
        except KeyError as ke:
            raise Exception('Key not found. ', ke)

    def get_dlconfig_manager(self):
        """
        | **@author:** Prathyush SP
        |
        | Get DL Configuration Manager
        :return: DL Configuration Manager
        """
        return self

    @typechecked
    def update_dl_config_manager(self, config_file_path: str):
        """
        | **@author:** Prathyush SP
        |
        | Update DL Configuration Manager
        :param config_file_path: Configuration file path
        """
        logger.info("Updating Library Configuration - Config File: {}".format(config_file_path))
        self.__init__(config_file_path=config_file_path)

    @typechecked
    def update_dl_logging_config_manager(self, config_file_path: str = None, logger_obj: Logger = None):
        """
        | **@author:** Prathyush SP
        |
        | Update DL Logging Configuration
        :param config_file_path: Configuration file path
        :param logger_obj: Logger Object
        """
        if logger_obj is None:
            if config_file_path is None:
                raise Exception('Provide Config File Path or logger_obj')
            logger.info("Updating Library Logging configuration - Config File:{}".format(config_file_path))
            setup_logging(default_path=config_file_path)
            self.CommonConfig._GLOBAL_LOGGING_CONFIG_FILE_PATH = config_file_path
        else:
            logger.warning("Replacing root logger with given object. Use with Caution")
            setup_logging(default_logger=logger_obj)


DLConfigPath = os.path.join("/".join(__file__.split('/')[:-1]), 'config', 'rztdl_config.json')
RZTDL_CONFIG = DLConfigManager(config_file_path=DLConfigPath).get_dlconfig_manager()
RZTDL_CONFIG_DATA = OrderedDict()
