# -*- coding: utf-8 -*-
"""
| **@created on:** 4/07/17,
| **@author:** Thebzeera V,
| **@version:** v0.0.1
|
| **Description:**
| ModelMetaAnalysis Class
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import os
from collections import OrderedDict
import numpy as np
from typeguard import typechecked
from rztdl import RZTDL_CONFIG
from rztdl.utils.pyutils import File
from rztdl.utils.string_constants import ModelMetaConstant
from rztdl.utils.validations import validate_name


class ModelMetaAnalysis(object):
    """
    | **@author:** Thebzeera V
    |
    | Used to analyse the model meta
    """

    def __init__(self, network_name):
        """
        :param network_name: Network name
        """
        self.name = validate_name(network_name)
        self._cost = None
        self._optimizer = None
        self._accuracy = None
        self._gini = None
        self._time_elapsed = None
        self._model_name = None
        self.metric_name = None
        self._network_name = None
        self._test_batches = None
        self._epochs = None
        self._epoch_step = None
        self._learning_rate = None
        self._train_batch_size = None
        self._train_batches = None
        self._valid_batch_size = None
        self._valid_batches = None
        self._test_batch_size = None
        self._epoch_cost = None
        self._epoch_valid_cost = None
        self._epoch_accuracy = None
        self._epoch_valid_accuracy = None
        self._epoch_valid_gini = None
        self._epoch_progress = None
        self._epoch_gini = None
        self._epoch_eta = None
        self._epoch_time_elapsed = None
        self.save_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL

    @property
    def time_elapsed(self):
        """

        :return: time elapsed
        """
        return self._time_elapsed

    @time_elapsed.setter
    def time_elapsed(self, value):
        """

        :param value: value
        """

        self._time_elapsed = value

    @property
    def cost(self):
        """

        :return: Cost
        """
        return self._cost

    @cost.setter
    def cost(self, value):
        """

        :param value: value
        """
        self._cost = value

    @property
    def optimizer(self):
        """

        :return: Optimizer
        """
        return self._optimizer

    @optimizer.setter
    def optimizer(self, value):
        """

        :param value: Value
        """
        self._optimizer = value

    @property
    def epoch_progress(self):
        """

        :return: Epoch progress
        """
        return self._epoch_progress

    @epoch_progress.setter
    def epoch_progress(self, value):
        """

        :param value: Value
        """
        self._epoch_progress = value

    @property
    def accuracy(self):
        """

        :return: Accuracy
        """
        return self._accuracy

    @accuracy.setter
    def accuracy(self, value):
        """

        :param value: Value
        """
        self._accuracy = value

    @property
    def network_name(self):
        """

        :return: Network name
        """
        return self._network_name

    @network_name.setter
    def network_name(self, value):
        """

        :param value: Value
        """
        self._network_name = value

    @property
    def gini(self):
        """

        :return: Gini
        """
        return self._gini

    @gini.setter
    def gini(self, value):
        """

        :param value: Value
        """
        self._gini = value

    @property
    def model_name(self):
        """

        :return: Model name
        """
        return self._model_name

    @model_name.setter
    def model_name(self, value):
        """

        :param value: Value
        """
        self._model_name = value

    @property
    def epoch_step(self):
        """

        :return: Epoch Step
        """

        return self._epoch_step

    @epoch_step.setter
    def epoch_step(self, value):
        """

        :param value:  Value
        """
        self._epoch_step = value

    @property
    def learning_rate(self):
        """

        :return: Learning rate
        """

        return self._learning_rate

    @learning_rate.setter
    def learning_rate(self, value):
        """

        :param value: Value
        """
        self._learning_rate = value

    @property
    def train_batch_size(self):
        """

        :return: Train batch size
        """
        return self._train_batch_size

    @train_batch_size.setter
    def train_batch_size(self, value):
        """

        :param value: Value
        """

        self._train_batch_size = value

    @property
    def train_batches(self):
        """

        :return: train batches
        """

        return self._train_batches

    @train_batches.setter
    def train_batches(self, value):
        """

        :param value: Value
        """
        self._train_batches = value

    @property
    def valid_batches(self):
        """

        :return: Valid batches
        """

        return self._valid_batches

    @valid_batches.setter
    def valid_batches(self, value):
        """

        :param value: Value
        """
        self._valid_batches = value

    @property
    def test_batch_size(self):
        """

        :return: Test batch size
        """

        return self._test_batch_size

    @test_batch_size.setter
    def test_batch_size(self, value):
        """

        :param value:  Value
        """
        self._test_batch_size = value

    @property
    def epoch_cost(self):
        """

        :return: Epoch cost
        """

        return self._epoch_cost

    @epoch_cost.setter
    def epoch_cost(self, value):
        """

        :param value: Value
        """
        self._epoch_cost = value

    @property
    def epoch_valid_cost(self):
        """

        :return: Epoch valid cost
        """

        return self._epoch_valid_cost

    @epoch_valid_cost.setter
    def epoch_valid_cost(self, value):
        """

        :param value: Value
        """
        self._epoch_valid_cost = value

    @property
    def epoch_accuracy(self):
        """

        :return: Epoch Accuracy
        """

        return self._epoch_accuracy

    @epoch_accuracy.setter
    def epoch_accuracy(self, value):
        """

        :param value: Value
        """
        self._epoch_accuracy = value

    @property
    def epoch_valid_accuracy(self):
        """

        :return: Epoch Valid Accuracy
        """

        return self._epoch_valid_accuracy

    @epoch_valid_accuracy.setter
    def epoch_valid_accuracy(self, value):
        """

        :param value: Value
        """
        self._epoch_valid_accuracy = value

    @property
    def epoch_valid_gini(self):
        """

        :return: Epoch valid gini
        """
        return self._epoch_valid_gini

    @epoch_valid_gini.setter
    def epoch_valid_gini(self, value):
        """

        :param value: Value
        """
        self._epoch_valid_gini = value

    @property
    def epoch_gini(self):
        """

        :return: Epoch gini
        """

        return self._epoch_gini

    @epoch_gini.setter
    def epoch_gini(self, value):
        """

        :param value:Value
        """
        self._epoch_gini = value

    @property
    def epoch_eta(self):
        """

        :return: Epoch eta
        """

        return self._epoch_eta

    @epoch_eta.setter
    def epoch_eta(self, value):
        """

        :param value: Value
        """
        self._epoch_eta = value

    @property
    def epoch_time_elapsed(self):
        """

        :return:  Epoch time elapsed
        """

        return self._epoch_time_elapsed

    @epoch_time_elapsed.setter
    def epoch_time_elapsed(self, value):
        """

        :param value: Value
        """

        self._epoch_time_elapsed = value

    @property
    def test_batches(self):
        """

        :return: Test batches
        """

        return self._test_batches

    @test_batches.setter
    def test_batches(self, value):
        """

        :param value: Value
        """
        self._test_batches = value

    def get_meta_data(self):
        """

        :return: Key, Cost, Accuracy, Gini
        """
        keys = self.metadata.keys()
        init_path = self.save_path + self.name + '/'
        if os.path.exists(path=init_path + 'model.meta'):
            self.metadata = File.read_json(path=init_path + 'model.meta', object_pairs_hook=OrderedDict)
        cost = [self.metadata[k][ModelMetaConstant.TEST_META][ModelMetaConstant.TEST_META_OPTIONS.TEST_COST] for k in
                keys]

        accuracy = [self.metadata[k][ModelMetaConstant.TEST_META][ModelMetaConstant.TEST_META_OPTIONS.TEST_ACCURACY] for
                    k in keys]

        gini = [self.metadata[k][ModelMetaConstant.TEST_META][ModelMetaConstant.TEST_META_OPTIONS.TEST_GINI] for k in
                keys]

        return keys, cost, accuracy, gini

    def initialize_params(self):
        """
        | **@author:** Thebzeera V
        |
        | Initializing the Parameter
        :return: parameters
        """
        self.cost = self.metadata[best_run_id][ModelMetaConstant.TEST_META][
            ModelMetaConstant.TEST_META_OPTIONS.TEST_COST]
        self.optimizer = self.metadata[best_run_id][ModelMetaConstant.OPTIMIZER]
        self.accuracy = self.metadata[best_run_id][ModelMetaConstant.TEST_META][
            ModelMetaConstant.TEST_META_OPTIONS.TEST_ACCURACY]
        self.model_name = self.metadata[best_run_id][ModelMetaConstant.MODEL_NAME]
        self.gini = self.metadata[best_run_id][ModelMetaConstant.TEST_META][
            ModelMetaConstant.TEST_META_OPTIONS.TEST_GINI]
        self.time_elapsed = self.metadata[best_run_id][ModelMetaConstant.TEST_META][
            ModelMetaConstant.TEST_META_OPTIONS.TEST_TIME_ELAPSED]
        self.learning_rate = self.metadata[best_run_id][ModelMetaConstant.LEARNING_RATE]
        self.test_batches = self.metadata[best_run_id][ModelMetaConstant.TEST_BATCHES]
        self.test_batch_size = self.metadata[best_run_id][ModelMetaConstant.TEST_BATCH_SIZE]
        self.valid_batch_size = self.metadata[best_run_id][ModelMetaConstant.VALID_BATCH_SIZE]
        self.train_batches = self.metadata[best_run_id][ModelMetaConstant.TRAIN_BATCHES]
        self.train_batch_size = self.metadata[best_run_id][ModelMetaConstant.TRAIN_BATCH_SIZE]
        self.valid_batches = self.metadata[best_run_id][ModelMetaConstant.VALID_BATCHES]
        self.epoch_cost = self.metadata[best_run_id][ModelMetaConstant.TRAIN_META][
            ModelMetaConstant.TRAIN_META_OPTIONS.EPOCH_COST]
        self.epoch_valid_cost = self.metadata[best_run_id][ModelMetaConstant.TRAIN_META][
            ModelMetaConstant.TRAIN_META_OPTIONS.EPOCH_VALID_COST]
        self.epoch_eta = self.metadata[best_run_id][ModelMetaConstant.TRAIN_META][
            ModelMetaConstant.TRAIN_META_OPTIONS.EPOCH_ETA]
        self.epoch_gini = self.metadata[best_run_id][ModelMetaConstant.TRAIN_META][
            ModelMetaConstant.TRAIN_META_OPTIONS.EPOCH_GINI]
        self.epoch_accuracy = self.metadata[best_run_id][ModelMetaConstant.TRAIN_META][
            ModelMetaConstant.TRAIN_META_OPTIONS.EPOCH_ACCURACY]
        self.epoch_progress = self.metadata[best_run_id][ModelMetaConstant.TRAIN_META][
            ModelMetaConstant.TRAIN_META_OPTIONS.EPOCH_PROGRESS]
        self.epoch_time_elapsed = self.metadata[best_run_id][ModelMetaConstant.TRAIN_META][
            ModelMetaConstant.TRAIN_META_OPTIONS.EPOCH_TIME_ELAPSED]
        self.epoch_valid_gini = self.metadata[best_run_id][ModelMetaConstant.TRAIN_META][
            ModelMetaConstant.TRAIN_META_OPTIONS.EPOCH_VALID_GINI]
        self.epoch_valid_accuracy = self.metadata[best_run_id][ModelMetaConstant.TRAIN_META][
            ModelMetaConstant.TRAIN_META_OPTIONS.EPOCH_VALID_ACCURACY]
        self.epoch_step = self.metadata[best_run_id][ModelMetaConstant.EPOCH_STEP]

        return self

    @typechecked
    def get_run(self, id: int):
        """
        | **@author:** Thebzeera V
        |
        | Corresponding to the run id return metadata
        :param id: Run id
        :return: Metadata
        """
        init_path = self.save_path + self.name + '/'
        if os.path.exists(path=init_path + 'model.meta'):
            self.metadata = File.read_json(path=init_path + 'model.meta', object_pairs_hook=OrderedDict)
        self.id = id
        keys = self.metadata.keys()
        for k in keys:
            if self.id is (int(k)):
                return self.metadata[k]

    @typechecked
    def get_best_run(self, metric_name: str):
        """
        | **@author:** Thebzeera V
        |
        | Best of runs
        :param metric_name: Metric Name
        """

        global best_run_id
        self.metric_name = metric_name
        keys, cost, accuracy, gini = self.get_meta_data()

        if self.metric_name is 'cost':
            best_cost = min(cost, key=float)
            for k in keys:
                if best_cost == self.metadata[k][ModelMetaConstant.TEST_META][
                    ModelMetaConstant.TEST_META_OPTIONS.TEST_COST]:
                    best_run_id = k

        if self.metric_name is 'accuracy':
            best_accuracy = max(accuracy, key=float)
            for k in keys:
                if best_accuracy == self.metadata[k][ModelMetaConstant.TEST_META][
                    ModelMetaConstant.TEST_META_OPTIONS.TEST_ACCURACY]:
                    best_run_id = k

        if self.metric_name is 'gini':
            best_gini = max(gini, key=float)
            for k in keys:
                if best_gini == self.metadata[k][ModelMetaConstant.TEST_META][
                    ModelMetaConstant.TEST_META_OPTIONS.TEST_GINI]:
                    best_run_id = k

        self.initialize_params()

        return self

    @typechecked
    def get_average_run(self, metric_name: str):
        """
        | **@author:** Thebzeera V
        |
        | Average of the runs
        |
        :param metric_name: metric name
        """

        self.metric_name = metric_name
        keys, cost, accuracy, gini = self.get_meta_data()

        if self.metric_name is 'cost':
            sum_meta = sum(cost)
            average_cost = np.divide(sum_meta, len(list(keys)))
            return average_cost

        if self.metric_name is 'accuracy':
            sum_meta = sum(accuracy)
            average_accuracy = np.divide(sum_meta, len(list(keys)))
            return average_accuracy

        if self.metric_name is 'gini':
            sum_meta = sum(gini)
            average_gini = np.divide(sum_meta, len(list(keys)))
            return average_gini

        self.initialize_params()

        return self

    @typechecked
    def get_least_run(self, metric_name: str):
        """
        | **@author:** Thebzeera V
        |
        | Least of the runs
        :param metric_name: Metric name
        """

        global best_run_id
        self.metric_name = metric_name
        keys, cost, accuracy, gini = self.get_meta_data()

        if self.metric_name is 'cost':
            least_cost = max(cost, key=float)
            for k in keys:
                if least_cost == self.metadata[k][ModelMetaConstant.TEST_META][
                    ModelMetaConstant.TEST_META_OPTIONS.TEST_COST]:
                    best_run_id = k

        if self.metric_name is 'accuracy':
            least_accuracy = min(accuracy, key=float)
            for k in keys:
                if least_accuracy == self.metadata[k][ModelMetaConstant.TEST_META][
                    ModelMetaConstant.TEST_META_OPTIONS.TEST_ACCURACY]:
                    best_run_id = k

        if self.metric_name is 'gini':
            least_gini = min(gini, key=float)
            for k in keys:
                if least_gini == self.metadata[k][ModelMetaConstant.TEST_META][
                    ModelMetaConstant.TEST_META_OPTIONS.TEST_GINI]:
                    best_run_id = k

        self.initialize_params()

        return self
