# -*- coding: utf-8 -*-
"""
| **@created on:** 11/05/17,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::
"""
from rztdl.meta.meta_class import Meta
from collections import OrderedDict
from rztdl.utils.string_constants import NetworkMetaConstant
from typeguard import typechecked
from rztdl import RZTDL_CONFIG
import logging
from rztdl.utils.pyutils import Directories, File

logger = logging.getLogger(__name__)


class NetworkMeta(Meta):
    """
    | **@author:** Prathyush SP
    |
    | Network Meta Class
    """

    def __init__(self):
        super().__init__(mtype='network_meta')
        self.type = 'network_meta'

    @typechecked
    def add_meta(self, name: str, runs: int, size: str, ntype: str):
        """
        | **@author:** Prathyush SP
        |
        | Add Network
        :param name: Network name
        :param runs: Network Runs
        :param size: Network Size
        :param ntype: Network Type [ml / dl]
        """
        self.meta[self.type][name] = OrderedDict()
        self.meta[self.type][name][NetworkMetaConstant.RUNS] = runs
        self.meta[self.type][name][NetworkMetaConstant.SIZE] = size
        self.meta[self.type][name][NetworkMetaConstant.TYPE] = ntype

    @typechecked
    def update_meta(self, name: str, save_path: str = RZTDL_CONFIG.CommonConfig.PATH_RZTDL,
                    ntype: str = NetworkMetaConstant.TYPE_OPTION.DL):
        """
        | **@author:** Prathyush SP
        |
        | Update Network
        :param save_path: path to save network meta
        :param ntype: Type of Network. It can be DL method or ML method
        :param name: Network Name
        """
        if name in self.meta[self.type].keys():
            try:
                self.meta[self.type][name][NetworkMetaConstant.RUNS] = len(
                    Directories.count_dirs(save_path + name, depth=1))
                self.meta[self.type][name][NetworkMetaConstant.SIZE] = Directories.size(save_path + name)
            except Exception as e:
                logger.warning('Error writing Network: {} to Network Meta . . .'.format(name))
        else:
            self.add_meta(name=name, runs=1, size=Directories.size(
                save_path + name), ntype=ntype)

    def save_meta(self, save_path: str = RZTDL_CONFIG.CommonConfig.PATH_RZTDL,
                  file_name: str = RZTDL_CONFIG.CommonConfig.NETWORK_META_FILE_NAME):
        """
        | **@author:** Prathyush SP
        |
        | Save Network Meta
        :param save_path: Save Path
        :param file_name: File Name
        """
        File.write_json(data=self.meta, save_path=save_path, file_name=file_name)

    def load_meta(self, network_name: str = None, load_path: str = RZTDL_CONFIG.CommonConfig.PATH_RZTDL,
                  file_name: str = RZTDL_CONFIG.CommonConfig.NETWORK_META_FILE_NAME,
                  ntype: str = NetworkMetaConstant.TYPE_OPTION.DL):
        """
        | **@author:** Prathyush SP
        |
        | Load Network Meta
        :param ntype: Type of Network. It can be DL method or ML method
        :param network_name: Network Name
        :param load_path: Load Path
        :param file_name: File Name
        """
        try:
            self.meta = File.load_json(load_path=load_path, file_name=file_name, load_format=OrderedDict)
        except FileNotFoundError:
            logger.warning('Meta not found. Creating new meta')
            self.add_meta(name=network_name, runs=1, size='0 kb', ntype=ntype)
        return self
