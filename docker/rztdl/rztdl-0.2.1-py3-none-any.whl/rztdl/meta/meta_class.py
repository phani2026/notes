# -*- coding: utf-8 -*-
"""
| **@created on:** 11/05/17,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::
"""

from abc import ABCMeta, abstractmethod
from collections import OrderedDict
from rztdl.utils.pyutils import ROrderedDict


class Meta(metaclass=ABCMeta):
    """
    | **@author:** Prathyush SP
    |
    | Abstract Meta Class
    """

    def __init__(self, mtype: str):
        self.meta = OrderedDict([(mtype, ROrderedDict())])

    @abstractmethod
    def add_meta(self, **kwargs):
        """
        | **@author:** Prathyush SP
        |
        | Add Meta
        :param kwargs: Implementation arguments
        """
        pass

    @abstractmethod
    def update_meta(self, name: str):
        """
        | **@author:** Prathyush SP
        |
        | Update Meta
        :param name:  Meta Name
        """
        pass

    @abstractmethod
    def save_meta(self, save_path: str):
        """
        | **@author:** Prathyush SP
        |
        | Save Meta
        :param save_path:  Save Path
        """
        pass

    @abstractmethod
    def load_meta(self, load_path: str):
        """
        | **@author:** Prathyush SP
        |
        | Load Meta Class
        :param load_path: Load Path
        :return:
        """
        pass
