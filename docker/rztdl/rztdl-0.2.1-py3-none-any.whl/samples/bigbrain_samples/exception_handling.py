# -*- coding: utf-8 -*-
"""
@created on: 30/05/2018,
@author: Prathyush SP
@version: v0.0.1

Description:

Sphinx Documentation Status:

..todo::

"""

import rztdl.dl
import logging
import traceback
from rztdl.utils.dl_exception import RztdlException
from functools import wraps

logger = logging.getLogger(__name__)


def check_exception(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except RztdlException as e:
            e.traceback = traceback.format_exc()
            logger.error(e.__repr__())
            exit(1)

    return wrapped


@check_exception
def model_fn():
    model = rztdl.dl.Model('titanic_model', scopes=['titanic_model', 't_model'])
    model.add_component(rztdl.dl.buffer.InBuffer(name="data_buffer", buffer_features=3))
    model.add_component(rztdl.dl.buffer.InBuffer(name="label_buffer", buffer_features=1))
    model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1",
                                                           layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                           layer_nodes=10,
                                                           layer_dropout=2.0))
    model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_3",
                                                           layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                           layer_nodes=1, component_input='hidden_layer_1'))
    model.add_component(
        rztdl.dl.cost.MeanSquareError(name='mse_error_next', labels='label_buffer', predictions='hidden_layer_3',
                                      log_component=True))
    model.add_component(rztdl.dl.optimizers.AdamOptimizer(name='adam_opt_1', component_input='mse_error_next',
                                                          ))
    model.close()
    return model


model = model_fn()
