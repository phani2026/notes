# -*- coding: utf-8 -*-
"""
@created on: 25/01/17,
@author: Prathyush SP,
@version: v0.0.1

Description:

Sphinx Documentation Status:

..todo::
"""

import rztdl.dl
from rztdl.utils.file import read_csv

from pympler.web import start_in_background
from pympler.classtracker import ClassTracker

ct = ClassTracker()

data_path = '/'.join(str(__file__).split('/')[:-2]) + "/data/mnist_dataset.csv"
train_data, train_label, valid_data, valid_label, test_data, test_label = read_csv(data_path, split_ratio=[50, 20, 30],
                                                                                   delimiter=";",
                                                                                   randomize=True, label_vector=True)

model = rztdl.dl.Model('cnn')
model.add_layer(rztdl.dl.layer.InputLayer("input_layer", layer_nodes=len(train_data[0])))
model.add_operator(rztdl.dl.operator.ReshapeOperator('reshape_op', shape=[-1, 4, 196, 1], operator_input='input_layer',
                                                     operator_output='reshape_op_out'))

# Start of Stack
model.add_operator(rztdl.dl.operator.SplitOperator('split_op', dimension=1, size_splits=[1, 1, 1, 1],
                                                   operator_input='reshape_op_out',
                                                   operator_output=['split_op_out1', 'split_op_out2',
                                                                    'split_op_out3', 'split_op_out4']))

model.add_layer(rztdl.dl.layer.ConvolutionLayer('con1', filter_dimensions=[5, 5, 1, 32], filter_strides=[1, 1, 1, 1],
                                                filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                layer_input='split_op_out1'))
model.add_layer(rztdl.dl.layer.PoolLayer('pool1', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                         pool_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_layer(rztdl.dl.layer.ConvolutionLayer('con2', filter_dimensions=[5, 5, 1, 32], filter_strides=[1, 1, 1, 1],
                                                filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                layer_input='split_op_out2'))
model.add_layer(rztdl.dl.layer.PoolLayer('pool2', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                         pool_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_layer(rztdl.dl.layer.ConvolutionLayer('con3', filter_dimensions=[5, 5, 1, 32], filter_strides=[1, 1, 1, 1],
                                                filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                layer_input='split_op_out3'))
model.add_layer(rztdl.dl.layer.PoolLayer('pool3', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                         pool_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_layer(rztdl.dl.layer.ConvolutionLayer('con4', filter_dimensions=[5, 5, 1, 32], filter_strides=[1, 1, 1, 1],
                                                filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                layer_input='split_op_out4'))
model.add_layer(rztdl.dl.layer.PoolLayer('pool4', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                         pool_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_operator(rztdl.dl.operator.ConcatOperator('concat_op', dimension=1,
                                                   operator_input=['pool1', 'pool2', 'pool3', 'pool4'],
                                                   operator_output='concat_op_out'))

# End of Stack

model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1", layer_nodes=10,
                                                   layer_activation=rztdl.dl.constants.ACTIVATION.RELU))
model.add_layer(rztdl.dl.layer.OutputLayer(name="output_layer",
                                           layer_activation=rztdl.dl.constants.ACTIVATION.IDENTITY,
                                           layer_nodes=len(train_label[0])))
model.close()

network = rztdl.dl.Network('mnist_data')
network.train(epoch=1000, learning_rate=0.01, model=model, cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
              optimizer=rztdl.dl.constants.OPTIMIZER.ADAM,
              train_data={'input_layer': train_data, 'output_layer': train_label},
              valid_data={'input_layer': valid_data, 'output_layer': valid_label},
              test_data={'input_layer': test_data, 'output_layer': test_label},
              display_step=1, train_batches=13)