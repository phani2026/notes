# -*- coding: utf-8 -*-
"""
| **@created on:** 02/11/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| Model Hooks Example
|
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""
import rztdl.dl
from rztdl.utils.file import read_csv
from rztdl.dl.dl_hooks import model_begin_hook, model_close_hook, model_update_hook
from datetime import datetime
from rztdl.dl.model import Model
import time

titan_start_time = None
titan_end_time = None
mnist_start_time = None
mnist_end_time = None


@model_begin_hook(model_name='titanic')
def model_begin_hook_sample_titanic(model: Model):
    """
    | **@author:** Prathyush SP
    |
    | Run Model begin hook on titanic model
    :param model: Model Object
    """
    global titan_start_time
    titan_start_time = time.time()


@model_close_hook(model_name='titanic')
def model_end_hook_sample_titanic(model: Model):
    """
    | **@author:** Prathyush SP
    |
    | Run Model end hook on titanic model
    :param model: Model Object
    """
    global titan_end_time
    titan_end_time = time.time()


@model_begin_hook(model_name='mnist')
def model_begin_hook_sample_mnist(model: Model):
    """
    | **@author:** Prathyush SP
    |
    | Run Model begin hook on mnist model
    :param model: Model Object
    """
    global mnist_start_time
    mnist_start_time = time.time()


@model_close_hook(model_name='mnist')
def model_end_hook_sample_mnist(model: Model):
    """
    | **@author:** Prathyush SP
    |
    | Run Model end hook on mnist model
    :param model: Model Object
    """
    global mnist_end_time
    mnist_end_time = time.time()


@model_update_hook()
def model_update_hook_sample(model: Model):
    """
    | **@author:** Prathyush SP
    |
    | Run Model update hook
    :param model: Model Object
    """
    print('Run Model Update Hook')
    # noinspection PyUnresolvedReferences
    print('Running for {} - Number of Components: {}'.format(model.name, model.component_id))


model = rztdl.dl.Model('titanic')
model.add_component(rztdl.dl.buffer.InBuffer("input_buffer", buffer_features=10))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1",
                                                       layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                       layer_nodes=10,
                                                       normalisation=rztdl.dl.constants.NormalizationType.l2_norm(),
                                                       component_input='input_buffer'))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_2",
                                                       layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                       layer_nodes=10, component_input='hidden_layer_1'))
model.add_component(rztdl.dl.buffer.InBuffer(name="output_buffer", buffer_features=1))
model.close()

model = rztdl.dl.Model('mnist')
model.add_component(rztdl.dl.buffer.InBuffer(name="input_buffer", buffer_features=784))
model.add_component(rztdl.dl.layer.ConvolutionLayer('convolution_layer_1', filter_dimensions=[5, 5, 1, 32],
                                                    filter_strides=[1, 1, 1, 1],
                                                    filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                    component_input='input_buffer'))
model.add_component(rztdl.dl.layer.PoolLayer('pool_layer_1', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                             pool_padding=rztdl.dl.constants.PaddingType.SAME, ))
model.add_component(rztdl.dl.layer.ConvolutionLayer('convolution_layer_2', filter_dimensions=[5, 5, 32, 64],
                                                    filter_strides=[1, 1, 1, 1],
                                                    filter_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_component(rztdl.dl.layer.PoolLayer('pool_layer_2', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                             pool_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1", layer_nodes=10,
                                                       layer_activation=rztdl.dl.constants.ActivationType.RELU))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_2", layer_nodes=10,
                                                       layer_activation=rztdl.dl.constants.ActivationType.RELU))
model.add_component(rztdl.dl.buffer.InBuffer(name="output_buffer", buffer_features=10))
model.close()

print('Model Building Time for titan: {}'.format(titan_end_time - titan_start_time))
print('Model Building Time for mnist: {}'.format(mnist_end_time - mnist_start_time))
