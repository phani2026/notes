# -*- coding: utf-8 -*-
"""
| **@created on:** 17/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

import rztdl.dl
from rztdl import RZTDL_MODULE_PATH
from rztdl.dl.dataset.dataset_handler import DatasetHandler
from rztdl.dl.dataset.dataset_split import Split
from rztdl.dl.dataset.primitive.csv_dataset import CsvDataset
from rztdl.dl.dataset.dataset_split import DatasetSplit
from rztdl.dl.dl_hooks.dl_hooks_repo.flow_hooks_repo import flow_begin_hook, flow_update_hook
from rztdl.dl.flows.flow import Flow
import logging
import tensorflow as tf

logger = logging.getLogger(__name__)


# @flow_begin_hook()
# def test_flow_begin_hook(flow: Flow):
#     """
#     | **@author:** Prathyush SP
#     |
#     | Run Flow begin hook
#     :param flow: Flow Object
#     """
#     print('Run Flow begin hook')
#     # noinspection PyUnresolvedReferences
#     print('Running for {} - Buffer Type: {}'.format(flow.name, flow.flow_type))
#     exit()

#
@flow_update_hook(interval=1, interval_type='epoch')
def saver_hook(*args, **kwargs):
    args = args[0]
    args['flow'].saver.save(sess=args['flow'].session, save_path='/tmp/saves/hook_save_1/ckpt',
                            global_step=args['interval'])
    print('Saving in hook save 1')


@flow_update_hook(interval=5, interval_type='epoch')
def saver_hook(*args, **kwargs):
    args = args[0]
    args['flow'].saver.save(sess=args['flow'].session, save_path='/tmp/saves/hook_save_2/ckpt',
                            global_step=args['interval'])
    print('Saving in hook save 2')


EPOCH = 10
BATCH_SIZE = 32
MODEL_NAME = 'titanic'
root_path = RZTDL_MODULE_PATH
d1 = DatasetHandler(name='titanic_data',
                    dataset_elements={'sepal_features_buffer', 'petal_features_buffer', 'label_buffer'})
d1.add_dataset(
    CsvDataset(name='features', file_name=root_path + '/../samples/data/iris_data_multiclass.csv',
               column_names={'sepal_features_buffer': ['Sepal Length', 'Sepal Width'],
                             'petal_features_buffer': ['Petal Length', 'Petal Width'],
                             'label_buffer': ['Label']}))
d1.close()

split = DatasetSplit(name='basic_split', split_ratio=[50, 20, 30], split_metrics={'meansq'})
split.add_split(Split('train_sp', template=rztdl.dl.constants.DatasetTemplate.train(), metrics={'meansq'}))
split.add_split(Split('valid_sp', template=rztdl.dl.constants.DatasetTemplate.valid(), metrics={'meansq'}))
split.add_split(Split('test_sp', template=rztdl.dl.constants.DatasetTemplate.test(), metrics={'meansq'}))
split.close()

model = rztdl.dl.Model(MODEL_NAME)
model.add_component(
    rztdl.dl.buffer.InBuffer(name="sepal_features_buffer", buffer_shape=[None, 2]))
model.add_component(
    rztdl.dl.buffer.InBuffer(name="petal_features_buffer", buffer_shape=[None, 2]))
model.add_component(
    rztdl.dl.buffer.InBuffer(name="label_buffer", buffer_shape=[None, 1]))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1",
                                                       layer_nodes=10, component_input='sepal_features_buffer'))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_2",
                                                       layer_nodes=1, component_input='petal_features_buffer'))
model.add_component(
    rztdl.dl.operator.ConcatOperator(name='concat_op', component_input=['hidden_layer_1', 'hidden_layer_2'],
                                     dimension=1, component_output='concat_operator_output'))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_3",
                                                       layer_nodes=1, component_input='concat_operator_output'))
model.add_component(
    rztdl.dl.cost.MeanSquareError(name='meansq', labels='label_buffer', predictions='hidden_layer_2',
                                  log_component=True))
model.add_component(rztdl.dl.optimizers.AdamOptimizer(name='adam_opt', component_input='meansq'))

model.close()

with rztdl.dl.ModelRunnerV1(name='mr', model=model) as model_runner:
    model_runner.run_flow(rztdl.dl.flow.TrainFlowV1(name='flow1', epoch=10, batch_size=5,
                                                    learning_rate=[0.01], optimizers=['adam_opt'],
                                                    dataset_handler=d1, dataset_split=split,
                                                    ))
