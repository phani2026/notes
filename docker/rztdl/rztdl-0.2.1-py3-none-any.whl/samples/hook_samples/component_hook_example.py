# -*- coding: utf-8 -*-
"""
| **@created on:** 02/11/17,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
|
| Component Hook Example
| **Sphinx Documentation Status:** Complete
|
..todo::
    --
"""

import rztdl.dl
from rztdl.dl.dl_hooks import component_begin_hook, component_end_hook
from rztdl.dl.components.component import Component
from rztdl.dl.helpers.tfhelpers import GraphUtils


@component_begin_hook()
def component_b_hook(component: Component):
    """
    | **@author:** Prathyush SP
    |
    | Component begin hook to run for all layers
    :param component: Component Object
    """
    print('Building Component "{}"'.format(component.name))


@component_end_hook()
def component_e_hook(component: Component):
    """
    | **@author:** Prathyush SP
    |
    | Component end hook to run for all layers
    :param component: Component Object
    """
    print('Completed layer "{}"'.format(component.name))


@component_begin_hook(component_name='input_buffer')
def run_component_begin_hook_only_for_input_buffer(component: Component):
    """
    | **@author:** Prathyush SP
    |
    | Component begin hook to run for only for Input Buffer
    :param component: Component Object
    """
    print('Run Component begin hook only for Input Buffer')
    # noinspection PyUnresolvedReferences
    print('Running for {} - Buffer Features: {}'.format(component.name, component.buffer_features))


@component_end_hook(component_name='convolution_layer_1')
def run_component_end_hook_only_for_convolution_layer(component: Component):
    """
    | **@author:** Prathyush SP
    |
    | Component end hook to run for only for Convolution Layer 1
    :param component: Component Object
    """
    print('Run Component end hook only for convolution layer')
    print('Running for {} - Component Output: {}'.format(component.name,
                                                         GraphUtils.get_tensor(component.component_output)))


@component_begin_hook(component_sub_type=rztdl.dl.constants.LayerType.POOL_LAYER)
def run_component_begin_hook_for_all_pool_layers(component: Component):
    """
    | **@author:** Prathyush SP
    |
    | Component begin hook run for all pool layers
    :param component: Component Object
    """
    print('Run for all pool layers')
    # noinspection PyUnresolvedReferences
    print('Running for {} - Component Output: {}'.format(component.name, component.pool_type))


@component_end_hook(component_sub_type=rztdl.dl.constants.LayerType.FULLY_CONNECTED_LAYER)
def run_component_end_hook_for_all_fully_connected_layers(component: Component):
    """
    | **@author:** Prathyush SP
    |
    | Component end hook to run for all fully connected layers
    :param component: Component Object
    """
    print('Run for all hidden layers')
    print('Running for {} - Component Output: {}'.format(component.name,
                                                         GraphUtils.get_tensor(component.component_output)))


@component_end_hook(model_name='titanic', component_sub_type=rztdl.dl.constants.LayerType.FULLY_CONNECTED_LAYER)
def run_component_end_hook_for_all_fully_connected_layers_of_titanic_model(component: Component):
    """
    | **@author:** Prathyush SP
    |
    | Component end hook to run for all fully connected layers of titanic model
    :param component: Component Object
    """
    print('Run for all hidden layers')
    print('Running for {} - Component Output: {}'.format(component.name,
                                                         GraphUtils.get_tensor(component.component_output)))


@component_begin_hook(model_name='mnist', component_name='input_buffer')
def run_component_begin_hook_only_for_input_layer_of_mnist_model(component: Component):
    """
    | **@author:** Prathyush SP
    |
    | component begin hook to run for only for output layer of mnist model
    :param component: Component Object
    """
    print('Run Layer begin hook only for Output layer of mnist model')
    # noinspection PyUnresolvedReferences
    print('Running for {} - Buffer Type: {}'.format(component.name, component.buffer_features))


@component_begin_hook(component_type=rztdl.dl.constants.ComponentType.BUFFER)
def run_component_begin_hook_only_for_all_buffers(component: Component):
    """
    | **@author:** Prathyush SP
    |
    | Run Component begin hook only for Buffer Components
    :param component: Component Object
    """
    print('Run Component begin hook only for Buffer Components')
    # noinspection PyUnresolvedReferences
    print('Running for {} - Buffer Type: {}'.format(component.name, component.buffer_features))


@component_end_hook(component_type=rztdl.dl.constants.ComponentType.BUFFER)
def run_component_end_hook_only_for_all_buffers_and_given_name(component: Component):
    """
    | **@author:** Prathyush SP
    |
    | Run Component end hook only for Buffer Components
    :param component: Component Object
    """
    print('Run Component end hook only for Buffer Components')
    # noinspection PyUnresolvedReferences
    print('Running for {} - Buffer Type: {}'.format(component.name, component.buffer_features))


@component_begin_hook(component_name='input_buffer', component_type=rztdl.dl.constants.ComponentType.BUFFER)
def run_component_begin_hook_only_for_all_buffers_and_given_name(component: Component):
    """
    | **@author:** Prathyush SP
    |
    | Run Component Begin hook only for Buffer Components with given name
    :param component: Component Object
    """
    print('Run Component Begin hook only for Buffer Components with given name')
    # noinspection PyUnresolvedReferences
    print('Running for {} - Buffer Type: {}'.format(component.name, component.buffer_features))


@component_end_hook(component_name='input_buffer_1', component_type=rztdl.dl.constants.ComponentType.BUFFER)
def run_component_end_hook_only_for_all_buffers_and_given_name(component: Component):
    """
    | **@author:** Prathyush SP
    |
    | Run Component end hook only for Buffer Components with given name
    :param component: Component Object
    """
    print('Run Component end hook only for Buffer Components with given name')
    # noinspection PyUnresolvedReferences
    print('Running for {} - Buffer Type: {}'.format(component.name, component.buffer_features))


@component_begin_hook(model_name='mnist', component_name='input_buffer',
                      component_type=rztdl.dl.constants.ComponentType.BUFFER)
def run_component_begin_hook_only_for_all_buffers_and_given_name_and_given_model(component: Component):
    """
    | **@author:** Prathyush SP
    |
    | Run Component Begin hook only for Buffer Components with given name and given model
    :param component: Component Object
    """
    print('Run Component Begin hook only for Buffer Components with given name and given model')
    # noinspection PyUnresolvedReferences
    print('Running for {} - Buffer Type: {}'.format(component.name, component.buffer_features))


@component_end_hook(model_name='titanic', component_name='input_buffer_1',
                    component_type=rztdl.dl.constants.ComponentType.BUFFER)
def run_component_end_hook_only_for_all_buffers_and_given_name_and_given_model(component: Component):
    """
    | **@author:** Prathyush SP
    |
    | Run Component end hook only for Buffer Components with given name and given model
    :param component: Component Object
    """
    print('Run Component end hook only for Buffer Components with given name and given model')
    # noinspection PyUnresolvedReferences
    print('Running for {} - Buffer Type: {}'.format(component.name, component.buffer_features))


model = rztdl.dl.Model('mnist')
model.add_component(rztdl.dl.buffer.InBuffer(name="input_buffer", buffer_features=784))
model.add_component(rztdl.dl.layer.ConvolutionLayer('convolution_layer_1', filter_dimensions=[5, 5, 1, 32],
                                                    filter_strides=[1, 1, 1, 1],
                                                    filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                    component_input='input_buffer'))
model.add_component(rztdl.dl.layer.PoolLayer('pool_layer_1', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                             pool_padding=rztdl.dl.constants.PaddingType.SAME, ))
model.add_component(rztdl.dl.layer.ConvolutionLayer('convolution_layer_2', filter_dimensions=[5, 5, 32, 64],
                                                    filter_strides=[1, 1, 1, 1],
                                                    filter_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_component(rztdl.dl.layer.PoolLayer('pool_layer_2', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                             pool_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1", layer_nodes=10,
                                                       layer_activation=rztdl.dl.constants.ActivationType.RELU))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_2", layer_nodes=10,
                                                       layer_activation=rztdl.dl.constants.ActivationType.RELU))
model.add_component(rztdl.dl.buffer.InBuffer(name="output_buffer", buffer_features=10))
model.close()

model = rztdl.dl.Model('titanic')
model.add_component(rztdl.dl.buffer.InBuffer("input_buffer_1", buffer_features=3))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1", layer_nodes=10,
                                                       layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                       component_input='input_buffer_1'))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_2", layer_nodes=10,
                                                       layer_activation=rztdl.dl.constants.ActivationType.RELU))
model.add_component(rztdl.dl.buffer.InBuffer(name="output_buffer", buffer_features=1))
model.close()
