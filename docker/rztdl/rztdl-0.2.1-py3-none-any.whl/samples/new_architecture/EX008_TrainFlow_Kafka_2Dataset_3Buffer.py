import rztdl.dl
from rztdl.dl.dataset.advanced.kafka_dataset import KafkaDataset
from rztdl.dl.dataset.dataset_handler import DatasetHandler
from rztdl.dl.dataset.dataset_split import Split
import logging
from rztdl.dl.dataset.dataset_split import DatasetSplit

logger = logging.getLogger(__name__)

EPOCH = 10
BATCH_SIZE = 32
MODEL_NAME = 'titanic'


d1 = DatasetHandler(name='titanic_data',
                    dataset_elements={'sepal_features_buffer', 'petal_features_buffer', 'label_buffer'})

d1.add_dataset(
    KafkaDataset(name='sepal', server='192.168.50.37:9092', topic_name="iris",
                 column_names={'sepal_features_buffer': ['Sepal Length', 'Sepal Width'],
                               'petal_features_buffer': ['Petal Length', 'Petal Width']}))
d1.add_dataset(
    KafkaDataset(name='label', server='192.168.50.37:9092', topic_name="iris",
                 column_names={'label_buffer': ['Label']}))
d1.close()

split = DatasetSplit(name='basic_split', split_ratio=[50, 20, 30],split_metrics={'error', 'meansq', 'accuracy'})
split.add_split(Split('train_sp', template=rztdl.dl.constants.DatasetTemplate.train(),metrics={'meansq'}))
split.add_split(Split('valid_sp', template=rztdl.dl.constants.DatasetTemplate.valid(),metrics={'meansq'}))
split.add_split(Split('test_sp', template=rztdl.dl.constants.DatasetTemplate.test(),metrics={'meansq'}))
split.close()

model = rztdl.dl.Model(MODEL_NAME)
t = model.add_component(
    rztdl.dl.buffer.InBuffer(name="sepal_features_buffer", buffer_shape=[None, 2]))
print(t)

model.add_component(
    rztdl.dl.buffer.InBuffer(name="petal_features_buffer", buffer_shape=[None, 2]))
model.add_component(
    rztdl.dl.buffer.InBuffer(name="label_buffer", buffer_shape=[None, 1]))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1",
                                                       layer_nodes=10, component_input='sepal_features_buffer'))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_2",
                                                       layer_nodes=1, component_input='petal_features_buffer'))
model.add_component(
    rztdl.dl.operator.ConcatOperator(name='concat_op', component_input=['hidden_layer_1', 'hidden_layer_2'],
                                     dimension=1, component_output='concat_operator_output'))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_3",
                                                       layer_nodes=1, component_input='concat_operator_output'))
x = model.add_component(
    rztdl.dl.cost.MeanSquareError(name='meansq', labels='label_buffer', predictions='hidden_layer_2',
                                  log_component=True))
print(x)

y = model.add_component(rztdl.dl.optimizers.AdamOptimizer(name='adam_opt', component_input='meansq'))
print(y)

model.close()

with rztdl.dl.ModelRunner(name='mr', model=model) as model_runner:
    model_runner.run_flow(rztdl.dl.flow.TrainFlow(name='flow1', epoch=1, batch_size=5,
                                                    learning_rate=[0.01], optimizers=['adam_opt'],
                                                    dataset_handler=d1, dataset_split=split,
                                                    dataset_mapping={'sepal_features_buffer': 'sepal_features_buffer',
                                                                     'petal_features_buffer': 'petal_features_buffer',
                                                                     'label_buffer': 'label_buffer'}))
