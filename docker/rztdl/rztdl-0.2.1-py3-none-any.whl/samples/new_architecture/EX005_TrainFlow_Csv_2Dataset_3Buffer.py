# -*- coding: utf-8 -*-
"""
@created on: 6/15/18,
@author: Himaprasoon,
@version: v0.0.1

Description:

Sphinx Documentation Status:

..todo::

"""

import os
os.environ['BBSDK_CONFIG'] = '/Users/prathyushsp/Downloads/config.json'
import logging
from pipelineblocksdk.api import BBSDK as sdk
import tensorflow as tf

def setup_bb_logging(bb_logger):
    bb_logger.level = logging.INFO
    bb_logger.handlers = logging.root.handlers
    bb_logger.propagate = True
    bb_logger.parent = logging.root.parent
    bb_logger._loggerClass = bb_logger
    bb_logger.manager = logging.Logger.manager
    bb_logger.log = logging.log
    bb_logger.setLevel = logging.root.setLevel
    bb_logger.removeHandler=logging.root.removeHandler
    bb_logger.addHandler = logging.root.addHandler
    logging.root = bb_logger
    logging.Logger.manager = logging.Manager(bb_logger)
    logging.getLogger = lambda _=None: logging.root


block_params = {'blockID': "123", 'pipelineID': "555", 'eaiID': "123", 'pipelineRunID': "123123",
                "currentIteration": "2"}
blk_params = {'block_id': block_params['blockID'], 'pipeline_id': block_params['pipelineID'],
              'stage_id': "c2027084-b5c1-4d3c-a981-dd489be2ad1f", 'eai_id': block_params['eaiID'],
              'run_id': block_params['pipelineRunID'], 'block_iteration': block_params['currentIteration']}
logger = sdk.block_log_handler(block_params=blk_params)

setup_bb_logging(logger)

import rztdl.dl
from rztdl.dl.dataset.dataset_handler import DatasetHandler
from rztdl.dl.dataset.dataset_split import Split
from rztdl.dl.dataset.dataset_split import DatasetSplit
from rztdl import RZTDL_MODULE_PATH
from rztdl.dl.dataset.primitive.csv_dataset import CsvDataset



EPOCH = 10
BATCH_SIZE = 32
MODEL_NAME = 'titanic'

d1 = DatasetHandler(name='titanic_data',
                    dataset_elements={'sepal_features_buffer', 'petal_features_buffer', 'label_buffer'})
root_path = RZTDL_MODULE_PATH
d1.add_dataset(
    CsvDataset(name='sepal', file_name=root_path + '/../samples/data/iris_data_multiclass.csv',
               column_names={'sepal_features_buffer': ['Sepal Length', 'Sepal Width'],
                             'petal_features_buffer': ['Petal Length', 'Petal Width']}))

d1.add_dataset(
    CsvDataset(name='label', file_name=root_path + '/../samples/data/iris_data/iris_label.csv',
               column_names={'label_buffer': ['Label']}))
d1.close()

split = DatasetSplit(name='basic_split', split_ratio=[50, 20, 30], split_metrics={'meansq'})
split.add_split(Split('train_sp', template=rztdl.dl.constants.DatasetTemplate.train(), metrics={'meansq'}))
split.add_split(Split('valid_sp', template=rztdl.dl.constants.DatasetTemplate.valid(), metrics={'meansq'}))
split.add_split(Split('test_sp', template=rztdl.dl.constants.DatasetTemplate.test(), metrics={'meansq'}))
split.close()

model = rztdl.dl.Model(MODEL_NAME)
model.add_component(rztdl.dl.buffer.InBuffer(name="sepal_features_buffer", buffer_shape=[None, 2]))
model.add_component(rztdl.dl.buffer.InBuffer(name="petal_features_buffer", buffer_shape=[None, 2]))
model.add_component(rztdl.dl.buffer.InBuffer(name="label_buffer", buffer_shape=[None, 1]))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1",
                                                       layer_nodes=10, component_input='sepal_features_buffer'))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_2",
                                                       layer_nodes=1, component_input='petal_features_buffer'))
model.add_component(
    rztdl.dl.operator.ConcatOperator(name='concat_op', component_input=['hidden_layer_1', 'hidden_layer_2'],
                                     dimension=1, component_output='concat_operator_output'))
model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_3",
                                                       layer_nodes=1, component_input='concat_operator_output'))
model.add_component(
    rztdl.dl.cost.MeanSquareError(name='meansq', labels='label_buffer', predictions='hidden_layer_2',
                                  log_component=True))
model.add_component(rztdl.dl.optimizers.AdamOptimizer(name='adam_opt', component_input='meansq'))
model.close()

with rztdl.dl.ModelRunner(name='mr', model=model) as model_runner:
    model_runner.run_flow(rztdl.dl.flow.TrainFlow(name='flow1', epoch=1, batch_size=5,
                                                    learning_rate=[0.01], optimizers=['adam_opt'],
                                                    dataset_handler=d1, dataset_split=split))
