# -*- coding: utf-8 -*-
"""
@created on: 6/15/18,
@author: Himaprasoon,
@version: v0.0.1

Description:

Sphinx Documentation Status:

..todo::

"""
from kafka import KafkaProducer
import pandas as pd
from rztdl import RZTDL_MODULE_PATH
import json
df = pd.read_csv(RZTDL_MODULE_PATH + "/../samples/data/iris_data_multiclass.csv")

producer = KafkaProducer(bootstrap_servers='localhost:9092')
counter = 0
for item in df.T.to_dict().values():
    if counter>=60:
        break
    producer.send('iris',json.dumps(item).encode("ASCII"), key=b"COMING",partition=0)
    counter += 1
producer.send('iris',json.dumps("end").encode("ASCII"), key=b"end",partition=0)
producer.flush()

print("ADDED 60 items to kafka queue")