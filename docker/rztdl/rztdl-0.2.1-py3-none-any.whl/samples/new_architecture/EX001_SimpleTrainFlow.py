# -*- coding: utf-8 -*-
"""
@created on: 07/06/2018,
@author: Umesh Kumar,
@version: v0.0.1

Description:

Sphinx Documentation Status:

..todo:: It should throw error

"""

import rztdl.dl
from rztdl.utils.file import read_csv
import logging

logger = logging.getLogger(__name__)

data_path = "../data/titanic.csv"
train_data, train_label, valid_data, valid_label, test_data, test_label = read_csv(data_path, split_ratio=[70, 20, 10],
                                                                                   delimiter=",",
                                                                                   randomize=True, output_label=True)
MODEL_NAME = 'titanic'

model = rztdl.dl.Model(MODEL_NAME)
data = model.add_component(rztdl.dl.buffer.InBuffer(name="data_buffer", buffer_features=3))
label = model.add_component(rztdl.dl.buffer.InBuffer(name="label_buffer", buffer_features=1))
f1 = model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1",
                                                            layer_nodes=10, component_input='data_buffer'))
f2 = model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_2",
                                                            layer_nodes=1))
model.add_component(rztdl.dl.cost.MeanSquareError(name='mse_error', labels='label_buffer', predictions='hidden_layer_2',
                                                  log_component=True))
model.add_component(rztdl.dl.optimizers.AdamOptimizer(name='adam_opt_1', component_input='mse_error'))

model.close()

# GraphUtils().save_graph('/tmp/s/a/c').run_tensorboard(port=6066)


# RZTDL_STORE.add_components_to_log(model_name='titanic', component_name='f1_weights',
#                                   tensor_name=model.get_component('hidden_layer_1').layer_weights)
# RZTDL_STORE.add_components_to_log(model_name='titanic', component_name='m_layer',
#                                   tensor_name=model.get_component('m_layer').component_output)

with rztdl.dl.ModelRunner(name='titanic_runner', model=model) as model_runner:
    model_runner.run_flow(rztdl.dl.flow.SimpleTrainFlow(name='sample_train', epoch=100, learning_rate=0.001,
                                                        optimizers=["adam_opt_1"],
                                                        train_data={'data_buffer': train_data,
                                                                    'label_buffer': train_label},
                                                        valid_data={'data_buffer': valid_data,
                                                                    'label_buffer': valid_label},
                                                        test_data={'data_buffer': test_data,
                                                                   'label_buffer': test_label}))

# rztdl.dl.TensorBoard(
#     logdir='/tmp/rztdl_logs/' + network.name + '/' + network.timestamp + '/graphs/tf/',
#     port=6006).start_tensorboard()
