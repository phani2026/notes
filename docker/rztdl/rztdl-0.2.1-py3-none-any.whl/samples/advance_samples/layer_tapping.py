# -*- coding: utf-8 -*-
"""
| **@created on**: 01/03/17,
| **@author**: Prathyush SP,
| **@version:** v0.0.1
|
| Description:
|
| Sphinx Documentation Status:
|
..todo::
|
"""

import rztdl.dl
from rztdl.utils.file import read_csv, read_network
import numpy as np

data_path = "../data/mnist_dataset.csv"
train_data, train_label, valid_data, valid_label, test_data, test_label = read_csv(data_path, split_ratio=[60, 20, 20],
                                                                                   delimiter=";", randomize=True,
                                                                                   label_vector=True)
model = rztdl.dl.Model('cnn')
model.add_layer(rztdl.dl.layer.InputLayer("input_layer", layer_nodes=len(train_data[0])))
model.add_layer(rztdl.dl.layer.ConvolutionLayer('con1', layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                filter_dimensions=[5, 5, 1, 32], filter_strides=[1, 1, 1, 1],
                                                filter_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_layer(rztdl.dl.layer.PoolLayer('pool1', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                         pool_padding=rztdl.dl.constants.PaddingType.SAME,
                                         pool_type=rztdl.dl.constants.PoolType.MAX_POOL, layer_input='cnn.con1'))
model.add_layer(rztdl.dl.layer.ConvolutionLayer('con2', layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                filter_dimensions=[5, 5, 32, 64], filter_strides=[1, 1, 1, 1],
                                                filter_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_layer(rztdl.dl.layer.PoolLayer('pool2', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                         pool_padding=rztdl.dl.constants.PaddingType.SAME,
                                         pool_type=rztdl.dl.constants.PoolType.MAX_POOL))
model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1",
                                                   layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                   layer_nodes=10, layer_input='cnn.pool2'))
model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_2",
                                                   layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                   layer_nodes=3, layer_input='cnn.hidden_layer_1'))
model.add_layer(rztdl.dl.layer.OutputLayer(name="output_layer",
                                           layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                           layer_nodes=len(train_label[0])))
model.close()

network = rztdl.dl.Network('nn1')
network.train(epoch=1, learning_rate=0.001, model=model, cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
              optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
              train_data={'input_layer': train_data, 'output_layer': train_label},
              valid_data={'input_layer': valid_data, 'output_layer': valid_label},
              test_data={'input_layer': test_data, 'output_layer': test_label},
              display_step=1)

# Tapping to another network

conv2_train_data_tap, conv2_valid_data_tap, conv2_test_data_tap = read_network(network_name='nn1.con2', layer_data={
    'input_layer': np.concatenate([train_data, test_data, valid_data])},
                                                                               split_ratio=[60, 20, 20],
                                                                               output_label=False)
hidden_layer_2_train_data_tap, hidden_layer_2_valid_data_tap, hidden_layer_2_test_data_tap = read_network(
    network_name='nn1.hidden_layer_2', layer_data={'input_layer': np.concatenate([train_data, test_data, valid_data])},
    split_ratio=[60, 20, 20], output_label=False)

model = rztdl.dl.Model('ffn')
model.add_layer(rztdl.dl.layer.InputLayer("input_layer", layer_nodes=len(train_data[0])))
model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1",
                                                   layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                   layer_nodes=10))
# Convolution 2 Tapping
model.add_layer(rztdl.dl.layer.InputLayer("conv2_tap", layer_shape=[None, 14, 14, 64]))
model.add_layer(rztdl.dl.layer.PoolLayer('pool2', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                         pool_padding=rztdl.dl.constants.PaddingType.SAME,
                                         pool_type=rztdl.dl.constants.PoolType.MAX_POOL, layer_input='conv2_tap'))
model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_2",
                                                   layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                   layer_nodes=10))

# Hidden Layer 2 Tapping
model.add_layer(rztdl.dl.layer.InputLayer("hidden_layer_2_tap", layer_nodes=3))
model.add_operator(
    rztdl.dl.operator.ConcatOperator(name='concat_tap',
                                     operator_input=['hidden_layer_1', 'hidden_layer_2', 'hidden_layer_2_tap'],
                                     operator_output='concat_out', dimension=1))
model.add_layer(rztdl.dl.layer.OutputLayer(name="output_layer",
                                           layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                           layer_nodes=10, layer_input='concat_out'))
model.close()
network = rztdl.dl.Network('nn2')
network.train(epoch=1, learning_rate=0.001, model=model, cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
              optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
              train_data={'input_layer': train_data, 'output_layer': train_label, 'conv2_tap': conv2_train_data_tap,
                          'hidden_layer_2_tap': hidden_layer_2_train_data_tap},
              valid_data={'input_layer': valid_data, 'output_layer': valid_label, 'conv2_tap': conv2_valid_data_tap,
                          'hidden_layer_2_tap': hidden_layer_2_valid_data_tap},
              test_data={'input_layer': test_data, 'output_layer': test_label, 'conv2_tap': conv2_test_data_tap,
                         'hidden_layer_2_tap': hidden_layer_2_test_data_tap},
              display_step=1)
