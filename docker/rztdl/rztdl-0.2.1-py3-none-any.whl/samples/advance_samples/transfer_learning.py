# -*- coding: utf-8 -*-
"""
@created on: 25/01/17,
@author: Prathyush SP,
@version: v0.0.1

Description:

Sphinx Documentation Status:

..todo::
"""

import rztdl.dl
from rztdl.utils.file import read_csv

data_path = '/'.join(str(__file__).split('/')[:-2]) + "/data/mnist_dataset.csv"
train_data, train_label, valid_data, valid_label, test_data, test_label = read_csv(data_path, split_ratio=[50, 20, 30],
                                                                                   delimiter=";",
                                                                                   randomize=False, label_vector=True)

print('Training model')
model = rztdl.dl.Model('cnn')

model.add_layer(rztdl.dl.layer.InputLayer("input_layer", layer_nodes=len(train_data[0])))
model.add_layer(rztdl.dl.layer.ConvolutionLayer('con1',
                                                filter_dimensions=[5, 5, 1, 32], filter_strides=[1, 1, 1, 1],
                                                filter_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_layer(rztdl.dl.layer.PoolLayer('pool1', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                         pool_padding=rztdl.dl.constants.PaddingType.SAME,
                                         layer_input='cnn.con1'))
model.add_layer(rztdl.dl.layer.ConvolutionLayer('con2',
                                                filter_dimensions=[5, 5, 32, 64], filter_strides=[1, 1, 1, 1],
                                                filter_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_layer(rztdl.dl.layer.PoolLayer('pool2', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                         pool_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1",
                                                   layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                   layer_nodes=10, layer_input='cnn.pool2'))
model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_2",
                                                   layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                   layer_nodes=10,
                                                   layer_input='cnn.hidden_layer_1'))
model.add_layer(rztdl.dl.layer.OutputLayer(name="output_layer",
                                           layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                           layer_nodes=len(train_label[0]), layer_input='hidden_layer_2'))
model.close()

network = rztdl.dl.Network('mnist_data')
network.train(epoch=30, learning_rate=0.01, model=model, cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
              optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
              train_data={'input_layer': train_data, 'output_layer': train_label},
              valid_data={'input_layer': valid_data, 'output_layer': valid_label},
              test_data={'input_layer': test_data, 'output_layer': test_label},
              display_step=1, train_batches=13)

pred = rztdl.dl.Prediction('mnist_data')

print('Transfer Learning ')
model = rztdl.dl.Model('transfer_model')

model.add_layer(rztdl.dl.layer.InputLayer("input_layer", layer_nodes=len(train_data[0])))
model.add_layer(rztdl.dl.layer.ConvolutionLayer('con1', layer_filter=pred.get_weights('con1'),
                                                layer_bias=pred.get_bias('con1'),
                                                filter_dimensions=[5, 5, 1, 32], filter_strides=[1, 1, 1, 1],
                                                filter_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_layer(rztdl.dl.layer.PoolLayer('pool1', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                         pool_padding=rztdl.dl.constants.PaddingType.SAME,
                                         layer_input='transfer_model.con1'))
model.add_layer(rztdl.dl.layer.ConvolutionLayer('con2', layer_filter=pred.get_weights('con2'),
                                                layer_bias=pred.get_bias('con2'),
                                                filter_dimensions=[5, 5, 32, 64], filter_strides=[1, 1, 1, 1],
                                                filter_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_layer(rztdl.dl.layer.PoolLayer('pool2', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                         pool_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1",
                                                   layer_weights=pred.get_weights('hidden_layer_1'),
                                                   layer_bias=pred.get_bias('hidden_layer_1'),
                                                   layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                   layer_nodes=10, layer_input='transfer_model.pool2'))
model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_2",
                                                   layer_weights=pred.get_weights('hidden_layer_2'),
                                                   layer_bias=pred.get_bias('hidden_layer_2'),
                                                   layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                   layer_nodes=10,
                                                   layer_input='transfer_model.hidden_layer_1'))
model.add_layer(rztdl.dl.layer.OutputLayer(name="output_layer",
                                           layer_weights=pred.get_weights('output_layer'),
                                           layer_bias=pred.get_bias('output_layer'),
                                           layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                           layer_nodes=len(train_label[0]), layer_input='hidden_layer_2'))
model.close()

network = rztdl.dl.Network('transfer_network')
network.train(epoch=1, learning_rate=0.01, model=model, cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
              optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
              train_data={'input_layer': train_data, 'output_layer': train_label},
              valid_data={'input_layer': valid_data, 'output_layer': valid_label},
              test_data={'input_layer': test_data, 'output_layer': test_label},
              display_step=1, train_batches=13)
