# -*- coding: utf-8 -*-
"""
@created on: 25/01/17,
@author: Prathyush SP,
@version: v0.0.1

Description:

Sphinx Documentation Status:

..todo::
"""

import rztdl.dl
from rztdl.utils.file import read_csv
import numpy as np
import tensorflow as tf
from rztdl.statistic.algorithms import NumpyVectorFunction

np.random.seed(0)

data_path = '/'.join(str(__file__).split('/')[:-2]) + "/data/mnist_dataset.csv"
train_data, train_label, valid_data, valid_label, test_data, test_label = read_csv(data_path, split_ratio=[50, 20, 30],
                                                                                   delimiter=";",
                                                                                   randomize=False, label_vector=True)

print('Training model')
model = rztdl.dl.Model('cnn')

model.add_layer(rztdl.dl.layer.InputLayer("input_layer", layer_nodes=len(train_data[0])))
model.add_layer(rztdl.dl.layer.ConvolutionLayer('con1', layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                filter_dimensions=[5, 5, 1, 32], filter_strides=[1, 1, 1, 1],
                                                filter_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_layer(rztdl.dl.layer.PoolLayer('pool1', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                         pool_padding=rztdl.dl.constants.PaddingType.SAME,
                                         pool_type=rztdl.dl.constants.POOL.MAX_POOL, layer_input='cnn.con1'))
model.add_layer(rztdl.dl.layer.ConvolutionLayer('con2', layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                filter_dimensions=[5, 5, 32, 64], filter_strides=[1, 1, 1, 1],
                                                filter_padding=rztdl.dl.constants.PaddingType.SAME))
model.add_layer(rztdl.dl.layer.PoolLayer('pool2', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                         pool_padding=rztdl.dl.constants.PaddingType.SAME,
                                         pool_type=rztdl.dl.constants.POOL.MAX_POOL,
                                         normalisation=rztdl.dl.constants.NormalizationType.LRN_NORM,
                                         norm_parameters=rztdl.dl.constants.NormalizationType.lrn_norm()))
model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1",
                                                   layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                   layer_nodes=10, layer_input='cnn.pool2'))
model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_2",
                                                   layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                   layer_nodes=10,
                                                   layer_input='cnn.hidden_layer_1'))
model.add_layer(rztdl.dl.layer.OutputLayer(name="output_layer",
                                           layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                           layer_nodes=len(train_label[0]), layer_input='hidden_layer_2'))
model.close()

network = rztdl.dl.Network('mnist_data')
network.train(epoch=10, learning_rate=0.01, model=model, cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
              optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
              train_data={'input_layer': train_data, 'output_layer': train_label},
              valid_data={'input_layer': valid_data, 'output_layer': valid_label},
              test_data={'input_layer': test_data, 'output_layer': test_label},
              display_step=1, train_batches=13)


# Inference Perturbation


def calculate_accuracy(sess, data):
    """
    Calculate Softmax Accuracy
    :param sess:
    :param data:
    :return:
    """
    correct_pred = tf.equal(tf.argmax(data, 1), tf.argmax(test_label, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_pred, 'float'))
    return sess.run(accuracy)


pred = rztdl.dl.Prediction('mnist_data')
original_predictions = NumpyVectorFunction.softmax(pred.predict('output_layer', data={'input_layer': test_data})[0])
sess = tf.InteractiveSession()

# Perturb Hidden Layer 2 Weights
hidden_layer_2_weights = pred.get_weights(layer_name='hidden_layer_2')
print('Hidden Layer 2 Weights: ', hidden_layer_2_weights)
pred.set_weights('hidden_layer_2', layer_weights=np.ones(hidden_layer_2_weights.shape))
print('Hidden Layer 2 Weights after Perturbation: ', pred.get_weights(layer_name='hidden_layer_2'))

perturbed_predictions = NumpyVectorFunction.softmax(pred.predict('output_layer', data={'input_layer': test_data})[0])
print('Original Accuracy: ', calculate_accuracy(sess, original_predictions))
print('Perturbed Accuracy: ', calculate_accuracy(sess, perturbed_predictions))
