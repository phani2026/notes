# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import rztdl.dl
from tensorflow import Tensor
import importlib
from nose.tools import *
import nose
import tensorflow as tf
from collections import OrderedDict
from nose import with_setup  # optional
from rztdl.hooks.hooks_manager import hooks_manager, hook_controller, wrap
from rztdl.utils.string_constants import Hook
from rztdl.utils.dl_exception import HookException
from functools import partial, wraps
from rztdl import RZTDL_CONFIG


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    print('********** Starting {} tests . . . **********'.format(__name__))


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    print('**********  {} tests completed successfully . . . **********'.format(__name__))


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


@hook_controller(hook_type=Hook.HookType.LayerHook, hook_pos=Hook.HookPosition.BeginHook, wrap_fn=wrap)
def lb_hook(func=None, always: bool = False, layer_name: str = None, layer_type: str = None,
            model_name: str = None):
    """
        | **author:** Prathyush SP
        |
        | Hook called during initialization of layer
        | Note: Follows Decorator design
        :param func: Customer Function
        :param always: Debug related variable
        :param layer_name: Layer Name Restriction
        :param layer_type: Layer Type Restriction
        :param model_name: Model Name Restriction
        :return: Decorator Wrapper
        """
    if not __debug__ and not always:  # pragma: no cover
        return func
    if func is None:
        return partial(lb_hook, always=always)

    # noinspection PyUnusedLocal
    @wraps(func)
    def wrapper(*args, **kwargs):
        """
        | **author:** Prathyush SP
        |
        | Wrapped Decorator
        :param args: Function args
        :param kwargs: Function kwargs
        :return: Function
        """
        return func

    return wrapper


class TestHooksManager:
    """
    | **@author:** Prathyush SP
    |
    | Hooks Manager Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        print('init', hooks_manager.hook_store)
        self.init_manager_data = hooks_manager.hook_store
        pass

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method in the class is called
        """
        hooks_manager.initialize_hook_store()
        pass

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        hooks_manager.initialize_hook_store()
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        print('class', hooks_manager.hook_store)
        RZTDL_CONFIG.CommonConfig.HOOKS_ENABLED = True
        pass

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        RZTDL_CONFIG.CommonConfig.HOOKS_ENABLED = False
        pass

    def test_hook_initialization(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests Sample Method
        """
        hooks_manager.initialize_hook_store()
        assert hooks_manager.hook_store == {i: {h: [] for h in Hook.HookPosition} for i in Hook.HookType}

    @staticmethod
    @lb_hook()
    def sample_hook_global():
        """
        | **@author:** Prathyush SP
        | Sample Global hook for hook controller test        
        """
        pass

    def sample_callable_fn(self, **kwargs):
        """
        | **@author:** Prathyush SP
        |
        | Sample Callable function for hooks
        :param kwargs: N Arguments        
        """
        pass

    def sample_callable_fn_2(self, **kwargs):
        """
        | **@author:** Prathyush SP
        |
        | Sample Callable function for hooks
        :param kwargs: N Arguments        
        """
        pass

    def test_add_hook(self):
        """
        | **@author:** Prathyush SP
        |
        | Test add hook functionality        
        """

        hooks_manager.add_hook(hook=self.sample_callable_fn, hook_pos=Hook.HookPosition.BeginHook,
                               hook_type=Hook.HookType.LayerHook, hook_args={})
        assert hooks_manager.hook_store[Hook.HookType.LayerHook][Hook.HookPosition.BeginHook][0] == (
            self.sample_callable_fn, {})

    def test_fetch_hook(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Fetch Hook Functionality        
        """

        hooks_manager.add_hook(hook=self.sample_callable_fn, hook_pos=Hook.HookPosition.BeginHook,
                               hook_type=Hook.HookType.LayerHook, hook_args={})
        assert hooks_manager.fetch_hook(hook_type=Hook.HookType.LayerHook, hook_pos=Hook.HookPosition.BeginHook)[0] == (
            self.sample_callable_fn, {})

    def test_fetch_hook_w_index(self):
        """
        | **@author:** Prathyush SP
        |
        | Test fetch hook with Index functionality        
        """
        hooks_manager.add_hook(hook=self.sample_callable_fn, hook_pos=Hook.HookPosition.BeginHook,
                               hook_type=Hook.HookType.LayerHook, hook_args={})
        assert hooks_manager.fetch_hook(hook_type=Hook.HookType.LayerHook, hook_pos=Hook.HookPosition.BeginHook,
                                        index=0) == (self.sample_callable_fn, {})

    def test_remove_hook(self):
        """
        | **@author:** Prathyush SP
        |
        | Test remove hook functionality        
        """
        hooks_manager.add_hook(hook=self.sample_callable_fn, hook_pos=Hook.HookPosition.BeginHook,
                               hook_type=Hook.HookType.LayerHook, hook_args={})
        hooks_manager.remove_hook(hook_type=Hook.HookType.LayerHook, hook_pos=Hook.HookPosition.BeginHook)
        assert hooks_manager.hook_store[Hook.HookType.LayerHook][Hook.HookPosition.BeginHook] == []

    def test_remove_hook_w_index(self):
        """
        | **@author:** Prathyush SP
        |
        | Test remove hook with index functionality        
        """
        hooks_manager.add_hook(hook=self.sample_callable_fn, hook_pos=Hook.HookPosition.BeginHook,
                               hook_type=Hook.HookType.LayerHook, hook_args={})
        hooks_manager.add_hook(hook=self.sample_callable_fn, hook_pos=Hook.HookPosition.BeginHook,
                               hook_type=Hook.HookType.LayerHook, hook_args={})
        assert len(hooks_manager.hook_store[Hook.HookType.LayerHook][Hook.HookPosition.BeginHook]) == 2
        hooks_manager.remove_hook(hook_type=Hook.HookType.LayerHook, hook_pos=Hook.HookPosition.BeginHook, index=0)
        assert len(hooks_manager.hook_store[Hook.HookType.LayerHook][Hook.HookPosition.BeginHook]) == 1

    @raises(HookException)
    def test_remove_hook_w_index(self):
        """
        | **@author:** Prathyush SP
        |
        | Test remove hook with index functionality        
        """
        hooks_manager.add_hook(hook=self.sample_callable_fn, hook_pos=Hook.HookPosition.BeginHook,
                               hook_type=Hook.HookType.LayerHook, hook_args={})
        hooks_manager.add_hook(hook=self.sample_callable_fn, hook_pos=Hook.HookPosition.BeginHook,
                               hook_type=Hook.HookType.LayerHook, hook_args={})
        hooks_manager.remove_hook(hook_type=Hook.HookType.LayerHook, hook_pos=Hook.HookPosition.BeginHook, index=10)

    def test_hook_manager_ordering(self):
        """
        | **@author:** Prathyush SP
        |
        | Test hook manager ordering        
        """
        hooks_manager.add_hook(hook=self.sample_callable_fn, hook_pos=Hook.HookPosition.BeginHook,
                               hook_type=Hook.HookType.LayerHook, hook_args={})
        hooks_manager.add_hook(hook=self.sample_callable_fn_2, hook_pos=Hook.HookPosition.BeginHook,
                               hook_type=Hook.HookType.LayerHook, hook_args={})
        assert hooks_manager.fetch_hook(hook_type=Hook.HookType.LayerHook, hook_pos=Hook.HookPosition.BeginHook,
                                        index=0) == (self.sample_callable_fn, {})
        assert hooks_manager.fetch_hook(hook_type=Hook.HookType.LayerHook, hook_pos=Hook.HookPosition.BeginHook,
                                        index=1) == (self.sample_callable_fn_2, {})

    @raises(HookException)
    def test_remove_hook_w_index_exception(self):
        """
        | **@author:** Prathyush SP
        |
        | Test remove hook with index exception        
        """
        hooks_manager.remove_hook(hook_type=Hook.HookType.LayerHook, hook_pos=Hook.HookPosition.BeginHook, index=10)

    @raises(HookException)
    def test_fetch_hook_w_index_exception(self):
        """
        | **@author:** Prathyush SP
        |
        | Test fetch hook with index exception        
        """
        hooks_manager.fetch_hook(hook_type=Hook.HookType.LayerHook, hook_pos=Hook.HookPosition.BeginHook, index=10)

    def test_hook_controller_objective(self):
        """
        | **@author:** Prathyush SP
        |
        | Test hook controller function
        """
        hooks_manager.hook_store = self.init_manager_data
        assert len(hooks_manager.hook_store[Hook.HookType.LayerHook][Hook.HookPosition.BeginHook]) == 1
