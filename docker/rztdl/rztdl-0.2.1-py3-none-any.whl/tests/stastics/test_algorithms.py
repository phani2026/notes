# -*- coding: utf-8 -*-
"""
@created on: 29/1/18,
@author: Vivek A Gupta,
@version: v0.0.1

Description:
Python Utils Tests

Sphinx Documentation Status:

..todo::

"""
from nose.tools import *
from rztdl.statistic.algorithms import *


def setup_module():
    """
    | **@author:** Vivek A Gupta
    |
    | Module Setup - Called when this module is initialized - First Call
    """
    print("*********Running Algorithms Test Case . . .*********")


def teardown_module():
    """
    | **@author:** Vivek A Gupta
    |
    | Module Teardown - Called when this module is completed - Last Call
    """
    print("*********Algorithms Test Case completed successfully . . .*********")


def test_calculate_gini_score_manual():
    assert_equal(calculate_gini_score_manual(np.asarray([1, 1, 0, 0]), np.asarray([0, 0, 1, 1])), -1.0)


def test_calculate_gini_score():
    assert_equal(calculate_gini_score(np.asarray([1, 1, 0, 0]), np.asarray([0, 0, 1, 1])), -1.0)
    assert_equal(calculate_gini_score(np.asarray([1, 1, 0, 1]), np.asarray([1, 1, 0, 2])), -1.0)


@raises(Exception)
def test_exception_gini_score():
    assert_equal(calculate_gini_score(np.asarray([1, 1, 0]), np.asarray([1, 1, 0, 1])), -1.0)


def test_calculate_mean():
    x = [1, 1]
    assert_equal(1, calculate_mean(x))


def test_calculate_slope():
    a = [2, 2]
    b = [1, 1]
    assert_equal(calculate_slope(a, b), 1)


def test_calculate_distance():
    a = [1, 1]
    b = [1, 1]
    assert_equal(calculate_distance(a, b), 0.0)


def test_calculate_iv_score():
    assert calculate_iv_score('/'.join(str(__file__).split('/')[:-2]) + "/data/sample_iv.csv", "OUT")
    assert calculate_iv_score('/'.join(str(__file__).split('/')[:-2]) + "/data/sample_iv.csv", "OUT", one_hot=True, one_hot_range={'A': [0, 0]})

