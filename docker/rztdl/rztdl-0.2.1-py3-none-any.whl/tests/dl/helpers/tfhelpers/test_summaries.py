# -*- coding: utf-8 -*-
"""
| **@created on:** 30/03/17,
| **@author:** Vivek A Gupta,
| **@version:** v0.0.1
|
| **Description:**
| tfhelper Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
from nose.tools import *
from rztdl import RZTDL_CONFIG
import tensorflow as tf
from rztdl.dl.helpers import tfhelpers
import os
import time
from tensorboard.backend.event_processing import event_accumulator as ea

rztdl_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Setup - Called when this module is initialized - First Call
    """
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = "/tmp/rztdl_tfhelpers_test_cases/"
    print("*********Running TF Helpers Test Case . . .*********")


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Teardown - Called when this module is completed - Last Call
    """
    os.system("rm -rf " + RZTDL_CONFIG.CommonConfig.PATH_RZTDL)
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = rztdl_path
    print("*********TF Helpers Test Case completed successfully . . .*********")


class TestTFSummaries:
    """
    | **@author**: Vivek A Gupta
    |
    | TFSummaries Class Test Cases
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        print("*********Running TFSummaries Test Cases . . .*********")
        cls.a = tf.constant(2)
        cls.b = tf.constant(2)
        cls.path_rzt = '/tmp/rzt_test/test/'
        cls.path_tf = '/tmp/tf_test/test/'
        cls.sess = tf.InteractiveSession()

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        cls.sess.close()
        os.system("rm -rf " + '/'.join(cls.path_rzt.split('/')[0:-2]))
        os.system("rm -rf " + '/'.join(cls.path_tf.split('/')[0:-2]))
        print("*********TFSummaries Test Cases completed successfully . . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a /new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_aclose_file_writer(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests close_file_writer function - Check if summary can be added even after closing the file writer.
        """
        summ_obj = tfhelpers.TFSummaries()
        summ_obj.add_scalar_summary('a', self.a)
        merged_rzt = tfhelpers.TFSummaries.create_summary_op()
        summ_obj.create_file_writer('test_close', self.path_rzt, self.sess.graph)

        summary_rzt = self.sess.run(merged_rzt)
        summ_obj.add_summary('test_close', summary_rzt, 1)

        summ_obj.close_file_writer('test_close')

        time.sleep(2)

        summ_obj.add_scalar_summary('b', self.b)

        path_1 = self.path_rzt + str(os.listdir(self.path_rzt)[0])

        acc_rzt = ea.EventAccumulator(path_1)
        acc_rzt.Reload()

        os.system("rm -rf " + self.path_rzt)

        assert_equal(len(acc_rzt.Tags()['scalars']), 1)

    def test_create_summary_op(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests create_summary_op function - Check against tensorflow function.
        """
        c = tf.multiply(self.a, self.b)

        summ_obj = tfhelpers.TFSummaries()
        summ_obj.add_scalar_summary('b', self.b)
        summ_obj.add_scalar_summary('c', c)
        merged_rzt = tfhelpers.TFSummaries.create_summary_op()

        tf.summary.scalar('b', self.b)
        tf.summary.scalar('c', c)
        merged_tf = tf.summary.merge_all()

        summ_obj.create_file_writer('test_cre_sum', self.path_rzt, self.sess.graph)
        tf_writer = tf.summary.FileWriter(self.path_tf, self.sess.graph)

        summary_rzt, summary_tf = self.sess.run([merged_rzt, merged_tf])
        summ_obj.add_summary('test_cre_sum', summary_rzt, 1)
        tf_writer.add_summary(summary_tf, 1)

        path_1 = self.path_rzt + str(os.listdir(self.path_rzt)[0])
        path_2 = self.path_tf + str(os.listdir(self.path_tf)[0])

        summ_obj.close_file_writer('test_cre_sum')
        tf_writer.close()

        time.sleep(2)

        acc_rzt = ea.EventAccumulator(path_1)
        acc_rzt.Reload()

        acc_tf = ea.EventAccumulator(path_2)
        acc_tf.Reload()

        os.system("rm -rf " + self.path_rzt)
        os.system("rm -rf " + self.path_tf)

        assert_equal(acc_rzt.Scalars('b')[0][2], acc_tf.Scalars('b')[0][2])
        assert_equal(acc_rzt.Scalars('c')[0][2], acc_tf.Scalars('c')[0][2])

    def test_create_file_writer(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests create_file_writer function - Checks if file writer is creating a new file.
        """
        summ_obj = tfhelpers.TFSummaries()
        summ_obj.create_file_writer('test_cre_file', self.path_rzt, self.sess.graph)
        summ_obj.close_file_writer('test_cre_file')

        assert len(os.listdir(self.path_rzt)) > 0

        os.system("rm -rf " + self.path_rzt)

    def test_get_file_writer(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests get_file_writer function - Check the return type.
        """
        c = tf.multiply(self.a, self.b)

        path = '/tmp/test/get_file'

        self.sess.run(c)

        summ_obj = tfhelpers.TFSummaries()
        summ_obj.create_file_writer('test_get_file', path, self.sess.graph)
        summ_obj.close_file_writer('test_get_file')

        os.system("rm -rf " + '/'.join(path.split('/')[0:-1]))

        assert_true(isinstance(summ_obj.file_writers['test_get_file'], tf.summary.FileWriter))

    def test_run_metadata(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests run_metadata function - Compare length of run_metadata tag with tensorflow function.
        """
        c = tf.multiply(self.a, self.b)

        summ_obj = tfhelpers.TFSummaries()
        summ_obj.add_scalar_summary('c', c)
        merged_rzt = summ_obj.create_summary_op()

        tf.summary.scalar('c', c)
        merged_tf = tf.summary.merge_all()

        summ_obj.create_file_writer('tester', self.path_rzt, self.sess.graph)
        tf_writer = tf.summary.FileWriter(self.path_tf, self.sess.graph)

        run_options = tf.RunOptions(trace_level=tf.RunOptions.FULL_TRACE)
        run_metadata = tf.RunMetadata()

        summary_rzt, summary_tf = self.sess.run([merged_rzt, merged_tf], run_metadata=run_metadata, options=run_options)

        summ_obj.add_run_metadata('tester', run_metadata, 1)
        summ_obj.add_summary('tester', summary_rzt, 1)

        tf_writer.add_run_metadata(run_metadata, 'step%d' % 1)
        tf_writer.add_summary(summary_tf, 1)

        path_1 = self.path_rzt + str(os.listdir(self.path_rzt)[0])
        path_2 = self.path_tf + str(os.listdir(self.path_tf)[0])

        summ_obj.close_file_writer('tester')
        tf_writer.close()

        time.sleep(2)

        acc_rzt = ea.EventAccumulator(path_1)
        acc_rzt.Reload()

        acc_tf = ea.EventAccumulator(path_2)
        acc_tf.Reload()

        os.system("rm -rf " + self.path_rzt)
        os.system("rm -rf " + self.path_tf)

        assert_equal(len(acc_rzt.Tags()['run_metadata']), len(acc_tf.Tags()['run_metadata']))

    def test_add_scalar_summary(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests add_scalar_summary function - Compare scalar value with tensorflow function.
        """
        c = tf.multiply(self.a, self.b)

        summ_obj = tfhelpers.TFSummaries()
        summ_obj.add_scalar_summary('c', c)

        tf.summary.scalar('c', c)

        merged_rzt = summ_obj.create_summary_op()
        merged_tf = tf.summary.merge_all()

        summ_obj.create_file_writer('tester', self.path_rzt, self.sess.graph)
        tf_writer = tf.summary.FileWriter(self.path_tf, self.sess.graph)

        summary_rzt, summary_tf = self.sess.run([merged_rzt, merged_tf])

        summ_obj.add_summary('tester', summary_rzt, 1)
        tf_writer.add_summary(summary_tf, 1)

        summ_obj.close_file_writer('tester')
        tf_writer.close()

        time.sleep(2)

        path_1 = self.path_rzt + str(os.listdir(self.path_rzt)[0])
        path_2 = self.path_tf + str(os.listdir(self.path_tf)[0])

        acc_rzt = ea.EventAccumulator(path_1)
        acc_rzt.Reload()

        acc_tf = ea.EventAccumulator(path_2)
        acc_tf.Reload()

        assert_equal(acc_rzt.Scalars('c')[0][2], acc_tf.Scalars('c')[0][2])

        os.system("rm -rf " + self.path_tf)
        os.system("rm -rf " + self.path_rzt)

    def test_add_summary(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests add_summary function - Compare scalar values with tensorflow function.
        """
        c = tf.multiply(self.a, self.b)

        summ_obj = tfhelpers.TFSummaries()
        summ_obj.add_scalar_summary('b', self.b)
        summ_obj.add_scalar_summary('c', c)
        merged_rzt = tfhelpers.TFSummaries.create_summary_op()

        tf.summary.scalar('b', self.b)
        tf.summary.scalar('c', c)
        merged_tf = tf.summary.merge_all()

        summ_obj.create_file_writer('tester', self.path_rzt, self.sess.graph)
        tf_writer = tf.summary.FileWriter(self.path_tf, self.sess.graph)

        summary_rzt, summary_tf = self.sess.run([merged_rzt, merged_tf])
        summ_obj.add_summary('tester', summary_rzt, 1)
        tf_writer.add_summary(summary_tf, 1)

        path_1 = self.path_rzt + str(os.listdir(self.path_rzt)[0])
        path_2 = self.path_tf + str(os.listdir(self.path_tf)[0])

        summ_obj.close_file_writer('tester')
        tf_writer.close()

        time.sleep(2)

        acc_rzt = ea.EventAccumulator(path_1)
        acc_rzt.Reload()

        acc_tf = ea.EventAccumulator(path_2)
        acc_tf.Reload()

        os.system("rm -rf " + self.path_tf)
        os.system("rm -rf " + self.path_rzt)

        assert_equal(acc_rzt.Scalars('b')[0][2], acc_tf.Scalars('b')[0][2])
        assert_equal(acc_rzt.Scalars('c')[0][2], acc_tf.Scalars('c')[0][2])

    def test_create_variable_summaries(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests create_variable_summaries function - Check length of scalar tags and histogram value.
        """

        def create_summaries(tensor):
            with tf.name_scope('summaries'):
                mean = tf.reduce_mean(tensor)
                tf.summary.scalar('mean', mean)
                with tf.name_scope('stddev'):
                    # noinspection PyUnresolvedReferences
                    stddev = tf.sqrt(tf.reduce_mean(tf.square(tensor - mean)))
                tf.summary.scalar('stddev', stddev)
                tf.summary.scalar('max', tf.reduce_max(tensor))
                tf.summary.scalar('min', tf.reduce_min(tensor))
                tf.summary.histogram('histogram', tensor)

        a = tf.Variable(tf.random_normal([10]))
        init = tf.global_variables_initializer()

        summ_obj = tfhelpers.TFSummaries()
        summ_obj.create_variable_summaries(a)

        create_summaries(a)

        merged_rzt = summ_obj.create_summary_op()
        merged_tf = tf.summary.merge_all()

        self.sess.run(init)

        summ_obj.create_file_writer('tester', self.path_rzt, self.sess.graph)
        tf_writer = tf.summary.FileWriter(self.path_tf, self.sess.graph)

        summary_rzt, summary_tf = self.sess.run([merged_rzt, merged_tf])
        summ_obj.add_summary('tester', summary_rzt, 1)
        tf_writer.add_summary(summary_tf)

        path_1 = self.path_rzt + str(os.listdir(self.path_rzt)[0])
        path_2 = self.path_tf + str(os.listdir(self.path_tf)[0])

        summ_obj.close_file_writer('tester')
        tf_writer.close()

        time.sleep(2)

        acc_rzt = ea.EventAccumulator(path_1)
        acc_rzt.Reload()

        acc_tf = ea.EventAccumulator(path_2)
        acc_tf.Reload()

        os.system("rm -rf " + self.path_tf)
        os.system("rm -rf " + self.path_rzt)

        assert_equal(acc_rzt.Histograms('summaries/histogram')[0][-1], acc_tf.Histograms('summaries/histogram')[0][-1])
        assert_equal(len(acc_rzt.Tags()['scalars']), len(acc_tf.Tags()['scalars']))
