# -*- coding: utf-8 -*-
"""
| **@created on:** 30/03/17,
| **@author:** Vivek A Gupta,
| **@version:** v0.0.1
|
| **Description:**
| tfhelper Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
from nose.tools import *
from rztdl import RZTDL_STORE, RZTDL_CONFIG
import tensorflow as tf
from rztdl.dl.helpers import tfhelpers
import numpy as np
import os

rztdl_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Setup - Called when this module is initialized - First Call
    """
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = "/tmp/rztdl_tfhelpers_test_cases/"
    print("*********Running TF Helpers Test Case . . .*********")


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Teardown - Called when this module is completed - Last Call
    """
    os.system("rm -rf " + RZTDL_CONFIG.CommonConfig.PATH_RZTDL)
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = rztdl_path
    print("*********TF Helpers Test Case completed successfully . . .*********")


class TestInitialization:
    """
    | **@author:** Prathyush SP
    |
    | Initialization Class Test Cases
    | 1. Random Uniform Initialization
    | 2. Random Normal Initialization
    | 3. Zeros Initialization
    | 4. Ones Initialization
    | 5. Constant Initialization
    | 6. Orthogonal Initialization
    | 7. Truncated Normal Initialization
    | 8. Xavier Initialization
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        RZTDL_STORE.initialize()
        tf.reset_default_graph()
        cls.sess = tf.InteractiveSession()
        print("*********Running Initializer Test Case . . .*********")

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        cls.sess.close()
        print("*********Initializer Test Case completed successfully . . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_ones(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests ones function - Manually.
        """
        result1, result2 = self.sess.run(
            [tfhelpers.Initialization([1, 2], seed=2).ones(),
             tf.initializers.ones().__call__(shape=[1, 2])])
        assert_true(np.array_equal(result1, result2))

    def test_zeros(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests zeros function - Manually.
        """
        result1, result2 = self.sess.run(
            [tfhelpers.Initialization([1, 2], seed=2).zeros(),
             tf.initializers.zeros().__call__(shape=[1, 2])])
        assert_true(np.array_equal(result1, result2))

    def test_random_uniform(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests random_uniform function - Check against tensorflow function.
        """
        result1, result2 = self.sess.run(
            [tfhelpers.Initialization([1, 2], seed=2).random_uniform(min_val=1.23, max_val=3.45),
             tf.initializers.random_uniform(minval=1.23, maxval=3.45, seed=2).__call__(shape=[1, 2])])
        assert_true(np.array_equal(result1, result2))

    def test_random_normal(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests random_normal function - Check against tensorflow function.
        """
        result1, result2 = self.sess.run(
            [tfhelpers.Initialization([1, 2], seed=2).random_normal(mean=1.23, std_dev=3.45),
             tf.initializers.random_normal(mean=1.23, stddev=3.45, seed=2).__call__(shape=[1, 2])])
        assert_true(np.array_equal(result1, result2))

    def test_constant(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests constant function - Check against tensorflow function.
        """
        result1, result2 = self.sess.run(
            [tfhelpers.Initialization([1, 2]).constant(constant=2.0),
             tf.initializers.constant(value=2.0).__call__(shape=[1, 2], dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE)])
        assert_true(np.array_equal(result1, result2))

    def test_orthogonal(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests orthogonal function - Check against tensorflow function.
        """
        result1, result2 = self.sess.run(
            [tfhelpers.Initialization([1, 2], seed=1).orthogonal(gain=1.245),
             tf.initializers.orthogonal(gain=1.245, seed=1).__call__(shape=[1, 2],
                                                                     dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE)])
        assert_true(np.array_equal(result1, result2))

    def test_xavier(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests xavier function - Check against tensorflow function.
        """
        result1, result2 = self.sess.run(
            [tfhelpers.Initialization([1, 2], seed=2).xavier(uniform=True),
             tf.contrib.layers.xavier_initializer(uniform=True, seed=2, dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE)(
                 shape=[1, 2])])
        assert_true(np.array_equal(result1, result2))

    def test_truncated_normal(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests truncated normal function - Check against tensorflow function.
        """
        result1, result2 = self.sess.run(
            [tfhelpers.Initialization([1, 2], seed=2).truncated_normal(mean=1.23, std_dev=2.45),
             tf.initializers.truncated_normal(mean=1.23, stddev=2.45, seed=2,
                                              dtype=RZTDL_CONFIG.TensorflowConfig.DTYPE)(
                 shape=[1, 2])])
        assert_true(np.array_equal(result1, result2))
