# -*- coding: utf-8 -*-
"""
| **@created on:** 30/03/17,
| **@author:** Vivek A Gupta,
| **@version:** v0.0.1
|
| **Description:**
| tfhelper Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
from nose.tools import *
from rztdl import RZTDL_STORE, RZTDL_CONFIG
import tensorflow as tf
from rztdl.dl.helpers import tfhelpers
import rztdl.utils.string_constants as constants
import os

rztdl_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Setup - Called when this module is initialized - First Call
    """
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = "/tmp/rztdl_tfhelpers_test_cases/"
    print("*********Running TF Helpers Test Case . . .*********")


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Teardown - Called when this module is completed - Last Call
    """
    os.system("rm -rf " + RZTDL_CONFIG.CommonConfig.PATH_RZTDL)
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = rztdl_path
    print("*********TF Helpers Test Case completed successfully . . .*********")


class TestOptimization:
    """
    | **@author:** Vivek A Gupta
    |
    | Optimization Class Test Cases
    | 1. Adam Optimizer
    | 2. Adam Grad Optimizer
    | 3. Gradient Descent Optimizer
    | 4. Momentum Optimizer
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        print("*********Running Optimizer Test Case . . .*********")
        RZTDL_STORE.initialize()
        tf.reset_default_graph()
        cls.x = tf.placeholder(dtype='float', shape=[1, 1])
        cls.y = tf.placeholder(dtype='float', shape=[1, 1])
        cls.b = tf.Variable(tf.ones([1, 1]))
        cls.w = tf.Variable(tf.ones([1, 1]))
        cls.model = tf.add(tf.multiply(cls.x, cls.w), cls.b)
        cls.learning_rate = 0.01
        cls.cost = tf.reduce_sum(tf.pow(cls.model - cls.y, 2)) / (2 * 1)
        cls.input = [[3]]
        cls.output = [[5]]
        cls.sess = tf.InteractiveSession()

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        cls.sess.close()
        print("*********Optimizer Test Case completed successfully. . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a /new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_adam_optimizer(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests adam optimizer - Check against tensorflow function..
        """
        opt = tfhelpers.Optimizer(self.learning_rate, self.cost).switch(constants.OptimizerTypes.ADAM)
        init = tf.global_variables_initializer()
        self.sess.run(init)
        self.sess.run(opt, feed_dict={self.x: self.input, self.y: self.output})
        assert_equal(opt.name, 'Adam')

    def test_ada_gradient_optimizer(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests ada gradient optimizer - Check against tensorflow function.
        """
        opt = tfhelpers.Optimizer(self.learning_rate, self.cost).switch(constants.OptimizerTypes.ADA_GRADIENT)
        init = tf.global_variables_initializer()
        self.sess.run(init)
        self.sess.run(opt, feed_dict={self.x: self.input, self.y: self.output})
        assert_equal(opt.name, 'Adagrad')

    def test_gradient_descent_optimizer(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests adam gradient optimizer - Check against tensorflow function.
        """
        opt = tfhelpers.Optimizer(self.learning_rate, self.cost).switch(constants.OptimizerTypes.GRADIENT_DESCENT)
        init = tf.global_variables_initializer()
        self.sess.run(init)
        self.sess.run(opt, feed_dict={self.x: self.input, self.y: self.output})
        assert_equal(opt.name, 'GradientDescent')

    def test_momentum_optimizer(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests momentum optimizer - Check against tensorflow function.
        """
        opt = tfhelpers.Optimizer(self.learning_rate, self.cost, 1.0).switch(constants.OptimizerTypes.MOMENTUM)
        init = tf.global_variables_initializer()
        self.sess.run(init)
        self.sess.run(opt, feed_dict={self.x: self.input, self.y: self.output})
        assert_equal(opt.name, 'Momentum')

    def test_ftrl_optimizer(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests ftrl optimizer - Check against tensorflow function.
        """
        opt = tfhelpers.Optimizer(self.learning_rate, self.cost, 1.0).switch(constants.OptimizerTypes.FTRL)
        init = tf.global_variables_initializer()
        self.sess.run(init)
        self.sess.run(opt, feed_dict={self.x: self.input, self.y: self.output})
        assert_equal(opt.name, 'Ftrl')

    def test_proximal_ada_grad_optimizer(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests PROXIMAL_ADAGRAD optimizer - Check against tensorflow function.
        """
        opt = tfhelpers.Optimizer(self.learning_rate, self.cost, 1.0).switch(constants.OptimizerTypes.PROXIMAL_ADAGRAD)
        init = tf.global_variables_initializer()
        self.sess.run(init)
        self.sess.run(opt, feed_dict={self.x: self.input, self.y: self.output})
        assert_equal(opt.name, 'ProximalAdagrad')

    def test_proximal_gradient_descent_optimizer(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests PROXIMAL_GRADIENT_DESCENT optimizer - Check against tensorflow function.
        """
        opt = tfhelpers.Optimizer(self.learning_rate, self.cost, 1.0).switch(
            constants.OptimizerTypes.PROXIMAL_GRADIENT_DESCENT)
        init = tf.global_variables_initializer()
        self.sess.run(init)
        self.sess.run(opt, feed_dict={self.x: self.input, self.y: self.output})
        assert_equal(opt.name, 'ProximalGradientDescent')

    def test_ada_delta_optimizer(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests ADA_DELTA optimizer - Check against tensorflow function.
        """
        opt = tfhelpers.Optimizer(self.learning_rate, self.cost, 1.0).switch(constants.OptimizerTypes.ADA_DELTA)
        init = tf.global_variables_initializer()
        self.sess.run(init)
        self.sess.run(opt, feed_dict={self.x: self.input, self.y: self.output})
        assert_equal(opt.name, 'Adadelta')
