# -*- coding: utf-8 -*-
"""
| **@created on:** 30/03/17,
| **@author:** Vivek A Gupta,
| **@version:** v0.0.1
|
| **Description:**
| tfhelper Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
from nose.tools import *
from rztdl import RZTDL_STORE, RZTDL_CONFIG
import tensorflow as tf
from rztdl.dl.helpers import tfhelpers
import numpy as np
import os

rztdl_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Setup - Called when this module is initialized - First Call
    """
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = "/tmp/rztdl_tfhelpers_test_cases/"
    print("*********Running TF Helpers Test Case . . .*********")


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Teardown - Called when this module is completed - Last Call
    """
    os.system("rm -rf " + RZTDL_CONFIG.CommonConfig.PATH_RZTDL)
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = rztdl_path
    print("*********TF Helpers Test Case completed successfully . . .*********")


class TestActivation:
    """
    | **@author:** Vivek A Gupta
    |
    | Activation Class Test Cases
    | 1. Sigmoid Activation
    | 2. Softmax Activation
    | 3. Tanh Activation
    | 4. Relu Activation
    | 5. None Activation
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        RZTDL_STORE.initialize()
        tf.reset_default_graph()
        cls.variable1 = tf.ones([1, 2])
        cls.init = tf.global_variables_initializer()
        cls.sess = tf.InteractiveSession()
        cls.sess.run(cls.init)
        print("*********Running Activation Test Case . . .*********")

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        cls.sess.close()
        print("*********Activation Test Case Completed successfully . . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_sigmoid(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests sigmoid function - Check against tensorflow function.
        """
        res = self.sess.run(tf.nn.sigmoid(self.variable1))
        ans = self.sess.run(tfhelpers.Activation(self.variable1).sigmoid())
        assert_true(np.array_equal(res, ans))

    def test_tanh(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests tanh function - Check against tensorflow function.
        """
        res = self.sess.run(tf.nn.tanh(self.variable1))
        ans = self.sess.run(tfhelpers.Activation(self.variable1).tanh())
        assert_true(np.array_equal(res, ans))

    def test_relu(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests relu function - Check against tensorflow function.
        """
        res = self.sess.run(tf.nn.relu(self.variable1))
        ans = self.sess.run(tfhelpers.Activation(self.variable1).relu())
        assert_true(np.array_equal(res, ans))

    def test_softmax(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests softmax function - Check against tensorflow function.
        """
        res = self.sess.run(tf.nn.softmax(self.variable1))
        ans = self.sess.run(tfhelpers.Activation(self.variable1).softmax())
        assert_true(np.array_equal(res, ans))

    def test_none(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests none function - Manually.
        """
        res = self.sess.run(tfhelpers.Activation(self.variable1).none())
        v1 = self.sess.run(self.variable1)
        assert_true(np.array_equal(v1, res))
