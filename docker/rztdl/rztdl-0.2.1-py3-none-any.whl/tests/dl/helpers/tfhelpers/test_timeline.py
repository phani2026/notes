# -*- coding: utf-8 -*-
"""
| **@created on:** 30/03/17,
| **@author:** Vivek A Gupta,
| **@version:** v0.0.1
|
| **Description:**
| tfhelper Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
from nose.tools import *
from rztdl import RZTDL_CONFIG
import tensorflow as tf
from rztdl.dl.helpers import tfhelpers
import os

rztdl_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Setup - Called when this module is initialized - First Call
    """
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = "/tmp/rztdl_tfhelpers_test_cases/"
    print("*********Running TF Helpers Test Case . . .*********")


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Teardown - Called when this module is completed - Last Call
    """
    os.system("rm -rf " + RZTDL_CONFIG.CommonConfig.PATH_RZTDL)
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = rztdl_path
    print("*********TF Helpers Test Case completed successfully . . .*********")


class TestTFTimeline:
    """
    | **@author**: Vivek A Gupta
    |
    | Timeline Class Test Cases
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        print("*********Running TFTimeline Test Cases . . .*********")
        cls.sess = tf.InteractiveSession()

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        cls.sess.close()
        print("*********TFTimeline Test Cases completed successfully . . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a /new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_run(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests run function - Check if the function is returning a json file.
        """
        x = tf.placeholder(dtype='float', shape=[1, 1])
        y = tf.placeholder(dtype='float', shape=[1, 1])

        b = tf.Variable(tf.ones([1, 1]))
        w = tf.Variable(tf.ones([1, 1]))

        model = tf.add(tf.multiply(x, w), b)

        learning_rate = 0.01
        cost = tf.reduce_sum(tf.pow(model - y, 2)) / (2 * 1)

        input = [[3]]
        output = [[5]]

        opt = tf.train.AdamOptimizer(learning_rate).minimize(cost)
        feed_dict = {x: input, y: output}

        tl_obj = tfhelpers.TFTimeline()

        init = tf.global_variables_initializer()

        self.sess.run(init)
        tl_json = tl_obj.run(self.sess, opt, feed_dict, True)

        fname = '/tmp/time1.json'
        with open(fname, 'w') as f:
            f.write(tl_json)

        assert os.path.isfile(fname)

        os.remove(fname)

    def test_get_run_options(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests get_run_options function - Check the return type of the function.
        """
        tl_obj = tfhelpers.TFTimeline()
        tl_obj_run_opt = tl_obj.get_run_options()
        assert_true(isinstance(tl_obj_run_opt, tf.RunOptions))

    def test_get_run_metadata(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests get_run_metadata function - Check the return type of the function.
        """
        tl_obj = tfhelpers.TFTimeline()
        tl_obj_meta = tl_obj.get_run_metadata()
        assert_true(isinstance(tl_obj_meta, tf.RunMetadata))

    def test_save(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests save function - Check if the json file is getting created.
        """
        x = tf.placeholder(dtype='float', shape=[1, 1])
        y = tf.placeholder(dtype='float', shape=[1, 1])

        b = tf.Variable(tf.ones([1, 1]))
        w = tf.Variable(tf.ones([1, 1]))

        model = tf.add(tf.multiply(x, w), b)

        learning_rate = 0.01
        cost = tf.reduce_sum(tf.pow(model - y, 2)) / (2 * 1)

        input = [[3]]
        output = [[5]]

        opt = tf.train.AdamOptimizer(learning_rate).minimize(cost)
        feed_dict = {x: input, y: output}

        tl_obj = tfhelpers.TFTimeline()

        init = tf.global_variables_initializer()

        self.sess.run(init)
        tl_obj.run(self.sess, opt, feed_dict, True)

        fname = '/tmp/time2.json'
        tl_obj.save(fname)

        assert os.path.isfile(fname)

        os.remove(fname)
