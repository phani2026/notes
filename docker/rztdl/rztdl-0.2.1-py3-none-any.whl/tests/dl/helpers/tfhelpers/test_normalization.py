# -*- coding: utf-8 -*-
"""
| **@created on:** 30/03/17,
| **@author:** Vivek A Gupta,
| **@version:** v0.0.1
|
| **Description:**
| tfhelper Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
from nose.tools import *
from rztdl import RZTDL_STORE, RZTDL_CONFIG
import tensorflow as tf
from rztdl.dl.helpers import tfhelpers
import rztdl.utils.string_constants as constants
import os
import numpy as np

rztdl_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Setup - Called when this module is initialized - First Call
    """
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = "/tmp/rztdl_tfhelpers_test_cases/"
    print("*********Running TF Helpers Test Case . . .*********")


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Teardown - Called when this module is completed - Last Call
    """
    os.system("rm -rf " + RZTDL_CONFIG.CommonConfig.PATH_RZTDL)
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = rztdl_path
    print("*********TF Helpers Test Case completed successfully . . .*********")


class TestNormalizationLayer:
    """
    | **@author:** Vivek A Gupta
    |
    | NormalizationLayer Class Test Cases
    | 1. l2 norm
    | 2. lrn norm
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        print("*********Running Normalization Test Case . . .*********")
        RZTDL_STORE.initialize()
        tf.reset_default_graph()
        cls.x1 = tf.random_normal([1, 5], seed=12)
        cls.x2 = tf.random_normal([1, 2, 3, 4], seed=23)
        cls.init = tf.global_variables_initializer()
        cls.sess = tf.InteractiveSession()
        cls.sess.run(cls.init)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        cls.sess.close()
        print("*********Normalization Test Case completed successfully . . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a /new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_l2_norm(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests l2_norm function - Check against tensorflow function.
        """
        n1 = tfhelpers.NormalizationLayer(self.x1).l2_norm(
            norm_parameters={constants.PARAMETERS.NORM_DIM: 0, constants.PARAMETERS.NORM_EPSILON: 1})
        n2 = tf.nn.l2_normalize(self.x1, 0, 1)
        ans, res = self.sess.run([n1, n2])
        assert_true(np.array_equal(ans, res))

    def test_lrn_norm(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests lrn_norm function - Check against tensorflow function.
        """
        n1 = tfhelpers.NormalizationLayer(self.x2).lrn_norm(
            norm_parameters={constants.PARAMETERS.DEPTH_RADIUS: 1, constants.PARAMETERS.NORM_BIAS: 1,
                             constants.PARAMETERS.NORM_ALPHA: 1,
                             constants.PARAMETERS.NORM_BETA: 0.5})
        n2 = tf.nn.lrn(self.x2, 1, 1, 1, 0.5)
        ans, res = self.sess.run([n1, n2])
        assert_true(np.array_equal(ans, res))
