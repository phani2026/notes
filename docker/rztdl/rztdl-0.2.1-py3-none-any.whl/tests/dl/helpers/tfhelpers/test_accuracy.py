# -*- coding: utf-8 -*-
"""
| **@created on:** 30/03/17,
| **@author:** Vivek A Gupta,
| **@version:** v0.0.1
|
| **Description:**
| tfhelper Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
from nose.tools import *
from rztdl import RZTDL_CONFIG
from rztdl.dl.helpers import tfhelpers
import os
import numpy as np

rztdl_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Setup - Called when this module is initialized - First Call
    """
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = "/tmp/rztdl_tfhelpers_test_cases/"
    print("*********Running TF Helpers Test Case . . .*********")


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Teardown - Called when this module is completed - Last Call
    """
    os.system("rm -rf " + RZTDL_CONFIG.CommonConfig.PATH_RZTDL)
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = rztdl_path
    print("*********TF Helpers Test Case completed successfully . . .*********")


class TestAccuracy:
    """
    | **@author:** Vivek A Gupta
    |
    | Accuracy Class Test Cases
    | 1. Simple accuracy
    | 2. Binary accuracy
    | 3. Softmax
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        print("*********Running Accuracy Test Case . . .*********")
        cls.pred = np.array([[1], [0], [1], [0]])
        cls.label = np.array([[1], [0], [0], [0]])
        cls.thresh = 0.5
        cls.acc_fun = tfhelpers.Accuracy(cls.pred, cls.label, cls.thresh)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        print("*********Accuracy Test Case completed successfully. . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a /new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_simple(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests simple function - Check if function is returning expected results.
        """
        x = self.acc_fun.simple()
        assert_equal(75.0, float(x['accuracy']))
        assert_equal(3.0, x['accurate_samples'])
        assert_equal(1.0, x['error_samples'])

    def test_binary(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests binary function - Check if function is returning expected results.
        """
        x = self.acc_fun.binary(1.0)
        assert_equal(50.0, float(x['accuracy']))
        assert_equal(1.0, x['accurate_samples'])
        assert_equal(1.0, x['error_samples'])

    def test_softmax(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests softmax function - Check if function is returning expected results.
        """
        pred = np.array([[1, 0], [2, 0], [0, 1], [0, 2]])
        label = np.array([[1, 0], [1, 0], [1, 0], [1, 0]])
        x = tfhelpers.Accuracy(pred, label).softmax()
        assert_equal(50.0, float(x['accuracy']))
        assert_equal(2.0, x['accurate_samples'])
        assert_equal(2.0, x['error_samples'])

    @raises(Exception)
    def test_length_simple(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests simple function - Check if an exception is thrown when the length of input and output do not match.
        """
        pred = [[2], [3]]
        label = [[2]]
        thresh = 0.5
        tfhelpers.Accuracy(pred, label, thresh).simple()

    @raises(Exception)
    def test_length_binary(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests binary function - Check if an exception is thrown when the length of input and output do not match.
        """
        pred = [[2], [3]]
        label = [[2]]
        thresh = 0.5
        tfhelpers.Accuracy(pred, label, thresh).binary()

    @raises(Exception)
    def test_length_softmax(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests softmax function - Check if an exception is thrown when the length of input and output do not match.
        """
        pred = [[1, 2]]
        label = [[1, 3], [2, 4]]
        thresh = 0.5
        tfhelpers.Accuracy(pred, label, thresh).softmax()
