# -*- coding: utf-8 -*-
"""
| **@created on:** 30/03/17,
| **@author:** Vivek A Gupta,
| **@version:** v0.0.1
|
| **Description:**
| tfhelper Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
from nose.tools import *
from rztdl import RZTDL_STORE, RZTDL_CONFIG
import tensorflow as tf
from rztdl.dl.helpers import tfhelpers
import numpy as np
import rztdl.utils.string_constants as constants
import os

rztdl_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Setup - Called when this module is initialized - First Call
    """
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = "/tmp/rztdl_tfhelpers_test_cases/"
    print("*********Running TF Helpers Test Case . . .*********")


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Teardown - Called when this module is completed - Last Call
    """
    os.system("rm -rf " + RZTDL_CONFIG.CommonConfig.PATH_RZTDL)
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = rztdl_path
    print("*********TF Helpers Test Case completed successfully . . .*********")


class TestCost:
    """
    | **@author:** Vivek A Gupta
    |
    | Cost Class Test Cases
    | 1. Cross Entropy
    | 2. Mean Square Error
    | 3. Simple Cross Entropy
    | 4. Softmax Cross Entropy

    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        print("*********Running Cost Test Case . . .*********")
        RZTDL_STORE.initialize()
        tf.reset_default_graph()
        cls.placeholder1 = tf.placeholder(dtype=tf.float32, shape=[1, 1])
        cls.placeholder2 = tf.placeholder(dtype=tf.float32, shape=[1, 1])
        cls.init = tf.global_variables_initializer()
        cls.sess = tf.InteractiveSession()
        cls.sess.run(cls.init)
        cls.predicted = np.random.rand(1, 1)
        cls.output = np.random.rand(1, 1)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        cls.sess.close()
        print("*********Cost Test Case completed successfully. . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_cross_entropy(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests cross entropy function - Cross check with the correct formula.
        """
        cal_loss = tf.reduce_mean(((self.placeholder1 * tf.log(self.placeholder2)) + (
                (1 - self.placeholder1) * tf.log(1.0 - self.placeholder2))) * -1)

        loss = tfhelpers.Cost(self.placeholder1, self.placeholder2).cross_entropy()
        cost, cal_cost = self.sess.run([loss, cal_loss],
                                       feed_dict={self.placeholder1: self.output, self.placeholder2: self.predicted})
        assert_equal(cost, cal_cost)

    def test_mean_square_error(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests mean square error function - Cross check with the correct formula.
        """
        cal_loss = tf.reduce_mean(tf.square(self.placeholder1 - self.placeholder2))
        loss = tfhelpers.Cost(self.placeholder1, self.placeholder2).switch(constants.CostType.MEAN_SQUARE_ERROR)
        cal_cost, cost = self.sess.run([cal_loss, loss],
                                       feed_dict={self.placeholder1: self.predicted, self.placeholder2: self.output})
        assert_equal(cost, cal_cost)

    def test_simple_cross_entropy(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests simple cross entropy function - Cross check with the correct formula.
        """
        cal_loss = tf.reduce_mean(-tf.reduce_sum(self.placeholder1 * tf.log(self.placeholder2), reduction_indices=1))

        loss = tfhelpers.Cost(self.placeholder1, self.placeholder2).simple_cross_entropy(reduction_indices=1)
        cost, cal_cost = self.sess.run([loss, cal_loss],
                                       feed_dict={self.placeholder1: self.output, self.placeholder2: self.predicted})
        assert_equal(cost, cal_cost)

    def test_softmax_cross_entropy(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests softmax cross entropy function - Cross check with the tensorflow function.
        """
        cal_loss = tf.reduce_mean(
            tf.nn.softmax_cross_entropy_with_logits(logits=self.placeholder2, labels=self.placeholder1))
        loss = tfhelpers.Cost(self.placeholder1, self.placeholder2).switch(constants.CostType.SOFTMAX_CROSS_ENTROPY)
        cost, cal_cost = self.sess.run([loss, cal_loss],
                                       feed_dict={self.placeholder1: self.output, self.placeholder2: self.predicted})
        assert_equal(cost, cal_cost)

    def test_weighted_cross_entropy(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests softmax cross entropy function - Cross check with the tensorflow function.
        """
        cal_loss = tf.reduce_mean(
            tf.nn.weighted_cross_entropy_with_logits(logits=self.placeholder2, targets=self.placeholder1,
                                                     pos_weight=100.123))
        loss = tfhelpers.Cost(self.placeholder1, self.placeholder2).weighted_cross_entropy(pos_weight=100.123)
        cost, cal_cost = self.sess.run([loss, cal_loss],
                                       feed_dict={self.placeholder1: self.output, self.placeholder2: self.predicted})
        assert_equal(cost, cal_cost)
