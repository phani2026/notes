# -*- coding: utf-8 -*-
"""
| **@created on:** 30/03/17,
| **@author:** Vivek A Gupta,
| **@version:** v0.0.1
|
| **Description:**
| tfhelper Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
from rztdl import RZTDL_CONFIG
from rztdl.dl.helpers import tfhelpers
import os
import time
import rztdl.dl
from rztdl.utils.file import read_csv
import multiprocessing
from multiprocessing import Process
import subprocess

multiprocessing.context._force_start_method('fork')

rztdl_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Setup - Called when this module is initialized - First Call
    """
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = "/tmp/rztdl_tfhelpers_test_cases/"
    print("*********Running TF Helpers Test Case . . .*********")


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Teardown - Called when this module is completed - Last Call
    """
    os.system("rm -rf " + RZTDL_CONFIG.CommonConfig.PATH_RZTDL)
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = rztdl_path
    print("*********TF Helpers Test Case completed successfully . . .*********")


class TestTensorboard:
    """
    | **@author**: Prathyush SP
    |
    | Tensorboard Class Test Cases
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        print("*********Running Tensorboard Test Cases . . .*********")
        data_path = '/'.join(str(__file__).split('/')[:-5]) + '/data/'
        train_data, train_label, valid_data, valid_label, test_data, test_label = read_csv(
            filename=data_path + '/sample_titanic.csv', split_ratio=[60, 20, 20], label_vector=False, randomize=True)
        model = rztdl.dl.Model('test_simple_ffn')

        model.add_layer(rztdl.dl.layer.InputLayer(name='input_layer', layer_nodes=3))
        model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name='hidden_layer_1', layer_nodes=4,
                                                           layer_activation=rztdl.dl.constants.ActivationType.SIGMOID))
        model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name='hidden_layer_2', layer_nodes=2,
                                                           layer_activation=rztdl.dl.constants.ActivationType.SIGMOID))
        model.add_layer(rztdl.dl.layer.OutputLayer(name='output_layer', layer_nodes=1,
                                                   layer_activation=rztdl.dl.constants.ActivationType.SIGMOID))

        model.close()
        cls.network = rztdl.dl.Network('test_nn_simple_ffn')

        # Training
        cls.network.train(epoch=1, learning_rate=0.01, model=model, cost=rztdl.dl.constants.CostType.MEAN_SQUARE_ERROR,
                          optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
                          train_data={'input_layer': train_data, 'output_layer': train_label},
                          valid_data={'input_layer': valid_data, 'output_layer': valid_label},
                          test_data={'input_layer': test_data, 'output_layer': test_label}, display_step=1,
                          train_batches=1, print_json=False)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        print("*********Tensorboard Test Cases completed successfully . . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a /new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_start_tensorboard(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests start_tensorboard function - Check tensorboard is running in different ports.
        """
        port1 = 1123

        def tens1():
            tb1 = tfhelpers.TensorBoard(self.network.name,
                                        '/tmp/rztdl_logs/' + self.network.name + '/' + self.network.timestamp + '/graphs/tf/',
                                        port=port1)
            tb1.start_tensorboard()
            time.sleep(1)

        port2 = 1122

        def tens2():
            tb2 = tfhelpers.TensorBoard(self.network.name,
                                        '/tmp/rztdl_logs/' + self.network.name + '/' + self.network.timestamp + '/graphs/tf/',
                                        port=port2)
            tb2.start_tensorboard()

        p1 = Process(target=tens1)
        p2 = Process(target=tens2)

        p1.start()
        p2.start()
        while True:
            if p1.is_alive() and p2.is_alive():
                p1.join(timeout=5)
                p2.join(timeout=5)
                break
        board1 = subprocess.Popen("lsof -i:{} -t".format(port1), shell=True, stdout=subprocess.PIPE)
        pid_to_kill = [i for i in board1.communicate()[0].decode("utf-8").split('\n') if i != '']
        board2 = subprocess.Popen("lsof -i:{} -t".format(port2), shell=True, stdout=subprocess.PIPE)
        pid_to_kill += [i for i in board2.communicate()[0].decode("utf-8").split('\n') if i != '']
        assert len(pid_to_kill) > 0
        time.sleep(2)
        p1.terminate()
        p2.terminate()
        os.system("kill `lsof -t -i:{}`".format(port1))
        os.system("kill `lsof -t -i:{}`".format(port2))
