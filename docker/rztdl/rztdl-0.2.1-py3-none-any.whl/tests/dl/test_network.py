# -*- coding: utf-8 -*-
"""
| **@created on**: 20/03/2017,
| **@author**: Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
|   1. Testcases for Network class and Prediction class
|
| **Sphinx Documentation Status:** Complete
|
| ..todo::
    --
"""
import glob
import logging
import os
import numpy as np
from collections import OrderedDict

import tensorflow as tf
from nose.tools import *

import rztdl.dl
import rztdl.utils.string_constants as constants
from rztdl import RZTDL_CONFIG, RZTDL_STORE
from rztdl.utils.file import read_csv, read_network
from rztdl.utils.pyutils import File
from rztdl.utils.string_constants import ModelMetaConstant

logger = logging.getLogger(__name__)


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Setup - Called when this module is initialized - First Call
    """
    RZTDL_CONFIG.update_dl_config_manager(
        config_file_path='/'.join(str(__file__).split('/')[:-2]) + '/rztdl_testing_config.json')
    print("*********Running Network Test Case . . .*********")


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Teardown - Called when this module is completed - Last Call
    """
    os.system("rm -rf " + RZTDL_CONFIG.CommonConfig.PATH_RZTDL)
    print("*********Network Test Case completed successfully . . .*********")


def stop_criteria_fn(epoch, current_epoch, cost, accuracy, gini):
    """
    | **@author:** Umesh Kumar
    |**Custom Stop Criteria Function:**
    |.. code-block:: python
    def stop_criteria_fn(epoch: int, current_epoch: int, cost: float, accuracy: float, gini: Union[float, None]):
    # condition1
    # return True, "Stopped due to Condition 1" # - Stop the training

    # condition2
    # return True, "Stopped due to Condition 2" - Stop the training

    # Continue Training

    :param epoch: epoch value
    :param current_epoch: current_epoch
    :param cost: cost calculated by model
    :param accuracy: accuracy calculated by model
    :param gini: gini calculated by model
    :return: bool, String(Message)
    """
    cost_limit = 0.5
    if cost <= cost_limit:
        return True, "Stop due to condition cost<= cost_limit"
    return False, "Continue training"


class TestNetwork:
    """
    | **@author:** Umesh Kumar
    |
    | **Description:**
    | Network module contains various utilities required to test using nose testcases
    | 1. Validate Network name.
    | 2. Create Directories.
    | 3. Generate batches
    | 4. Train validation
    | 5. Persist training validation
    | 6. Persist train model build
    | 7. Persist train Cost and Optimizer
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Umesh Kumar
        |
        | Runs when class is initialized.
        :return:
        """
        cls.model = None
        cls.network = None
        cls.data_path = '/'.join(str(__file__).split('/')[:-2]) + '/data/'
        rztdl.RZTDL_STORE.dag = OrderedDict()
        rztdl.RZTDL_CONFIG.CommonConfig.DRY_RUN = False
        tf.reset_default_graph()
        cls.session = tf.InteractiveSession()

        # Load Regression Data
        cls.regression_train_data, cls.regression_train_label, cls.regression_valid_data, cls.regression_valid_label, \
        cls.regression_test_data, cls.regression_test_label = read_csv(
            cls.data_path + "/sample_energy.csv", split_ratio=[60, 20, 20], randomize=True,
            strict_type=False)

        # Create Regression Model
        cls.regression_model = rztdl.dl.Model('regression_model')
        cls.regression_model.add_layer(
            rztdl.dl.layer.InputLayer('input_layer', layer_nodes=len(cls.regression_train_data[0])))
        cls.regression_model.add_layer(
            rztdl.dl.layer.OutputLayer('output_layer', layer_nodes=len(cls.regression_train_label[0]),
                                       layer_activation=rztdl.dl.constants.ActivationType.NONE))
        cls.regression_model.close()

        # Load Classification Data
        cls.classification_train_data, cls.classification_train_label, cls.classification_valid_data, \
        cls.classification_valid_label, cls.classification_test_data, cls.classification_test_label = read_csv(
            cls.data_path + "/sample_titanic.csv", split_ratio=[60, 20, 20], randomize=True)

        # Create Classification Model
        cls.classification_model = rztdl.dl.Model('titanic_model')
        cls.classification_model.add_layer(
            rztdl.dl.layer.InputLayer(name='input_layer', layer_nodes=len(cls.classification_train_data[0])))
        cls.classification_model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name='hidden_layer', layer_nodes=3,
                                                                              layer_activation=rztdl.dl.constants.ActivationType.SIGMOID))
        cls.classification_model.add_layer(
            rztdl.dl.layer.OutputLayer(name='output_layer', layer_nodes=len(cls.classification_train_label[0]),
                                       layer_activation=rztdl.dl.constants.ActivationType.SIGMOID))
        cls.classification_model.close()

        # Load Multivariate Data
        cls.multivariate_train_data, cls.multivariate_train_label, cls.multivariate_valid_data, \
        cls.multivariate_valid_label, cls.multivariate_test_data, cls.multivariate_test_label = read_csv(
            cls.data_path + "/sample_iris.csv", split_ratio=[60, 20, 20], randomize=True,
            output_label=[[4, 7]])
        logger.info(len(cls.multivariate_train_data))
        logger.info(len(cls.multivariate_valid_data))
        logger.info(len(cls.multivariate_test_data))
        # Create Multivariate Model
        cls.multivariate_model = rztdl.dl.Model("multivariate_model")
        cls.multivariate_model.add_layer(
            rztdl.dl.layer.InputLayer("input_layer", layer_nodes=len(cls.multivariate_train_data[0])))
        cls.multivariate_model.add_layer(rztdl.dl.layer.FullyConnectedLayer("hidden_layer", layer_nodes=10))
        cls.multivariate_model.add_layer(rztdl.dl.layer.OutputLayer(name="output_layer",
                                                                    layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                                                    layer_nodes=len(cls.multivariate_train_label[0]),
                                                                    layer_input="input_layer"))
        cls.multivariate_model.close()
        cls.network = rztdl.dl.Network("test_network")
        cls.network.train(epoch=1, learning_rate=0.01, model=cls.multivariate_model,
                          cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
                          optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
                          train_data={'input_layer': cls.multivariate_train_data,
                                      'output_layer': cls.multivariate_train_label},
                          valid_data={'input_layer': cls.multivariate_valid_data,
                                      'output_layer': cls.multivariate_valid_label},
                          test_data={'input_layer': cls.multivariate_test_data,
                                     'output_layer': cls.multivariate_test_label},
                          display_step=1, train_batch_size=1, regularisation=True,
                          regularisation_params=rztdl.dl.constants.REGULARISATION.regularisation(
                              regularisation_type=rztdl.dl.constants.REGULARISATION.L2_REGULARISATION,
                              beta=0.01))

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Umesh Kumar
        |
        | Runs when class is completed.
        :return:
        """

        pass

    def setup(self):
        """
        | **@author:** Umesh Kumar
        |
        | Runs for each test method.
        :return:
        """
        pass

    def teardown(self):
        """
        | **@author:** Umesh Kumar
        |
        | Runs when each test method is completed.
        :return:
        """
        pass

    def test_network_name(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Network name format - Checks whether the network name is in correct format or not.
        """

        validate_names = ['3network_', '_network1', '1network', 'nn_seg']
        for name in validate_names:
            assert rztdl.dl.Network(name)

    def test_create_directories(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Network create_directories functionality - Tests whether the directories for model like graphs, saves,
        | logs etc. are saved or not
        """
        init_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL + '/' + self.network.name + '/' + RZTDL_STORE.get_meta_data_by_key(
            self.multivariate_model.name, 'timestamp') + '/'
        if RZTDL_CONFIG.CommonConfig.DRY_RUN:
            for path in [RZTDL_CONFIG.CommonConfig.PATH_LOG,
                         RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_DL,
                         RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_ML, RZTDL_CONFIG.CommonConfig.PATH_GRAPH,
                         RZTDL_CONFIG.CommonConfig.PATH_DATA]:
                if os.path.isdir(init_path + path):
                    assert True
                else:
                    assert False

    def test_generate_batches(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Network Generate batches Functionality - Returns batches based upon the batch size and no of batches.
        """
        batches = self.network._generate_batches(placeholders=RZTDL_STORE.get_all_placeholders(
            model_name=self.multivariate_model.name).items(),
                                                 data={'input_layer': self.multivariate_test_data,
                                                       'output_layer': self.multivariate_test_label}, batches=1,
                                                 batch_size=2, mode="train")
        assert_equal(len(batches), 1)

    def test_network_train_validation(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Network Train validation - Returns 3 dictionaries of train, valid, test respectively
        """
        train_dict, valid_dict, test_dict = self.network._train_validation(
            train_data={'input_layer': self.multivariate_train_data,
                        'output_layer': self.multivariate_train_label},
            valid_data={'input_layer': self.multivariate_valid_data,
                        'output_layer': self.multivariate_valid_label},
            test_data={'input_layer': self.multivariate_test_data,
                       'output_layer': self.multivariate_test_label},
            learning_rate=0.001,
            placeholders=RZTDL_STORE.get_all_placeholders(model_name=self.multivariate_model.name).items(),
            train_batches=1, train_batch_size=2, valid_batches=1, valid_batch_size=2,
            test_batches=1, test_batch_size=2,
            save_path="/tmp/rzt_directory")
        os.system("rm -rf /tmp/rzt_directory")
        assert_equal(len(train_dict), 3)
        assert_equal(len(valid_dict), 1)
        assert_equal(len(test_dict), 1)

    def test_persist_training_validation(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Network Persist Train validation - Returns the model_metadata and model save path

        """
        run_id = -1
        save_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL
        metadata, model_save_path = self.network._persist_training_validation(save_path, run_id=-1)
        model_metadata = File.read_json(path=save_path + '/' + self.network.name + '/model.meta',
                                        object_pairs_hook=OrderedDict)
        try:
            save_path += '/' + model_metadata[ModelMetaConstant.NETWORK_NAME] + '/' + model_metadata[
                ModelMetaConstant.TIMESTAMP] + '/' + model_metadata[ModelMetaConstant.PATH][
                             ModelMetaConstant.PATH_OPTIONS.DL_SAVE_PATH] + self.network.name
        except KeyError:
            keys = [int(k) for k in model_metadata.keys()]
            model_metadata = model_metadata[str(run_id)] if run_id in keys else model_metadata[str(max(keys))]
            save_path += '/' + model_metadata[ModelMetaConstant.NETWORK_NAME] + '/' + metadata[
                ModelMetaConstant.TIMESTAMP] + '/' + model_metadata[ModelMetaConstant.PATH][
                             ModelMetaConstant.PATH_OPTIONS.DL_SAVE_PATH] + self.network.name
        assert_equal(metadata, model_metadata)
        assert_equal(save_path, model_save_path)

    def test_persist_training_predict_in_single_file(self):
        """
        | **@author:** Umesh Kumar
        |
        | Persist Training - Testing network train and persist training and prediction in single file
        :return:
        """
        persist_model = rztdl.dl.Model("persist_model")
        persist_model.add_layer(
            rztdl.dl.layer.InputLayer("input_layer", layer_nodes=len(self.classification_train_data[0])))
        persist_model.add_layer(rztdl.dl.layer.OutputLayer(name="output_layer",
                                                           layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                                           layer_nodes=len(self.classification_train_label[0]),
                                                           layer_input="input_layer"))
        persist_model.close()
        network = rztdl.dl.Network("test_persist_network")
        network.train(epoch=1, learning_rate=0.01, model=persist_model,
                      cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
                      optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
                      train_data={'input_layer': self.classification_train_data,
                                  'output_layer': self.classification_train_label},
                      valid_data={'input_layer': self.classification_valid_data,
                                  'output_layer': self.classification_valid_label},
                      test_data={'input_layer': self.classification_test_data,
                                 'output_layer': self.classification_test_label},
                      display_step=1, train_batch_size=1, regularisation=True,
                      regularisation_params=constants.REGULARISATION.regularisation(
                          regularisation_type=constants.REGULARISATION.L2_REGULARISATION,
                          beta=0.01))
        network.persist_training(epoch=1, learning_rate=0.01,
                                 train_data={'input_layer': self.classification_train_data,
                                             'output_layer': self.classification_train_label},
                                 valid_data={'input_layer': self.classification_valid_data,
                                             'output_layer': self.classification_valid_label},
                                 test_data={'input_layer': self.classification_test_data,
                                            'output_layer': self.classification_test_label},
                                 display_step=1)
        prediction = rztdl.dl.Prediction('test_persist_network')
        prediction.predict(layer_name='output_layer',
                           data={'input_layer': self.classification_train_data}, batches=2)

    def test_two_persist_training_predict_in_single_file(self):
        """
        | **@author:** Umesh Kumar
        |
        | Persist Training - Testing network train and persist training for two times and prediction in single file
        | and loading and saving from the different path
        :return:
        """
        persist_model_2 = rztdl.dl.Model("two_persist_model")
        persist_model_2.add_layer(
            rztdl.dl.layer.InputLayer("input_layer", layer_nodes=len(self.classification_train_data[0])))
        persist_model_2.add_layer(rztdl.dl.layer.OutputLayer(name="output_layer",
                                                             layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                                             layer_nodes=len(self.classification_train_label[0]),
                                                             layer_input="input_layer"))
        persist_model_2.close()
        persist_network = rztdl.dl.Network("test_two_persist_network")
        persist_network.train(epoch=1, learning_rate=0.01, model=persist_model_2,
                              cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
                              optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
                              train_data={'input_layer': self.classification_train_data,
                                          'output_layer': self.classification_train_label},
                              valid_data={'input_layer': self.classification_valid_data,
                                          'output_layer': self.classification_valid_label},
                              test_data={'input_layer': self.classification_test_data,
                                         'output_layer': self.classification_test_label}, sess=None,
                              display_step=1, train_batch_size=1, regularisation=True,
                              regularisation_params=rztdl.dl.constants.REGULARISATION.regularisation(
                                  regularisation_type=rztdl.dl.constants.REGULARISATION.L2_REGULARISATION,
                                  beta=0.01), save_path=RZTDL_CONFIG.CommonConfig.PATH_RZTDL + "/rzt_persist/")
        persist_network.persist_training(epoch=2, learning_rate=0.01,
                                         train_data={'input_layer': self.classification_train_data,
                                                     'output_layer': self.classification_train_label},
                                         valid_data={'input_layer': self.classification_valid_data,
                                                     'output_layer': self.classification_valid_label},
                                         test_data={'input_layer': self.classification_test_data,
                                                    'output_layer': self.classification_test_label},
                                         display_step=1,
                                         load_path=RZTDL_CONFIG.CommonConfig.PATH_RZTDL + "/rzt_persist/",
                                         save_path=RZTDL_CONFIG.CommonConfig.PATH_RZTDL + "/rzt_persist/")
        persist_network.persist_training(epoch=1, learning_rate=0.01,
                                         train_data={'input_layer': self.classification_train_data,
                                                     'output_layer': self.classification_train_label},
                                         valid_data={'input_layer': self.classification_valid_data,
                                                     'output_layer': self.classification_valid_label},
                                         test_data={'input_layer': self.classification_test_data,
                                                    'output_layer': self.classification_test_label},
                                         display_step=1,
                                         load_path=RZTDL_CONFIG.CommonConfig.PATH_RZTDL + "/rzt_persist/",
                                         save_path=RZTDL_CONFIG.CommonConfig.PATH_RZTDL + "/rzt_persist/")
        prediction = rztdl.dl.Prediction('test_two_persist_network',
                                         model_save_path=RZTDL_CONFIG.CommonConfig.PATH_RZTDL + "/rzt_persist/")
        prediction.predict(layer_name='output_layer',
                           data={'input_layer': self.classification_train_data}, batches=2)

    def test_saving_persist_model_in_different_location(self):
        """
        | **@author:** Umesh Kumar
        |
        | Persist Training - Testing network train and persist training and saving in different path
        :return:
        """
        persist_model = rztdl.dl.Model("saving_persist_model")
        persist_model.add_layer(
            rztdl.dl.layer.InputLayer("input_layer", layer_nodes=len(self.classification_train_data[0])))
        persist_model.add_layer(rztdl.dl.layer.OutputLayer(name="output_layer",
                                                           layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                                           layer_nodes=len(self.classification_train_label[0]),
                                                           layer_input="input_layer"))
        persist_model.close()
        network = rztdl.dl.Network("saving_persist_network")
        network.train(epoch=1, learning_rate=0.01, model=persist_model,
                      cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
                      optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
                      train_data={'input_layer': self.classification_train_data,
                                  'output_layer': self.classification_train_label},
                      valid_data={'input_layer': self.classification_valid_data,
                                  'output_layer': self.classification_valid_label},
                      test_data={'input_layer': self.classification_test_data,
                                 'output_layer': self.classification_test_label}, sess=None,
                      display_step=1, train_batch_size=1, regularisation=True,
                      regularisation_params=rztdl.dl.constants.REGULARISATION.regularisation(
                          regularisation_type=rztdl.dl.constants.REGULARISATION.L2_REGULARISATION,
                          beta=0.01))
        network.persist_training(epoch=1, learning_rate=0.01,
                                 train_data={'input_layer': self.classification_train_data,
                                             'output_layer': self.classification_train_label},
                                 valid_data={'input_layer': self.classification_valid_data,
                                             'output_layer': self.classification_valid_label},
                                 test_data={'input_layer': self.classification_test_data,
                                            'output_layer': self.classification_test_label},
                                 display_step=1, save_path=RZTDL_CONFIG.CommonConfig.PATH_RZTDL + "/rzt_persist/")

    def test_persist_training_from_different_file(self):
        """
        | **@author:** Umesh Kumar
        |
        | Testing persist training from different file
        :return:
        """

        network = rztdl.dl.Network("test_network")
        network.persist_training(epoch=1, learning_rate=0.01,
                                 train_data={'input_layer': self.multivariate_train_data,
                                             'output_layer': self.multivariate_train_label},
                                 valid_data={'input_layer': self.multivariate_valid_data,
                                             'output_layer': self.multivariate_valid_label},
                                 test_data={'input_layer': self.multivariate_test_data,
                                            'output_layer': self.multivariate_test_label},
                                 display_step=1)
        prediction = rztdl.dl.Prediction("test_network")
        prediction.predict(layer_name="output_layer", data={"input_layer": self.multivariate_train_data})

    def test_persist_training_train_op(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Persist Training Cost and Optimizer - Build Model from saves

        """
        metadata, model_save_path = self.network._persist_training_validation(RZTDL_CONFIG.CommonConfig.PATH_RZTDL,
                                                                              run_id=1)
        persist_cost, persist_optimizer = self.network._persist_training_train_op(metadata)
        cost = metadata[ModelMetaConstant.COST]
        optimizer = \
            tf.get_collection(metadata[ModelMetaConstant.TRAIN_OP][ModelMetaConstant.TRAIN_OP_OPTIONS.OPTIMIZER])[0]
        assert_equal(persist_cost, cost)
        assert_equal(persist_optimizer, optimizer)

    def test_type_of_regularisation(self):
        """
        | **@author:** Umesh Kumar
        |
        | Tests type of the Regularisation applied, value of the regularisation constant of the model.
        :return:
        """
        regularisation_model = rztdl.dl.Model("regularisation_model")
        regularisation_model.add_layer(
            rztdl.dl.layer.InputLayer("input_layer", layer_nodes=len(self.multivariate_train_data[0])))
        regularisation_model.add_layer(rztdl.dl.layer.OutputLayer(name="output_layer",
                                                                  layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                                                  layer_nodes=len(self.multivariate_train_label[0]),
                                                                  layer_input="input_layer"))
        regularisation_model.close()
        test_regularisation = rztdl.dl.Network(name="test_regularisation")
        test_regularisation.train(epoch=1, learning_rate=0.01, model=regularisation_model,
                                  cost=rztdl.dl.constants.CostType.MEAN_SQUARE_ERROR,
                                  optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
                                  train_data={'input_layer': self.multivariate_train_data,
                                              'output_layer': self.multivariate_train_label},
                                  valid_data={'input_layer': self.multivariate_valid_data,
                                              'output_layer': self.multivariate_valid_label},
                                  test_data={'input_layer': self.multivariate_test_data,
                                             'output_layer': self.multivariate_test_label}, sess=None,
                                  display_step=1, train_batch_size=1, regularisation=True,
                                  regularisation_params=constants.REGULARISATION.regularisation(
                                      regularisation_type=constants.REGULARISATION.L2_REGULARISATION,
                                      beta=0.01))
        assert_equal(test_regularisation.regularisation, True)
        assert_equal(test_regularisation.regularisation_params[constants.PARAMETERS.REGULARISATION_TYPE],
                     constants.REGULARISATION.L2_REGULARISATION)
        assert_equal(test_regularisation.regularisation_params[constants.PARAMETERS.REGULARISATION_BETA], 0.01)

    def test_network_parameters(self):
        """
        | **@author:** Umesh Kumar
        |
        | Testing parameters of the Network module. Tests whether the functionality of each parameter is same as we assumed or not

        """
        epoch = 5
        learning_rate = 0.01
        cost = rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY
        accuracy = rztdl.dl.constants.ACCURACY.SOFTMAX
        optimizer = rztdl.dl.constants.OptimizerTypes.ADAM
        display_step = 2
        train_batch_size = 1
        train_batches = 1
        valid_batches = 1
        valid_batch_size = 1
        threshold = 0.5
        test_batches = 1
        test_batch_size = 1
        batch_display_step = 2
        tf_tracing = True
        stop_criteria_func = stop_criteria_fn
        save_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL + "/rztdl_test_cases/"
        test_network = rztdl.dl.Network("test_parameters")
        train_data = {'input_layer': self.multivariate_train_data,
                      'output_layer': self.multivariate_train_label}
        valid_data = {'input_layer': self.multivariate_valid_data,
                      'output_layer': self.multivariate_valid_label}
        test_data = {'input_layer': self.multivariate_test_data,
                     'output_layer': self.multivariate_test_label}
        test_network.train(epoch=epoch, learning_rate=learning_rate, model=self.multivariate_model,
                           cost=cost,
                           optimizer=optimizer, init=True, sess=None,
                           train_batches=train_batches, valid_batches=valid_batches, valid_batch_size=valid_batch_size,
                           test_batches=test_batches, test_batch_size=test_batch_size,
                           batch_display_step=batch_display_step, saver=None,
                           tf_tracing=tf_tracing, print_json=False, save_path=save_path,
                           # stop_criteria=None, stop_criteria_fn=stop_criteria_func,
                           train_data=train_data, valid_data=valid_data, test_data=test_data,
                           display_step=display_step, train_batch_size=train_batch_size)
        train_dict, valid_dict, test_dict = test_network._train_validation(train_data=train_data, valid_data=None,
                                                                           test_data=test_data,
                                                                           learning_rate=learning_rate,
                                                                           placeholders=RZTDL_STORE.get_all_placeholders(
                                                                               model_name=self.multivariate_model.name).items(),
                                                                           train_batches=train_batches,
                                                                           train_batch_size=train_batch_size,
                                                                           valid_batches=valid_batches,
                                                                           valid_batch_size=valid_batch_size,
                                                                           test_batches=test_batches,
                                                                           test_batch_size=test_batch_size,
                                                                           save_path=save_path)

    def test_checkpoint_max_to_keep(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Max to keep checkpoint
        """
        RZTDL_CONFIG.TensorflowConfig.CHECKPOINT_MAX_SAVES = 3
        RZTDL_CONFIG.TensorflowConfig.CHECKPOINT_EPOCH = 1
        self.network.train(epoch=3, learning_rate=0.01, model=self.multivariate_model,
                           cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
                           optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
                           train_data={'input_layer': self.multivariate_train_data,
                                       'output_layer': self.multivariate_train_label},
                           valid_data={'input_layer': self.multivariate_valid_data,
                                       'output_layer': self.multivariate_valid_label},
                           test_data={'input_layer': self.multivariate_test_data,
                                      'output_layer': self.multivariate_test_label})
        assert len(
            glob.glob(
                self.network.get_network_save_path() + '/' + RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_DL + '/*.meta')) == 3

    def test_checkpoint_n_epochs(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Max to keep checkpoint
        """
        RZTDL_CONFIG.TensorflowConfig.CHECKPOINT_MAX_SAVES = 5
        RZTDL_CONFIG.TensorflowConfig.CHECKPOINT_EPOCH = 2
        self.network.train(epoch=4, learning_rate=0.01, model=self.multivariate_model,
                           cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
                           optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
                           train_data={'input_layer': self.multivariate_train_data,
                                       'output_layer': self.multivariate_train_label},
                           valid_data={'input_layer': self.multivariate_valid_data,
                                       'output_layer': self.multivariate_valid_label},
                           test_data={'input_layer': self.multivariate_test_data,
                                      'output_layer': self.multivariate_test_label})
        assert len(
            glob.glob(
                self.network.get_network_save_path() + '/' + RZTDL_CONFIG.CommonConfig.PATH_MODEL_SAVE_DL + '/*.meta')) == 2

    def test_tapped_network(self):
        """
        | **@author:** Umesh Kumar
        |
        | Testing tapped network
        :return:
        """
        model = rztdl.dl.Model("tapped_model")
        model.add_layer(
            rztdl.dl.layer.InputLayer("input_layer", layer_nodes=len(self.classification_train_data[0])))
        model.add_layer(
            rztdl.dl.layer.FullyConnectedLayer(name="ffn1", layer_activation=constants.ActivationType.RELU, layer_nodes=3,
                                               layer_input="input_layer"))
        model.add_layer(rztdl.dl.layer.OutputLayer(name="output_layer",
                                                   layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                                   layer_nodes=len(self.classification_train_label[0]),
                                                   layer_input="ffn1"))
        model.close()
        network = rztdl.dl.Network("test_tapped_network")
        network.train(epoch=1, learning_rate=0.01, model=model,
                      cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
                      optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
                      train_data={'input_layer': self.classification_train_data,
                                  'output_layer': self.classification_train_label},
                      valid_data={'input_layer': self.classification_valid_data,
                                  'output_layer': self.classification_valid_label},
                      test_data={'input_layer': self.classification_test_data,
                                 'output_layer': self.classification_test_label},
                      display_step=1, train_batch_size=1)
        ffn1_train_data_tap, ffn1_valid_data_tap, ffn1_test_data_tap = read_network(
            network_name='test_tapped_network.ffn1',
            layer_data={'input_layer': np.concatenate(
                [self.classification_train_data, self.classification_valid_data, self.classification_test_data])},
            split_ratio=[60, 20, 20], output_label=False)

        model = rztdl.dl.Model('ffn_tapped_model')
        model.add_layer(rztdl.dl.layer.InputLayer("input_layer", layer_nodes=len(self.classification_train_data[0])))
        model.add_layer(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1", layer_nodes=3,
                                                           layer_activation=rztdl.dl.constants.ActivationType.RELU))
        # Hidden Layer 1 Tapping
        model.add_layer(
            rztdl.dl.layer.InputLayer("hidden_layer_1_tap", layer_nodes=len(self.classification_train_data[0])))
        model.add_operator(
            rztdl.dl.operator.ConcatOperator(name='concat_tap',
                                             operator_input=['hidden_layer_1', 'hidden_layer_1_tap'],
                                             operator_output='concat_out', dimension=1))
        model.add_layer(rztdl.dl.layer.OutputLayer(name="output_layer",
                                                   layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                                   layer_nodes=len(self.classification_train_label[0]),
                                                   layer_input='concat_out'))
        model.close()
        network = rztdl.dl.Network('tapped_network')
        network.train(epoch=1, learning_rate=0.001, model=model, cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
                      optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
                      train_data={'input_layer': self.classification_train_data,
                                  'output_layer': self.classification_train_label,
                                  'hidden_layer_1_tap': ffn1_train_data_tap},
                      valid_data={'input_layer': self.classification_valid_data,
                                  'output_layer': self.classification_valid_label,
                                  'hidden_layer_1_tap': ffn1_valid_data_tap},
                      test_data={'input_layer': self.classification_test_data,
                                 'output_layer': self.classification_test_label,
                                 'hidden_layer_1_tap': ffn1_test_data_tap},
                      display_step=1)
