# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import rztdl.dl
from rztdl.utils.dl_exception import ActivationError, RangeError
from nose.tools import *
import tensorflow as tf
from nose import with_setup  # optional


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    pass


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    pass


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestActivationLayer:
    """
    | **@author:** Himaprasoon P T
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        pass

    def setup(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Runs before a new method in the class is called
        """

        pass

    def teardown(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Runs after each method is called
        """

        pass

    @classmethod
    def setup_class(cls):
        print("*********Activation  Layer Test Case . . .*********")
        cls.model_name = 'test_activation_layer_model'
        cls.model = rztdl.dl.Model(cls.model_name)
        cls.input_layer = rztdl.dl.dl_layer.InputLayer(name='inp_layer', layer_nodes=3)
        cls.model.add_layer(cls.input_layer)

    @classmethod
    def teardown_class(cls):
        print("*********Activation Test Case completed successfully . . .*********")

    def test_name_validation(self):
        false_names = ['dl_layer 1', 'dl_layer .', '%dl_layer']
        for name in false_names:
            try:
                rztdl.dl.dl_layer.ActivationLayer(name=name)
                raise Exception('Invalid name validated . . .')
            except NameError:
                pass

    def test_create_layer(self):
        temp_layer = rztdl.dl.dl_layer.ActivationLayer(name='ac_layer').create_layer(model_name=self.model_name,
                                                                                     layer=self.input_layer,
                                                                                     layer_id=2)
        # Test TF Collection Insertion
        assert len(tf.get_collection(temp_layer.layer_output.name)) == 1

        # Test Dropout
        temp_layer = rztdl.dl.dl_layer.ActivationLayer(name='ac_layer_dp', layer_dropout=0.5).create_layer(
            model_name=self.model_name,
            layer=self.input_layer, layer_id=2)
        assert '/dropout/' in temp_layer.layer_output.name

        temp_layer = rztdl.dl.dl_layer.ActivationLayer(name='ac_layer_manual',
                                                       layer_activation=rztdl.dl.constants.ACTIVATION.RELU).create_layer(
            model_name=self.model_name,
            layer=self.input_layer, layer_id=2)

        assert 'Relu' in temp_layer.layer_output.name

        self.model.add_layer(
            rztdl.dl.dl_layer.ActivationLayer('test_fc_layer_input_tensor', layer_input=self.input_layer.layer_output))
        # Test String as Layer Input
        self.model.add_layer(
            rztdl.dl.dl_layer.ActivationLayer('test_fc_layer_input_str', layer_input='test_fc_layer_input_tensor'))

    @raises(ActivationError)
    def test_activation_error(self):
        rztdl.dl.dl_layer.ActivationLayer(name='layer_act_test', layer_activation='abcd').create_layer(
            model_name=self.model_name,
            layer=self.input_layer, layer_id=2)

    @raises(RangeError)
    def test_dropout_neg_range_error(self):
        rztdl.dl.dl_layer.ActivationLayer(name='activation_layer_dropout_test', layer_dropout=-0.2).create_layer(
            model_name=self.model_name,
            layer=self.input_layer, layer_id=2)

    @raises(RangeError)
    def test_dropout_pos_range_error(self):
        rztdl.dl.dl_layer.ActivationLayer(name='activation_layer_dropout_test', layer_dropout=1.2).create_layer(
            model_name=self.model_name,
            layer=self.input_layer, layer_id=2)
