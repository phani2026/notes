# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import copy

import rztdl.dl
from rztdl.utils.dl_exception import LayerException
import tensorflow as tf
from nose import with_setup  # optional


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    pass


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    pass


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestBatchNormalisationLayer:
    """
    | **@author:** Umesh Kumar
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        self.batch_norm_layer_name = None
        pass

    def setup(self):
        """
        | **@author:** Umesh Kumar
        |
        | Runs before a new method in the class is called
        """

        pass

    def teardown(self):
        """
        | **@author:** Umesh Kumar
        |
        | Runs after each method is called
        """

        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Umesh Kumar
        |
        | Runs during class initialization
        """
        print("*********Batch Normalisation Layer Test Case . . .*********")
        cls.model_name = 'test_batch_norma_layer_model'
        cls.model = rztdl.dl.Model(cls.model_name)
        cls.input_layer = rztdl.dl.dl_layer.InputLayer(name='inp_layer', layer_nodes=2).create_layer(cls.model_name, '',
                                                                                                     1)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        print("*********Batch Normalisation Layer Test Case completed successfully . . .*********")

    def test_name_validation(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests Sample Method
        """
        false_names = ['dl_layer 1', 'dl_layer .', '%dl_layer']
        for name in false_names:
            try:
                rztdl.dl.dl_layer.BatchNormalisationLayer(name=name)
                raise Exception('Invalid name validated . . .')
            except NameError:
                pass

    def test_create_layer(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Create Layer
        :return:
        """
        temp_layer = rztdl.dl.dl_layer.BatchNormalisationLayer(name='batch_norm_layer').create_layer(
            model_name=self.model_name,
            layer=self.input_layer,
            layer_id=2)

        # Test TF Collection Insertion
        assert len(tf.get_collection(temp_layer.layer_output.name)) == 1

        # Test DAG Insertion
        self.model.add_layer(rztdl.dl.dl_layer.InputLayer('in_l', layer_nodes=4))
        self.model.add_layer(rztdl.dl.dl_layer.BatchNormalisationLayer('test_batch_norm_layer_ins'))

        # Test Tensor as Layer Input
        self.model.add_layer(
            rztdl.dl.dl_layer.BatchNormalisationLayer('test_batch_norm_layer_input_tensor',
                                                      layer_input=self.input_layer.layer_output))
        # Test String as Layer Input
        self.model.add_layer(
            rztdl.dl.dl_layer.BatchNormalisationLayer('test_batch_norm_layer_input_str',
                                                      layer_input='in_l'))

    def test_layer_exception(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Exception
        :return:
        """
        this_ip_layer = copy.copy(self.input_layer)
        this_ip_layer.layer_nodes = 0

        try:
            rztdl.dl.dl_layer.BatchNormalisationLayer(name='batch_norm_layer_excep_test').create_layer(
                model_name=self.model_name,
                layer=this_ip_layer, layer_id=2)
            assert False
        except LayerException:
            assert True

        this_ip_layer.layer_output = None
        try:
            rztdl.dl.dl_layer.BatchNormalisationLayer(name='batch_norm_layer_excep_test').create_layer(
                model_name=self.model_name,
                layer=this_ip_layer, layer_id=2)
            assert False
        except LayerException:
            assert True
