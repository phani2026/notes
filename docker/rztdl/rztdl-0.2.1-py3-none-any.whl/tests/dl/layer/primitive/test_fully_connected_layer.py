# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import copy
import numpy as np
import rztdl.dl
from rztdl import RZTDL_DAG, RZTDL_CONFIG
from rztdl.utils.dl_exception import LayerException, NormalizationError, ParameterError, RangeError, ActivationError, \
    DimensionError
from nose.tools import *
import tensorflow as tf
from nose import with_setup  # optional


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    pass


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    pass


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestFullyConnectedLayer:
    """
    | **@author:** Prathyush SP
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        self.fc_layer_name = None
        pass

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method in the class is called
        """

        pass

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """

        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        print("*********Fully Connected Layer Test Case . . .*********")
        cls.model_name = 'test_fully_connected_layer_model'
        cls.model = rztdl.dl.Model(cls.model_name)
        cls.input_layer = rztdl.dl.dl_layer.InputLayer(name='inp_layer', layer_nodes=2).create_layer(cls.model_name, '',
                                                                                                     1)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        print("*********Fully Connected Layer Test Case completed successfully . . .*********")

    def test_name_validation(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests Sample Method
        """
        false_names = ['dl_layer 1', 'dl_layer .', '%dl_layer']
        for name in false_names:
            try:
                rztdl.dl.dl_layer.FullyConnectedLayer(name=name, layer_nodes=10)
                raise Exception('Invalid name validated . . .')
            except NameError:
                pass

    def test_create_layer(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Create Layer
        :return:
        """
        temp_layer = rztdl.dl.dl_layer.FullyConnectedLayer(name='fc_layer').create_layer(model_name=self.model_name,
                                                                                         layer=self.input_layer,
                                                                                         layer_id=2)

        # Test TF Collection Insertion
        assert len(tf.get_collection(temp_layer.layer_output.name)) == 1

        # Test Dropout
        temp_layer = rztdl.dl.dl_layer.FullyConnectedLayer(name='fc_layer_dp', layer_dropout=0.5).create_layer(
            model_name=self.model_name,
            layer=self.input_layer, layer_id=2)
        assert '/dropout/' in temp_layer.layer_output.name

        # Test Normalization
        temp_layer = rztdl.dl.dl_layer.FullyConnectedLayer(name='fc_layer_norm',
                                                           norm_type=rztdl.dl.constants.NORMALIZATION.L2_NORM,
                                                           norm_parameters=rztdl.dl.constants.NORMALIZATION.l2_norm(
                                                            dim=0,
                                                            epsilon=1e-12)
                                                           ).create_layer(model_name=self.model_name,
                                                                       layer=self.input_layer, layer_id=2)
        assert '/l2_norm' in temp_layer.layer_output.name

        # todo: Prathyush SP - Test if scalar summary is being created - No easy way in v1.1
        # Test Layer Weights and Bias

        # Auto Generated:
        assert 'fc_layer_norm/weights/Variable:0' in temp_layer.layer_weights.__str__()
        assert 'fc_layer_norm/biases/Variable:0' in temp_layer.layer_bias.__str__()

        # Complete Manual Given
        temp_layer = rztdl.dl.dl_layer.FullyConnectedLayer(name='fc_layer_weights_manual',
                                                           layer_weights=np.array([[1.0, 1.0], [1.0, 3.0]],
                                                                               dtype=np.float32),
                                                           layer_bias=np.array([[1.0], [2.1]],
                                                                            dtype=np.float32),
                                                           layer_nodes=2).create_layer(model_name=self.model_name,
                                                                                    layer=self.input_layer, layer_id=2)
        assert "<tf.Variable 'fc_layer_weights_manual/weights/Variable:0' shape=(2, 2) dtype=float32_ref>" == temp_layer.layer_weights.__str__()
        assert "<tf.Variable 'fc_layer_weights_manual/biases/Variable:0' shape=(2, 1) dtype=float32_ref>" == temp_layer.layer_bias.__str__()

        # Semi Automated
        temp_layer = rztdl.dl.dl_layer.FullyConnectedLayer(name='fc_layer_weights_semi',
                                                           layer_weights=rztdl.dl.constants.INITIALIZER.random_normal(),
                                                           layer_bias=rztdl.dl.constants.INITIALIZER.zeros(),
                                                           layer_nodes=2).create_layer(model_name=self.model_name,
                                                                                    layer=self.input_layer, layer_id=2)
        assert 'Tensor("fc_layer_weights_semi/weights/random_normal:0", shape=(2, 2), dtype=float32)' == str(
            temp_layer.layer_weights.initial_value)
        assert 'Tensor("fc_layer_weights_semi/biases/zeros:0", shape=(2,), dtype=float32)' == str(
            temp_layer.layer_bias.initial_value)

        # Test Tensorflow Collection
        assert len(tf.get_collection(temp_layer.layer_weights.name)) == 1
        assert len(tf.get_collection(temp_layer.layer_bias.name)) == 1

        # Test DAG Insertion
        self.model.add_layer(rztdl.dl.dl_layer.InputLayer('in_l', layer_nodes=4))
        self.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer('test_fc_layer_ins'))
        RZTDL_DAG.get_weights(model_name=self.model_name, layer_name='test_fc_layer_ins')
        RZTDL_DAG.get_bias(model_name=self.model_name, layer_name='test_fc_layer_ins')

        # Test Layer Activation
        temp_layer = rztdl.dl.dl_layer.FullyConnectedLayer(name='fc_layer_activation_test',
                                                           layer_activation=rztdl.dl.constants.ACTIVATION.SOFT_SIGN,
                                                           layer_nodes=2).create_layer(model_name=self.model_name,
                                                                                    layer=self.input_layer, layer_id=2)
        assert 'Softsign' in temp_layer.layer_output.name

        # Test Auto Tensor Conversion
        self.model.add_layer(rztdl.dl.dl_layer.InputLayer("input_layer4d", layer_nodes=729))
        self.model.add_layer(
            rztdl.dl.dl_layer.ConvolutionLayer('con1', layer_activation=rztdl.dl.constants.ACTIVATION.RELU,
                                               filter_dimensions=[5, 5, 1, 32], filter_strides=[1, 1, 1, 1],
                                               filter_padding=rztdl.dl.constants.PADDING.SAME))
        RZTDL_CONFIG.TensorflowConfig.AUTO_TENSOR_CONVERSION = False
        try:
            self.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer('fc_layer_dim_test'))
            assert False
        except DimensionError:
            assert True
        RZTDL_CONFIG.TensorflowConfig.AUTO_TENSOR_CONVERSION = True
        self.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer('fc_layer_dim_test_1', layer_input='con1'))

        # Test Layer Input
        # Test Tensor as Layer Input
        self.model.add_layer(
            rztdl.dl.dl_layer.FullyConnectedLayer('test_fc_layer_input_tensor', layer_input=self.input_layer.layer_output))
        # Test String as Layer Input
        self.model.add_layer(
            rztdl.dl.dl_layer.FullyConnectedLayer('test_fc_layer_input_str', layer_input='fc_layer_dim_test_1'))

    @raises(ActivationError)
    def test_activation_error(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Activation
        :return:
        """
        rztdl.dl.dl_layer.FullyConnectedLayer(name='fc_layer_act_test', layer_activation='abcd').create_layer(
            model_name=self.model_name,
            layer=self.input_layer, layer_id=2)

    def test_dropout_range_error(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Dropout
        :return:
        """
        try:
            rztdl.dl.dl_layer.FullyConnectedLayer(name='fc_layer_dropout_test', layer_dropout=-0.2).create_layer(
                model_name=self.model_name,
                layer=self.input_layer, layer_id=2)
            assert False
        except RangeError:
            assert True
        try:
            rztdl.dl.dl_layer.FullyConnectedLayer(name='fc_layer_dropout_test', layer_dropout=1.2).create_layer(
                model_name=self.model_name,
                layer=self.input_layer, layer_id=2)
            assert False
        except RangeError:
            assert True

    def test_normalization_error(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Normalization
        :return:
        """
        try:
            rztdl.dl.dl_layer.FullyConnectedLayer(name='fc_layer_norm_test', norm_type='a',
                                                  norm_parameters={}).create_layer(
                model_name=self.model_name,
                layer=self.input_layer, layer_id=2)
            assert False
        except NormalizationError:
            assert True
        try:
            rztdl.dl.dl_layer.FullyConnectedLayer(name='fc_layer_norm_test',
                                                  norm_type=rztdl.dl.constants.NORMALIZATION.L2_NORM,
                                                  norm_parameters={'a': 1}).create_layer(
                model_name=self.model_name,
                layer=self.input_layer, layer_id=2)
            assert False
        except ParameterError:
            assert True

    def test_layer_exception(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Exception
        :return:
        """
        this_ip_layer = copy.copy(self.input_layer)
        this_ip_layer.layer_nodes = 0

        try:
            rztdl.dl.dl_layer.FullyConnectedLayer(name='fc_layer_excep_test').create_layer(model_name=self.model_name,
                                                                                           layer=this_ip_layer, layer_id=2)
            assert False
        except LayerException:
            assert True

        this_ip_layer.layer_output = None
        try:
            rztdl.dl.dl_layer.FullyConnectedLayer(name='fc_layer_excep_test').create_layer(model_name=self.model_name,
                                                                                           layer=this_ip_layer, layer_id=2)
            assert False
        except LayerException:
            assert True
