# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import copy

import rztdl.dl
from rztdl.utils.dl_exception import LayerException, NormalizationError, ParameterError, RangeError
import tensorflow as tf
from nose import with_setup  # optional


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    pass


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    pass


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestPoolLayer:
    """
    | **@author:** Prathyush SP
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        self.fc_layer_name = None
        pass

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method in the class is called
        """
        pass

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        print("*********Pool Layer Test Case . . .*********")
        cls.model_name = 'test_pool_connected_layer_model'
        cls.model = rztdl.dl.Model(cls.model_name)
        cls.input_layer = rztdl.dl.dl_layer.InputLayer(name='inp_layer', layer_shape=[1, 2, 2, 1]).create_layer(
            cls.model_name, '',
            1)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        print("*********Pool Layer Test Case completed successfully . . .*********")

    def test_name_validation(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests Sample Method
        """
        false_names = ['dl_layer 1', 'dl_layer .', '%dl_layer']
        for name in false_names:
            try:
                rztdl.dl.dl_layer.PoolLayer(name=name,
                                            pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                            pool_padding=rztdl.dl.constants.PADDING.SAME,
                                            pool_type=rztdl.dl.constants.POOL.MAX_POOL,
                                            )
                raise Exception('Invalid name validated . . .')
            except NameError:
                pass

    def test_create_layer(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Create Layer
        :return:
        """
        temp_layer = rztdl.dl.dl_layer.PoolLayer(name='pool_layer',
                                                 pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                                 pool_padding=rztdl.dl.constants.PADDING.SAME,
                                                 pool_type=rztdl.dl.constants.POOL.MAX_POOL,
                                                 ).create_layer(model_name=self.model_name,
                                                             layer=self.input_layer,
                                                             layer_id=2)

        # Test TF Collection Insertion
        assert len(tf.get_collection(temp_layer.layer_output.name)) == 1

        # Test Dropout
        temp_layer = rztdl.dl.dl_layer.PoolLayer(name='pool_layer_dp',
                                                 pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                                 pool_padding=rztdl.dl.constants.PADDING.SAME,
                                                 layer_dropout=0.5).create_layer(
            model_name=self.model_name,
            layer=self.input_layer, layer_id=2)
        assert '/dropout/' in temp_layer.layer_output.name

        # Test Normalization
        temp_layer = rztdl.dl.dl_layer.PoolLayer(name='pool_layer_norm_l2',
                                                 pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                                 pool_padding=rztdl.dl.constants.PADDING.SAME,
                                                 norm_type=rztdl.dl.constants.NORMALIZATION.L2_NORM,
                                                 norm_parameters=rztdl.dl.constants.NORMALIZATION.l2_norm(
                                                  dim=0,
                                                  epsilon=1e-12)
                                                 ).create_layer(model_name=self.model_name,
                                                             layer=self.input_layer, layer_id=2)
        assert '/l2_norm' in temp_layer.layer_output.name

        temp_layer = rztdl.dl.dl_layer.PoolLayer(name='pool_layer_norm_lrn',
                                                 pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                                 pool_padding=rztdl.dl.constants.PADDING.SAME,
                                                 norm_type=rztdl.dl.constants.NORMALIZATION.LRN_NORM,
                                                 norm_parameters=rztdl.dl.constants.NORMALIZATION.lrn_norm()
                                                 ).create_layer(model_name=self.model_name,
                                                             layer=self.input_layer, layer_id=2)
        assert '/lrn' in temp_layer.layer_output.name

        # todo: Prathyush SP - Test if scalar summary is being created - No easy way in v1.1

        # Test Layer Input
        # Test Tensor as Layer Input
        self.model.add_layer(rztdl.dl.dl_layer.InputLayer(name='samp_layer', layer_shape=[1, 2, 2, 1]))
        self.model.add_layer(
            rztdl.dl.dl_layer.PoolLayer('test_pool_layer_input_tensor',
                                        pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                        pool_padding=rztdl.dl.constants.PADDING.SAME,
                                        layer_input=self.input_layer.layer_output))
        # Test String as Layer Input
        self.model.add_layer(rztdl.dl.dl_layer.PoolLayer('test_pool_layer_input_tensor1',
                                                         pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                                         pool_padding=rztdl.dl.constants.PADDING.SAME,
                                                         layer_input='samp_layer'))

    def test_dropout_range_error(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Dropout
        :return:
        """
        try:
            rztdl.dl.dl_layer.PoolLayer(name='pool_layer_drop_test', pool_dimensions=[1, 2, 2, 1],
                                        pool_strides=[1, 2, 2, 1],
                                        pool_padding=rztdl.dl.constants.PADDING.SAME,
                                        layer_dropout=-0.12).create_layer(model_name=self.model_name,
                                                                       layer=self.input_layer, layer_id=2)
            assert False
        except RangeError:
            assert True
        try:
            rztdl.dl.dl_layer.PoolLayer(name='pool_layer_drop_test', pool_dimensions=[1, 2, 2, 1],
                                        pool_strides=[1, 2, 2, 1],
                                        pool_padding=rztdl.dl.constants.PADDING.SAME,
                                        layer_dropout=1.2).create_layer(model_name=self.model_name,
                                                                     layer=self.input_layer, layer_id=2)
            assert False
        except RangeError:
            assert True

    def test_normalization_error(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Normalization
        :return:
        """
        try:
            rztdl.dl.dl_layer.PoolLayer(name='pool_layer_norm_test', norm_type='a', norm_parameters={},
                                        pool_dimensions=[1, 2, 2, 1],
                                        pool_strides=[1, 2, 2, 1],
                                        pool_padding=rztdl.dl.constants.PADDING.SAME,
                                        ).create_layer(
                model_name=self.model_name,
                layer=self.input_layer, layer_id=2)
            assert False
        except NormalizationError:
            assert True
        try:
            rztdl.dl.dl_layer.PoolLayer(name='pool_layer_norm_test', norm_type=rztdl.dl.constants.NORMALIZATION.LRN_NORM,
                                        norm_parameters={},
                                        pool_dimensions=[1, 2, 2, 1],
                                        pool_strides=[1, 2, 2, 1],
                                        pool_padding=rztdl.dl.constants.PADDING.SAME,
                                        ).create_layer(
                model_name=self.model_name,
                layer=self.input_layer, layer_id=2)
            assert False
        except ParameterError:
            assert True

    def test_layer_exception(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Exception
        :return:
        """
        this_ip_layer = copy.copy(self.input_layer)
        this_ip_layer.layer_nodes = 0

        try:
            rztdl.dl.dl_layer.PoolLayer(name='pool_layer_exep_test',
                                        pool_dimensions=[1, 2, 2, 1],
                                        pool_strides=[1, 2, 2, 1],
                                        pool_padding=rztdl.dl.constants.PADDING.SAME,
                                        ).create_layer(model_name=self.model_name, layer=this_ip_layer, layer_id=2)
            assert False
        except LayerException:
            assert True

        this_ip_layer.layer_output = None
        try:
            rztdl.dl.dl_layer.PoolLayer(name='pool_layer_exep_test',
                                        pool_dimensions=[1, 2, 2, 1],
                                        pool_strides=[1, 2, 2, 1],
                                        pool_padding=rztdl.dl.constants.PADDING.SAME,
                                        ).create_layer(model_name=self.model_name, layer=this_ip_layer, layer_id=2)
            assert False
        except LayerException:
            assert True
