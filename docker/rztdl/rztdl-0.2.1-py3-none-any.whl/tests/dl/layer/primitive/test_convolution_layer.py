# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import copy
import rztdl.dl
from rztdl import RZTDL_CONFIG, RZTDL_DAG
from rztdl.utils.dl_exception import LayerException, NormalizationError, ParameterError, RangeError, ActivationError, \
    DimensionError
from nose.tools import *
import numpy as np
import tensorflow as tf
from nose import with_setup  # optional


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    pass


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    pass


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestConvolutionLayer:
    """
    | **@author:** Prathyush SP
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        self.conv_layer_name = None
        pass

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method in the class is called
        """
        pass

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        print("*********Convolution Layer Test Case . . .*********")
        cls.model_name = 'test_conv_layer_model'
        cls.model = rztdl.dl.Model(cls.model_name)
        cls.input_layer = rztdl.dl.dl_layer.InputLayer(name='inp_layer', layer_nodes=729).create_layer(cls.model_name, '',
                                                                                                       1)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        print("*********Convolution Layer Test Case completed successfully . . .*********")

    def test_name_validation(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests Sample Method
        """
        false_names = ['dl_layer 1', 'dl_layer .', '%dl_layer']
        for name in false_names:
            try:
                rztdl.dl.dl_layer.FullyConnectedLayer(name=name, layer_nodes=10)
                raise Exception('Invalid name validated . . .')
            except NameError:
                pass

    def test_create_layer(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Create Layer
        :return:
        """
        temp_layer = rztdl.dl.dl_layer.ConvolutionLayer(name='conv_layer', filter_dimensions=[5, 5, 1, 32],
                                                        filter_strides=[1, 1, 1, 1],
                                                        filter_padding=rztdl.dl.constants.PADDING.SAME).create_layer(
            model_name=self.model_name,
            layer=self.input_layer,
            layer_id=2)

        # Test TF Collection Insertion
        assert len(tf.get_collection(temp_layer.layer_output.name)) == 1

        # Test Dropout
        temp_layer = rztdl.dl.dl_layer.ConvolutionLayer(name='conv_layer_dp', filter_dimensions=[5, 5, 1, 32],
                                                        filter_strides=[1, 1, 1, 1],
                                                        filter_padding=rztdl.dl.constants.PADDING.SAME,
                                                        layer_dropout=0.5).create_layer(
            model_name=self.model_name,
            layer=self.input_layer, layer_id=2)
        assert '/dropout/' in temp_layer.layer_output.name
        #
        # Test Normalization
        temp_layer = rztdl.dl.dl_layer.ConvolutionLayer(name='conv_layer_norm',
                                                        filter_dimensions=[5, 5, 1, 32],
                                                        filter_strides=[1, 1, 1, 1],
                                                        filter_padding=rztdl.dl.constants.PADDING.SAME,
                                                        norm_type=rztdl.dl.constants.NORMALIZATION.L2_NORM,
                                                        norm_parameters=rztdl.dl.constants.NORMALIZATION.l2_norm(
                                                         dim=0,
                                                         epsilon=1e-12)
                                                        ).create_layer(model_name=self.model_name,
                                                                    layer=self.input_layer, layer_id=2)
        assert '/l2_norm' in temp_layer.layer_output.name

        temp_layer = rztdl.dl.dl_layer.ConvolutionLayer(name='conv_layer_norm1',
                                                        filter_dimensions=[5, 5, 1, 32],
                                                        filter_strides=[1, 1, 1, 1],
                                                        filter_padding=rztdl.dl.constants.PADDING.SAME,
                                                        norm_type=rztdl.dl.constants.NORMALIZATION.LRN_NORM,
                                                        norm_parameters=rztdl.dl.constants.NORMALIZATION.lrn_norm()
                                                        ).create_layer(model_name=self.model_name,
                                                                    layer=self.input_layer, layer_id=2)
        assert '/lrn' in temp_layer.layer_output.name
        # todo: Prathyush SP - Test if scalar summary is being created - No easy way in v1.1
        # Test Layer Weights and Bias

        # Auto Generated:
        assert 'conv_layer_norm1/filters/Variable:0' in temp_layer.layer_filter.__str__()
        assert 'conv_layer_norm1/biases/Variable:0' in temp_layer.layer_bias.__str__()

        # Complete Manual Given
        temp_layer = rztdl.dl.dl_layer.ConvolutionLayer(name='conv_layer_weights_manual',
                                                        filter_dimensions=[2, 2, 1, 1],
                                                        filter_strides=[1, 1, 1, 1],
                                                        filter_padding=rztdl.dl.constants.PADDING.SAME,
                                                        layer_filter=np.array([[[[1.0, 1.0]], [[1.0, 3.0]]]],
                                                                           dtype=np.float32),
                                                        layer_bias=np.array([1.0, 2.0],
                                                                         dtype=np.float32),
                                                        ).create_layer(model_name=self.model_name,
                                                                    layer=self.input_layer, layer_id=2)
        assert "<tf.Variable 'conv_layer_weights_manual/filters/Variable:0' shape=(1, 2, 1, 2) dtype=float32_ref>" == temp_layer.layer_filter.__str__()
        assert "<tf.Variable 'conv_layer_weights_manual/biases/Variable:0' shape=(2,) dtype=float32_ref>" == temp_layer.layer_bias.__str__()

        # Semi Automated
        temp_layer = rztdl.dl.dl_layer.ConvolutionLayer(name='conv_layer_weights_semi',
                                                        filter_dimensions=[2, 2, 1, 1],
                                                        filter_strides=[1, 1, 1, 1],
                                                        filter_padding=rztdl.dl.constants.PADDING.SAME,
                                                        layer_filter=rztdl.dl.constants.INITIALIZER.ones(),
                                                        layer_bias=rztdl.dl.constants.INITIALIZER.random_uniform()
                                                        ).create_layer(model_name=self.model_name,
                                                                    layer=self.input_layer, layer_id=2)
        assert 'Tensor("conv_layer_weights_semi/filters/ones:0", shape=(2, 2, 1, 1), dtype=float32)' == str(
            temp_layer.layer_filter.initial_value)
        assert 'Tensor("conv_layer_weights_semi/biases/random_uniform:0", shape=(1,), dtype=float32)' == str(
            temp_layer.layer_bias.initial_value)

        # Test Tensorflow Collection
        assert len(tf.get_collection(temp_layer.layer_filter.name)) == 1
        assert len(tf.get_collection(temp_layer.layer_bias.name)) == 1

        # Test DAG Insertion
        # self.model.add_layer(temp_layer)
        self.model.add_layer(rztdl.dl.dl_layer.InputLayer('in_l', layer_nodes=64))
        self.model.add_layer(rztdl.dl.dl_layer.ConvolutionLayer('test_conv_layer_ins',
                                                                filter_dimensions=[2, 2, 1, 1],
                                                                filter_strides=[1, 1, 1, 1],
                                                                filter_padding=rztdl.dl.constants.PADDING.SAME,
                                                                ))
        RZTDL_DAG.get_weights(model_name=self.model_name, layer_name='test_conv_layer_ins')
        RZTDL_DAG.get_bias(model_name=self.model_name, layer_name='test_conv_layer_ins')

        # Test Layer Activation
        temp_layer = rztdl.dl.dl_layer.ConvolutionLayer(name='conv_layer_activation_test',
                                                        layer_activation=rztdl.dl.constants.ACTIVATION.SOFT_SIGN,
                                                        filter_dimensions=[2, 2, 1, 1],
                                                        filter_strides=[1, 1, 1, 1],
                                                        filter_padding=rztdl.dl.constants.PADDING.SAME,
                                                        ).create_layer(model_name=self.model_name,
                                                                    layer=self.input_layer, layer_id=2)
        assert 'Softsign' in temp_layer.layer_output.name

        # Test Auto Tensor Conversion
        self.model.add_layer(rztdl.dl.dl_layer.InputLayer("input_layer2d", layer_nodes=729))
        RZTDL_CONFIG.TensorflowConfig.AUTO_TENSOR_CONVERSION = False
        try:
            self.model.add_layer(rztdl.dl.dl_layer.ConvolutionLayer('conv_layer_dim_test',
                                                                    filter_dimensions=[2, 2, 1, 1],
                                                                    filter_strides=[1, 1, 1, 1],
                                                                    filter_padding=rztdl.dl.constants.PADDING.SAME,
                                                                    ))
            assert False
        except DimensionError:
            assert True
        RZTDL_CONFIG.TensorflowConfig.AUTO_TENSOR_CONVERSION = True
        self.model.add_layer(
            rztdl.dl.dl_layer.ConvolutionLayer('con1', layer_activation=rztdl.dl.constants.ACTIVATION.RELU,
                                               filter_dimensions=[5, 5, 1, 32], filter_strides=[1, 1, 1, 1],
                                               filter_padding=rztdl.dl.constants.PADDING.SAME))

        # Test Layer Input
        # Test Tensor as Layer Input
        self.model.add_layer(
            rztdl.dl.dl_layer.ConvolutionLayer('test_conv_layer_input_tensor',
                                               filter_dimensions=[2, 2, 1, 1],
                                               filter_strides=[1, 1, 1, 1],
                                               filter_padding=rztdl.dl.constants.PADDING.SAME,
                                               layer_input=self.input_layer.layer_output))
        # Test String as Layer Input
        self.model.add_layer(
            rztdl.dl.dl_layer.ConvolutionLayer('test_conv_layer_input_str',
                                               filter_dimensions=[2, 2, 32, 1],
                                               filter_strides=[1, 1, 1, 1],
                                               filter_padding=rztdl.dl.constants.PADDING.SAME,
                                               layer_input='con1'))

    @raises(ActivationError)
    def test_activation_error(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Activation
        :return:
        """
        rztdl.dl.dl_layer.ConvolutionLayer(name='conv_layer_act_test', layer_activation='abcd',
                                           filter_dimensions=[2, 2, 32, 1],
                                           filter_strides=[1, 1, 1, 1],
                                           filter_padding=rztdl.dl.constants.PADDING.SAME,
                                           ).create_layer(model_name=self.model_name, layer=self.input_layer, layer_id=2)

    def test_dropout_range_error(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Dropout
        :return:
        """
        try:
            rztdl.dl.dl_layer.ConvolutionLayer(name='conv_layer_drop_test', layer_dropout=-0.2,
                                               filter_dimensions=[2, 2, 1, 1],
                                               filter_strides=[1, 1, 1, 1],
                                               filter_padding=rztdl.dl.constants.PADDING.SAME,
                                               ).create_layer(model_name=self.model_name, layer=self.input_layer,
                                                           layer_id=2)
            assert False
        except RangeError:
            assert True
        try:
            rztdl.dl.dl_layer.ConvolutionLayer(name='conv_layer_drop_test', layer_dropout=1.2,
                                               filter_dimensions=[2, 2, 1, 1],
                                               filter_strides=[1, 1, 1, 1],
                                               filter_padding=rztdl.dl.constants.PADDING.SAME,
                                               ).create_layer(model_name=self.model_name, layer=self.input_layer,
                                                           layer_id=2)
            assert False
        except RangeError:
            assert True

    def test_normalization_error(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Normalization
        :return:
        """
        try:
            rztdl.dl.dl_layer.ConvolutionLayer(name='conv_layer_norm_test', norm_type='a', norm_parameters={},
                                               filter_dimensions=[2, 2, 1, 1],
                                               filter_strides=[1, 1, 1, 1],
                                               filter_padding=rztdl.dl.constants.PADDING.SAME,
                                               ).create_layer(
                model_name=self.model_name,
                layer=self.input_layer, layer_id=2)
            assert False
        except NormalizationError:
            assert True
        try:
            rztdl.dl.dl_layer.ConvolutionLayer(name='conv_layer_norm_test',
                                               norm_type=rztdl.dl.constants.NORMALIZATION.L2_NORM,
                                               norm_parameters={'a': 1},
                                               filter_dimensions=[2, 2, 1, 1],
                                               filter_strides=[1, 1, 1, 1],
                                               filter_padding=rztdl.dl.constants.PADDING.SAME,
                                               ).create_layer(model_name=self.model_name, layer=self.input_layer,
                                                           layer_id=2)
            assert False
        except ParameterError:
            assert True

    def test_layer_exception(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Exception
        :return:
        """
        this_ip_layer = copy.copy(self.input_layer)
        this_ip_layer.layer_nodes = 0

        try:
            rztdl.dl.dl_layer.ConvolutionLayer(name='conv_layer_exep_test',
                                               norm_type=rztdl.dl.constants.NORMALIZATION.L2_NORM,
                                               norm_parameters={'a': 1},
                                               filter_dimensions=[2, 2, 1, 1],
                                               filter_strides=[1, 1, 1, 1],
                                               filter_padding=rztdl.dl.constants.PADDING.SAME,
                                               ).create_layer(model_name=self.model_name, layer=this_ip_layer, layer_id=2)
            assert False
        except LayerException:
            assert True

        this_ip_layer.layer_output = None
        try:
            rztdl.dl.dl_layer.ConvolutionLayer(name='conv_layer_exep_test',
                                               norm_type=rztdl.dl.constants.NORMALIZATION.L2_NORM,
                                               norm_parameters={'a': 1},
                                               filter_dimensions=[2, 2, 1, 1],
                                               filter_strides=[1, 1, 1, 1],
                                               filter_padding=rztdl.dl.constants.PADDING.SAME,
                                               ).create_layer(model_name=self.model_name, layer=this_ip_layer, layer_id=2)
            assert False
        except LayerException:
            assert True
