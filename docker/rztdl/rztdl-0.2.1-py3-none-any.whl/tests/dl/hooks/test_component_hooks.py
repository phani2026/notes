# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import rztdl.dl
from nose.tools import *
from nose import with_setup  # optional
from rztdl.dl.dl_hooks import component_begin_hook, component_end_hook
from rztdl.utils.dl_exception import HookException
from rztdl import RZTDL_CONFIG
from rztdl.hooks import hooks_manager


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    print('********** Starting {} tests . . . **********'.format(__name__))


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    print('**********  {} tests completed successfully . . . **********'.format(__name__))


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


order = {'component_begin_hook_impl': [], 'component_end_hook_impl': [],
         'component_begin_hook_component_type_condition_impl': [],
         'component_end_hook_component_type_condition_impl': [],
         'component_begin_hook_component_name_condition_impl': [],
         'component_end_hook_component_name_condition_impl': [],
         'component_begin_hook_model_name_condition_impl': [], 'component_end_hook_model_name_condition_impl': []}


class TestLayerHooks:
    """
    | **@author:** Prathyush SP
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        pass

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method in the class is called
        """
        pass

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        RZTDL_CONFIG.CommonConfig.HOOKS_ENABLED = True
        pass

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        RZTDL_CONFIG.CommonConfig.HOOKS_ENABLED = False
        hooks_manager.initialize_hook_store()

    def create_new_model(self, model_name):
        """
        | **@author:** Prathyush SP
        |
        | Create New Model based on model name
        :param model_name: Model Name        
        """
        model = rztdl.dl.Model(model_name)
        model.add_component(rztdl.dl.buffer.InBuffer("input_component", buffer_features=3))
        model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1",
                                                               layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                               component_input='input_component'))
        model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_2",
                                                               layer_activation=rztdl.dl.constants.ActivationType.RELU))
        model.add_component(rztdl.dl.buffer.InBuffer(name="output_component", buffer_features=1))
        model.close()

    @staticmethod
    @component_begin_hook()
    def component_begin_hook_impl(component):
        """
        | **@author:** Prathyush SP
        |
        | Layer Begin Hook
        """
        global order
        order['component_begin_hook_impl'].append(type(component))

    @staticmethod
    @component_end_hook()
    def component_end_hook_impl(component):
        """
        | **@author:** Prathyush SP
        |
        | Layer End Hook
        """
        global order
        order['component_end_hook_impl'].append(type(component))

    @staticmethod
    @component_begin_hook(component_sub_type=rztdl.dl.constants.LayerType.FULLY_CONNECTED_LAYER)
    def component_begin_hook_component_type_condition_impl(component):
        """
        | **@author:** Prathyush SP
        |
        | Layer Begin Hook
        """
        global order
        order['component_begin_hook_component_type_condition_impl'].append(type(component))

    @staticmethod
    @component_end_hook(component_type=rztdl.dl.constants.BufferType.IN_BUFFER)
    def component_end_hook_component_type_condition_impl(component):
        """
        | **@author:** Prathyush SP
        |
        | Layer End Hook
        """
        global order
        order['component_end_hook_component_type_condition_impl'].append(type(component))

    @staticmethod
    @component_begin_hook(component_name='input_component')
    def component_begin_hook_component_name_condition_impl(component):
        """
        | **@author:** Prathyush SP
        |
        | Layer Begin Hook
        """
        global order
        order['component_begin_hook_component_name_condition_impl'].append(type(component))

    @staticmethod
    @component_end_hook(component_name='output_component')
    def component_end_hook_component_name_condition_impl(component):
        """
        | **@author:** Prathyush SP
        |
        | Layer End Hook
        """
        global order
        order['component_end_hook_component_name_condition_impl'].append(type(component))

    @staticmethod
    @component_begin_hook(model_name='unknown_model_1', component_name='input_component')
    def component_begin_hook_model_name_condition_impl(component):
        """
        | **@author:** Prathyush SP
        |
        | Layer Begin Hook
        """
        global order
        order['component_begin_hook_model_name_condition_impl'].append(type(component))

    @staticmethod
    @component_end_hook(model_name='unknown_model_2', component_name='output_component')
    def component_end_hook_model_name_condition_impl(component):
        """
        | **@author:** Prathyush SP
        |
        | Layer End Hook
        """
        global order
        order['component_end_hook_model_name_condition_impl'].append(type(component))

    @staticmethod
    @component_end_hook(component_name='output_component')
    def component_end_hook_model_name_condition_impl(component):
        """
        | **@author:** Prathyush SP
        |
        | Layer End Hook
        """
        raise Exception('Exception Raised')

    @raises(HookException)
    def test_component_begin_and_end_hook(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Begin and End Hook
        :return:
        """
        global order
        self.create_new_model('test_component_begin_and_end_hook')
        assert order['component_begin_hook_impl'] == [rztdl.dl.buffer.InBuffer, rztdl.dl.layer.FullyConnectedLayer,
                                                      rztdl.dl.layer.FullyConnectedLayer, rztdl.dl.buffer.InBuffer]
        assert order['component_end_hook_impl'] == [rztdl.dl.buffer.InBuffer, rztdl.dl.layer.FullyConnectedLayer,
                                                    rztdl.dl.layer.FullyConnectedLayer, rztdl.dl.buffer.InBuffer]
        assert order['component_begin_hook_component_type_condition_impl'] == [rztdl.dl.layer.FullyConnectedLayer,
                                                                               rztdl.dl.layer.FullyConnectedLayer]
        assert order['component_end_hook_component_type_condition_impl'] == [rztdl.dl.buffer.InBuffer]
        assert order['component_begin_hook_component_name_condition_impl'] == [rztdl.dl.buffer.InBuffer]
        assert order['component_end_hook_component_name_condition_impl'] == [rztdl.dl.buffer.InBuffer]
        assert order['component_begin_hook_model_name_condition_impl'] == []
        assert order['component_end_hook_model_name_condition_impl'] == []
