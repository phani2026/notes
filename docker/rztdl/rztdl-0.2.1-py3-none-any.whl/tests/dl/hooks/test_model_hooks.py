# -*- coding: utf-8 -*-
"""
| **@created on:** 2/11/17,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import rztdl.dl
from nose.tools import *
from nose import with_setup  # optional
from rztdl.dl.dl_hooks import model_update_hook, model_close_hook, model_begin_hook
from rztdl.utils.dl_exception import HookException
from rztdl.dl.model import Model
from rztdl import RZTDL_CONFIG
from rztdl.hooks import hooks_manager
import logging

logger = logging.getLogger(__name__)


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    print('********** Starting {} tests . . . **********'.format(__name__))


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    print('**********  {} tests completed successfully . . . **********'.format(__name__))


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


order = {'model_begin_hook_impl': [], 'model_close_hook_impl': [], 'model_update_hook_impl': [],
         'undefined_model_1': [], 'undefined_model_2': [], 'undefined_model_3': []}


class TestModelHooks:
    """
    | **@author:** Prathyush SP
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        pass

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method in the class is called
        """
        pass

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        RZTDL_CONFIG.CommonConfig.HOOKS_ENABLED = True

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        RZTDL_CONFIG.CommonConfig.HOOKS_ENABLED = False
        hooks_manager.initialize_hook_store()
        pass

    def create_new_model(self, model_name: str):
        """
        | **@author:** Prathyush SP
        |
        | Create New Model based on model name
        :param model_name: Model Name
        """
        model = rztdl.dl.Model(model_name)
        model.add_component(rztdl.dl.buffer.InBuffer("input_component", buffer_features=3))
        model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1",
                                                               layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                               component_input='input_component'))
        model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_2",
                                                               layer_activation=rztdl.dl.constants.ActivationType.RELU))
        model.add_component(rztdl.dl.buffer.InBuffer(name="output_component", buffer_features=1))
        model.close()

    @staticmethod
    @model_begin_hook()
    def model_begin_hook_impl(model: Model):
        """
        | **@author:** Prathyush SP
        |
        | Model Begin Hook
        """
        global order
        order['model_begin_hook_impl'].append(len(model.component_dict))

    @staticmethod
    @model_close_hook()
    def model_close_hook_impl(model: Model):
        """
        | **@author:** Prathyush SP
        |
        | Model Close Hook
        """
        global order
        order['model_close_hook_impl'].append(len(model.component_dict))

    @staticmethod
    @model_update_hook()
    def model_update_hook_impl(model: Model):
        """
        | **@author:** Prathyush SP
        |
        | Model Update Hook
        """
        global order
        order['model_update_hook_impl'].append(1)

    @staticmethod
    @model_begin_hook(model_name='undefined_model_1')
    def model_begin_hook_impl(model: Model):
        """
        | **@author:** Prathyush SP
        |
        | Model Begin Hook
        """
        global order
        order['undefined_model_1'].append(len(model.component_dict))

    @staticmethod
    @model_close_hook(model_name='undefined_model_2')
    def model_close_hook_impl(model: Model):
        """
        | **@author:** Prathyush SP
        |
        | Model Close Hook
        """
        global order
        order['undefined_model_2'].append(len(model.component_dict))

    @staticmethod
    @model_update_hook(model_name='undefined_model_3')
    def model_update_hook_impl(model: Model):
        """
        | **@author:** Prathyush SP
        |
        | Model Update Hook
        """
        global order
        order['undefined_model_3'].append(1)

    @raises(HookException)
    def test_model_begin_update_close_hook(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Begin and End Hook
        :return:
        """

        @model_close_hook()
        def model_close_hook_exception_impl(model:Model):
            """
            | **@author:** Prathyush SP
            |
            | Layer End Hook
            """
            raise Exception('Exception Raised')

        global order
        self.create_new_model('test_model_begin_update_close_hook')
        assert order['model_begin_hook_impl'] == [0]
        assert order['model_close_hook_impl'] == [4]
        logger.critical(order['model_close_hook_impl'])
        assert len(order['model_update_hook_impl']) == 4
        assert order['undefined_model_1'] == []
        assert order['undefined_model_2'] == []
        assert order['undefined_model_3'] == []
