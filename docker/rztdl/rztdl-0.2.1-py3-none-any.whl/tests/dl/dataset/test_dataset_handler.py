# -*- coding: utf-8 -*-
"""
| **@created on:** 19/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

import rztdl.dl
from tensorflow import Tensor
import importlib
from nose.tools import *
import nose
import tensorflow as tf
from collections import OrderedDict
from nose import with_setup  # optional


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    pass


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    pass


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestModel:
    """
    | **@author:** Prathyush SP
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        pass

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method in the class is called
        """
        pass

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        pass

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        pass

    def test_dataset_exception(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests sample.py method which throws exception
        """
        from rztdl.dl.dataset import DatasetHandler, CsvDataset
        from rztdl.utils.dl_exception import DatasetException
        from rztdl import RZTDL_MODULE_PATH

        # Dataset Element declared but dataset is missing

        try:
            d1 = DatasetHandler(name='iris_data',
                                dataset_elements={'sepal_features_buffer', 'petal'})
            root_path = RZTDL_MODULE_PATH
            d1.add_dataset(
                CsvDataset(name='sepal', file_name=root_path + '/../samples/data/iris_data/iris_sepal.csv',
                           column_names={'sepal_features_buffer': ['Sepal Length', 'Sepal Width']}))
            d1.close()
            assert False
        except DatasetException:
            assert True

        # Dataset Element not declared but dataset is given

        try:
            d1 = DatasetHandler(name='iris_data',
                                dataset_elements={'sepal_features_buffer'})
            root_path = RZTDL_MODULE_PATH
            d1.add_dataset(
                CsvDataset(name='sepal', file_name=root_path + '/../samples/data/iris_data/iris_sepal.csv',
                           column_names={'sepal_features_buffer': ['Sepal Length', 'Sepal Width']}))
            d1.add_dataset(
                CsvDataset(name='petal', file_name=root_path + '/../samples/data/iris_data/iris_petal.csv',
                           column_names={'petal': ['Petal Length', 'Petal Width']}))
            d1.close()
            assert False
        except DatasetException:
            assert True

        # Dataset Validation Success
        try:
            d1 = DatasetHandler(name='iris_data',
                                dataset_elements={'sepal_features_buffer', 'petal', 'label_buffer'})
            root_path = RZTDL_MODULE_PATH
            d1.add_dataset(
                CsvDataset(name='sepal', file_name=root_path + '/../samples/data/iris_data/iris_sepal.csv',
                           column_names={'sepal_features_buffer': ['Sepal Length', 'Sepal Width']}))
            d1.add_dataset(
                CsvDataset(name='petal', file_name=root_path + '/../samples/data/iris_data/iris_petal.csv',
                           column_names={'petal': ['Petal Length', 'Petal Width']}))
            d1.add_dataset(
                CsvDataset(name='label', file_name=root_path + '/../samples/data/iris_data/iris_label.csv',
                           column_names={'label_buffer': ['Label']}))
            d1.close()
            assert True
        except DatasetException:
            assert False
