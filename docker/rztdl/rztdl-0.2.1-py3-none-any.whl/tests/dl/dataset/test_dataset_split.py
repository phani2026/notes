# -*- coding: utf-8 -*-
"""
| **@created on:** 19/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| 
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

import rztdl.dl
from tensorflow import Tensor
import importlib
from nose.tools import *
import nose
import tensorflow as tf
from collections import OrderedDict
from nose import with_setup  # optional

from rztdl.dl.dataset import DatasetSplit, Split
from rztdl.utils.dl_exception import DatasetSplitException, SplitException


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    pass


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    pass


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestModel:
    """
    | **@author:** Prathyush SP
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        pass

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method in the class is called
        """
        pass

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        pass

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        pass

    def test_dataset_split_exception(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests sample.py method which throws exception
        """

        # Check for Declared Splits > Given Splits
        try:
            split = DatasetSplit(name='basic_split', split_ratio=[50, 20, 30],
                                 split_metrics={'error', 'gini', 'accuracy'})
            split.add_split(Split('train_sp', template=rztdl.dl.constants.DatasetTemplate.train(), metrics={'error'}))
            split.add_split(Split('valid_sp', template=rztdl.dl.constants.DatasetTemplate.valid(), metrics={'gini'}))
            split.close()
            assert False
        except SplitException:
            assert True

        # Metrics used but not declared

        try:
            split = DatasetSplit(name='basic_split', split_ratio=[50, 50], split_metrics={'error', 'accuracy'})
            split.add_split(Split('train_sp', template=rztdl.dl.constants.DatasetTemplate.train(), metrics={'error'}))
            split.add_split(Split('valid_sp', template=rztdl.dl.constants.DatasetTemplate.valid(), metrics={'gini'}))
            split.close()
            assert False
        except DatasetSplitException:
            assert True

        # Try to add split > declared splits
        try:
            split = DatasetSplit(name='basic_split', split_ratio=[100],
                                 split_metrics={'error', 'gini', 'accuracy'})
            split.add_split(Split('train_sp', template=rztdl.dl.constants.DatasetTemplate.train(), metrics={'error'}))
            split.add_split(Split('valid_sp', template=rztdl.dl.constants.DatasetTemplate.valid(), metrics={'gini'}))
            split.close()
            assert False
        except SplitException:
            assert True

        # Split ration <100
        try:
            DatasetSplit(name='basic_split', split_ratio=[65, 10])
            assert False
        except SplitException:
            assert True

        # Split ration >100
        try:
            DatasetSplit(name='basic_split', split_ratio=[65, 90])
            assert False
        except SplitException:
            assert True
