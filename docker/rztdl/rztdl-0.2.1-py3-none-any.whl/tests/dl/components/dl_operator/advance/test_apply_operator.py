# # -*- coding: utf-8 -*-
# """
# | **@created on:** 16/12/16,
# | **@author:** Prathyush SP,
# | **@version:** v0.0.1
# |
# | **Description:**
# | DL Module Tests
# | **Sphinx Documentation Status:** Complete
# |
# ..todo::
#
# """
#
# import rztdl.dl
# from nose.tools import *
# import tensorflow as tf
# from collections import OrderedDict
#
#
# def setup_module():
#     """
#     | **@author:** Prathyush SP
#     |
#     | DL Module Setup - Called when this module is initialized - First Call
#     """
#     print('********** Starting {} tests . . . **********'.format(__name__))
#
#
# def teardown_module():
#     """
#     | **@author:** Prathyush SP
#     |
#     | DL Module Teardown - Called when this module is completed - Last Call
#     """
#     print('**********  {} tests completed successfully . . . **********'.format(__name__))
#
#
# class TestApplyOperator:
#     """
#     | **@author:** Thebzeera V
#     |
#     | **Description:**
#     | apply dl_operator module contains various utilities required to test using nose test cases
#     | 1. apply dl_operator Input dl_layer
#     | 2. apply dl_operator Fully connected dl_layer
#     | 3. apply dl_operator Convolution dl_layer
#     | 4. apply dl_operator Pool dl_layer
#     | 5. apply dl_operator Output dl_layer
#     | 6. validate apply dl_operator output
#     """
#
#     def __init__(self):
#         """
#         | Initialize Test dl_operator
#         """
#         self.model_name = None
#         self.model = None
#         self.operator_name = None
#
#     def setup(self):
#         """
#         | **@author:** Thebzeera V
#         |
#         | Runs before a new method is called
#         """
#         rztdl.RZTDL_STORE.dag = OrderedDict()
#         self.model_name = 'test_model'
#         self.model = rztdl.dl.Model(self.model_name)
#         self.operator_name = 'apply'
#         self.input_layer = rztdl.dl.layer.InputLayer('input_Layer', layer_nodes=10)
#
#     def teardown(self):
#         """
#         | **@author:** Thebzeera V
#         |
#         | Runs after each method is called
#         """
#
#         pass
#
#     @classmethod
#     def setup_class(cls):
#         """
#         | **@author:** Thebzeera V
#         |
#         | Runs during class initialization
#         """
#         cls.input = tf.constant(.90)
#         cls.tensor_abs = tf.abs(cls.input)
#         cls.tensor_tan = tf.tan(cls.input)
#         cls.tensor_ceil = tf.ceil(cls.input)
#         cls.init = tf.global_variables_initializer()
#         cls.sess = tf.InteractiveSession()
#         cls.sess.run(cls.init)
#
#     @classmethod
#     def teardown_class(cls):
#         """
#         | **@author:** Thebzeera V
#         |
#         | Runs after class reference is removed / class test cases are completed
#         """
#         cls.sess.close()
#
#     def test_operator_name(self):
#         """
#         | **@author:** Thebzeera v
#         |
#         | Tests Operator Name Validation
#         """
#         false_names = ['reduce 1', 'reduce .', '%reduce']
#         for name in false_names:
#             try:
#                 rztdl.dl.dl_operator(name)
#                 exit()
#             except:
#                 assert True
#
#     def test_input_layer_operation(self):
#
#         """
#         | **@author:** Thebzeera v
#         |
#         | Test input dl_layer apply dl_operator
#         """
#         self.model.add_component_output_as_tensor(self.input_layer)
#         output_tan = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_tan',
#                                                                                 operator_input='input_Layer',
#                                                                                 function=tf.tan,
#                                                                                 operator_output='apply_op_tan'))
#         output_abs = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_abs',
#                                                                                 operator_input='input_Layer',
#                                                                                 function=tf.abs,
#                                                                                 operator_output='apply_op_abs'))
#         output_ceil = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_ceil',
#                                                                                  operator_input='input_Layer',
#                                                                                  function=tf.ceil,
#                                                                                  operator_output='apply_op_ceil'))
#
#         # Test updated model architecture key is present or not
#         rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, 'apply_abs')
#         # Test RZTDL DAG Layer Insertion
#         rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, 'apply_op_abs')
#         # Test the shape of abs operation
#         assert_equal(output_tan.get_shape().as_list(), [None, 10])
#         # Test updated model architecture key is present or not
#         rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, 'apply_tan')
#         # Test RZTDL DAG Layer Insertion
#         rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, 'apply_op_tan')
#         # Test the shape of tan operation
#         assert_equal(output_abs.get_shape().as_list(), [None, 10])
#         # Test updated model architecture key is present or not
#         rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, 'apply_ceil')
#         # Test RZTDL DAG Layer Insertion
#         rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, 'apply_op_ceil')
#         # Test the shape of ceil operation
#         assert_equal(output_ceil.get_shape().as_list(), [None, 10])
#
#     def test_fully_connected_operation(self):
#         """
#         | **@author:** Thebzeera v
#         |
#         | Test fully connected dl_layer apply operator
#         """
#         self.model.add_component_output_as_tensor(self.input_layer)
#         self.model.add_component_output_as_tensor(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer',
#                                                                                      layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
#                                                                                      layer_nodes=10))
#         output_tan = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_tan',
#                                                                                 operator_input='fully_connected_layer',
#                                                                                 function=tf.tan,
#                                                                                 operator_output='apply_op_tan'))
#         output_abs = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_abs',
#                                                                                 operator_input='fully_connected_layer',
#                                                                                 function=tf.abs,
#                                                                                 operator_output='apply_op_abs'))
#         output_ceil = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_ceil',
#                                                                                  operator_input='fully_connected_layer',
#                                                                                  function=tf.ceil,
#                                                                                  operator_output='apply_op_ceil'))
#
#         # Test updated model architecture key is present or not
#         rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, 'apply_abs')
#         # Test RZTDL DAG Layer Insertion
#         rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, 'apply_op_abs')
#         # Test the shape of abs operation
#         assert_equal(output_tan.get_shape().as_list(), [None, 10])
#         # Test updated model architecture key is present or not
#         rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, 'apply_tan')
#         # Test RZTDL DAG Layer Insertion
#         rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, 'apply_op_tan')
#         # Test the shape of tan operation
#         assert_equal(output_abs.get_shape().as_list(), [None, 10])
#         # Test updated model architecture key is present or not
#         rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, 'apply_ceil')
#         # Test RZTDL DAG Layer Insertion
#         rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, 'apply_op_ceil')
#         # Test the shape of ceil operation
#         assert_equal(output_ceil.get_shape().as_list(), [None, 10])
#
#     def test_convolution_layer_operation(self):
#         """
#         | **@author:** Thebzeera v
#         |
#         | Test convolution dl_layer apply operator
#         """
#         self.model.add_component_output_as_tensor(self.input_layer)
#         self.model.add_operator(rztdl.dl.operator.ReshapeOperator(self.operator_name, operator_input='input_Layer',
#                                                                      operator_output='reshape_out',
#                                                                      shape=[-1, 1, 1, 1]))
#
#         self.model.add_component_output_as_tensor(rztdl.dl.layer.ConvolutionLayer('convolution_layer',
#                                                                                   layer_activation=rztdl.dl.constants.ActivationType.RELU,
#                                                                                   filter_dimensions=[1, 1, 1, 1],
#                                                                                   filter_strides=[1, 2, 3, 1],
#                                                                                   filter_padding=rztdl.dl.constants.PaddingType.SAME,
#                                                                                   layer_input='reshape_out'))
#
#         output_tan = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_tan',
#                                                                                 operator_input='convolution_layer',
#                                                                                 function=tf.tan,
#                                                                                 operator_output='apply_op_tan'))
#         output_abs = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_abs',
#                                                                                 operator_input='convolution_layer',
#                                                                                 function=tf.abs,
#                                                                                 operator_output='apply_op_abs'))
#         output_ceil = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_ceil',
#                                                                                  operator_input='convolution_layer',
#                                                                                  function=tf.ceil,
#                                                                                  operator_output='apply_op_ceil'))
#
#         # Test updated model architecture key is present or not
#         rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, 'apply_abs')
#         # Test RZTDL DAG Layer Insertion
#         rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, 'apply_op_abs')
#         # Test the shape of abs operation
#         assert_equal(output_tan.get_shape().as_list(), [None, 1, 1, 1])
#         # Test updated model architecture key is present or not
#         rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, 'apply_tan')
#         # Test RZTDL DAG Layer Insertion
#         rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, 'apply_op_tan')
#         # Test the shape of tan operation
#         assert_equal(output_abs.get_shape().as_list(), [None, 1, 1, 1])
#         # Test updated model architecture key is present or not
#         rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, 'apply_ceil')
#         # Test RZTDL DAG Layer Insertion
#         rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, 'apply_op_ceil')
#         # Test the shape of ceil operation
#         assert_equal(output_ceil.get_shape().as_list(), [None, 1, 1, 1])
#
#     def test_pool_layer_operation(self):
#         """
#         | **@author:** Thebzeera v
#         |
#         | Test pool dl_layer apply operator
#         """
#
#         self.model.add_component_output_as_tensor(self.input_layer)
#         self.model.add_operator(rztdl.dl.operator.ReshapeOperator(self.operator_name, operator_input='input_Layer',
#                                                                      operator_output='reshape_out',
#                                                                      shape=[-1, 2, 2, 1]))
#
#         self.model.add_component_output_as_tensor(rztdl.dl.layer.PoolLayer('pool', pool_dimensions=[1, 4, 4, 1], pool_strides=[1, 1, 1, 1],
#                                                                            pool_padding=rztdl.dl.constants.PaddingType.SAME,
#                                                                            pool_type=rztdl.dl.constants.PoolType.MAX_POOL,
#                                                                            layer_input='reshape_out'))
#         output_tan = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_tan',
#                                                                                 operator_input='pool',
#                                                                                 function=tf.tan,
#                                                                                 operator_output='apply_op_tan'))
#         output_abs = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_abs',
#                                                                                 operator_input='pool',
#                                                                                 function=tf.abs,
#                                                                                 operator_output='apply_op_abs'))
#         output_ceil = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_ceil',
#                                                                                  operator_input='pool',
#                                                                                  function=tf.ceil,
#                                                                                  operator_output='apply_op_ceil'))
#
#         # Test updated model architecture key is present or not
#         rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, 'apply_abs')
#         # Test RZTDL DAG Layer Insertion
#         rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, 'apply_op_abs')
#         # Test the shape of abs operation
#         assert_equal(output_tan.get_shape().as_list(), [None, 2, 2, 1])
#         # Test updated model architecture key is present or not
#         rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, 'apply_tan')
#         # Test RZTDL DAG Layer Insertion
#         rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, 'apply_op_tan')
#         # Test the shape of tan operation
#         assert_equal(output_abs.get_shape().as_list(), [None, 2, 2, 1])
#         # Test updated model architecture key is present or not
#         rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, 'apply_ceil')
#         # Test RZTDL DAG Layer Insertion
#         rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, 'apply_op_ceil')
#         # Test the shape of ceil operation
#         assert_equal(output_ceil.get_shape().as_list(), [None, 2, 2, 1])
#
#     def test_output_layer_apply_operator(self):
#         """
#         | **@author:** Thebzeera v
#         |
#         | Test Output dl_layer apply dl_operator
#         """
#
#         self.model.add_component_output_as_tensor(self.input_layer)
#         self.model.add_component_output_as_tensor(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer',
#                                                                                      layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
#                                                                                      layer_nodes=6))
#         self.model.add_component_output_as_tensor(
#             rztdl.dl.layer.OutputLayer(name='output_name', layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
#                                        layer_nodes=3, layer_input='fully_connected_layer'))
#         output_tan = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_tan',
#                                                                                 operator_input='fully_connected_layer',
#                                                                                 function=tf.tan,
#                                                                                 operator_output='apply_op_tan'))
#         output_abs = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_abs',
#                                                                                 operator_input='fully_connected_layer',
#                                                                                 function=tf.abs,
#                                                                                 operator_output='apply_op_abs'))
#         output_ceil = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_ceil',
#                                                                                  operator_input='fully_connected_layer',
#                                                                                  function=tf.ceil,
#                                                                                  operator_output='apply_op_ceil'))
#
#         # Test updated model architecture key is present or not
#         rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, 'apply_abs')
#         # Test RZTDL DAG Layer Insertion
#         rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, 'apply_op_abs')
#         # Test the shape of abs operation
#         assert_equal(output_tan.get_shape().as_list(), [None, 6])
#         # Test updated model architecture key is present or not
#         rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, 'apply_tan')
#         # Test RZTDL DAG Layer Insertion
#         rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, 'apply_op_tan')
#         # Test the shape of tan operation
#         assert_equal(output_abs.get_shape().as_list(), [None, 6])
#         # Test updated model architecture key is present or not
#         rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, 'apply_ceil')
#         # Test RZTDL DAG Layer Insertion
#         rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, 'apply_op_ceil')
#         # Test the shape of ceil operation
#         assert_equal(output_ceil.get_shape().as_list(), [None, 6])
#
#     def test_apply_operator(self):
#
#         """
#         | **@author:** Thebzeera v
#         |
#         | Test apply dl_operator output
#         """
#
#         output_tan = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_tan',
#                                                                                 operator_input=self.input,
#                                                                                 function=tf.tan,
#                                                                                 operator_output='apply_op_tan'))
#         output_abs = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_abs',
#                                                                                 operator_input=self.input,
#                                                                                 function=tf.abs,
#                                                                                 operator_output='apply_op_abs'))
#         output_ceil = self.model.add_operator(rztdl.dl.operator.ApplyOperator(name='apply_ceil',
#                                                                                  operator_input=self.input,
#                                                                                  function=tf.ceil,
#                                                                                  operator_output='apply_op_ceil'))
#         output_tensor_tan, output_reduce_tan = self.sess.run([self.tensor_tan, output_tan])
#         output_tensor, output_reduce = self.sess.run([self.tensor_ceil, output_ceil])
#         output_tensor_ceil, output_reduce_ceil = self.sess.run([self.tensor_abs, output_abs])
#         # Test reduce cos
#         assert_equal(output_tensor.all(), output_reduce.all())
#         # Test reduce tan
#         assert_equal(output_tensor_tan.all(), output_reduce_tan.all())
#         # Test reduce ceil
#         assert_equal(output_tensor_ceil.all(), output_reduce_ceil.all())
