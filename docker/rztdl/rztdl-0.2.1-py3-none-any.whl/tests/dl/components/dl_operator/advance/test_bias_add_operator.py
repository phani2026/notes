# # -*- coding: utf-8 -*-
# """
# | **@created on:** 16/12/16,
# | **@author:** Prathyush SP,
# | **@version:** v0.0.1
# |
# | **Description:**
# | DL Module Tests
# | **Sphinx Documentation Status:** Complete
# |
# ..todo::
#
# """
#
# import rztdl.dl
# from nose.tools import *
# import tensorflow as tf
# from collections import OrderedDict
# import numpy as np
# from rztdl import RZTDL_CONFIG
# from rztdl.utils.dl_exception import ShapeError
#
#
# def setup_module():
#     """
#     | **@author:** Prathyush SP
#     |
#     | DL Module Setup - Called when this module is initialized - First Call
#     """
#     print('********** Starting {} tests . . . **********'.format(__name__))
#     pass
#
#
# def teardown_module():
#     """
#     | **@author:** Prathyush SP
#     |
#     | DL Module Teardown - Called when this module is completed - Last Call
#     """
#     print('**********  {} tests completed successfully . . . **********'.format(__name__))
#     pass
#
#
# def get_rztdl_default_type_as_numpy():
#     """
#     | **@author:** Himaprasoon PT
#     |
#     | Get dtype of numpy based on config
#     :return:
#     """
#     return {tf.float32: np.float32,
#             tf.float64: np.float64
#             }[RZTDL_CONFIG.TensorflowConfig.DTYPE]
#
#
# class TestBiasAddOperator:
#     """
#     | **@author:** Himaprasoon PT
#     |
#     | **Description:**
#     | Test Bias Add dl_operator
#     """
#
#     def __init__(self):
#         """
#         | Initialize Test dl_operator
#         """
#         self.model_name = None
#         self.model = None
#         self.operator_name = None
#         self.input_layer = None
#         self.bias_operator = None
#         self.output_layer = None
#         self.bias_layer = None
#
#     def setup(self):
#         """
#         | **@author:** Himaprasoon PT
#         |
#         | Runs before a new method is called
#         """
#         rztdl.RZTDL_STORE.dag = OrderedDict()
#         self.model_name = 'bias_test_model'
#         self.model = rztdl.dl.Model(self.model_name)
#         self.operator_name = 'bias'
#         self.input_layer = rztdl.dl.layer.InputLayer('input_layer', layer_nodes=3)
#         self.model.add_layer(self.input_layer)
#         self.session = tf.Session()
#
#     def teardown(self):
#         """
#         | **@author:** Himaprasoon PT
#         |
#         | Runs after each method is called
#         """
#         self.bias_layer = None
#         self.output_layer = None
#         self.session.close()
#
#     @classmethod
#     def setup_class(cls):
#         """
#         | **@author:** Himaprasoon PT
#         |
#         | Runs during class initialization
#         """
#         cls.correct_train_data = np.array([[1, 2, 3]])
#
#     @classmethod
#     def teardown_class(cls):
#         """
#         | **@author:** Himaprasoon PT
#         |
#         | Runs after class reference is removed / class test cases are completed
#         """
#         pass
#
#     def add_bias_op(self, b):
#         """
#         | **@author:** Himaprasoon PT
#         |
#         | Adds bias
#         :param b: Bias value
#         """
#         self.bias_operator = rztdl.dl.operator.BiasAddOperator(self.operator_name, operator_output="bias_out",
#                                                                operator_input="input_layer", bias=b)
#         self.model.add_operator(self.bias_operator)
#         init = tf.global_variables_initializer()
#         self.session.run(init)
#         return self.session.run(self.bias_operator.operator_output,
#                                 feed_dict={self.input_layer.layer_output: self.correct_train_data})
#
#     def test_bias_numpy_array_1d_input(self):
#         """
#         | **@author:** Himaprasoon PT
#         |
#         | Test bias for 1d array
#         """
#         b = np.array([1, 1, 1])
#         out = self.add_bias_op(b)
#         assert np.array_equal(out, np.add(b, self.correct_train_data))
#
#     def test_bias_constant(self):
#         """
#         | **@author:** Himaprasoon PT
#         |
#         | Test bias dl_operator with a constant
#         """
#         assert self.add_bias_op(10.123).tolist()[0] == [11.123000144958496, 12.123000144958496, 13.123000144958496]
#
#     @raises(ShapeError)
#     def test_bias_2d_exception(self):
#         """
#         | **@author:** Himaprasoon PT
#         |
#         | Test bias dl_operator shape exception
#         """
#         b = np.array([1, 1, 1, 1])
#         self.add_bias_op(b)
#
#     def test_bias_random_uniform_1d_input(self):
#         """
#         | **@author:** Himaprasoon PT
#         |
#         | Tests bias random uniform 1d input
#         """
#         b = rztdl.dl.constants.InitializerType.random_uniform(min_val=0.0, max_val=1.0, seed=0)
#         self.add_bias_op(b)
#
#     def test_bias_random_normal_1d_input(self):
#         """
#         | **@author:** Himaprasoon PT
#         |
#         | Tests bias random normal 1d input
#         """
#         b = rztdl.dl.constants.InitializerType.random_normal(std_dev=1.0, mean=1.0, seed=0)
#         self.add_bias_op(b)
#
#     def test_bias_zeros(self):
#         """
#         | **@author:** Himaprasoon PT
#         |
#         | Test bias dl_operator for zeros
#         """
#         b = rztdl.dl.constants.InitializerType.zeros()
#         out = self.add_bias_op(b)
#         assert np.array_equal(out, self.correct_train_data)
#
#     def test_bias_ones(self):
#         """
#         | **@author:** Himaprasoon PT
#         |
#         | Tests bias dl_operator for ones
#         """
#         b = rztdl.dl.constants.InitializerType.ones()
#         out = self.add_bias_op(b)
#         assert np.array_equal(out, np.add(self.correct_train_data, np.ones(self.correct_train_data.shape)))
