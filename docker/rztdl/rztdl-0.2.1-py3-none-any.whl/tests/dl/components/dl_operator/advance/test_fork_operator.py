# -*- coding: utf-8 -*-
"""
| **@created on:** 22/06/18,
| **@author:** Umesh Kumar
| **@version:** v0.0.1
|
| **Description:**
| Fork Operator Module Tests
|
|
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import inspect

import tensorflow as tf
from nose.tools import *

import rztdl.dl
from rztdl import RZTDL_CONFIG
from rztdl.utils.dl_exception import SizeError


def setup_module():
    """
    | **@author:** Umesh Kumar
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    print('********** Starting {} tests . . . **********'.format(__name__))


def teardown_module():
    """
    | **@author:** Umesh Kumar
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    print('**********  {} tests completed successfully . . . **********'.format(__name__))


def my_setup_function():
    """
    | **@author:** Umesh Kumar
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Umesh Kumar
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Umesh Kumar
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestForkOperator:
    """
    | **@author:** Umesh Kumar
    |
    | **Description:**
    |  Fork dl_operator module contains various utilities required to test using nose test cases
    """

    def __init__(self):
        """
        | Initialize Test dl_operator
        """
        pass

    def setup(self):
        """
        | **@author:** Umesh Kumar
        |
        | Runs before a new method is called
        """
        RZTDL_CONFIG.update_dl_config_manager(
            config_file_path='/'.join(__file__.split('/')[:-5]) + '/rztdl_testing_config.json')
        self.model.clear_components()
        self.model.add_component(self.input_buffer)

    def teardown(self):
        """
        | **@author:** Umesh Kumar
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Umesh Kumar
        |
        | Runs during class initialization
        """
        print("*********Fork operator Test Case . . .*********")
        cls.model_name = 'test_fork_operator_model'
        cls.model = rztdl.dl.Model(cls.model_name)
        # noinspection PyTypeChecker
        cls.operator_name = 'fork_op'
        cls.operator_output_name = 'fork_op_out'
        cls.input_buffer = rztdl.dl.buffer.InBuffer(name='input_buffer', buffer_features=2)
        cls.model.add_component(cls.input_buffer)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Umesh Kumar
        |
        | Runs after class reference is removed / class test cases are completed
        """
        print("*********Fork Operator Test Case completed successfully . . .*********")

    def test_operator_name(self):
        """
        | **@author:** Umesh Kumar
        |
        | Tests Operator Name Validation
        """
        false_names = ['op 1', 'op .', '%op']
        for name in false_names:
            try:
                rztdl.dl.operator.ForkOperator(name, component_input='', component_output=[])
                assert False
            except NameError:
                assert True

    def test_component_exception(self):
        """
        | **@author:** Umesh Kumar
        |
        |  Test the Fork dl_operator raises exception
        """

        # Len of output < 2
        self.model.add_component(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer',
                                                                    layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                    layer_nodes=15,
                                                                    component_input=self.input_buffer.name))

        try:
            self.model.add_component(rztdl.dl.operator.ForkOperator(self.operator_name,
                                                                    component_input='fully_connected_layer',
                                                                    component_output=[self.operator_output_name]))
            assert False
        except SizeError:
            assert True

    def test_create_component(self):
        """
        | **@author:** Prathyush SP
        |
        | Test create component
        """
        self.model.add_component(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer_1',
                                                                    layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                    layer_nodes=2,
                                                                    component_input=self.input_buffer.name))
        comp = self.model.add_component(rztdl.dl.operator.ForkOperator(self.operator_name,
                                                                       component_input='fully_connected_layer_1',
                                                                       component_output=[
                                                                           self.operator_output_name + '_1',
                                                                           self.operator_output_name + '_2']))

        # Test updated model architecture key is present or not
        rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, self.operator_name)

        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, self.operator_output_name + '_1')
        rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, self.operator_output_name + '_2')

        # Test if added to tensorflow  collection
        assert len(tf.get_collection(comp[0].name)) > 0
        assert len(tf.get_collection(comp[1].name)) > 0

        # Test the shape
        assert_equal(
            rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name,
                                                             self.operator_output_name + '_1').get_shape().as_list(),
            [None, 2])
        assert_equal(
            rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name,
                                                             self.operator_output_name + '_2').get_shape().as_list(),
            [None, 2])

    def test_tensor_inputs(self):
        """
        | **@author:** Prathyush SP
        |
        | Test mix of inputs for the operator
        """
        self.model.add_component(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer_2',
                                                                    layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                    layer_nodes=10,
                                                                    component_input=self.input_buffer.name))
        f1 = self.model.add_component(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer_3',
                                                                         layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                         layer_nodes=10,
                                                                         component_input=self.input_buffer.name))
        self.model.add_component(rztdl.dl.operator.ForkOperator(self.operator_name,
                                                                component_input=f1,
                                                                component_output=[
                                                                    self.operator_output_name + '_1',
                                                                    self.operator_output_name + '_2']))

    # noinspection PyDunderSlots,PyUnresolvedReferences
    @raises(AttributeError)
    def test_slots(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Slot functionality
        """
        rztdl.dl.operator.ForkOperator(name=self.operator_name,
                                       component_input='input_buffer',
                                       component_output=[
                                           self.operator_output_name + '_1',
                                           self.operator_output_name + '_2']).new_var_comp = 0

    def test_blueprint_json_parameters(self):
        """
        | *@author:* Umesh Kumar
        |
        | Test Component Blueprint
        """
        blueprint_json = rztdl.dl.operator.ForkOperator.blueprint().to_json()
        x = [parameter for parameter in inspect.signature(rztdl.dl.operator.ForkOperator).parameters.keys()]
        blueprint_parameters = []
        component_parameters = ["inputs", "parameters", "outputs"]
        for each_component_parameter in component_parameters:
            for value in blueprint_json[each_component_parameter]:
                blueprint_parameters.append(value["name"])
                if "properties" in value.keys():
                    for each_property in value["properties"]:
                        if "link_to_attribute" in each_property.keys():
                            blueprint_parameters.append(each_property["link_to_attribute"])
                else:
                    blueprint_parameters.append(value["name"])
        assert_equal(set(blueprint_parameters), set(x))
