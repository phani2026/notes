# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Sub Operator Module Tests
|
|
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import inspect
import tensorflow as tf
from nose.tools import *
import rztdl.dl
from rztdl import RZTDL_CONFIG
from rztdl.utils.dl_exception import ShapeError, SizeError


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    print('********** Starting {} tests . . . **********'.format(__name__))


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    print('**********  {} tests completed successfully . . . **********'.format(__name__))


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestSubOperator:
    """
    | **@author:** Prathyush SP
    |
    | **Description:**
    |  Sub dl_operator module contains various utilities required to test using nose test cases
    """

    def __init__(self):
        """
        | Initialize Test dl_operator
        """
        pass

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method is called
        """
        RZTDL_CONFIG.update_dl_config_manager(
            config_file_path='/'.join(__file__.split('/')[:-5]) + '/rztdl_testing_config.json')
        self.model.clear_components()
        self.model.add_component(self.input_buffer)

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        print("*********Sub operator Test Case . . .*********")
        cls.model_name = 'test_sub_operator_model'
        cls.model = rztdl.dl.Model(cls.model_name)
        # noinspection PyTypeChecker
        cls.operator_name = 'sub_op'
        cls.operator_output_name = 'sub_op_out'
        cls.input_buffer = rztdl.dl.buffer.InBuffer(name='input_buffer', buffer_features=2)
        cls.model.add_component(cls.input_buffer)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        print("*********Sub Operator Test Case completed successfully . . .*********")

    def test_operator_name(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests Operator Name Validation
        """
        false_names = ['op 1', 'op .', '%op']
        for name in false_names:
            try:
                rztdl.dl.operator.SubOperator(name, component_input=[], component_output='')
                assert False
            except NameError:
                assert True

    @raises(ShapeError)
    def test_validation(self):
        """
        | **@author:** Prathyush SP
        |
        |  Test the Add dl_operator raises exception when trying to add two different shapes of dl_layer
        """
        self.model.add_component(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer',
                                                                    layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                    layer_nodes=15,
                                                                    component_input=self.input_buffer.name))
        self.model.add_component(rztdl.dl.operator.SubOperator(self.operator_name,
                                                               component_input=['fully_connected_layer',
                                                                                'input_buffer'],
                                                               component_output=self.operator_output_name))

    def test_create_component(self):
        """
        | **@author:** Prathyush SP
        |
        | Test create component
        """
        self.model.add_component(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer_1',
                                                                    layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                    layer_nodes=2,
                                                                    component_input=self.input_buffer.name))
        comp = self.model.add_component(rztdl.dl.operator.SubOperator(self.operator_name,
                                                                      component_input=['fully_connected_layer_1',
                                                                                       'input_buffer'],
                                                                      component_output=self.operator_output_name))
        # Test updated model architecture key is present or not
        rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, self.operator_name)

        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, self.operator_output_name)

        # Test if added to tensorflow  collection
        assert len(tf.get_collection(comp.name)) > 0

        # Test the shape
        assert_equal(rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, self.operator_output_name).get_shape().as_list(), [None, 2])

    def test_mix_inputs(self):
        """
        | **@author:** Prathyush SP
        |
        | Test mix of inputs for the operator
        """
        self.model.add_component(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer_2',
                                                                    layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                    layer_nodes=10,
                                                                    component_input=self.input_buffer.name))
        f1 = self.model.add_component(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer_3',
                                                                         layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                         layer_nodes=10,
                                                                         component_input=self.input_buffer.name))
        self.model.add_component(rztdl.dl.operator.SubOperator(self.operator_name,
                                                               component_input=['fully_connected_layer_2',
                                                                                f1],
                                                               component_output=self.operator_output_name))

    @raises(SizeError)
    def test_size_error(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Size Error
        """
        self.model.add_component(rztdl.dl.operator.SubOperator(name=self.operator_name,
                                                               component_input=['input_buffer'],
                                                               component_output=self.operator_output_name))

    # noinspection PyDunderSlots,PyUnresolvedReferences
    @raises(AttributeError)
    def test_slots(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Slot functionality
        """
        rztdl.dl.operator.SubOperator(name=self.operator_name,
                                      component_input=['input_buffer', 'input_buffer'],
                                      component_output=self.operator_output_name).new_var_comp = 0

    def test_blueprint_json_parameters(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Blueprint JSON Parameters
        """
        blueprint_json = rztdl.dl.operator.SubOperator.blueprint().to_json()
        x = [parameter for parameter in inspect.signature(rztdl.dl.operator.SubOperator).parameters.keys()]
        input_parameters = [value["name"] for value in blueprint_json["inputs"]]
        component_parameters = [value["name"] for value in blueprint_json["parameters"]]
        output_parameters = [value["name"] for value in blueprint_json["outputs"]]
        blueprint_parameters = input_parameters + component_parameters + output_parameters
        assert_equal(set(blueprint_parameters), set(x))
