# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import rztdl.dl
from nose.tools import *
import tensorflow as tf
from collections import OrderedDict
from nose import with_setup  # optional


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    print('********** Starting {} tests . . . **********'.format(__name__))


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    print('**********  {} tests completed successfully . . . **********'.format(__name__))


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestUnstackOperator:
    """
    | **@author:** Thebzeera V
    |
    | **Description:**
    |  Unstack dl_operator module contains various utilities required to test using nose test cases
    | 1. Unstack dl_operator on Input dl_layer
    | 2. Unstack dl_operator on connected dl_layer
    | 3. Unstack dl_operator on Convolution dl_layer
    | 4. Unstack dl_operator on Pool dl_layer
    """

    def __init__(self):
        """
        | Initialize Test dl_operator
        """
        self.model_name = None
        self.model = None
        self.operator_name = None

    def setup(self):
        """
        | **@author:** Thebzeera V
        |
        | Runs before a new method is called
        """
        rztdl.RZTDL_STORE.dag = OrderedDict()
        tf.reset_default_graph()
        self.model_name = 'unstack_model'
        self.model = rztdl.dl.Model(self.model_name)
        self.operator_name = 'Unstack'
        self.input_layer = rztdl.dl.layer.InputLayer('input_Layer', layer_nodes=5)

    def teardown(self):
        """
        | **@author:** Thebzeera V
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Thebzeera V
        |
        | Runs during class initialization
        """
        cls.session = tf.InteractiveSession()

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Thebzeera V
        |
        | Runs after class reference is removed / class test cases are completed
        """
        cls.session.close()

    def test_operator_name(self):
        """
        | **@author:** Thebzeera v
        |
        | Tests Model Name Validation
        """
        false_names = ['unstack 1', 'unstack .', '%unstack']
        for name in false_names:
            try:
                rztdl.dl.operator(name)
                exit()
            except:
                assert True

    def test_input_layer_unstack(self):
        """
        | **@author:** Thebzeera v
        |
        | Test unstack dl_operator on Input  dl_layer
        """

        self.model.add_component_output_as_tensor(self.input_layer)
        obj = rztdl.dl.operator.UnstackOperator(self.operator_name, operator_input='input_Layer',
                                                operator_output="unstack_op",
                                                dimension=1)
        self.model.add_operator(obj)
        rztdl.RZTDL_STORE.get_meta_data(self.model_name)

        # Test number of Unstack
        assert_equal(len(obj.operator_output), 5)

    #
    def test_fully_connected_layer_unstack(self):
        """
        | **@author:** Thebzeera v
        |
        | Test unstack dl_operator on Fully connected  dl_layer
        """
        self.model.add_component_output_as_tensor(self.input_layer)
        self.model.add_component_output_as_tensor(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer',
                                                                                     layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                                     layer_nodes=2))
        obj = rztdl.dl.operator.UnstackOperator("unstack1", operator_input='fully_connected_layer',
                                                operator_output="unstack_op",
                                                dimension=1)
        self.model.add_operator(obj)
        # Test updated model architecture key is present or not
        rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, 'unstack1')

        rztdl.RZTDL_STORE.get_meta_data(self.model_name)

        # Test number of unstack
        assert_equal(len(obj.operator_output), 2)

    def test_con_unstack(self):
        """
        | **@author:** Thebzeera v
        |
        | Test unstack dl_operator on Convolution  dl_layer
        """
        self.model.add_component_output_as_tensor(self.input_layer)
        self.model.add_operator(rztdl.dl.operator.ReshapeOperator(self.operator_name, operator_input='input_Layer',
                                                                  operator_output='reshape_out',
                                                                  shape=[-1, 4, 4, 1]))
        self.model.add_component_output_as_tensor(rztdl.dl.layer.ConvolutionLayer('convolution_layer',
                                                                                  layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                                                  filter_dimensions=[1, 1, 1, 1],
                                                                                  filter_strides=[1, 2, 3, 1],
                                                                                  filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                                                  layer_input='reshape_out'))
        obj = rztdl.dl.operator.UnstackOperator("unstack2", operator_input='convolution_layer',
                                                operator_output="unstack_op",
                                                dimension=2)
        self.model.add_operator(obj)

        rztdl.RZTDL_STORE.get_meta_data(self.model_name)

        # Test number of unstack
        assert_equal(len(obj.operator_output), 2)

    def test_pool_layer_unstack(self):

        """
        | **@author:** Thebzeera v
        |
        | Test unstack dl_operator on Pool  dl_layer
        """
        self.model.add_component_output_as_tensor(self.input_layer)
        self.model.add_operator(rztdl.dl.operator.ReshapeOperator(self.operator_name, operator_input='input_Layer',
                                                                  operator_output='reshape_out',
                                                                  shape=[-1, 4, 4, 1]))
        self.model.add_component_output_as_tensor(
            rztdl.dl.layer.PoolLayer('pool', pool_dimensions=[1, 4, 4, 1], pool_strides=[1, 2, 2, 1],
                                     pool_padding=rztdl.dl.constants.PaddingType.SAME,
                                     pool_type=rztdl.dl.constants.PoolType.MAX_POOL,
                                     layer_input='reshape_out'))
        obj = rztdl.dl.operator.UnstackOperator("unstack3", operator_input='pool',
                                                operator_output="unstack_op",
                                                dimension=0, no_of_sequences=2)
        self.model.add_operator(obj)
        # Test number of unstack
        assert_equal(len(obj.operator_output), 2)

    def test_output_layer_unstack(self):
        """
        | **@author:** Thebzeera v
        |
        | Test unstack dl_operator on Fully  dl_layer
        """

        self.model.add_component_output_as_tensor(self.input_layer)
        self.model.add_component_output_as_tensor(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer',
                                                                                     layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                                     layer_nodes=6))
        self.model.add_component_output_as_tensor(
            rztdl.dl.layer.OutputLayer(name='output_name', layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                       layer_nodes=3, layer_input='fully_connected_layer'))
        obj = rztdl.dl.operator.UnstackOperator('unstack4', operator_input='output_name',
                                                operator_output="unstack_op",
                                                dimension=1)
        self.model.add_operator(obj)

        assert_equal(len(obj.operator_output), 3)
