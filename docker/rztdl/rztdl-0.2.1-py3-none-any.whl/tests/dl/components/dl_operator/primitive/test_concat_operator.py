# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP, Umesh Kumar
| **@version:** v0.0.1
|
| **Description:**
| Concat Operator Test Cases
|
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import inspect
import tensorflow as tf
from nose.tools import *
import rztdl.dl
from rztdl import RZTDL_CONFIG
from rztdl.utils.dl_exception import DimensionError, SizeError


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    print('********** Starting {} tests . . . **********'.format(__name__))


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    print('**********  {} tests completed successfully . . . **********'.format(__name__))


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestConcatOperator:
    """
    | **@author:** Prathyush SP
    |
    | **Description:**
    |  Mul dl_operator module contains various utilities required to test using nose test cases
    | 1. concat dl_operator validation
    | 2. concat dl_operator on Input dl_layer
    | 3. concat dl_operator on connected dl_layer
    | 4. concat dl_operator on Convolution dl_layer
    | 5. concat dl_operator on Pool dl_layer
    """

    def __init__(self):
        """
        | Initialize Test dl_operator name
        """
        pass

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method is called
        """
        RZTDL_CONFIG.update_dl_config_manager(
            config_file_path='/'.join(__file__.split('/')[:-5]) + '/rztdl_testing_config.json')

        self.model.clear_components()
        self.model.add_component(self.input_buffer)

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        print("*********Concat operator Test Case . . .*********")
        cls.model_name = 'test_concat_operator_model'
        cls.model = rztdl.dl.Model(cls.model_name)
        # noinspection PyTypeChecker
        cls.operator_name = 'cocat_op'
        cls.operator_output_name = 'concat_op_out'
        cls.input_buffer = rztdl.dl.buffer.InBuffer(name='input_buffer', buffer_features=2)
        cls.model.add_component(cls.input_buffer)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        print("*********Concat Operator Test Case completed successfully . . .*********")

    def test_operator_name(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests Operator Name Validation
        """
        false_names = ['op 1', 'op .', '%op']
        for name in false_names:
            try:
                rztdl.dl.operator.ConcatOperator(name, component_input=[], component_output='', dimension=0)
                assert False
            except NameError:
                assert True

    def test_create_component(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test create component
        """
        self.model.add_component(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer_1',
                                                                    layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                    layer_nodes=4,
                                                                    component_input=self.input_buffer.name))
        comp = self.model.add_component(rztdl.dl.operator.ConcatOperator(self.operator_name,
                                                                         component_input=['fully_connected_layer_1',
                                                                                          'input_buffer'],
                                                                         component_output=self.operator_output_name,
                                                                         dimension=1))
        # Test updated model architecture key is present or not
        rztdl.RZTDL_STORE.get_key_of_model_operator_architecture(self.model_name, self.operator_name)

        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, self.operator_output_name)

        # Test if added to tensorflow  collection
        assert len(tf.get_collection(comp.name)) > 0

        # Test the shape
        assert_equal(rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name,
                                                                      self.operator_output_name).get_shape().as_list(),
                     [None, 6])

    @raises(DimensionError)
    def test_tensor_dimension(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test whether all the tensor inputs have same dimension
        """
        self.model.add_component(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer_2',
                                                                    layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                    layer_nodes=4,
                                                                    component_input=self.input_buffer.name))
        self.model.add_component(rztdl.dl.layer.ConvolutionLayer('conv_layer_1',
                                                                 filter_dimensions=[2, 2, 1, 1],
                                                                 filter_strides=[1, 1, 1, 1],
                                                                 filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                                 component_input='fully_connected_layer_2'))
        self.model.add_component(rztdl.dl.operator.ConcatOperator(self.operator_name,
                                                                  component_input=['fully_connected_layer_2',
                                                                                   'conv_layer_1'],
                                                                  component_output=self.operator_output_name,
                                                                  dimension=1))

    @raises(DimensionError)
    def test_dimension_parameter(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test whether the dimension value whether is in len(shape of tensor input)
        """
        self.model.add_component(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer_3',
                                                                    layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                    layer_nodes=4,
                                                                    component_input=self.input_buffer.name))
        self.model.add_component(rztdl.dl.operator.ConcatOperator(self.operator_name,
                                                                  component_input=['fully_connected_layer_3',
                                                                                   self.input_buffer.name],
                                                                  component_output=self.operator_output_name,
                                                                  dimension=3))

    def test_mix_inputs(self):
        """
        | **@author:** Prathyush SP
        |
        | Test mix of inputs for the operator
        """
        self.model.add_component(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer_4',
                                                                    layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                    layer_nodes=10,
                                                                    component_input=self.input_buffer.name))
        f1 = self.model.add_component(rztdl.dl.layer.FullyConnectedLayer('fully_connected_layer_5',
                                                                         layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                         layer_nodes=10,
                                                                         component_input=self.input_buffer.name))
        self.model.add_component(rztdl.dl.operator.ConcatOperator(self.operator_name,
                                                                  component_input=['fully_connected_layer_4',
                                                                                   f1],
                                                                  component_output=self.operator_output_name,
                                                                  dimension=1))

    # noinspection PyDunderSlots,PyUnresolvedReferences
    @raises(AttributeError)
    def test_slots(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Slot functionality
        """
        rztdl.dl.operator.ConcatOperator(name=self.operator_name,
                                         component_input=['input_buffer', 'input_buffer'],
                                         component_output=self.operator_output_name, dimension=1).new_var_comp = 0

    @raises(SizeError)
    def test_size_error(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Size Error
        """
        self.model.add_component(rztdl.dl.operator.ConcatOperator(name=self.operator_name, dimension=0,
                                                                  component_input=['input_buffer'],
                                                                  component_output=self.operator_output_name))

    def test_blueprint_json_parameters(self):
        """
        | *@author:* Umesh Kumar
        |
        | Test Component Blueprint
        """
        blueprint_json = rztdl.dl.layer.FullyConnectedLayer.blueprint().to_json()
        x = [parameter for parameter in inspect.signature(rztdl.dl.layer.FullyConnectedLayer).parameters.keys()]
        blueprint_parameters = []
        component_parameters = ["inputs", "parameters", "outputs"]
        for each_component_parameter in component_parameters:
            for value in blueprint_json[each_component_parameter]:
                blueprint_parameters.append(value["name"])
                if "properties" in value.keys():
                    for each_property in value["properties"]:
                        if "link_to_attribute" in each_property.keys():
                            blueprint_parameters.append(each_property["link_to_attribute"])
                else:
                    blueprint_parameters.append(value["name"])
        assert_equal(set(blueprint_parameters), set(x))
