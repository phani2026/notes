# -*- coding: utf-8 -*-
"""
| @created on: 21/2/18,
| @author: Vivek A Gupta,
| @version: v0.1.6
|
| Description:
| Convolution 3D Layer Test Case
|
|Sphinx Documentation Status:
|
|..todo::
"""

import rztdl.dl
from rztdl import RZTDL_CONFIG, RZTDL_STORE
from rztdl.utils.dl_exception import ComponentException, NormalizationError, RangeError, DimensionError
from nose.tools import *
import numpy as np
import tensorflow as tf
from nose import with_setup  # optional
from rztdl.dl.helpers.tfhelpers import GraphUtils
import inspect


def setup_module():
    """
    | **@author:** Vivek A Gupta
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    pass


def teardown_module():
    """
    | **@author:** Vivek A Gupta
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    pass


def my_setup_function():
    """
    | **@author:** Vivek A Gupta
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Vivek A Gupta
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Vivek A Gupta
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestConvolution3DLayer:
    """
    | **@author:** Vivek A Gupta
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        self.conv_3D_layer_name = None

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a new method in the class is called
        """
        RZTDL_CONFIG.update_dl_config_manager(
            config_file_path='/'.join(__file__.split('/')[:-5]) + '/rztdl_testing_config.json')
        self.model.clear_components()
        self.model.add_component(self.input_buffer)

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization
        """
        print("*********Convolution 3D Layer Test Case . . .*********")
        cls.model_name = 'test_conv_3D_layer_model'
        cls.model = rztdl.dl.Model(cls.model_name)
        # noinspection PyTypeChecker
        cls.input_buffer = rztdl.dl.buffer.InBuffer(name='input_buffer', buffer_features=729).create_component(
            model_name=cls.model_name, previous_component='', component_id=1)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed
        """
        print("*********Convolution 3D Layer Test Case completed successfully . . .*********")

    def test_name_validation(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests Sample Method
        """
        false_names = ['dl_layer 1', 'dl_layer .', '%dl_layer']
        for name in false_names:
            try:
                rztdl.dl.layer.Convolution3DLayer(name=name, filter_dimensions=[5, 5, 1, 32],
                                                  filter_strides=[1, 1, 1, 1],
                                                  filter_padding=rztdl.dl.constants.PaddingType.SAME)
                raise Exception('Invalid name validated . . .')
            except NameError:
                pass

    def test_create_component(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Test Create Compoent
        :return:
        """
        temp_layer = rztdl.dl.layer.Convolution3DLayer(name='conv_3D_layer_temp_l', filter_dimensions=[5, 5, 5, 1, 32],
                                                       filter_strides=[1, 1, 1, 1, 1],
                                                       filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                       component_input=self.input_buffer.name).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer,
            component_id=2)

        # Test TF Collection Insertion
        assert len(tf.get_collection(temp_layer.component_output)) == 1

        # Test Dropout
        temp_layer = rztdl.dl.layer.Convolution3DLayer(name='conv_3D_layer_dp', filter_dimensions=[5, 5, 5, 1, 32],
                                                       filter_strides=[1, 1, 1, 1, 1],
                                                       filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                       layer_dropout=0.5,
                                                       component_input=self.input_buffer.name).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer,
            component_id=2)
        assert '/dropout/' in temp_layer.component_output
        #
        # Test Normalization
        temp_layer = rztdl.dl.layer.Convolution3DLayer(name='conv_3D_layer_norm',
                                                       filter_dimensions=[5, 5, 5, 1, 32],
                                                       filter_strides=[1, 1, 1, 1, 1],
                                                       filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                       normalisation=rztdl.dl.constants.NormalizationType.l2_norm(),
                                                       component_input=self.input_buffer.name
                                                       ).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer,
            component_id=2)
        assert '/l2_norm' in temp_layer.component_output

        # Complete Manual Given
        temp_layer = rztdl.dl.layer.Convolution3DLayer(name='conv_3D_layer_weights_manual',
                                                       filter_dimensions=[2, 2, 2, 1, 1],
                                                       filter_strides=[1, 1, 1, 1, 1],
                                                       filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                       layer_filter=np.array([[[[[1.0, 1.0]], [[1.0, 3.0]]]]],
                                                                             dtype=np.float32),
                                                       layer_bias=np.array([1.0, 2.0],
                                                                           dtype=np.float32),
                                                       component_input=self.input_buffer.name
                                                       ).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert "<tf.Variable 'test_conv_3D_layer_model/conv_3D_layer_weights_manual/weights/Variable:0' shape=(1, 1, 2, 1, 2) dtype=float32_ref>" == GraphUtils.get_variable(
            name=temp_layer.layer_filter).__str__()
        assert "<tf.Variable 'test_conv_3D_layer_model/conv_3D_layer_weights_manual/biases/Variable:0' shape=(2,) dtype=float32_ref>" == GraphUtils.get_variable(
            name=temp_layer.layer_bias).__str__()

        # Semi Automated
        temp_layer = rztdl.dl.layer.Convolution3DLayer(name='conv_3D_layer_weights_semi',
                                                       filter_dimensions=[2, 2, 2, 1, 1],
                                                       filter_strides=[1, 1, 1, 1, 1],
                                                       filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                       layer_filter=rztdl.dl.constants.InitializerType.ones(),
                                                       layer_bias=rztdl.dl.constants.InitializerType.random_uniform(),
                                                       component_input=self.input_buffer.name
                                                       ).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert 'Tensor("test_conv_3D_layer_model/conv_3D_layer_weights_semi/weights/ones:0", shape=(2, 2, 2, 1, 1), dtype=float32)' == str(
            GraphUtils.get_variable(name=temp_layer.layer_filter).initial_value)
        assert 'Tensor("test_conv_3D_layer_model/conv_3D_layer_weights_semi/biases/random_uniform:0", shape=(1,), dtype=float32)' == str(
            GraphUtils.get_variable(name=temp_layer.layer_bias).initial_value)

        # Test Tensorflow Collection
        assert len(tf.get_collection(temp_layer.layer_filter)) == 1
        assert len(tf.get_collection(temp_layer.layer_bias)) == 1

        # Test DAG Insertion
        # self.model.add_layer(temp_layer)
        self.model.add_component(rztdl.dl.buffer.InBuffer('in_l', buffer_features=64))
        self.model.add_component(rztdl.dl.layer.Convolution3DLayer('test_conv_3D_layer_ins',
                                                                   filter_dimensions=[2, 2, 2, 1, 1],
                                                                   filter_strides=[1, 1, 1, 1, 1],
                                                                   filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                                   component_input='in_l'
                                                                   ))
        RZTDL_STORE.get_weights(model_name=self.model_name, layer_name='test_conv_3D_layer_ins')
        RZTDL_STORE.get_bias(model_name=self.model_name, layer_name='test_conv_3D_layer_ins')

        # Test Layer Activation
        temp_layer = rztdl.dl.layer.Convolution3DLayer(name='conv_3D_layer_activation_test',
                                                       layer_activation=rztdl.dl.constants.ActivationType.SOFT_SIGN,
                                                       filter_dimensions=[2, 2, 2, 1, 1],
                                                       filter_strides=[1, 1, 1, 1, 1],
                                                       filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                       component_input=self.input_buffer.name
                                                       ).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert 'Softsign' in temp_layer.component_output

        # Test Auto Tensor Conversion
        self.model.add_component(rztdl.dl.buffer.InBuffer("input_layer2d", buffer_features=729))
        RZTDL_CONFIG.TensorflowConfig.AUTO_TENSOR_CONVERSION = False
        try:
            self.model.add_component(rztdl.dl.layer.Convolution3DLayer('conv_3D_layer_dim_test',
                                                                       filter_dimensions=[2, 2, 2, 1, 1],
                                                                       filter_strides=[1, 1, 1, 1, 1],
                                                                       filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                                       component_input='input_layer2d',
                                                                       ))
            assert False
        except DimensionError:
            assert True
        RZTDL_CONFIG.TensorflowConfig.AUTO_TENSOR_CONVERSION = True
        self.model.add_component(
            rztdl.dl.layer.Convolution3DLayer('con1', layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                              filter_dimensions=[5, 5, 5, 1, 32], filter_strides=[1, 1, 1, 1, 1],
                                              filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                              component_input='input_layer2d'),
        )

        # Test Layer Input
        # Test Tensor as Layer Input
        self.model.add_component(
            rztdl.dl.layer.Convolution3DLayer('test_conv_3D_layer_input_tensor',
                                              filter_dimensions=[2, 2, 2, 1, 1],
                                              filter_strides=[1, 1, 1, 1, 1],
                                              filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                              component_input=GraphUtils.get_tensor(
                                                  name=self.input_buffer.component_output)))
        # Test String as Layer Input
        self.model.add_component(
            rztdl.dl.layer.Convolution3DLayer('test_conv_3D_layer_input_str',
                                              filter_dimensions=[2, 2, 2, 1, 1],
                                              filter_strides=[1, 1, 1, 1, 1],
                                              filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                              component_input='input_layer2d'))

    def test_dropout_range_error(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Test Layer Dropout
        :return:
        """
        try:
            rztdl.dl.layer.Convolution3DLayer(name='conv_3D_layer_drop_test', layer_dropout=-0.2,
                                              filter_dimensions=[2, 2, 2, 1, 1],
                                              filter_strides=[1, 1, 1, 1, 1],
                                              filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                              component_input=self.input_buffer.name
                                              ).create_component(
                model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
            assert False
        except RangeError:
            assert True
        try:
            rztdl.dl.layer.Convolution3DLayer(name='conv_3D_layer_drop_test', layer_dropout=1.2,
                                              filter_dimensions=[2, 2, 2, 1, 1],
                                              filter_strides=[1, 1, 1, 1, 1],
                                              filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                              component_input=self.input_buffer.name
                                              ).create_component(
                model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
            assert False
        except RangeError:
            assert True

    @raises(NormalizationError)
    def test_normalization_error(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Normalization
        """
        rztdl.dl.layer.Convolution3DLayer(name='conv3d_layer_norm_test',
                                          filter_dimensions=[2, 2, 2, 1, 1],
                                          filter_strides=[1, 1, 1, 1, 1],
                                          filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                          normalisation=rztdl.dl.constants.NormalizationType.lrn_norm(),
                                          component_input=self.input_buffer.name).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer, component_id=2)

    def test_component_exception(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Component Exception
        """

        # 1. Component Input is of type tensor
        # noinspection PyTypeChecker
        self.this_ip_buffer_1 = rztdl.dl.buffer.InBuffer(name='this_ip_buffer_1', buffer_features=0).create_component(
            model_name=self.model_name, previous_component=None, component_id=1)

        try:
            rztdl.dl.layer.Convolution3DLayer(name='conv3d_layer_excep_test_1',
                                              filter_dimensions=[2, 2, 1, 1, 1],
                                              filter_strides=[1, 1, 1, 1, 1],
                                              filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                              component_input=GraphUtils.get_tensor(
                                                  self.this_ip_buffer_1.component_output)).create_component(
                model_name=self.model_name,
                previous_component=self.this_ip_buffer_1,
                component_id=2)
            assert False
        except ComponentException:
            assert True

        # 2. Component Input is of type String

        try:
            rztdl.dl.layer.Convolution3DLayer(name='conv3d_layer_excep_test_2',
                                              filter_dimensions=[2, 2, 1, 1, 1],
                                              filter_strides=[1, 1, 1, 1, 1],
                                              filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                              component_input=self.this_ip_buffer_1.name).create_component(
                model_name=self.model_name,
                previous_component=self.this_ip_buffer_1,
                component_id=2)
            assert False
        except ComponentException:
            assert True

        # 3. Fetch from previous component if component is of type layer
        try:
            cl = rztdl.dl.layer.Convolution3DLayer(name='conv3d_layer_excep_test_2',
                                                   filter_dimensions=[2, 2, 1, 1, 1],
                                                   filter_strides=[1, 1, 1, 1, 1],
                                                   filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                   component_input=self.this_ip_buffer_1.name).create_component(
                model_name=self.model_name,
                previous_component=self.this_ip_buffer_1,
                component_id=2)
            cl.component_output = None
            rztdl.dl.layer.Convolution3DLayer(name='conv3d_layer_excep_test_3',
                                              filter_dimensions=[2, 2, 1, 1, 1],
                                              filter_strides=[1, 1, 1, 1, 1],
                                              filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                              ).create_component(
                model_name=self.model_name,
                previous_component=cl,
                component_id=2)
            assert False
        except ComponentException:
            assert True

    # noinspection PyDunderSlots,PyUnresolvedReferences
    @raises(AttributeError)
    def test_slots(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Slot functionality
        """
        rztdl.dl.layer.Convolution3DLayer(name='test_convolution3d_layer', filter_dimensions=[2, 2, 1, 1, 1],
                                          filter_strides=[1, 1, 1, 1, 1],
                                          filter_padding=rztdl.dl.constants.PaddingType.SAME).new_var_comp = 0

    def test_names(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Names
        | 1. Layer Filter
        | 2. Layer Bias
        | 3. Layer Output
        """
        temp_layer = rztdl.dl.layer.Convolution3DLayer(name='conv3d_layer_name_test',
                                                       filter_dimensions=[2, 2, 1, 1, 1],
                                                       filter_strides=[1, 1, 1, 1, 1],
                                                       filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                       layer_filter_output='conv3d_layer_name_test_weight',
                                                       layer_bias_output='conv3d_layer_name_test_bias',
                                                       component_output='conv3d_layer_name_test_output',
                                                       component_input=self.input_buffer.name).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer,
            component_id=2)

        # Check in Tensorflow Collection
        assert len(tf.get_collection(temp_layer.layer_filter_name)) == 1
        assert len(tf.get_collection(temp_layer.layer_bias_name)) == 1
        assert len(tf.get_collection(temp_layer.component_output_name)) == 1
        assert len(tf.get_collection(temp_layer.component_output)) == 1

        # Check in RZTDL Store
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=temp_layer.name)
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=temp_layer.layer_filter_name)
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=temp_layer.layer_bias_name)
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=temp_layer.component_output_name)

    def test_tensorboard_summaries(self):
        """
        | **@author:** Prathyush SP
        |
        | Test tensorboard summaries
        """

        # Default True
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = True
        rztdl.dl.layer.Convolution3DLayer(name='conv3d_layer_sum_test_1',
                                          filter_dimensions=[2, 2, 1, 1, 1],
                                          filter_strides=[1, 1, 1, 1, 1],
                                          filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                          component_input=self.input_buffer.name).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer,
            component_id=2)

        summary_collection = [coll.name for coll in tf.get_collection(tf.GraphKeys.SUMMARIES)]
        assert 'conv3d_layer_sum_test_1/weights/' in summary_collection[0]
        assert 'conv3d_layer_sum_test_1/biases/' in summary_collection[6]
        assert 'conv3d_layer_sum_test_1/summaries/' in summary_collection[-1]

        # Default False
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = False
        rztdl.dl.layer.Convolution3DLayer(name='conv3d_layer_sum_test_2',
                                          filter_dimensions=[2, 2, 1, 1, 1],
                                          filter_strides=[1, 1, 1, 1, 1],
                                          filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                          component_input=self.input_buffer.name).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer,
            component_id=2)
        assert len(tf.get_collection(tf.GraphKeys.SUMMARIES)) == len(summary_collection)

        # Parameter False
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = True
        rztdl.dl.layer.Convolution3DLayer(name='conv3d_layer_sum_test_3',
                                          filter_dimensions=[2, 2, 1, 1, 1],
                                          filter_strides=[1, 1, 1, 1, 1],
                                          filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                          component_input=self.input_buffer.name,
                                          layer_summaries=False).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer,
            component_id=2)
        assert len(tf.get_collection(tf.GraphKeys.SUMMARIES)) == len(summary_collection)

        # Parameter True
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = False
        rztdl.dl.layer.Convolution3DLayer(name='conv3d_layer_sum_test_4',
                                          filter_dimensions=[2, 2, 1, 1, 1],
                                          filter_strides=[1, 1, 1, 1, 1],
                                          filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                          component_input=self.input_buffer.name,
                                          layer_summaries=True).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer,
            component_id=2)
        assert len(tf.get_collection(tf.GraphKeys.SUMMARIES)) > len(summary_collection)


    def test_layer_scopes(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer scopes
        """
        layer_scopes = ['xyz', 'abc']
        rztdl.dl.layer.Convolution3DLayer(name='conv3d_layer_sum_test_5',
                                        filter_dimensions=[2, 2, 1, 1,1],
                                        filter_strides=[1, 1, 1, 1,1],
                                        filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                        component_input=self.input_buffer.name,
                                        layer_scopes=layer_scopes).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)

        for scope in layer_scopes:
            if scope in RZTDL_STORE.get_scopes_of_model_components(model_name=self.model_name).keys():
                assert True
                continue
            assert False

        for scope_name, scopes in RZTDL_STORE.get_scopes_of_model_components(model_name=self.model_name).items():
            assert self.model_name+'/conv3d_layer_sum_test_5/weights/Variable:0' in scopes
            assert self.model_name+'/conv3d_layer_sum_test_5/biases/Variable:0' in scopes

        try:
            layer_scopes = ['xyz,-', 'abc']
            rztdl.dl.layer.Convolution3DLayer(name='conv3d_layer_sum_test_6',
                                            filter_dimensions=[2, 2, 1, 1,1],
                                            filter_strides=[1, 1, 1, 1,1],
                                            filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                            component_input=self.input_buffer.name,
                                            layer_scopes=layer_scopes, ).create_component(
                model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
            assert False
        except NameError:
            assert True

    def test_blueprint_json_parameters(self):
        """
        **@author:** Himaprasoon PT : copied from umesh's test_fully_connected_layer

        :return:
        """
        blueprint_json = rztdl.dl.layer.Convolution3DLayer.blueprint().to_json()
        x = [parameter for parameter in inspect.signature(rztdl.dl.layer.Convolution3DLayer).parameters.keys()]
        input_parameters = [value["name"] for value in blueprint_json["inputs"]]
        component_parameters = [value["name"] for value in blueprint_json["parameters"]]
        output_parameters = [value["name"] for value in blueprint_json["outputs"]]
        blueprint_parameters = input_parameters + component_parameters + output_parameters
        assert_equal(set(blueprint_parameters), set(x))
        assert rztdl.dl.layer.Convolution3DLayer.blueprint().to_json() == blueprint_json
