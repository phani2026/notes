# # -*- coding: utf-8 -*-
# """
# | **@created on:** 16/12/16,
# | **@author:** Prathyush SP,
# | **@version:** v0.0.1
# |
# | **Description:**
# | DL Module Tests
# | **Sphinx Documentation Status:** Complete
# |
# ..todo::
#
# """
#
# import rztdl.dl
# from rztdl import RZTDL_STORE
# from rztdl.utils.dl_exception import ShapeError
# from nose.tools import *
# import tensorflow as tf
# from nose import with_setup  # optional
#
#
# def setup_module():
#     """
#     | **@author:** Prathyush SP
#     |
#     | DL Module Setup - Called when this module is initialized - First Call
#     """
#     pass
#
#
# def teardown_module():
#     """
#     | **@author:** Prathyush SP
#     |
#     | DL Module Teardown - Called when this module is completed - Last Call
#     """
#     pass
#
#
# def my_setup_function():
#     """
#     | **@author:** Prathyush SP
#     |
#     | Custom Setup function
#     """
#     pass
#
#
# def my_teardown_function():
#     """
#     | **@author:** Prathyush SP
#     |
#     | Custom Teardown function
#     """
#     pass
#
#
# @with_setup(my_setup_function, my_teardown_function)
# def test_simple():
#     """
#     | **@author:** Prathyush SP
#     |
#     | Test function utilizing custom setup and teardown
#     """
#     pass
#
#
# class TestInputLayer:
#     """
#     | **@author:** Prathyush SP
#     |
#     | Model Module Test Cases
#     """
#
#     def __init__(self):
#         """
#         | One time class Initialization
#         """
#
#         pass
#
#     def setup(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Runs before a new method in the class is called
#         """
#         pass
#
#     def teardown(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Runs after each method is called
#         """
#         pass
#
#     @classmethod
#     def setup_class(cls):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Runs during class initialization
#         """
#         print("*********Input Layer Test Case . . .*********")
#         cls.model_name = 'test_input_layer_model'
#         cls.model = rztdl.dl.Model(cls.model_name)
#         pass
#
#     @classmethod
#     def teardown_class(cls):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Runs after class reference is removed / class test cases are completed
#         """
#         print("*********Input Layer Test Case completed successfully . . .*********")
#
#     def test_name_validation(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Tests Sample Method
#         """
#         false_names = ['dl_layer 1', 'dl_layer .', '%dl_layer']
#         for name in false_names:
#             try:
#                 rztdl.dl.dl_layer.InputLayer(name=name, layer_nodes=10)
#                 raise Exception('Invalid name validated . . .')
#             except NameError:
#                 pass
#
#     @raises(ShapeError)
#     def test_layer_shape_exception(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Raise exception when Layer nodes and Layer Shape is None
#         :return:
#         """
#         rztdl.dl.dl_layer.InputLayer(name='dl_layer').create_layer(model_name='a', layer='1', layer_id=1)
#
#     def test_layer_insertions(self):
#         """
#         | **@author:** Prathyush SP
#         :return:
#         """
#         layer_name = 'input_layer'
#         input_layer = self.model.add_layer(rztdl.dl.dl_layer.InputLayer(name=layer_name, layer_nodes=10))
#         # Test tf.collection
#         assert len(tf.get_collection(input_layer.name)) == 1
#         # Test RZTDL DAG for placeholder insertion
#         RZTDL_STORE.get_placeholder(model_name=self.model_name, layer_name=layer_name)
