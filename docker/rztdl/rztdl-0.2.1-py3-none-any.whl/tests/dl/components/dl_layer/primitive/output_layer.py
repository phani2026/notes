# # -*- coding: utf-8 -*-
# """
# | **@created on:** 16/12/16,
# | **@author:** Prathyush SP,
# | **@version:** v0.0.1
# |
# | **Description:**
# | DL Module Tests
# | **Sphinx Documentation Status:** Complete
# |
# ..todo::
# 
# """
# import copy
# 
# import rztdl.dl
# from rztdl import RZTDL_DAG, RZTDL_CONFIG
# from rztdl.utils.dl_exception import DimensionError, LayerException, ActivationError
# import numpy as np
# from nose.tools import *
# import tensorflow as tf
# from nose import with_setup  # optional
# 
# 
# def setup_module():
#     """
#     | **@author:** Prathyush SP
#     |
#     | DL Module Setup - Called when this module is initialized - First Call
#     """
#     pass
# 
# 
# def teardown_module():
#     """
#     | **@author:** Prathyush SP
#     |
#     | DL Module Teardown - Called when this module is completed - Last Call
#     """
#     pass
# 
# 
# def my_setup_function():
#     """
#     | **@author:** Prathyush SP
#     |
#     | Custom Setup function
#     """
#     pass
# 
# 
# def my_teardown_function():
#     """
#     | **@author:** Prathyush SP
#     |
#     | Custom Teardown function
#     """
#     pass
# 
# 
# @with_setup(my_setup_function, my_teardown_function)
# def test_simple():
#     """
#     | **@author:** Prathyush SP
#     |
#     | Test function utilizing custom setup and teardown
#     """
#     pass
# 
# 
# class TestOutputLayer:
#     """
#     | **@author:** Prathyush SP
#     |
#     | Model Module Test Cases
#     """
# 
#     def __init__(self):
#         """
#         | One time class Initialization
#         """
#         self.op_layer_name = None
#         pass
# 
#     def setup(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Runs before a new method in the class is called
#         """
# 
#         pass
# 
#     def teardown(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Runs after each method is called
#         """
#         pass
# 
#     @classmethod
#     def setup_class(cls):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Runs during class initialization
#         """
#         print("*********Output Layer Test Case . . .*********")
#         cls.model_name = 'test_op_layer_model'
#         cls.model = rztdl.dl.Model(cls.model_name)
#         cls.input_layer = rztdl.dl.layer.InputLayer(name='inp_layer', layer_nodes=2).create_layer(cls.model_name, '',
#                                                                                                   1)
# 
#     @classmethod
#     def teardown_class(cls):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Runs after class reference is removed / class test cases are completed
#         """
#         print("*********Output Layer Test Case completed successfully . . .*********")
# 
#     def test_name_validation(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Tests Sample Method
#         """
#         false_names = ['layer 1', 'layer .', '%layer']
#         for name in false_names:
#             try:
#                 rztdl.dl.layer.FullyConnectedLayer(name=name, layer_nodes=10)
#                 raise Exception('Invalid name validated . . .')
#             except NameError:
#                 pass
# 
#     def test_create_layer(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Test Create Layer
#         :return:
#         """
#         temp_layer = rztdl.dl.layer.OutputLayer(name='op_layer', layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
#                                                 layer_nodes=1).create_layer(model_name=self.model_name,
#                                                                             layer=self.input_layer,
#                                                                             layer_id=2)
# 
#         # Test TF Collection Insertion
#         assert len(tf.get_collection(temp_layer.layer_output)) == 1
#         # todo: Prathyush SP - Test if scalar summary is being created - No easy way in v1.1
#         # Test Layer Weights and Bias
# 
#         # Auto Generated:
#         assert "<tf.Variable 'test_op_layer_model/op_layer/weights/Variable:0' shape=(2, 1) dtype=float32_ref>" == temp_layer.get_variable(temp_layer.layer_weights).__str__()
#         assert "<tf.Variable 'test_op_layer_model/op_layer/biases/Variable:0' shape=(1,) dtype=float32_ref>" == temp_layer.get_variable(temp_layer.layer_bias).__str__()
# 
#         # Complete Manual Given
#         temp_layer = rztdl.dl.layer.OutputLayer(name='op_layer_weights_manual',
#                                                 layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
#                                                 layer_weights=np.array([[1.0, 1.0], [1.0, 3.0]],
#                                                                        dtype=np.float32),
#                                                 layer_bias=np.array([[1.0], [2.1]],
#                                                                     dtype=np.float32),
#                                                 layer_nodes=2).create_layer(model_name=self.model_name,
#                                                                             layer=self.input_layer, layer_id=2)
# 
#         assert "<tf.Variable 'test_op_layer_model/op_layer_weights_manual/weights/Variable:0' shape=(2, 2) dtype=float32_ref>" == temp_layer.get_variable(temp_layer.layer_weights).__str__()
#         assert "<tf.Variable 'test_op_layer_model/op_layer_weights_manual/biases/Variable:0' shape=(2, 1) dtype=float32_ref>" == temp_layer.get_variable(temp_layer.layer_bias).__str__()
# 
#         # Semi Automated
#         temp_layer = rztdl.dl.layer.OutputLayer(name='op_layer_weights_semi',
#                                                 layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
#                                                 layer_weights=rztdl.dl.constants.INITIALIZER.random_normal(),
#                                                 layer_bias=rztdl.dl.constants.INITIALIZER.zeros(),
#                                                 layer_nodes=2).create_layer(model_name=self.model_name,
#                                                                             layer=self.input_layer, layer_id=2)
#         assert 'Tensor("test_op_layer_model/op_layer_weights_semi/weights/random_normal:0", shape=(2, 2), dtype=float32)' == str(
#             temp_layer.get_variable(temp_layer.layer_weights).initial_value)
#         assert 'Tensor("test_op_layer_model/op_layer_weights_semi/biases/zeros:0", shape=(2,), dtype=float32)' == str(
#             temp_layer.get_variable(temp_layer.layer_bias).initial_value)
# 
#         # Test Tensorflow Collection
#         assert len(tf.get_collection(temp_layer.layer_weights)) == 1
#         assert len(tf.get_collection(temp_layer.layer_bias)) == 1
# 
#         # Test DAG Insertion
#         self.model.add_layer(rztdl.dl.layer.InputLayer('in_l', layer_nodes=4))
#         self.model.add_layer(
#             rztdl.dl.layer.OutputLayer('test_op_layer_ins', layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
#                                        layer_nodes=1))
#         RZTDL_DAG.get_weights(model_name=self.model_name, layer_name='test_op_layer_ins')
#         RZTDL_DAG.get_bias(model_name=self.model_name, layer_name='test_op_layer_ins')
# 
#         # Test Layer Activation
#         temp_layer = rztdl.dl.layer.OutputLayer(name='op_layer_activation_test',
#                                                 layer_activation=rztdl.dl.constants.ActivationType.SOFT_SIGN,
#                                                 layer_nodes=2).create_layer(model_name=self.model_name,
#                                                                             layer=self.input_layer, layer_id=2)
#         assert 'Softsign' in temp_layer.layer_output
# 
#         # Test Auto Tensor Conversion
#         self.model.add_layer(rztdl.dl.layer.InputLayer("input_layer4d", layer_nodes=729))
#         self.model.add_layer(
#             rztdl.dl.layer.ConvolutionLayer('con1', layer_activation=rztdl.dl.constants.ActivationType.RELU,
#                                             filter_dimensions=[5, 5, 1, 32], filter_strides=[1, 1, 1, 1],
#                                             filter_padding=rztdl.dl.constants.PADDING.SAME))
#         RZTDL_CONFIG.TensorflowConfig.AUTO_TENSOR_CONVERSION = False
#         try:
#             self.model.add_layer(
#                 rztdl.dl.layer.OutputLayer('op_layer_dim_test', layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
#                                            layer_nodes=1))
#             assert False
#         except DimensionError:
#             assert True
#         RZTDL_CONFIG.TensorflowConfig.AUTO_TENSOR_CONVERSION = True
#         self.model.add_layer(rztdl.dl.layer.OutputLayer('op_layer_dim_test_1', layer_input='con1',
#                                                         layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
#                                                         layer_nodes=1))
#         op_layer = self.model.get_layer('op_layer_dim_test_1')
#         assert 'Tensor("test_op_layer_model/op_layer_dim_test_1/auto_tensor_conversion/Reshape:0", shape=(?, 23328), dtype=float32)' == op_layer.get_tensor(name=op_layer.layer_input).__str__()
#         RZTDL_DAG.get_placeholder(model_name=self.model_name, layer_name='op_layer_dim_test_1')
# 
#         # Test Layer Input
#         # Test Tensor as Layer Input
#         self.model.add_layer(
#             rztdl.dl.layer.OutputLayer('test_op_layer_input_tensor',
#                                        layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
#                                        layer_input=self.input_layer.get_tensor(self.input_layer.layer_output), layer_nodes=1))
#         # Test String as Layer Input
#         self.model.add_layer(
#             rztdl.dl.layer.OutputLayer('test_op_layer_input_str',
#                                        layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
#                                        layer_input='op_layer_dim_test_1', layer_nodes=1))
# 
#     @raises(ActivationError)
#     def test_activation_error(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Test Layer Activation
#         :return:
#         """
#         rztdl.dl.layer.OutputLayer(name='op_layer_act_test', layer_activation='abcd',
#                                    layer_nodes=1).create_layer(
#             model_name=self.model_name,
#             layer=self.input_layer, layer_id=2)
# 
#     def test_layer_exception(self):
#         """
#         | **@author:** Prathyush SP
#         |
#         | Test Layer Exception
#         :return:
#         """
#         this_ip_layer = copy.copy(self.input_layer)
#         this_ip_layer.layer_nodes = 0
# 
#         try:
#             rztdl.dl.layer.OutputLayer(name='op_layer_excep_test',
#                                        layer_activation=rztdl.dl.constants.ActivationType.SIGMOID, layer_nodes=1
#                                        ).create_layer(model_name=self.model_name, layer=this_ip_layer, layer_id=2)
#             assert False
#         except LayerException:
#             assert True
# 
#         this_ip_layer.layer_output = None
#         try:
#             rztdl.dl.layer.OutputLayer(name='op_layer_excep_test',
#                                        layer_activation=rztdl.dl.constants.ActivationType.SIGMOID, layer_nodes=1
#                                        ).create_layer(model_name=self.model_name, layer=this_ip_layer, layer_id=2)
#             assert False
#         except LayerException:
#             assert True
