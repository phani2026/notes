# # -*- coding: utf-8 -*-
# """
# | **@created on:** 16/12/16,
# | **@author:** Prathyush SP,
# | **@version:** v0.0.1
# |
# | **Description:**
# | DL Module Tests
# | **Sphinx Documentation Status:** Complete
# |
# ..todo::
#
# """
#
# import rztdl.dl
# import rztdl.utils.string_constants as constants
# from nose.tools import *
# from rztdl.utils.dl_exception import SizeError, RangeError, ActivationError
# from rztdl.utils.string_constants import RNNCell
# from rztdl.utils.dl_exception import keyexception
#
#
# def setup_module():
#     """
#     | **@author:** Prathyush SP
#     |
#     | DL Module Setup - Called when this module is initialized - First Call
#     """
#     pass
#
#
# def teardown_module():
#     """
#     | **@author:** Prathyush SP
#     |
#     | DL Module Teardown - Called when this module is completed - Last Call
#     """
#     pass
#
#
# def my_setup_function():
#     """
#     | **@author:** Prathyush SP
#     |
#     | Custom Setup function
#     """
#     pass
#
#
# def my_teardown_function():
#     """
#     | **@author:** Prathyush SP
#     |
#     | Custom Teardown function
#     """
#     pass
#
#
# @with_setup(my_setup_function, my_teardown_function)
# def test_simple():
#     """
#     | **@author:** Prathyush SP
#     |
#     | Test function utilizing custom setup and teardown
#     """
#     pass
#
#
# class TestRNNBlock:
#     """
#     | **@author:** Sumith Krishna
#     |
#     | Model Module Test Cases
#     """
#
#     def __init__(self):
#         """
#         | One time class Initialization
#         """
#         pass
#
#     def setup(self):
#         """
#         | **@author:** Sumith Krishna
#         |
#         | Runs before a new method in the class is called
#         """
#
#         pass
#
#     def teardown(self):
#         """
#         | **@author:** Sumith Krishna
#         |
#         | Runs after each method is called
#         """
#
#         pass
#
#     @classmethod
#     def setup_class(cls):
#         """
#         | **@author:** Sumith Krishna
#         |
#         | Class level setup
#         """
#         print("*********RNNLayer Test Case . . .*********")
#         cls.model_name = 'test_rnn_block'
#         cls.model = rztdl.dl.Model(cls.model_name)
#         cls.input_layer = rztdl.dl.layer.InputLayer(name='input_layer', layer_nodes=3, layer_shape=[None, 12, 24])
#         cls.x = cls.model.add_layer(cls.input_layer)
#
#     @classmethod
#     def teardown_class(cls):
#         """
#         | **@author:** Sumith Krishna
#         |
#         | Class level teardown
#         """
#         print("*********RNNLayer Test Case completed successfully . . .*********")
#
#     def test_name_validation(self):
#         """
#         | **@author:** Sumith Krishna
#         |
#         | Test Name Validation
#         """
#         false_names = ['dl_layer 1', 'dl_layer .', '%dl_layer']
#         cell1 = RNNCell.basic_lstm_cell(num_units=18, activation=constants.ACTIVATION.RELU)
#         for name in false_names:
#             try:
#                 rztdl.dl.layer.RNNLayer(name=name, layer_input=rztdl.dl.constants.OPERATOR_OUTPUT.get_output(
#                     name="unstack_op", start_index=0, end_index=24), layer_cells=[cell1])
#                 raise Exception('Invalid name validated . . .')
#             except NameError:
#                 pass
#
#     def test_create_layer_multiple_cell(self):
#         """
#         | **@author:** Sumith Krishna
#         |
#         | Test Create multiple rnn cell
#         """
#         cell1 = RNNCell.basic_lstm_cell(num_units=18, activation=constants.ACTIVATION.RELU)
#         cell2 = RNNCell.gru_cell(num_units=24, activation=constants.ACTIVATION.RELU)
#         cell3 = RNNCell.lstm_cell(num_units=24, activation=constants.ACTIVATION.RELU)
#         cell4 = RNNCell.basic_rnn_cell(num_units=128, activation=constants.ACTIVATION.TANH)
#         self.model.add_operator(rztdl.dl.operator.UnstackOperator("unstack1", operator_input="input_layer",
#                                                                   operator_output="unstack_op", no_of_sequences=24,
#                                                                   dimension=2))
#         temp_layer = rztdl.dl.layer.RNNLayer(name='rnn_layer_1',
#                                              layer_input=rztdl.dl.constants.OPERATOR_OUTPUT.get_output(
#                                                  name="unstack_op", start_index=0, end_index=24),
#                                              layer_cells=[cell1, cell2, cell3, cell4])
#         self.model.add_layer(temp_layer)
#
#         assert 128 == temp_layer.layer_nodes
#
#     @raises(ActivationError)
#     def test_invalid_activation_function(self):
#         """
#         | **@author:** Sumith Krishna
#         |
#         | Test dl_layer activation exception
#         """
#         cell1 = RNNCell.basic_lstm_cell(num_units=18, activation='abc')
#         rztdl.dl.layer.RNNLayer(name='rnn_layer_2', layer_input=rztdl.dl.constants.OPERATOR_OUTPUT.get_output(
#             name="unstack_op", start_index=0, end_index=24), layer_cells=[cell1]).create_layer \
#             (model_name=self.model_name, layer=self.input_layer, layer_id=4)
#
#     @raises(RangeError)
#     def test_invalid_hidden_units(self):
#         """
#         | **@author:** Sumith Krishna
#         |
#         | Test dl_layer hidden units exception
#         """
#         cell1 = RNNCell.basic_lstm_cell(num_units=-1, activation=constants.ACTIVATION.TANH)
#         rztdl.dl.layer.RNNLayer(name='rnn_layer_3', layer_input=rztdl.dl.constants.OPERATOR_OUTPUT.get_output(
#             name="unstack_op", start_index=0, end_index=24), layer_cells=[cell1]).create_layer \
#             (model_name=self.model_name, layer=self.input_layer, layer_id=5)
#
#     @raises(RangeError)
#     def test_invalid_forget_bias(self):
#         """
#         | **@author:** Sumith Krishna
#         |
#         | Test forget bias exception
#         """
#         cell1 = RNNCell.basic_lstm_cell(num_units=18, activation=constants.ACTIVATION.TANH, forget_bias=2.0)
#         rztdl.dl.layer.RNNLayer(name='rnn_layer_4', layer_input=rztdl.dl.constants.OPERATOR_OUTPUT.get_output(
#             name="unstack_op", start_index=0, end_index=24), layer_cells=[cell1]).create_layer \
#             (model_name=self.model_name, layer=self.input_layer, layer_id=6)
#
#     @raises(SizeError)
#     def test_invalid_cell_length(self):
#         """
#         | **@author:** Sumith Krishna
#         |
#         | Test cell length exception
#         """
#         rztdl.dl.layer.RNNLayer(name='rnn_layer_4', layer_input=rztdl.dl.constants.OPERATOR_OUTPUT.get_output(
#             name="unstack_op", start_index=0, end_index=24), layer_cells=[]).create_layer \
#             (model_name=self.model_name, layer=self.input_layer, layer_id=6)
#
#     def test_invalid_layer_input(self):
#         """
#         | **@author:** Sumith Krishna
#         |
#         | Test dl_layer input exception
#         """
#         try :
#             cell1 = RNNCell.basic_lstm_cell(num_units=18, activation=constants.ACTIVATION.TANH, forget_bias=0.6)
#             rztdl.dl.layer.RNNLayer(name='rnn_layer_4', layer_input=rztdl.dl.constants.OPERATOR_OUTPUT.get_output(
#                 name="unstack_op1", start_index=0, end_index=24), layer_cells=[cell1]).create_layer \
#                 (model_name=self.model_name, layer=self.input_layer, layer_id=6)
#         except:
#             assert True
