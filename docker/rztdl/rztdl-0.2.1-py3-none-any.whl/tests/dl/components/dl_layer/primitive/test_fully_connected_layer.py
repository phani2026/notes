# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Fully Connected Layer Test Cases
|
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import inspect
import numpy as np
import rztdl.dl
from rztdl import RZTDL_STORE, RZTDL_CONFIG
from rztdl.utils.dl_exception import ComponentException, NormalizationError, RangeError, DimensionError
from nose.tools import *
import tensorflow as tf
from nose import with_setup  # optional
from rztdl.dl.helpers.tfhelpers import GraphUtils


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    pass


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    pass


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestFullyConnectedLayer:
    """
    | **@author:** Prathyush SP
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        self.fc_layer_name = None

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method in the class is called
        """
        RZTDL_CONFIG.update_dl_config_manager(
            config_file_path='/'.join(__file__.split('/')[:-5]) + '/rztdl_testing_config.json')
        self.model.clear_components()
        self.model.add_component(self.input_buffer)

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        print("*********Fully Connected Layer Test Case . . .*********")
        cls.model_name = 'test_fully_connected_layer_model'
        cls.model = rztdl.dl.Model(cls.model_name)
        # noinspection PyTypeChecker
        cls.input_buffer = rztdl.dl.buffer.InBuffer(name='inp_buffer', buffer_features=2).create_component(
            model_name=cls.model_name, previous_component=None, component_id=1)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        print("*********Fully Connected Layer Test Case completed successfully . . .*********")

    def test_name_validation(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests Sample Method
        """
        false_names = ['layer 1', 'layer .', '%layer']
        for name in false_names:
            try:
                rztdl.dl.layer.FullyConnectedLayer(name=name, layer_nodes=10)
                raise Exception('Invalid name validated . . .')
            except NameError:
                pass

    def test_create_component(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Create Component
        """
        temp_layer = rztdl.dl.layer.FullyConnectedLayer(name='fc_layer', layer_nodes=4,
                                                        component_input=self.input_buffer.name).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)

        # Test TF Collection Insertion
        assert len(tf.get_collection(temp_layer.component_output)) == 1

        # Test Dropout
        temp_layer = rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_dp', layer_nodes=4, layer_dropout=0.5,
                                                        component_input=self.input_buffer.name).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert '/dropout/' in temp_layer.component_output

        # Test Normalization
        temp_layer = rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_norm', layer_nodes=4,
                                                        normalisation=rztdl.dl.constants.NormalizationType.l2_norm(),
                                                        component_input=self.input_buffer.name
                                                        ).create_component(model_name=self.model_name,
                                                                           previous_component=self.input_buffer,
                                                                           component_id=2)
        assert '/l2_norm' in temp_layer.component_output

        # todo: Prathyush SP - Test if scalar summary is being created - No easy way in v1.1
        # Test Layer Weights and Bias

        # Auto Generated:
        assert "<tf.Variable 'test_fully_connected_layer_model/fc_layer_norm/weights/Variable:0' shape=(2, 4) dtype=float32_ref>" == GraphUtils.get_variable(
            temp_layer.layer_weights).__str__()
        assert "<tf.Variable 'test_fully_connected_layer_model/fc_layer_norm/biases/Variable:0' shape=(4,) dtype=float32_ref>" == GraphUtils.get_variable(
            temp_layer.layer_bias).__str__()

        # Complete Manual Given
        temp_layer = rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_weights_manual',
                                                        layer_weights=np.array([[1.0, 1.0], [1.0, 3.0]],
                                                                               dtype=np.float32),
                                                        layer_bias=np.array([[1.0], [2.1]], dtype=np.float32),
                                                        component_input=self.input_buffer.name,
                                                        layer_nodes=2).create_component(model_name=self.model_name,
                                                                                        previous_component=self.input_buffer,
                                                                                        component_id=2)
        assert "<tf.Variable 'test_fully_connected_layer_model/fc_layer_weights_manual/weights/Variable:0' shape=(2, 2) dtype=float32_ref>" == GraphUtils.get_variable(
            temp_layer.layer_weights).__str__()
        assert "<tf.Variable 'test_fully_connected_layer_model/fc_layer_weights_manual/biases/Variable:0' shape=(2, 1) dtype=float32_ref>" == GraphUtils.get_variable(
            temp_layer.layer_bias).__str__()

        # Semi Automated
        temp_layer = rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_weights_semi',
                                                        layer_weights=rztdl.dl.constants.InitializerType.random_normal(),
                                                        layer_bias=rztdl.dl.constants.InitializerType.zeros(),
                                                        component_input=self.input_buffer.name,
                                                        layer_nodes=2).create_component(model_name=self.model_name,
                                                                                        previous_component=self.input_buffer,
                                                                                        component_id=2)
        assert 'Tensor("test_fully_connected_layer_model/fc_layer_weights_semi/weights/random_normal:0", shape=(2, 2), dtype=float32)' == str(
            GraphUtils.get_variable(temp_layer.layer_weights).initial_value)
        assert 'Tensor("test_fully_connected_layer_model/fc_layer_weights_semi/biases/zeros:0", shape=(2,), dtype=float32)' == str(
            GraphUtils.get_variable(temp_layer.layer_bias).initial_value)

        # Test Tensorflow Collection
        assert len(tf.get_collection(temp_layer.layer_weights)) == 1
        assert len(tf.get_collection(temp_layer.layer_bias)) == 1

        # Test DAG Insertion
        self.model.add_component(rztdl.dl.buffer.InBuffer(name='in_l', buffer_features=4))
        self.model.add_component(
            rztdl.dl.layer.FullyConnectedLayer(name='test_fc_layer_ins', layer_nodes=4, component_input='in_l'))
        RZTDL_STORE.get_weights(model_name=self.model_name, layer_name='test_fc_layer_ins')
        RZTDL_STORE.get_bias(model_name=self.model_name, layer_name='test_fc_layer_ins')

        # Test Layer Activation
        temp_layer = rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_activation_test',
                                                        layer_activation=rztdl.dl.constants.ActivationType.SOFT_SIGN,
                                                        component_input=self.input_buffer.name,
                                                        layer_nodes=2).create_component(model_name=self.model_name,
                                                                                        previous_component=self.input_buffer,
                                                                                        component_id=2)
        assert 'Softsign' in temp_layer.component_output

        # Test Auto Tensor Conversion
        self.model.add_component(rztdl.dl.buffer.InBuffer(name="input_layer4d", buffer_features=729))
        self.model.add_component(
            rztdl.dl.layer.ConvolutionLayer(name='con1', layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                            filter_dimensions=[5, 5, 1, 32], filter_strides=[1, 1, 1, 1],
                                            component_input='input_layer4d',
                                            filter_padding=rztdl.dl.constants.PaddingType.SAME))
        RZTDL_CONFIG.TensorflowConfig.AUTO_TENSOR_CONVERSION = False
        try:
            self.model.add_component(rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_dim_test', layer_nodes=4))
            assert False
        except DimensionError:
            assert True
        RZTDL_CONFIG.TensorflowConfig.AUTO_TENSOR_CONVERSION = True
        self.model.add_component(
            rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_dim_test_1', layer_nodes=4, component_input='con1'))
        fc_layer = self.model.get_component('fc_layer_dim_test_1')
        assert 'Tensor("test_fully_connected_layer_model/fc_layer_dim_test_1/auto_tensor_conversion/Reshape:0", shape=(?, 23328), dtype=float32)' == GraphUtils.get_tensor(
            name=fc_layer.component_input).__str__()

        # Test Layer Input
        # Test Tensor as Layer Input
        self.model.add_component(
            rztdl.dl.layer.FullyConnectedLayer(name='test_fc_layer_input_tensor', layer_nodes=4,
                                               component_input=GraphUtils.get_tensor(
                                                   self.input_buffer.component_output)))
        # Test String as Layer Input
        self.model.add_component(
            rztdl.dl.layer.FullyConnectedLayer(name='test_fc_layer_input_str', layer_nodes=4,
                                               component_input='fc_layer_dim_test_1'))

    def test_dropout_range_error(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Dropout
        :return:
        """
        try:
            rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_dropout_test', layer_dropout=-0.2, layer_nodes=4,
                                               component_input=self.input_buffer.name).create_component(
                model_name=self.model_name,
                previous_component=self.input_buffer, component_id=2)
            assert False
        except RangeError:
            assert True
        try:
            rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_dropout_test', layer_dropout=1.2, layer_nodes=4,
                                               component_input=self.input_buffer.name).create_component(
                model_name=self.model_name,
                previous_component=self.input_buffer, component_id=2)
            assert False
        except RangeError:
            assert True

    @raises(NormalizationError)
    def test_normalization_error(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Normalization
        """
        rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_norm_test', layer_nodes=4,
                                           normalisation=rztdl.dl.constants.NormalizationType.lrn_norm(),
                                           component_input=self.input_buffer.name).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer, component_id=2)

    def test_names(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Names
        | 1. Layer Weight
        | 2. Layer Bias
        | 3. Layer Output
        """
        temp_layer = rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_name_test', layer_nodes=4,
                                                        layer_weights_output='fc_layer_name_test_weight',
                                                        layer_bias_output='fc_layer_name_test_bias',
                                                        component_output='fc_layer_name_test_output',
                                                        component_input=self.input_buffer.name).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer,
            component_id=2)

        # Check in Tensorflow Collection
        assert len(tf.get_collection(temp_layer.layer_weight_name)) == 1
        assert len(tf.get_collection(temp_layer.layer_bias_name)) == 1
        assert len(tf.get_collection(temp_layer.component_output_name)) == 1
        assert len(tf.get_collection(temp_layer.component_output)) == 1

        # Check in RZTDL Store
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=temp_layer.name)
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name,
                                                   component_name=temp_layer.layer_weight_name)
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name,
                                                   component_name=temp_layer.layer_bias_name)
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name,
                                                   component_name=temp_layer.component_output_name)

    def test_component_exception(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Component Exception
        """

        # 1. Component Input is of type tensor
        # noinspection PyTypeChecker
        self.this_ip_buffer_1 = rztdl.dl.buffer.InBuffer(name='this_ip_buffer_1', buffer_features=0).create_component(
            model_name=self.model_name, previous_component=None, component_id=1)

        try:
            rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_excep_test_1', layer_nodes=4,
                                               component_input=GraphUtils.get_tensor(
                                                   self.this_ip_buffer_1.component_output)).create_component(
                model_name=self.model_name, previous_component=self.this_ip_buffer_1, component_id=2)
            assert False
        except ComponentException:
            assert True

        # 2. Component Input is of type String

        try:
            rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_excep_test_2', layer_nodes=4,
                                               component_input=self.this_ip_buffer_1.name).create_component(
                model_name=self.model_name, previous_component=self.this_ip_buffer_1, component_id=2)
            assert False
        except ComponentException:
            assert True

        # 3. Fetch from previous component if component is of type layer
        try:
            fcl = rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_excep_test_2', layer_nodes=4,
                                                     component_input=self.this_ip_buffer_1.name).create_component(
                model_name=self.model_name, previous_component=self.this_ip_buffer_1, component_id=2)
            fcl.component_output = None
            rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_excep_test_3',
                                               ).create_component(
                model_name=self.model_name, previous_component=fcl, component_id=2)
            assert False
        except ComponentException:
            assert True

    # noinspection PyDunderSlots,PyUnresolvedReferences
    @raises(AttributeError)
    def test_slots(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Slot functionality
        """
        rztdl.dl.layer.FullyConnectedLayer(name='test_fullyconnected_layer', layer_nodes=4).new_var_comp = 0

    def test_tensorboard_summaries(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Tensorboard summaries
        """

        # Default True
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = True
        rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_sum_test_1', layer_nodes=4,
                                           component_input=self.input_buffer.name).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)

        summary_collection = [coll.name for coll in tf.get_collection(tf.GraphKeys.SUMMARIES)]
        assert 'fc_layer_sum_test_1/weights/' in summary_collection[0]
        assert 'fc_layer_sum_test_1/biases/' in summary_collection[6]
        assert 'fc_layer_sum_test_1/summaries/' in summary_collection[-1]

        # Default False
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = False
        rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_sum_test_2', layer_nodes=4,
                                           component_input=self.input_buffer.name).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert len(tf.get_collection(tf.GraphKeys.SUMMARIES)) == len(summary_collection)

        # Parameter False
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = True
        rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_sum_test_3', layer_nodes=4,
                                           component_input=self.input_buffer.name,
                                           layer_summaries=False).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert len(tf.get_collection(tf.GraphKeys.SUMMARIES)) == len(summary_collection)

        # Parameter True
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = False
        rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_sum_test_4',
                                           layer_nodes=4,
                                           component_input=self.input_buffer.name,
                                           layer_summaries=True).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert len(tf.get_collection(tf.GraphKeys.SUMMARIES)) > len(summary_collection)

    def test_layer_scopes(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer scopes
        """
        layer_scopes = ['xyz', 'abc']
        rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_sum_test_5', layer_nodes=4,
                                           component_input=self.input_buffer.name,
                                           layer_scopes=layer_scopes).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)

        for scope in layer_scopes:
            if scope in RZTDL_STORE.get_scopes_of_model_components(model_name=self.model_name).keys():
                assert True
                continue
            assert False

        for scope_name, scopes in RZTDL_STORE.get_scopes_of_model_components(model_name=self.model_name).items():
            assert self.model_name + '/fc_layer_sum_test_5/weights/Variable:0' in scopes
            assert self.model_name + '/fc_layer_sum_test_5/biases/Variable:0' in scopes

        try:
            layer_scopes = ['xyz,-', 'abc']
            rztdl.dl.layer.FullyConnectedLayer(name='fc_layer_sum_test_6', layer_nodes=4,
                                               component_input=self.input_buffer.name,
                                               layer_scopes=layer_scopes, ).create_component(
                model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
            assert False
        except NameError:
            assert True

    def test_blueprint_json_parameters(self):
        """
        | *@author:* Umesh Kumar
        |
        | Test Component Blueprint
        """
        blueprint_json = rztdl.dl.layer.FullyConnectedLayer.blueprint().to_json()
        x = [parameter for parameter in inspect.signature(rztdl.dl.layer.FullyConnectedLayer).parameters.keys()]
        blueprint_parameters = []
        component_parameters = ["inputs", "parameters", "outputs"]
        for each_component_parameter in component_parameters:
            for value in blueprint_json[each_component_parameter]:
                blueprint_parameters.append(value["name"])
                if "properties" in value.keys():
                    for each_property in value["properties"]:
                        if "link_to_attribute" in each_property.keys():
                            blueprint_parameters.append(each_property["link_to_attribute"])
                else:
                    blueprint_parameters.append(value["name"])
        assert_equal(set(blueprint_parameters), set(x))
