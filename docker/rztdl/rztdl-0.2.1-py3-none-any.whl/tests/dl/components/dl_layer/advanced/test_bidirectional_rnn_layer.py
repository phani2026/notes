# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP, Umesh Kumar
| **@version:** v0.0.1
|
| **Description:**
| Bidirectional RNN Layer Test Cases
|
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import inspect

import tensorflow as tf
from nose.tools import *

import rztdl.dl
import rztdl.utils.string_constants as constants
from rztdl import RZTDL_CONFIG, RZTDL_STORE
from rztdl.dl.helpers.tfhelpers import GraphUtils
from rztdl.utils.dl_exception import ComponentException, NormalizationError
from rztdl.utils.dl_exception import RangeError


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    pass


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    pass


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestBiDirectionalRNNLayer:
    """
    | **@author:** Prathyush SP
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        pass

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method in the class is called
        """
        RZTDL_CONFIG.update_dl_config_manager(
            config_file_path='/'.join(__file__.split('/')[:-5]) + '/rztdl_testing_config.json')
        self.model.clear_components()
        self.model.add_component(self.input_buffer)

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        pass

    # noinspection PyTypeChecker
    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        print("*********BiDirectional RNN Layer Test Case . . .*********")
        cls.model_name = 'test_birnn_layer_model'
        cls.model = rztdl.dl.Model(cls.model_name)
        cls.forward_cell = [constants.RNNCell.basic_lstm_cell(num_units=12,
                                                              activation=rztdl.dl.constants.ActivationType.TANH,
                                                              forget_bias=1.0),
                            constants.RNNCell.lstm_cell(num_units=28, cell_clip=None,
                                                        activation=rztdl.dl.constants.ActivationType.SIGMOID),
                            constants.RNNCell.lstm_cell(num_units=32, cell_clip=None,
                                                        activation=rztdl.dl.constants.ActivationType.SIGMOID)]
        cls.backward_cell = [constants.RNNCell.lstm_cell(num_units=28, cell_clip=None,
                                                         activation=rztdl.dl.constants.ActivationType.SIGMOID)
                             ]
        cls.input_buffer = rztdl.dl.buffer.InBuffer(name='inp_buffer', buffer_features=4,
                                                    buffer_shape=[None, 2, 2]).create_component(
            model_name=cls.model_name, previous_component='', component_id=1)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        print("*********Convolution Layer Test Case completed successfully . . .*********")

    def test_name_validation(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests Sample Method
        """
        false_names = ['layer 1', 'layer .', '%layer']
        for name in false_names:
            try:
                rztdl.dl.layer.BidirectionalRNNLayer(name=name, forward_cell=self.forward_cell,
                                                     backward_cell=self.backward_cell)
                raise Exception('Invalid name validated . . .')
            except NameError:
                pass

    def test_create_layer(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Create Layer
        :return:
        """
        temp_layer = rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer',
                                                          component_input=self.input_buffer.name,
                                                          forward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                              num_units=10),
                                                          backward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                              num_units=10)).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)

        # Test TF Collection Insertion
        assert len(tf.get_collection(temp_layer.component_output)) == 1

        # Test Tensor as Layer Input
        self.model.add_component(
            rztdl.dl.layer.BidirectionalRNNLayer('test_rnn_layer_layer_input_tensor',
                                                 forward_cell=rztdl.utils.string_constants.RNNCell.lstm_cell(
                                                     num_units=10),
                                                 backward_cell=rztdl.utils.string_constants.RNNCell.lstm_cell(
                                                     num_units=10),
                                                 component_input=GraphUtils.get_tensor(
                                                     name=self.input_buffer.component_output),
                                                 ))
        # Test String as Layer Input
        self.model.add_component(
            rztdl.dl.layer.BidirectionalRNNLayer('test_rnn_layer_input_str',
                                                 forward_cell=rztdl.utils.string_constants.RNNCell.gru_cell(
                                                     num_units=10),
                                                 backward_cell=rztdl.utils.string_constants.RNNCell.gru_cell(
                                                     num_units=10),
                                                 component_input=self.input_buffer.name,
                                                 ))

    def test_names(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Layer Names
        | 1. Layer Output
        """
        temp_layer = rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_name_test',
                                                          component_output='bi_rnn_layer_name_test_output',
                                                          component_input=self.input_buffer.name,
                                                          forward_cell=rztdl.utils.string_constants.RNNCell.lstm_cell(
                                                              num_units=10),
                                                          backward_cell=rztdl.utils.string_constants.RNNCell.lstm_cell(
                                                              num_units=10)).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)

        # Check in Tensorflow Collection
        assert len(tf.get_collection(temp_layer.component_output_name)) == 1
        assert len(tf.get_collection(temp_layer.component_output)) == 1

        # Check in RZTDL Store
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=temp_layer.name)
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=temp_layer.component_output_name)

    def test_component_exception(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Component Exception
        """

        # 1. Component Input don't have nodes and input is Tensor
        # noinspection PyTypeChecker
        self.this_ip_buffer_1 = rztdl.dl.buffer.InBuffer(name='this_ip_buffer_1', buffer_features=0).create_component(
            model_name=self.model_name, previous_component=None, component_id=1)

        try:
            rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_excep_test_1',
                                                 forward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                     num_units=10),
                                                 backward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                     num_units=10),
                                                 component_input=GraphUtils.get_tensor(
                                                     self.this_ip_buffer_1.component_output)).create_component(
                model_name=self.model_name, previous_component=self.this_ip_buffer_1, component_id=2)
            assert False
        except ComponentException:
            assert True

        # 2. Component Input don't have nodes and input is String
        try:
            rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_excep_test_2',
                                                 forward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                     num_units=12),
                                                 backward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                     num_units=12),
                                                 component_input=self.this_ip_buffer_1.name).create_component(
                model_name=self.model_name, previous_component=self.this_ip_buffer_1, component_id=2)
            assert False
        except ComponentException:
            assert True

        # RNN input can take only 3d inputs
        # noinspection PyTypeChecker
        in_buffer = rztdl.dl.buffer.InBuffer(name='ip_buffer_1', buffer_features=10,
                                             buffer_shape=[None, 5]).create_component(
            model_name=self.model_name, previous_component=None, component_id=1)

        try:
            rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_excep_test_3',
                                                 forward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                     num_units=10,
                                                     forget_bias=1),
                                                 backward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                     num_units=10,
                                                     forget_bias=1),
                                                 component_input=in_buffer.name).create_component(
                model_name=self.model_name, previous_component=in_buffer, component_id=2)
            assert False
        except ComponentException:
            assert True

    # noinspection PyDunderSlots,PyUnresolvedReferences
    @raises(AttributeError)
    def test_slots(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Slot functionality
        """
        rztdl.dl.layer.BidirectionalRNNLayer(name='test_bi_rnn_layer',
                                             forward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                 num_units=12),
                                             backward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                 num_units=12)).new_var_comp = 0

    def test_tensorboard_summaries(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Tensorboard summaries
        """

        # Default True
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = True
        rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_sum_test_1',
                                             forward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                 num_units=12),
                                             backward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                 num_units=12),
                                             component_input=self.input_buffer.name).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)

        summary_collection = [coll.name for coll in tf.get_collection(tf.GraphKeys.SUMMARIES)]
        assert 'bi_rnn_layer_sum_test_1/summaries/' in summary_collection[-1]

        # Default False
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = False
        rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_sum_test_2',
                                             forward_cell=rztdl.utils.string_constants.RNNCell.lstm_cell(
                                                 num_units=12),
                                             backward_cell=rztdl.utils.string_constants.RNNCell.lstm_cell(
                                                 num_units=12),
                                             component_input=self.input_buffer.name).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert len(tf.get_collection(tf.GraphKeys.SUMMARIES)) == len(summary_collection)

        # Parameter False
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = True
        rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_sum_test_3',
                                             forward_cell=rztdl.utils.string_constants.RNNCell.gru_cell(
                                                 num_units=12),
                                             backward_cell=rztdl.utils.string_constants.RNNCell.gru_cell(
                                                 num_units=12),
                                             component_input=self.input_buffer.name,
                                             layer_summaries=False).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert len(tf.get_collection(tf.GraphKeys.SUMMARIES)) == len(summary_collection)

        # Parameter True
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = False
        rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_sum_test_4',
                                             forward_cell=rztdl.utils.string_constants.RNNCell.basic_rnn_cell(
                                                 num_units=12),
                                             backward_cell=rztdl.utils.string_constants.RNNCell.basic_rnn_cell(
                                                 num_units=12),
                                             component_input=self.input_buffer.name,
                                             layer_summaries=True).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert len(tf.get_collection(tf.GraphKeys.SUMMARIES)) > len(summary_collection)

    @raises(NormalizationError)
    def test_normalization_error(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Layer Normalization
        """
        rztdl.dl.layer.BidirectionalRNNLayer(name='rnn_layer_norm_test',
                                             forward_cell=[
                                                 rztdl.utils.string_constants.RNNCell.basic_rnn_cell(num_units=10)],
                                             backward_cell=[
                                                 rztdl.utils.string_constants.RNNCell.basic_rnn_cell(num_units=10)],
                                             normalisation=rztdl.dl.constants.NormalizationType.lrn_norm(),
                                             component_input=self.input_buffer.name).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer, component_id=2)

    def test_dropout_range_error(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Layer Dropout
        :return:
        """
        try:
            rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_dropout_test', layer_dropout=-0.2,
                                                 forward_cell=[
                                                     rztdl.utils.string_constants.RNNCell.basic_rnn_cell(num_units=10)],
                                                 backward_cell=[
                                                     rztdl.utils.string_constants.RNNCell.basic_rnn_cell(num_units=10)],
                                                 component_input=self.input_buffer.name).create_component(
                model_name=self.model_name,
                previous_component=self.input_buffer, component_id=2)
            assert False
        except RangeError:
            assert True
        try:
            rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_dropout_test_1', layer_dropout=1.2,
                                                 forward_cell=[
                                                     rztdl.utils.string_constants.RNNCell.lstm_cell(num_units=10)],
                                                 backward_cell=[
                                                     rztdl.utils.string_constants.RNNCell.lstm_cell(num_units=10)],
                                                 component_input=self.input_buffer.name).create_component(
                model_name=self.model_name,
                previous_component=self.input_buffer, component_id=2)
            assert False
        except RangeError:
            assert True

    def test_control_state_hidden_state(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Layer control state and hidden state
        :return:
        """
        bi_rnn_layer = rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_states_test', layer_dropout=0.5,
                                                            forward_cell=[
                                                                rztdl.utils.string_constants.RNNCell.basic_rnn_cell(
                                                                    num_units=10)],
                                                            backward_cell=[
                                                                rztdl.utils.string_constants.RNNCell.basic_rnn_cell(
                                                                    num_units=10)],
                                                            component_input=self.input_buffer.name,
                                                            forward_cell_control_state_name="bi_forward_rnn_control_state",
                                                            forward_cell_hidden_state_name="bi_forward_rnn_hidden_state",
                                                            backward_cell_control_state_name="bi_backward_rnn_control_state",
                                                            backward_cell_hidden_state_name="bi_backward_rnn_hidden_state",
                                                            normalisation=rztdl.utils.string_constants.NormalizationType.l2_norm()).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer, component_id=2)
        # Check in Tensorflow Collection
        assert len(tf.get_collection(bi_rnn_layer.forward_cell_control_state)) == 1
        assert len(tf.get_collection(bi_rnn_layer.forward_cell_hidden_state)) == 1
        assert len(tf.get_collection(bi_rnn_layer.backward_cell_control_state)) == 1
        assert len(tf.get_collection(bi_rnn_layer.backward_cell_hidden_state)) == 1

        # Check in RZTDL Store
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=bi_rnn_layer.forward_cell_hidden_state)
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=bi_rnn_layer.forward_cell_control_state)
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=bi_rnn_layer.backward_cell_hidden_state)
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=bi_rnn_layer.backward_cell_control_state)

    def test_bi_rnn_outputs_dag(self):
        """
        | *@author:* Umesh Kumar
        |
        | Test RNN outputs dag
        """
        # noinspection PyTypeChecker
        in_buffer = rztdl.dl.buffer.InBuffer(name='ip_buffer_1', buffer_features=10,
                                             buffer_shape=[None, 2, 5]).create_component(
            model_name=self.model_name, previous_component=None, component_id=1)
        bi_rnn_layer = rztdl.dl.layer.BidirectionalRNNLayer(name='rnn_layer_excep_test_3',
                                                            forward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                                num_units=10,
                                                                forget_bias=0.5),
                                                            backward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                                num_units=10,
                                                                forget_bias=0.5),
                                                            component_input=in_buffer.name,
                                                            forward_cell_output=["bi_forward_rnn1", "bi_forward_rnn2"],
                                                            backward_cell_output=["bi_backward_rnn1",
                                                                                  "bi_backward_rnn2"],
                                                            forward_cell_output_indices=[0, 1],
                                                            backward_cell_output_indices=[0, 1]).create_component(
            model_name=self.model_name, previous_component=in_buffer, component_id=2)

        # Check in Tensorflow Collection
        assert len(tf.get_collection(bi_rnn_layer.forward_cell_outputs[0])) == 1
        assert len(tf.get_collection(bi_rnn_layer.forward_cell_outputs[1])) == 1
        assert len(tf.get_collection(bi_rnn_layer.backward_cell_outputs[0])) == 1
        assert len(tf.get_collection(bi_rnn_layer.backward_cell_outputs[1])) == 1

        # Check in RZTDL Store
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=bi_rnn_layer.forward_cell_outputs[0])
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=bi_rnn_layer.forward_cell_outputs[1])
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=bi_rnn_layer.backward_cell_outputs[0])
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=bi_rnn_layer.backward_cell_outputs[1])

    def test_rnn_outputs_exception(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test RNN outputs
        :return:
        """
        # noinspection PyTypeChecker
        in_buffer = rztdl.dl.buffer.InBuffer(name='ip_buffer_1', buffer_features=10,
                                             buffer_shape=[None, 2, 5]).create_component(
            model_name=self.model_name, previous_component=None, component_id=1)

        # Forward cell Outputs are given but Forward output indices are not given
        try:
            rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_states_test', layer_dropout=0.5,
                                                 forward_cell=[
                                                     rztdl.utils.string_constants.RNNCell.basic_rnn_cell(num_units=10)],
                                                 backward_cell=[
                                                     rztdl.utils.string_constants.RNNCell.basic_rnn_cell(num_units=10)],
                                                 component_input=in_buffer.name,
                                                 forward_cell_output=["bi_rnn_op1", "bi_rnn_op2"]).create_component(
                model_name=self.model_name,
                previous_component=self.input_buffer, component_id=2)
            assert False
        except ComponentException:
            assert True

        # Length of Forward Output RNN Outputs and Forward Output Component indices are not equal
        try:
            rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_states_test', layer_dropout=0.5,
                                                 forward_cell=[
                                                     rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                         num_units=10)],
                                                 backward_cell=[
                                                     rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                         num_units=10)],
                                                 component_input=in_buffer.name,
                                                 forward_cell_output=["bi_rnn_op1", "bi_rnn_op2"],
                                                 forward_cell_output_indices=[0, 1, 2]).create_component(
                model_name=self.model_name,
                previous_component=self.input_buffer, component_id=2)
            assert False
        except ComponentException:
            assert True

        # Forward Output Component indices should be in range of timesteps
        try:
            rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_states_test', layer_dropout=0.5,
                                                 forward_cell=[
                                                     rztdl.utils.string_constants.RNNCell.basic_rnn_cell(num_units=10)],
                                                 backward_cell=[
                                                     rztdl.utils.string_constants.RNNCell.basic_rnn_cell(num_units=10)],
                                                 component_input=in_buffer.name,
                                                 forward_cell_output=["bi_rnn_op1", "bi_rnn_op2"],
                                                 forward_cell_output_indices=[0, 5]).create_component(
                model_name=self.model_name,
                previous_component=self.input_buffer, component_id=2)
            assert False
        except ComponentException:
            assert True

        # Backward cell Outputs are given but Backward output indices are not given
        try:
            rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_states_test', layer_dropout=0.5,
                                                 forward_cell=[
                                                     rztdl.utils.string_constants.RNNCell.basic_rnn_cell(
                                                         num_units=10)],
                                                 backward_cell=[
                                                     rztdl.utils.string_constants.RNNCell.basic_rnn_cell(
                                                         num_units=10)],
                                                 component_input=in_buffer.name,
                                                 backward_cell_output=["bi_rnn_op1", "bi_rnn_op2"]).create_component(
                model_name=self.model_name,
                previous_component=self.input_buffer, component_id=2)
            assert False
        except ComponentException:
            assert True

        # Length of Backward Output RNN Outputs and Backward Output Component indices are not equal
        try:
            rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_states_test', layer_dropout=0.5,
                                                 forward_cell=[
                                                     rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                         num_units=10)],
                                                 backward_cell=[
                                                     rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                         num_units=10)],
                                                 component_input=in_buffer.name,
                                                 backward_cell_output=["bi_rnn_op1", "bi_rnn_op2"],
                                                 backward_cell_output_indices=[0, 1, 2]).create_component(
                model_name=self.model_name,
                previous_component=self.input_buffer, component_id=2)
            assert False
        except ComponentException:
            assert True

        # Backward Output Component indices should be in range of timesteps
        try:
            rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_states_test', layer_dropout=0.5,
                                                 forward_cell=[
                                                     rztdl.utils.string_constants.RNNCell.basic_rnn_cell(
                                                         num_units=10)],
                                                 backward_cell=[
                                                     rztdl.utils.string_constants.RNNCell.basic_rnn_cell(
                                                         num_units=10)],
                                                 component_input=in_buffer.name,
                                                 backward_cell_output=["bi_rnn_op1", "bi_rnn_op2"],
                                                 backward_cell_output_indices=[0, 5]).create_component(
                model_name=self.model_name,
                previous_component=self.input_buffer, component_id=2)
            assert False
        except ComponentException:
            assert True

        # num_units parameter must be greater than 0
        try:
            rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_excep_test_2',
                                                 forward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                     num_units=-1),
                                                 backward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                     num_units=-1),
                                                 component_input=in_buffer.name).create_component(
                model_name=self.model_name, previous_component=in_buffer, component_id=2)
            assert False
        except RangeError:
            assert True

        # forget_bias parameter must be greater than 0
        try:
            rztdl.dl.layer.BidirectionalRNNLayer(name='bi_rnn_layer_excep_test_3',
                                                 forward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                     num_units=10,
                                                     forget_bias=-1),
                                                 backward_cell=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                     num_units=10,
                                                     forget_bias=-1),
                                                 component_input=in_buffer.name).create_component(
                model_name=self.model_name, previous_component=in_buffer, component_id=2)
            assert False
        except RangeError:
            assert True

    def test_blueprint_json_parameters(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Component Blueprint
        """
        blueprint_json = rztdl.dl.layer.BidirectionalRNNLayer.blueprint().to_json()
        x = [parameter for parameter in inspect.signature(rztdl.dl.layer.BidirectionalRNNLayer).parameters.keys()]
        blueprint_parameters = []
        component_parameters = ["inputs", "parameters", "outputs"]
        for each_component_parameter in component_parameters:
            for value in blueprint_json[each_component_parameter]:
                blueprint_parameters.append(value["name"])
                if "properties" in value.keys():
                    for each_property in value["properties"]:
                        if "link_to_attribute" in each_property.keys():
                            blueprint_parameters.append(each_property["link_to_attribute"])
                else:
                    blueprint_parameters.append(value["name"])
        assert_equal(set(blueprint_parameters), set(x))
