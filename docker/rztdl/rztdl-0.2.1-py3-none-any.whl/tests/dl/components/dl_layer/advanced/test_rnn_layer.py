# -*- coding: utf-8 -*-
"""
| **@created on:** 06/06/18,
| **@author:** Umesh Kumar,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import inspect

import tensorflow as tf
from nose.tools import *

import rztdl.dl
import rztdl.dl
from rztdl import RZTDL_CONFIG, RZTDL_STORE
from rztdl.dl.helpers.tfhelpers import GraphUtils
from rztdl.utils.dl_exception import ComponentException, RangeError, NormalizationError


def setup_module():
    """
    | **@author:** Umesh Kumar
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    pass


def teardown_module():
    """
    | **@author:** Umesh Kumar
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    pass


def my_setup_function():
    """
    | **@author:** Umesh Kumar
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Umesh Kumar
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Umesh Kumar
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestRNNLayer:
    """
    | **@author:** Umesh Kumar
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        self.rnn_layer_name = None
        pass

    def setup(self):
        """
        | **@author:** Umesh Kumar
        |
        | Runs before a new method in the class is called
        """
        RZTDL_CONFIG.update_dl_config_manager(
            config_file_path='/'.join(__file__.split('/')[:-5]) + '/rztdl_testing_config.json')
        self.model.clear_components()
        self.model.add_component(self.input_buffer)

    def teardown(self):
        """
        | **@author:** Umesh Kumar
        |
        | Runs after each method is called
        """

        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Umesh Kumar
        |
        | Runs during class initialization
        """
        print("*********RNN Normalisation Layer Test Case . . .*********")
        cls.model_name = 'test_rnn_layer_model'
        cls.model = rztdl.dl.Model(cls.model_name)
        cls.input_buffer = rztdl.dl.buffer.InBuffer(name='input_buffer', buffer_features=3, buffer_shape=[None, 1, 2])
        cls.model.add_component(cls.input_buffer)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Umesh Kumar
        |
        | Runs after class reference is removed / class test cases are completed
        """
        print("*********Batch Normalisation Layer Test Case completed successfully . . .*********")

    def test_name_validation(self):
        """
        | **@author:** Umesh Kumar
        |
        | Tests Sample Method
        """
        false_names = ['layer 1', 'layer .', '%layer']
        for name in false_names:
            try:
                rztdl.dl.layer.RNNLayer(name=name, layer_cells=[])
                raise Exception('Invalid name validated . . .')
            except NameError:
                pass

    def test_create_layer(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Create Layer
        :return:
        """
        temp_layer = rztdl.dl.layer.RNNLayer(name='rnn_layer',
                                             component_input=self.input_buffer.name,
                                             layer_cells=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                 num_units=10)).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)

        # Test TF Collection Insertion
        assert len(tf.get_collection(temp_layer.component_output)) == 1

        # Test Tensor as Layer Input
        self.model.add_component(
            rztdl.dl.layer.RNNLayer('test_rnn_layer_layer_input_tensor',
                                    component_input=GraphUtils.get_tensor(
                                        name=self.input_buffer.component_output),
                                    layer_cells=rztdl.utils.string_constants.RNNCell.lstm_cell(
                                        num_units=10)))
        # Test String as Layer Input
        self.model.add_component(
            rztdl.dl.layer.RNNLayer('test_rnn_layer_input_str',
                                    component_input=self.input_buffer.name,
                                    layer_cells=rztdl.utils.string_constants.RNNCell.gru_cell(
                                        num_units=10)),
        )

    def test_names(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Layer Names
        | 1. Layer Output
        """
        temp_layer = rztdl.dl.layer.RNNLayer(name='rnn_layer_name_test',
                                             component_output='rnn_layer_name_test_output',
                                             component_input=self.input_buffer.name,
                                             layer_cells=rztdl.utils.string_constants.RNNCell.lstm_cell(
                                                 num_units=10)).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)

        # Check in Tensorflow Collection
        assert len(tf.get_collection(temp_layer.component_output_name)) == 1
        assert len(tf.get_collection(temp_layer.component_output)) == 1

        # Check in RZTDL Store
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=temp_layer.name)
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=temp_layer.component_output_name)

    def test_component_exception(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Component Exception
        """

        # 1. Component Input don't have nodes and input is Tensor
        # noinspection PyTypeChecker
        self.this_ip_buffer_1 = rztdl.dl.buffer.InBuffer(name='this_ip_buffer_1', buffer_features=0).create_component(
            model_name=self.model_name, previous_component=None, component_id=1)

        try:
            rztdl.dl.layer.RNNLayer(name='rnn_layer_excep_test_1',
                                    layer_cells=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(num_units=10),
                                    component_input=GraphUtils.get_tensor(
                                        self.this_ip_buffer_1.component_output)).create_component(
                model_name=self.model_name, previous_component=self.this_ip_buffer_1, component_id=2)
            assert False
        except ComponentException:
            assert True

        # 2. Component Input don't have nodes and input is String
        try:
            rztdl.dl.layer.RNNLayer(name='rnn_layer_excep_test_2',
                                    layer_cells=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(num_units=12),
                                    component_input=self.this_ip_buffer_1.name).create_component(
                model_name=self.model_name, previous_component=self.this_ip_buffer_1, component_id=2)
            assert False
        except ComponentException:
            assert True

        # RNN input can take only 3d inputs
        # noinspection PyTypeChecker
        in_buffer = rztdl.dl.buffer.InBuffer(name='ip_buffer_1', buffer_features=10,
                                             buffer_shape=[None, 5]).create_component(
            model_name=self.model_name, previous_component=None, component_id=1)

        try:
            rztdl.dl.layer.RNNLayer(name='rnn_layer_excep_test_3',
                                    layer_cells=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(num_units=10,
                                                                                                     forget_bias=1),
                                    component_input=in_buffer.name).create_component(
                model_name=self.model_name, previous_component=in_buffer, component_id=2)
            assert False
        except ComponentException:
            assert True

    # noinspection PyDunderSlots,PyUnresolvedReferences
    @raises(AttributeError)
    def test_slots(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Slot functionality
        """
        rztdl.dl.layer.RNNLayer(name='test_rnn_layer', layer_cells=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
            num_units=12)).new_var_comp = 0

    #
    def test_tensorboard_summaries(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Tensorboard summaries
        """

        # Default True
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = True
        rztdl.dl.layer.RNNLayer(name='rnn_layer_sum_test_1',
                                layer_cells=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(num_units=12),
                                component_input=self.input_buffer.name).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)

        summary_collection = [coll.name for coll in tf.get_collection(tf.GraphKeys.SUMMARIES)]
        assert 'rnn_layer_sum_test_1/summaries/' in summary_collection[-1]

        # Default False
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = False
        rztdl.dl.layer.RNNLayer(name='rnn_layer_sum_test_2',
                                layer_cells=rztdl.utils.string_constants.RNNCell.lstm_cell(
                                    num_units=12),
                                component_input=self.input_buffer.name).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert len(tf.get_collection(tf.GraphKeys.SUMMARIES)) == len(summary_collection)

        # Parameter False
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = True
        rztdl.dl.layer.RNNLayer(name='rnn_layer_sum_test_3',
                                layer_cells=rztdl.utils.string_constants.RNNCell.gru_cell(
                                    num_units=12),
                                component_input=self.input_buffer.name,
                                layer_summaries=False).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert len(tf.get_collection(tf.GraphKeys.SUMMARIES)) == len(summary_collection)

        # Parameter True
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = False
        rztdl.dl.layer.RNNLayer(name='rnn_layer_sum_test_4',
                                layer_cells=rztdl.utils.string_constants.RNNCell.basic_rnn_cell(
                                    num_units=12),
                                component_input=self.input_buffer.name,
                                layer_summaries=True).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert len(tf.get_collection(tf.GraphKeys.SUMMARIES)) > len(summary_collection)

    @raises(NormalizationError)
    def test_normalization_error(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Layer Normalization
        """
        rztdl.dl.layer.RNNLayer(name='rnn_layer_norm_test',
                                layer_cells=[rztdl.utils.string_constants.RNNCell.basic_rnn_cell(num_units=10)],
                                normalisation=rztdl.dl.constants.NormalizationType.lrn_norm(),
                                component_input=self.input_buffer.name).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer, component_id=2)

    def test_dropout_range_error(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Layer Dropout
        :return:
        """
        try:
            rztdl.dl.layer.RNNLayer(name='rnn_layer_dropout_test', layer_dropout=-0.2,
                                    layer_cells=[rztdl.utils.string_constants.RNNCell.basic_rnn_cell(num_units=10)],
                                    component_input=self.input_buffer.name).create_component(
                model_name=self.model_name,
                previous_component=self.input_buffer, component_id=2)
            assert False
        except RangeError:
            assert True
        try:
            rztdl.dl.layer.RNNLayer(name='rnn_layer_dropout_test_1', layer_dropout=1.2,
                                    layer_cells=[rztdl.utils.string_constants.RNNCell.basic_rnn_cell(num_units=10)],
                                    component_input=self.input_buffer.name).create_component(
                model_name=self.model_name,
                previous_component=self.input_buffer, component_id=2)
            assert False
        except RangeError:
            assert True

    def test_control_state_hidden_state(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Layer control state and hidden state
        :return:
        """
        rnn_layer = rztdl.dl.layer.RNNLayer(name='rnn_layer_states_test', layer_dropout=0.5,
                                            layer_cells=[
                                                rztdl.utils.string_constants.RNNCell.basic_rnn_cell(num_units=10)],
                                            component_input=self.input_buffer.name,
                                            layer_control_state="rnn_control_state",
                                            layer_hidden_state="rnn_hidden_state",
                                            normalisation=rztdl.utils.string_constants.NormalizationType.l2_norm()).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer, component_id=2)
        # Check in Tensorflow Collection
        assert len(tf.get_collection(rnn_layer.layer_control_state)) == 1
        assert len(tf.get_collection(rnn_layer.layer_hidden_state)) == 1

        # Check in RZTDL Store
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=rnn_layer.layer_control_state)
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=rnn_layer.layer_hidden_state)

    def test_rnn_outputs_exception(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test RNN outputs
        :return:
        """
        # noinspection PyTypeChecker
        in_buffer = rztdl.dl.buffer.InBuffer(name='ip_buffer_1', buffer_features=10,
                                             buffer_shape=[None, 2, 5]).create_component(
            model_name=self.model_name, previous_component=None, component_id=1)

        # RNN Outputs are given but indices are not given
        try:
            rztdl.dl.layer.RNNLayer(name='rnn_layer_states_test', layer_dropout=0.5,
                                    layer_cells=[
                                        rztdl.utils.string_constants.RNNCell.basic_rnn_cell(num_units=10)],
                                    component_input=in_buffer.name,
                                    layer_control_state="rnn_control_state",
                                    layer_hidden_state="rnn_hidden_state",
                                    rnn_outputs=["rnn_op1", "rnn_op2"]).create_component(
                model_name=self.model_name,
                previous_component=self.input_buffer, component_id=2)
            assert False
        except:
            assert True

        # Length of RNN Outputs and Component indices are not equal
        try:
            rztdl.dl.layer.RNNLayer(name='rnn_layer_states_test', layer_dropout=0.5,
                                    layer_cells=[
                                        rztdl.utils.string_constants.RNNCell.basic_rnn_cell(num_units=10)],
                                    component_input=in_buffer.name,
                                    layer_control_state="rnn_control_state",
                                    layer_hidden_state="rnn_hidden_state",
                                    rnn_outputs=["rnn_op1", "rnn_op2"], component_indices=[0, 1, 2]).create_component(
                model_name=self.model_name,
                previous_component=self.input_buffer, component_id=2)
            assert False
        except:
            assert True

        # Component indices should be in range of timesteps
        try:
            rztdl.dl.layer.RNNLayer(name='rnn_layer_states_test_1', layer_dropout=0.5,
                                    layer_cells=[
                                        rztdl.utils.string_constants.RNNCell.basic_rnn_cell(num_units=10)],
                                    component_input=in_buffer.name,
                                    layer_control_state="rnn_control_state",
                                    layer_hidden_state="rnn_hidden_state",
                                    rnn_outputs=["rnn_op1", "rnn_op2"], component_indices=[0, 5]).create_component(
                model_name=self.model_name,
                previous_component=self.input_buffer, component_id=2)
            assert False
        except:
            assert True

        # num_units parameter must be greater than 0
        try:
            rztdl.dl.layer.RNNLayer(name='rnn_layer_excep_test_2',
                                    layer_cells=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(num_units=-1),
                                    component_input=in_buffer.name).create_component(
                model_name=self.model_name, previous_component=in_buffer, component_id=2)
            assert False
        except RangeError:
            assert True

        # forget_bias parameter must be greater than 0
        try:
            rztdl.dl.layer.RNNLayer(name='rnn_layer_excep_test_3',
                                    layer_cells=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(num_units=10,
                                                                                                     forget_bias=-1),
                                    component_input=in_buffer.name).create_component(
                model_name=self.model_name, previous_component=in_buffer, component_id=2)
            assert False
        except RangeError:
            assert True

    def test_rnn_outputs_dag(self):
        """
        | *@author:* Umesh Kumar
        |
        | Test RNN outputs dag
        """
        # noinspection PyTypeChecker
        in_buffer = rztdl.dl.buffer.InBuffer(name='ip_buffer_1', buffer_features=10,
                                             buffer_shape=[None, 2, 5]).create_component(
            model_name=self.model_name, previous_component=None, component_id=1)
        rnn_layer = rztdl.dl.layer.RNNLayer(name='rnn_layer_excep_test_3',
                                            layer_cells=rztdl.utils.string_constants.RNNCell.basic_lstm_cell(
                                                num_units=10,
                                                forget_bias=0.5),
                                            component_input=in_buffer.name, rnn_outputs=["rnn1", "rnn2"],
                                            component_indices=[0, 1]).create_component(
            model_name=self.model_name, previous_component=in_buffer, component_id=2)

        # Check in Tensorflow Collection
        assert len(tf.get_collection(rnn_layer.rnn_outputs[0])) == 1
        assert len(tf.get_collection(rnn_layer.rnn_outputs[1])) == 1

        # Check in RZTDL Store
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=rnn_layer.rnn_outputs[0])
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=rnn_layer.rnn_outputs[1])

    def test_blueprint_json_parameters(self):
        """
        | *@author:* Umesh Kumar
        |
        | Test Component Blueprint
        """
        blueprint_json = rztdl.dl.layer.RNNLayer.blueprint().to_json()
        x = [parameter for parameter in inspect.signature(rztdl.dl.layer.RNNLayer).parameters.keys()]
        blueprint_parameters = []
        component_parameters = ["inputs", "parameters", "outputs"]
        for each_component_parameter in component_parameters:
            for value in blueprint_json[each_component_parameter]:
                blueprint_parameters.append(value["name"])
                if "properties" in value.keys():
                    for each_property in value["properties"]:
                        if "link_to_attribute" in each_property.keys():
                            blueprint_parameters.append(each_property["link_to_attribute"])
                else:
                    blueprint_parameters.append(value["name"])
        assert_equal(set(blueprint_parameters), set(x))
