# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| Test cases for Activation Layer
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import inspect
import rztdl.dl
import tensorflow as tf
from nose import with_setup  # optional
from nose.tools import *
from rztdl import RZTDL_STORE, RZTDL_CONFIG
from rztdl.dl.helpers.tfhelpers import GraphUtils
from rztdl.utils.dl_exception import ComponentException, RangeError


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    pass


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    pass


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestActivationLayer:
    """
    | **@author:** Himaprasoon P T
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        pass

    def setup(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Runs before a new method in the class is called
        """
        RZTDL_CONFIG.update_dl_config_manager(
            config_file_path='/'.join(__file__.split('/')[:-5]) + '/rztdl_testing_config.json')
        self.model.clear_components()
        self.model.add_component(self.input_buffer)

    def teardown(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Runs after each method is called
        """

        pass

    @classmethod
    def setup_class(cls):
        print("*********Activation  Layer Test Case . . .*********")
        cls.model_name = 'test_activation_layer_model'
        cls.model = rztdl.dl.Model(cls.model_name)
        cls.input_buffer = rztdl.dl.buffer.InBuffer(name='input_buffer', buffer_features=3)
        cls.model.add_component(cls.input_buffer)

    @classmethod
    def teardown_class(cls):
        print("*********Activation Test Case completed successfully . . .*********")

    def test_name_validation(self):
        false_names = ['layer 1', 'layer .', '%layer']
        for name in false_names:
            try:
                rztdl.dl.layer.ActivationLayer(name=name)
                raise Exception('Invalid name validated . . .')
            except NameError:
                pass

    def test_create_component(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Create Component
        """
        temp_layer = rztdl.dl.layer.ActivationLayer(name='ac_layer',
                                                    component_input=self.input_buffer.name).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        # Test TF Collection Insertion
        assert len(tf.get_collection(temp_layer.component_output)) == 1

        # Test Dropout
        temp_layer = rztdl.dl.layer.ActivationLayer(name='ac_layer_dp', layer_dropout=0.5,
                                                    component_input=self.input_buffer.name).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert '/dropout/' in temp_layer.component_output

        temp_layer = rztdl.dl.layer.ActivationLayer(name='ac_layer_manual',
                                                    layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                    component_input=self.input_buffer.name).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)

        assert 'Relu' in temp_layer.component_output

        self.model.add_component(
            rztdl.dl.layer.ActivationLayer('test_fc_layer_input_tensor', component_input=GraphUtils.get_tensor(
                name=self.input_buffer.component_output)))
        # Test String as Layer Input
        self.model.add_component(
            rztdl.dl.layer.ActivationLayer('test_fc_layer_input_str', component_input='test_fc_layer_input_tensor'))

    def test_dropout_range_error(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Dropout Range
        """
        try:
            rztdl.dl.layer.ActivationLayer(name='activation_layer_dropout_test', layer_dropout=-0.2,
                                           component_input=self.input_buffer.name).create_component(
                model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
            assert False
        except RangeError:
            assert True

        try:
            rztdl.dl.layer.ActivationLayer(name='activation_layer_dropout_test', layer_dropout=1.2,
                                           component_input=self.input_buffer.name).create_component(
                model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
            assert False
        except RangeError:
            assert True

    def test_names(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Names
        | 1. Layer Output
        """
        temp_layer = rztdl.dl.layer.ActivationLayer(name='act_layer_name_test',
                                                    component_output='act_layer_name_test_output',
                                                    component_input=self.input_buffer.name).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer,
            component_id=2)

        # Check in Tensorflow Collection
        assert len(tf.get_collection(temp_layer.component_output_name)) == 1
        assert len(tf.get_collection(temp_layer.component_output)) == 1

        # Check in RZTDL Store
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=temp_layer.name)
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=temp_layer.component_output_name)

    def test_component_exception(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Component Exception
        """

        # 1. Component Input is of type tensor
        # noinspection PyTypeChecker
        self.this_ip_buffer_1 = rztdl.dl.buffer.InBuffer(name='this_ip_buffer_1', buffer_features=0).create_component(
            model_name=self.model_name, previous_component=None, component_id=1)

        try:
            rztdl.dl.layer.ActivationLayer(name='act_layer_excep_test_1',
                                           component_input=GraphUtils.get_tensor(
                                               self.this_ip_buffer_1.component_output)).create_component(
                model_name=self.model_name, previous_component=self.this_ip_buffer_1, component_id=2)
            assert False
        except ComponentException:
            assert True

        # 2. Component Input is of type String

        try:
            rztdl.dl.layer.ActivationLayer(name='act_layer_excep_test_2',
                                           component_input=self.this_ip_buffer_1.name).create_component(
                model_name=self.model_name, previous_component=self.this_ip_buffer_1, component_id=2)
            assert False
        except ComponentException:
            assert True

        # 3. Fetch from previous component if component is of type layer
        try:
            fcl = rztdl.dl.layer.ActivationLayer(name='act_layer_excep_test_2',
                                                 component_input=self.this_ip_buffer_1.name).create_component(
                model_name=self.model_name, previous_component=self.this_ip_buffer_1, component_id=2)
            fcl.component_output = None
            rztdl.dl.layer.FullyConnectedLayer(name='act_layer_excep_test_3',
                                               ).create_component(
                model_name=self.model_name, previous_component=fcl, component_id=2)
            assert False
        except ComponentException:
            assert True

    # noinspection PyDunderSlots,PyUnresolvedReferences
    @raises(AttributeError)
    def test_slots(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Slot functionality
        """
        rztdl.dl.layer.ActivationLayer(name='test_act_layer').new_var_comp = 0

    def test_tensorboard_summaries(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Tensorboard summaries
        """

        # Default True
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = True
        rztdl.dl.layer.ActivationLayer(name='act_layer_sum_test_1',
                                       component_input=self.input_buffer.name).create_component(
            model_name=self.model_name,
            previous_component=self.input_buffer,
            component_id=2)

        summary_collection = [coll.name for coll in tf.get_collection(tf.GraphKeys.SUMMARIES)]
        assert 'act_layer_sum_test_1/summaries/' in summary_collection[-1]

        # Default False
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = False
        rztdl.dl.layer.ActivationLayer(name='act_layer_sum_test_2',
                                       component_input=self.input_buffer.name).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert len(tf.get_collection(tf.GraphKeys.SUMMARIES)) == len(summary_collection)

        # Parameter False
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = True
        rztdl.dl.layer.ActivationLayer(name='act_layer_sum_test_3',
                                       component_input=self.input_buffer.name,
                                       layer_summaries=False).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert len(tf.get_collection(tf.GraphKeys.SUMMARIES)) == len(summary_collection)

        # Parameter True
        RZTDL_CONFIG.TensorflowConfig.TENSORBOARD_SUMMARY = False
        rztdl.dl.layer.ActivationLayer(name='act_layer_sum_test_4',
                                       component_input=self.input_buffer.name,
                                       layer_summaries=True).create_component(
            model_name=self.model_name, previous_component=self.input_buffer, component_id=2)
        assert len(tf.get_collection(tf.GraphKeys.SUMMARIES)) > len(summary_collection)

    def test_blueprint_json_parameters(self):
        """
        |**@author:** Umesh Kumar
        |
        | Test Blueprint JSON Parameters
        """
        blueprint_json = rztdl.dl.layer.ActivationLayer.blueprint().to_json()
        x = [parameter for parameter in inspect.signature(rztdl.dl.layer.ActivationLayer).parameters.keys()]
        input_parameters = [value["name"] for value in blueprint_json["inputs"]]
        component_parameters = [value["name"] for value in blueprint_json["parameters"]]
        output_parameters = [value["name"] for value in blueprint_json["outputs"]]
        blueprint_parameters = input_parameters + component_parameters + output_parameters
        assert_equal(set(blueprint_parameters), set(x))
