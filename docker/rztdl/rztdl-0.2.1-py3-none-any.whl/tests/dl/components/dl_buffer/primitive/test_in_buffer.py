# -*- coding: utf-8 -*-
"""
| **@created on:** 30/05/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| Input Buffer Test Cases
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

import rztdl.dl
from nose.tools import *
import nose
from rztdl import RZTDL_CONFIG
import tensorflow as tf
from nose import with_setup  # optional
from rztdl.utils.dl_exception import ShapeError
from rztdl import RZTDL_STORE
import inspect


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    pass


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    pass


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestInBuffer:
    """
    | **@author:** Prathyush SP
    |
    | InBuffer Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        pass

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method in the class is called
        """
        RZTDL_CONFIG.update_dl_config_manager(
            config_file_path='/'.join(__file__.split('/')[:-5]) + '/rztdl_testing_config.json')

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        print("*********In Buffer Test Case . . .*********")
        cls.model_name = 'test_in_buffer_model'
        cls.model = rztdl.dl.Model(cls.model_name)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        print("*********Input Layer Test Case completed successfully . . .*********")

    def test_name_validation(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests Sample Method
        """
        false_names = ['dl_layer 1', 'dl_layer .', '%dl_layer']
        for name in false_names:
            try:
                rztdl.dl.buffer.InBuffer(name=name, buffer_features=10)
                raise Exception('Invalid name validated . . .')
            except NameError:
                pass

    def test_names(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Names
        | 1. Layer Output
        :return:
        """
        # noinspection PyTypeChecker
        temp_layer = rztdl.dl.buffer.InBuffer(name='fc_layer_name_test', buffer_features=10,
                                              component_output='fc_layer_name_test_output').create_component(
            model_name=self.model_name,
            previous_component=None,
            component_id=2)

        # Check in Tensorflow Collection

        assert len(tf.get_collection(temp_layer.component_output_name)) == 1
        assert len(tf.get_collection(temp_layer.component_output)) == 1

        # Check in RZTDL Store
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=temp_layer.name)
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=temp_layer.component_output_name)

    # noinspection PyTypeChecker
    @raises(ShapeError)
    def test_layer_shape_exception(self):
        """
        | **@author:** Prathyush SP
        |
        | Raise exception when Layer nodes and Layer Shape is None
        :return:
        """
        rztdl.dl.buffer.InBuffer(name='dl_layer').create_component(model_name='a', previous_component='1',
                                                                   component_id=1)

    # noinspection PyTypeChecker
    @raises(ShapeError)
    def test_layer_shape_dimension_exception(self):
        """
        | **@author:** Prathyush SP
        |
        | Raise exception when Layer nodes and Layer Shape is None
        """
        # Provide Valid shape
        rztdl.dl.buffer.InBuffer(name='dl_layer', buffer_shape=[1, 10]).create_component(model_name=self.model_name,
                                                                                         previous_component='1',
                                                                                         component_id=1)

        rztdl.dl.buffer.InBuffer(name='dl_layer', buffer_shape=[1]).create_component(model_name=self.model_name,
                                                                                     previous_component='1',
                                                                                     component_id=1)

    # noinspection PyDunderSlots,PyUnresolvedReferences
    @raises(AttributeError)
    def test_slots(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Slot functionality
        """
        rztdl.dl.buffer.InBuffer(name='test_in_buffer').new_var_comp = 0

    def test_layer_insertions(self):
        """
        | **@author:** Prathyush SP
        |
        | Test layer insertions
        """
        buffer_name = 'input_buffer'
        input_layer = self.model.add_component(rztdl.dl.buffer.InBuffer(name=buffer_name, buffer_features=10))

        # Test tf.collection
        assert len(tf.get_collection(input_layer.name)) == 1

        # Test RZTDL DAG for placeholder insertion
        RZTDL_STORE.get_placeholder(model_name=self.model_name, layer_name=buffer_name)

    def test_blueprint_json_parameters(self):
        """
        | *@author:* Umesh Kumar
        |
        | Test Component Blueprint
        """
        blueprint_json = rztdl.dl.buffer.InBuffer.blueprint().to_json()
        x = [parameter for parameter in inspect.signature(rztdl.dl.buffer.InBuffer).parameters.keys()]
        blueprint_parameters = []
        component_parameters = ["inputs", "parameters", "outputs"]
        for each_component_parameter in component_parameters:
            for value in blueprint_json[each_component_parameter]:
                blueprint_parameters.append(value["name"])
                if "properties" in value.keys():
                    for each_property in value["properties"]:
                        if "link_to_attribute" in each_property.keys():
                            blueprint_parameters.append(each_property["link_to_attribute"])
                else:
                    blueprint_parameters.append(value["name"])
        assert_equal(set(blueprint_parameters), set(x))