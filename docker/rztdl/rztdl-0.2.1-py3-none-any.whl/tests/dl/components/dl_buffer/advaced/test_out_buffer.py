# -*- coding: utf-8 -*-
"""
| **@created on:** 23/06/18,
| **@author:** prathyushsp,
| **@version:** v0.0.1
|
| **Description:**
| Test Outbuffer Module
|
| **Sphinx Documentation Status:** --
|
..todo::
"""

import rztdl.dl
from nose.tools import *
import nose
from rztdl import RZTDL_CONFIG
import tensorflow as tf
from nose import with_setup  # optional
from rztdl.utils.dl_exception import ShapeError
from rztdl import RZTDL_STORE
import rztdl.dl
import inspect


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    pass


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    pass


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestOutBuffer:
    """
    | **@author:** Prathyush SP
    |
    | Outbuffer Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        pass

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method in the class is called
        """
        RZTDL_CONFIG.update_dl_config_manager(
            config_file_path='/'.join(__file__.split('/')[:-5]) + '/rztdl_testing_config.json')
        self.model.clear_components()
        self.model.add_component(self.input_buffer)

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        print("*********Out Buffer Test Case . . .*********")
        cls.model_name = 'test_out_buffer_model'
        cls.model = rztdl.dl.Model(cls.model_name)
        cls.input_buffer = rztdl.dl.buffer.InBuffer(name='inp_buffer', buffer_features=2).create_component(
            model_name=cls.model_name, previous_component=None, component_id=1)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        print("*********Input Layer Test Case completed successfully . . .*********")

    def test_name_validation(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests Sample Method
        """
        false_names = ['dl_layer 1', 'dl_layer .', '%dl_layer']
        for name in false_names:
            try:
                rztdl.dl.buffer.OutBuffer(name=name)
                raise Exception('Invalid name validated . . .')
            except NameError:
                pass

    def test_names(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Layer Names
        | 1. Layer Output
        :return:
        """
        self.model.add_component(
            rztdl.dl.buffer.InBuffer(name="sepal_features_buffer", buffer_shape=[None, 2],
                                     component_output='sepal_buffer'))

        self.model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1",
                                                                    layer_nodes=10, component_input='sepal_buffer'))

        # noinspection PyTypeChecker
        temp_layer = rztdl.dl.buffer.OutBuffer(name='fc_layer_name_test',
                                               component_input='hidden_layer_1').create_component(
            model_name=self.model_name,
            previous_component=None,
            component_id=2)

        # Check in RZTDL Store
        RZTDL_STORE.get_component_output_as_tensor(model_name=self.model_name, component_name=temp_layer.name)

    # noinspection PyDunderSlots,PyUnresolvedReferences
    @raises(AttributeError)
    def test_slots(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Slot functionality
        """
        rztdl.dl.buffer.OutBuffer(name='test_out_buffer').new_var_comp = 0

    def test_layer_insertions(self):
        """
        | **@author:** Prathyush SP
        |
        | Test layer insertions
        """
        buffer_name = 'output_buffer'
        self.model.add_component(
            rztdl.dl.buffer.InBuffer(name="sepal_features_buffer_1", buffer_shape=[None, 2],
                                     component_output='sepal_buffer'))

        self.model.add_component(rztdl.dl.layer.FullyConnectedLayer(name="hidden_layer_1_2",
                                                                    layer_nodes=10,
                                                                    component_input='sepal_features_buffer_1'))
        output_buffer = self.model.add_component(
            rztdl.dl.buffer.OutBuffer(name=buffer_name))

        # Test tf.collection
        assert len(tf.get_collection(output_buffer.name)) == 1

    def test_blueprint_json_parameters(self):
        """
        | *@author:* Umesh Kumar
        |
        | Test Component Blueprint
        """
        blueprint_json = rztdl.dl.buffer.OutBuffer.blueprint().to_json()
        x = [parameter for parameter in inspect.signature(rztdl.dl.buffer.OutBuffer).parameters.keys()]
        blueprint_parameters = []
        component_parameters = ["inputs", "parameters", "outputs"]
        for each_component_parameter in component_parameters:
            for value in blueprint_json[each_component_parameter]:
                blueprint_parameters.append(value["name"])
                if "properties" in value.keys():
                    for each_property in value["properties"]:
                        if "link_to_attribute" in each_property.keys():
                            blueprint_parameters.append(each_property["link_to_attribute"])
                else:
                    blueprint_parameters.append(value["name"])
        assert_equal(set(blueprint_parameters), set(x))
