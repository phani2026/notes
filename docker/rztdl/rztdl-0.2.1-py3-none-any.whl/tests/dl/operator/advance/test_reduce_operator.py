# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import rztdl.dl
from nose.tools import *
import tensorflow as tf
from collections import OrderedDict


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    print('********** Starting {} tests . . . **********'.format(__name__))


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    print('**********  {} tests completed successfully . . . **********'.format(__name__))


class TestReduceOperator:
    """
    | **@author:** Thebzeera V
    |
    | **Description:**
    | reduce dl_operator module contains various utilities required to test using nose test cases
    | 1. reduce dl_operator Input dl_layer
    | 2. reduce dl_operator Fully connected dl_layer
    | 3. reduce dl_operator Convolution dl_layer
    | 4. reduce dl_operator Pool dl_layer
    | 5. reduce dl_operator Output dl_layer
    | 6. validate reduce dl_operator output
    """

    def __init__(self):
        """
        | Initialize Test dl_operator
        """
        self.model_name = None
        self.model = None
        self.operator_name = None

    def setup(self):
        """
        | **@author:** Thebzeera V
        |
        | Runs before a new method is called
        """
        rztdl.RZTDL_DAG.dag = OrderedDict()
        self.model_name = 'test_model'
        self.model = rztdl.dl.Model(self.model_name)
        self.operator_name = 'Reduce_max'
        self.input_layer = rztdl.dl.dl_layer.InputLayer('input_Layer', layer_nodes=10)

    def teardown(self):
        """
        | **@author:** Thebzeera V
        |
        | Runs after each method is called
        """

        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Thebzeera V
        |
        | Runs during class initialization
        """
        cls.a = [i for i in range(32)]
        cls.b = tf.Variable(cls.a)
        cls.input = tf.reshape(cls.b, (2, 2, 2, 4))
        cls.tensor_max = tf.reduce_max(input_tensor=cls.input, axis=3, keep_dims=True)
        cls.tensor_min = tf.reduce_min(input_tensor=cls.input, axis=3, keep_dims=True)
        cls.tensor_mean = tf.reduce_mean(input_tensor=cls.input, axis=3, keep_dims=True)
        cls.init = tf.global_variables_initializer()
        cls.sess = tf.InteractiveSession()
        cls.sess.run(cls.init)
        cls.operator_type = rztdl.dl.constants.REDUCE_OPERATOR.MAX

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Thebzeera V
        |
        | Runs after class reference is removed / class test cases are completed
        """
        cls.sess.close()

    def test_operator_name(self):
        """
        | **@author:** Thebzeera v
        |
        | Tests Operator Name Validation
        """
        false_names = ['reduce 1', 'reduce .', '%reduce']
        for name in false_names:
            try:
                rztdl.dl.dl_operator(name)
                exit()
            except:
                assert True

    def test_input_layer_reduce_operator(self):

        """
        | **@author:** Thebzeera v
        |
        | Test input dl_layer reduce dl_operator
        """
        self.model.add_layer(self.input_layer)
        output_reduce_min = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_min', operator_input='input_Layer', dimension=1,
                                                keep_dimension=True,
                                                operator_output='reduce_min_op',
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MIN))
        output_max = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_max', operator_input='input_Layer', dimension=1,
                                                keep_dimension=True,
                                                operator_output='reduce_max_op',
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MAX)
        )

        output_mean = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_mean', operator_input='input_Layer', dimension=1,
                                                keep_dimension=True,
                                                operator_output='reduce_mean_op',
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MEAN)
        )
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'reduce_min')
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'reduce_min_op')
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'reduce_max')
        # Test the shape of reduce min dl_operator
        assert_equal(output_reduce_min.get_shape().as_list(), [None, 1])
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'reduce_max_op')
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'reduce_mean')
        # Test the shape of reduce mean dl_operator
        assert_equal(output_max.get_shape().as_list(), [None, 1])
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'reduce_mean_op')
        # Test the shape of reduce mean dl_operator
        assert_equal(output_mean.get_shape().as_list(), [None, 1])

    def test_fully_connected_reduce_operator(self):
        """
        | **@author:** Thebzeera v
        |
        | Test fully connected dl_layer reduce dl_operator
        """
        self.model.add_layer(self.input_layer)
        self.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer('fully_connected_layer',
                                                                   layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID,
                                                                   layer_nodes=10))
        output = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_mean', operator_input='fully_connected_layer', dimension=1,
                                                keep_dimension=False,
                                                operator_output='reduce_mean_op',
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MEAN))
        output_max = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_max', operator_input='fully_connected_layer', dimension=1,
                                                keep_dimension=False,
                                                operator_output='reduce_max_op',
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MAX))
        output_min = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_min', operator_input='fully_connected_layer', dimension=1,
                                                keep_dimension=False,
                                                operator_output='reduceop',
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MIN))

        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'reduce_min')
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'reduceop')
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'reduce_max')
        # Test the shape of reduce min dl_operator
        assert_equal(output_min.get_shape().as_list(), [None])
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'reduce_max_op')
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'reduce_mean')
        # Test the shape of reduce mean dl_operator
        assert_equal(output_max.get_shape().as_list(), [None])
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'reduce_mean_op')
        # Test the shape of reduce mean dl_operator
        assert_equal(output.get_shape().as_list(), [None])

    def test_convolution_layer_reduce_operator(self):
        """
        | **@author:** Thebzeera v
        |
        | Test convolution dl_layer reduce dl_operator
        """
        self.model.add_layer(self.input_layer)
        self.model.add_operator(rztdl.dl.dl_operator.ReshapeOperator(self.operator_name, operator_input='input_Layer',
                                                                     operator_output='reshape_out',
                                                                     shape=[-1, 1, 1, 1]))

        self.model.add_layer(rztdl.dl.dl_layer.ConvolutionLayer('convolution_layer',
                                                                layer_activation=rztdl.dl.constants.ACTIVATION.RELU,
                                                                filter_dimensions=[1, 1, 1, 1],
                                                                filter_strides=[1, 2, 3, 1],
                                                                filter_padding=rztdl.dl.constants.PADDING.SAME,
                                                                layer_input='reshape_out'))
        output = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_mean', operator_input='convolution_layer', dimension=1,
                                                keep_dimension=False,
                                                operator_output='reduce_mean_op',
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MEAN))
        output_max = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_max', operator_input='convolution_layer', dimension=1,
                                                keep_dimension=False,
                                                operator_output='reduce_max_op',
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MAX))
        output_min = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_min', operator_input='convolution_layer', dimension=1,
                                                keep_dimension=False,
                                                operator_output='reduceop',
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MIN))

        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'reduce_min')
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'reduceop')
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'reduce_max')
        # Test the shape of reduce min dl_operator
        assert_equal(output_min.get_shape().as_list(), [None, 1, 1])
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'reduce_max_op')
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'reduce_mean')
        # Test the shape of reduce mean dl_operator
        assert_equal(output_max.get_shape().as_list(), [None, 1, 1])
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'reduce_mean_op')
        # Test the shape of reduce mean dl_operator
        assert_equal(output.get_shape().as_list(), [None, 1, 1])

    def test_pool_layer_reduce_max(self):
        """
        | **@author:** Thebzeera v
        |
        | Test pool dl_layer reduce dl_operator
        """

        self.model.add_layer(self.input_layer)
        self.model.add_operator(rztdl.dl.dl_operator.ReshapeOperator(self.operator_name, operator_input='input_Layer',
                                                                     operator_output='reshape_out',
                                                                     shape=[-1, 2, 2, 1]))

        pool = self.model.add_layer(
            rztdl.dl.dl_layer.PoolLayer('pool', pool_dimensions=[1, 4, 4, 1], pool_strides=[1, 1, 1, 1],
                                        pool_padding=rztdl.dl.constants.PADDING.SAME,
                                        pool_type=rztdl.dl.constants.POOL.MAX_POOL,
                                        layer_input='reshape_out'))
        # print(pool.get_shape())
        output = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_mean', operator_input='pool', dimension=1,
                                                keep_dimension=True,
                                                operator_output='reduce_mean_op',
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MEAN))
        # print(output.get_shape())
        output_max = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_max', operator_input='pool', dimension=1,
                                                keep_dimension=False,
                                                operator_output='reduce_max_op',
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MAX))
        output_min = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_min', operator_input='pool', dimension=1,
                                                keep_dimension=False,
                                                operator_output='reduceop',
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MIN))

        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'reduce_min')
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'reduceop')
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'reduce_max')
        # Test the shape of reduce min dl_operator
        assert_equal(output_min.get_shape().as_list(), [None, 2, 1])
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'reduce_max_op')
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'reduce_mean')
        # Test the shape of reduce mean dl_operator
        assert_equal(output_max.get_shape().as_list(), [None, 2, 1])
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'reduce_mean_op')
        # Test the shape of reduce mean dl_operator
        assert_equal(output.get_shape().as_list(), [None, 1, 2, 1])

    def test_output_layer_reduce_operator(self):
        """
        | **@author:** Thebzeera v
        |
        | Test Output dl_layer reduce dl_operator
        """

        self.model.add_layer(self.input_layer)
        self.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer('fully_connected_layer',
                                                                   layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID,
                                                                   layer_nodes=6))
        self.model.add_layer(
            rztdl.dl.dl_layer.OutputLayer(name='output_name', layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID,
                                          layer_nodes=3, layer_input='fully_connected_layer'))
        output = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_mean', operator_input='output_name', dimension=1,
                                                keep_dimension=False,
                                                operator_output='reduce_mean_op',
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MEAN))
        output_max = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_max', operator_input='output_name', dimension=1,
                                                keep_dimension=False,
                                                operator_output='reduce_max_op',
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MAX))
        output_min = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_min', operator_input='output_name', dimension=1,
                                                keep_dimension=False,
                                                operator_output='reduceop',
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MIN))

        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'reduce_min')
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'reduceop')
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'reduce_max')
        # Test the shape of reduce min dl_operator
        assert_equal(output_min.get_shape().as_list(), [None])
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'reduce_max_op')
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'reduce_mean')
        # Test the shape of reduce mean dl_operator
        assert_equal(output_max.get_shape().as_list(), [None])
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'reduce_mean_op')
        # Test the shape of reduce mean dl_operator
        assert_equal(output.get_shape().as_list(), [None])

    def test_reduce_operator(self):
        """
        | **@author:** Thebzeera v
        |
        | Test reduce dl_operator output
        """

        self.max = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce', operator_input=self.input, dimension=3,
                                                operator_output='reduceop', keep_dimension=True,
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MAX))
        self.min = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_min', operator_input=self.input, dimension=3,
                                                operator_output='reduce_op_min', keep_dimension=True,
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MIN))
        self.mean = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce_mean', operator_input=self.input, dimension=3,
                                                operator_output='reduce_op_mean', keep_dimension=True,
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MEAN))
        output_tensor_max, output_reduce_max = self.sess.run([self.tensor_max, self.max])
        output_tensor, output_reduce = self.sess.run([self.tensor_mean, self.mean])
        output_tensor_min, output_reduce_min = self.sess.run([self.tensor_min, self.min])
        # Test reduce mean
        assert_equal(output_tensor.all(), output_reduce.all())
        # Test reduce max
        assert_equal(output_tensor_max.all(), output_reduce_max.all())
        # Test reduce min
        assert_equal(output_tensor_min.all(), output_reduce_min.all())

    def test_keep_dimension(self):
        """

        :return:
        """
        self.max = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce', operator_input=self.input, dimension=3,
                                                operator_output='reduceop', keep_dimension=False,
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MAX))
        output_tensor_max, output_reduce_max = self.sess.run([self.tensor_max, self.max])
        assert_not_equal(output_tensor_max.shape, output_reduce_max.shape)

    @raises(Exception)
    def test_reduce_operator_type(self):

        self.max = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce', operator_input=self.input, dimension=3,
                                                operator_output='reduceop', keep_dimension=False,
                                                operator_type="reduce_max"))

    @raises(Exception)
    def test_dimension_range(self):

        self.max = self.model.add_operator(
            rztdl.dl.dl_operator.ReduceOperator(name='reduce', operator_input=self.input, dimension=10,
                                                operator_output='reduceop', keep_dimension=False,
                                                operator_type=rztdl.dl.constants.REDUCE_OPERATOR.MAX))
