# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import rztdl.dl
from tensorflow import Tensor
from nose.tools import *
import tensorflow as tf
from collections import OrderedDict
from nose import with_setup  # optional


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    print('********** Starting {} tests . . . **********'.format(__name__))


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    print('**********  {} tests completed successfully . . . **********'.format(__name__))


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestConcatOperator:
    """
    | **@author:** Thebzeera V
    |
    | **Description:**
    |  Mul dl_operator module contains various utilities required to test using nose test cases
    | 1. concat dl_operator validation
    | 2. concat dl_operator on Input dl_layer
    | 3. concat dl_operator on connected dl_layer
    | 4. concat dl_operator on Convolution dl_layer
    | 5. concat dl_operator on Pool dl_layer
    """

    def __init__(self):
        """
        | Initialize Test dl_operator name
        """
        self.model = None
        self.model_name = None
        self.operator_name = None

    def setup(self):
        """
        | **@author:** Thebzeera V
        |
        | Runs before a new method is called
        """
        rztdl.RZTDL_DAG.dag = OrderedDict()
        tf.reset_default_graph()
        self.input_layer = rztdl.dl.dl_layer.InputLayer('input_Layer', layer_nodes=10)
        self.model_name = 'test_model'
        self.model = rztdl.dl.Model(self.model_name)
        self.operator_name = 'con'

    def teardown(self):
        """
        | **@author:** Thebzeera V
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Thebzeera V
        |
        | Runs during class initialization
        """
        cls.session = tf.InteractiveSession()

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Thebzeera V
        |
        | Runs after class reference is removed / class test cases are completed
        """
        cls.session.close()

    def test_operator_name(self):
        """
        | **@author:** Thebzeera v
        |
        | Tests Model Name Validation
        """
        false_names = ['con 1', 'con .', '%con']
        for name in false_names:
            try:
                rztdl.dl.dl_operator(name)
                exit()
            except:
                assert True

    @raises(Exception)
    def test_validation(self):
        """
        | **@author:** Thebzeera v
        |
        | Test the concat dl_operator raises exception when trying to concat two different shapes of dl_layer
        """
        self.model.add_layer(self.input_layer)
        self.model.add_operator(rztdl.dl.dl_operator.ReshapeOperator(self.operator_name, operator_input='input_Layer',
                                                                     operator_output='reshape_out',
                                                                     shape=[-1, 2, 2]))
        self.model.add_layer(rztdl.dl.dl_layer.ConvolutionLayer('convolution_layer',
                                                                layer_activation=rztdl.dl.constants.ACTIVATION.RELU,
                                                                filter_dimensions=[1, 1, 1, 1],
                                                                filter_strides=[1, 2, 3, 1],
                                                                filter_padding=rztdl.dl.constants.PADDING.SAME,
                                                                layer_input='reshape_out'))
        self.model.add_layer(rztdl.dl.dl_layer.ConvolutionLayer('convolution_layer1',
                                                                layer_activation=rztdl.dl.constants.ACTIVATION.RELU,
                                                                filter_dimensions=[1, 1, 1, 1],
                                                                filter_strides=[1, 2, 3, 1],
                                                                filter_padding=rztdl.dl.constants.PADDING.SAME,
                                                                layer_input='convolution_layer'))
        self.model.add_operator(rztdl.dl.dl_operator.ConcatOperator(self.operator_name,
                                                                    operator_input=[1, 2, 3, 4],
                                                                    operator_output='concat_out',
                                                                    dimension=2))

    def test_2d_concat_operator(self):
        """
        | **@author:** Thebzeera v
        |
        | Test Concat dl_operator on 2 Dimension
        """
        tensor = tf.placeholder(dtype=tf.float32, shape=(3, 10))
        self.model.add_layer(self.input_layer)
        self.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer('fully_connected_layer',
                                                                   layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID,
                                                                   layer_nodes=5))

        self.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer('fully_connected_layer1',
                                                                   layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID,
                                                                   layer_nodes=5))
        concat_operator_output = self.model.add_operator(rztdl.dl.dl_operator.ConcatOperator("con2",
                                                                                             operator_input=['input_Layer',
                                                                                                          'fully_connected_layer',
                                                                                                          'fully_connected_layer1'],
                                                                                             operator_output='concat_out',
                                                                                             dimension=1))
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'con2')
        # Test for dimension 1
        assert (concat_operator_output.get_shape().as_list() == [None, 20])
        # Test the instance of the variable
        assert isinstance(concat_operator_output, Tensor)
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'concat_out')
        # Test type
        assert type(concat_operator_output) == type(tensor)

    def test_4d_concat_operator(self):
        """
        **@author:** Thebzeera v
        |
        | Test Concat dl_operator on 4 Dimension
        |
        """
        tensor = tf.placeholder(dtype=tf.float32, shape=(3, 10))
        self.model.add_layer(self.input_layer)
        self.model.add_operator(rztdl.dl.dl_operator.ReshapeOperator(self.operator_name, operator_input='input_Layer',
                                                                     operator_output='reshape_out',
                                                                     shape=[-1, 1, 1, 1]))
        self.model.add_layer(rztdl.dl.dl_layer.ConvolutionLayer('convolution_layer',
                                                                layer_activation=rztdl.dl.constants.ACTIVATION.RELU,
                                                                filter_dimensions=[1, 1, 1, 1],
                                                                filter_strides=[1, 2, 3, 1],
                                                                filter_padding=rztdl.dl.constants.PADDING.SAME,
                                                                layer_input='reshape_out'))

        self.model.add_layer(rztdl.dl.dl_layer.ConvolutionLayer('convolution_layer1',
                                                                layer_activation=rztdl.dl.constants.ACTIVATION.RELU,
                                                                filter_dimensions=[1, 1, 1, 1],
                                                                filter_strides=[1, 2, 3, 1],
                                                                filter_padding=rztdl.dl.constants.PADDING.SAME,
                                                                layer_input='convolution_layer'))

        concat_operator_output = self.model.add_operator(rztdl.dl.dl_operator.ConcatOperator(name="con1",
                                                                                             operator_input=[
                                                                                              'reshape_out',
                                                                                              'convolution_layer1',
                                                                                              'convolution_layer'],
                                                                                             operator_output='concat_out',
                                                                                             dimension=2))
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'con1')
        # Test for dimension 2
        assert_equal(concat_operator_output.get_shape().as_list(), [None, 1, 3, 1])
        # Test the instance of the variable
        assert isinstance(concat_operator_output, Tensor)
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'concat_out')
        # Test type
        assert type(concat_operator_output) == type(tensor)

    def test_4d_concat_operator1(self):
        """
        | **@author:** Thebzeera v
        |
        | Test Concat dl_operator on 4 Dimension
        """
        self.model.add_layer(self.input_layer)
        tensor = tf.placeholder(dtype=tf.float32, shape=(3, 10))
        self.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer('fully_connected_layer1',
                                                                   layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID,
                                                                   layer_nodes=5))
        self.model.add_operator(rztdl.dl.dl_operator.ReshapeOperator(name='ninp', operator_input='fully_connected_layer1',
                                                                     operator_output='reshape_out',
                                                                     shape=[-1, 1, 1, 1]))
        self.model.add_layer(rztdl.dl.dl_layer.PoolLayer('pool', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                                         pool_padding=rztdl.dl.constants.PADDING.SAME,
                                                         pool_type=rztdl.dl.constants.POOL.MAX_POOL,
                                                         layer_input='reshape_out'))
        concat_operator_output = self.model.add_operator(rztdl.dl.dl_operator.ConcatOperator(self.operator_name,
                                                                                             operator_input=[
                                                                                              'reshape_out',
                                                                                              'pool'],
                                                                                             operator_output='concat_out',
                                                                                             dimension=3))
        # Test for dimension 3
        assert_equal(concat_operator_output.get_shape().as_list(), [None, 1, 1, 2])
        # Test the instance of the variable
        assert isinstance(concat_operator_output, Tensor)
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'concat_out')

        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, self.operator_name)
        # Test type
        assert type(concat_operator_output) == type(tensor)

    def test_tensor(self):
        """
        | **@author:** Thebzeera V
        | test by passing operator_input in concat dl_operator as list[tensor]
        |
        """
        import numpy as np
        tensor_a = tf.constant(value=np.ones(shape=[2, 2], dtype=np.float32))
        tensor_b = tf.constant(value=np.ones(shape=[2, 4], dtype=np.float32))
        concat_operator_output = self.model.add_operator(rztdl.dl.dl_operator.ConcatOperator(self.operator_name,
                                                                                             operator_input=[tensor_b,
                                                                                                          tensor_a],
                                                                                             operator_output='concat_out',
                                                                                             dimension=1))
        # Test the instance of the variable
        assert isinstance(concat_operator_output, Tensor)
        # Test RZTDL DAG Layer Insertion
        # rztdl.dl.RZTDL_DAG.get_layer(self.model_name, 'concat_out')#***********have issue while adding to the rzdl_dag
