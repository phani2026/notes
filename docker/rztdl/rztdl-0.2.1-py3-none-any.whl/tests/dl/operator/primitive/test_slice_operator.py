# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import rztdl.dl
from nose.tools import *
import tensorflow as tf
from collections import OrderedDict
from nose import with_setup


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    print('********** Starting {} tests . . . **********'.format(__name__))


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    print('**********  {} tests completed successfully . . . **********'.format(__name__))


class TestSliceOperator:
    """
    | **@author:** Thebzeera V
    |
    | **Description:**
    | Slice module contains various utilities required to test using nose test cases
    | 1. slice Operator validation
    | 2. slice Input dl_layer
    | 3. slice Fully connected dl_layer
    | 4. slice Convolution dl_layer
    | 4. slice Pool dl_layer
    | 5. slice Output dl_layer
    | 6. validate slice output
    """

    def __init__(self):
        """
        | Initialize Test dl_operator
        """
        self.model_name = None
        self.model = None
        self.operator_name = None

    def setup(self):
        """
        | **@author:** Thebzeera V
        |
        | Runs before a new method is called
        """
        rztdl.RZTDL_DAG.dag = OrderedDict()
        self.model_name = 'test_model'
        self.model = rztdl.dl.Model(self.model_name)
        self.operator_name = 'slice'
        self.input_layer = rztdl.dl.dl_layer.InputLayer('input_Layer', layer_nodes=10)

    def teardown(self):
        """
        | **@author:** Thebzeera V
        |
        | Runs after each method is called
        """

        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Thebzeera V
        |
        | Runs during class initialization
        """
        cls.a = [i for i in range(32)]
        cls.b = tf.Variable(cls.a)
        cls.input = tf.reshape(cls.b, (2, 2, 2, 4))
        cls.tensor = tf.slice(cls.input, [1, 1, 0, 0], [1, 1, 2, 1])
        cls.init = tf.global_variables_initializer()
        cls.sess = tf.InteractiveSession()
        cls.sess.run(cls.init)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Thebzeera V
        |
        | Runs after class reference is removed / class test cases are completed
        """
        cls.sess.close()

    def test_operator_name(self):
        """
        | **@author:** Thebzeera v
        |
        | Tests Operator Name Validation
        """
        false_names = ['slice 1', 'slice .', '%slice']
        for name in false_names:
            try:
                rztdl.dl.dl_operator(name)
                exit()
            except:
                assert True

    @raises(Exception)
    def test_validate_begin(self):
        """
        | **@author:** Thebzeera v
        |
        | Test the slice dl_operator raises exception when trying to slice input with different shapes of begin
        """
        self.model.add_layer(self.input_layer)
        self.model.add_operator(
            rztdl.dl.dl_operator.SliceOperator(name='slice', operator_input='input_Layer', begin=[1], size=[1, 1],
                                               operator_output='sliceop'))

    @raises(Exception)
    def test_validate_size(self):
        """
        | **@author:** Thebzeera v
        |
        | Test the slice dl_operator raises exception when trying to slice  input with different shapes of size
        """
        self.model.add_layer(self.input_layer)
        self.model.add_operator(
            rztdl.dl.dl_operator.SliceOperator(name='slice', operator_input='input_Layer', begin=[0, 1],
                                               size=[1, 1, 1], operator_output='sliceop'))

    def test_input_layer_slice(self):

        """
        | **@author:** Thebzeera v
        |
        | Test input dl_layer slice
        """

        self.model.add_layer(self.input_layer)
        output = self.model.add_operator(
            rztdl.dl.dl_operator.SliceOperator(name='slice', operator_input='input_Layer', begin=[0, 1], size=[1, 1],
                                               operator_output='sliceop'))
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'slice')
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'sliceop')
        # Test the shape
        assert_equal(output.get_shape(), [1, 1])

    def test_fully_connected_slice(self):
        """
        | **@author:** Thebzeera v
        |
        | Test fully connected dl_layer slice
        """
        self.model.add_layer(self.input_layer)
        self.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer('fully_connected_layer',
                                                                   layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID,
                                                                   layer_nodes=10))
        output = self.model.add_operator(
            rztdl.dl.dl_operator.SliceOperator(name='slice1', operator_input='fully_connected_layer', begin=[0, 1],
                                               size=[1, 1],
                                               operator_output='sliceop'))
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'slice1')
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'sliceop')
        # Test the shape
        assert_equal(output.get_shape(), [1, 1])

    def test_convolution_layer_slice(self):
        """
        | **@author:** Thebzeera v
        |
        | Test convolution dl_layer slice
        """
        self.model.add_layer(self.input_layer)
        self.model.add_operator(rztdl.dl.dl_operator.ReshapeOperator(self.operator_name, operator_input='input_Layer',
                                                                     operator_output='reshape_out',
                                                                     shape=[-1, 1, 1, 1]))

        self.model.add_layer(rztdl.dl.dl_layer.ConvolutionLayer('convolution_layer',
                                                                layer_activation=rztdl.dl.constants.ACTIVATION.RELU,
                                                                filter_dimensions=[1, 1, 1, 1],
                                                                filter_strides=[1, 2, 3, 1],
                                                                filter_padding=rztdl.dl.constants.PADDING.SAME,
                                                                layer_input='reshape_out'))
        output = self.model.add_operator(
            rztdl.dl.dl_operator.SliceOperator(name='slice2', operator_input='convolution_layer', begin=[0, 1, 0, 0],
                                               size=[1, 1, 3, 1],
                                               operator_output='sliceop'))
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'slice2')
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'sliceop')
        # Test the shape
        assert_equal(output.get_shape(), [1, 1, 3, 1])

    def test_pool_layer_slice(self):
        """
        | **@author:** Thebzeera v
        |
        | Test pool dl_layer slice
        """

        self.model.add_layer(self.input_layer)
        self.model.add_operator(rztdl.dl.dl_operator.ReshapeOperator(self.operator_name, operator_input='input_Layer',
                                                                     operator_output='reshape_out',
                                                                     shape=[-1, 2, 2, 1]))

        self.model.add_layer(rztdl.dl.dl_layer.PoolLayer('pool', pool_dimensions=[1, 4, 4, 1], pool_strides=[1, 1, 1, 1],
                                                         pool_padding=rztdl.dl.constants.PADDING.SAME,
                                                         pool_type=rztdl.dl.constants.POOL.MAX_POOL,
                                                         layer_input='reshape_out'))
        output = self.model.add_operator(
            rztdl.dl.dl_operator.SliceOperator(name='slice3', operator_input='pool', begin=[0, 1, 0, 0],
                                               size=[1, 1, 3, 1], operator_output='sliceop'))
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'slice3')
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'sliceop')
        # Test the shape
        assert_equal(output.get_shape(), [1, 1, 3, 1])

    def test_output_layer_slice(self):
        """
        | **@author:** Thebzeera v
        |
        | Test Output dl_layer slice
        """

        self.model.add_layer(self.input_layer)
        self.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer('fully_connected_layer',
                                                                   layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID,
                                                                   layer_nodes=6))
        self.model.add_layer(
            rztdl.dl.dl_layer.OutputLayer(name='output_name', layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID,
                                          layer_nodes=3, layer_input='fully_connected_layer'))
        output = self.model.add_operator(
            rztdl.dl.dl_operator.SliceOperator(name='slice4', operator_input='output_name', begin=[0, 1],
                                               size=[1, 1], operator_output='sliceop'))
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'slice4')
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'sliceop')
        # Test the shape
        assert_equal(output.get_shape(), [1, 1])

    def test_slice(self):
        """
        | **@author:** Thebzeera v
        |
        | Test slice output
        """
        self.obj = self.model.add_operator(
            rztdl.dl.dl_operator.SliceOperator(name='slice', operator_input=self.input, begin=[1, 1, 0, 0],
                                               size=[1, 1, 2, 1], operator_output='sliceop'))

        output_tensor, output_slice = self.sess.run([self.obj, self.tensor])
        # Test Slice Output
        assert_equal(output_tensor.all(), output_slice.all())
