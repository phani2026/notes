# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import rztdl.dl
from nose.tools import *
import tensorflow as tf
from collections import OrderedDict
from nose import with_setup


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    print('********** Starting {} tests . . . **********'.format(__name__))


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    print('**********  {} tests completed successfully . . . **********'.format(__name__))


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestSubOperator:
    """
    | **@author:** Thebzeera V
    |
    | **Description:**
    |  Mul dl_operator module contains various utilities required to test using nose test cases
    | 1. sub dl_operator validation
    | 2. sub dl_operator on Input dl_layer
    | 3. sub dl_operator on connected dl_layer
    | 4. sub dl_operator on Convolution dl_layer
    | 5. sub dl_operator on Pool dl_layer
    """

    def __init__(self):
        """
        | Initialize Test dl_operator
        """
        self.model_name = None
        self.model = None
        self.operator_name = None

    def setup(self):
        """
        | **@author:** Thebzeera V
        |
        | Runs before a new method is called
        """
        rztdl.RZTDL_DAG.dag = OrderedDict()
        tf.reset_default_graph()
        self.model_name = 'test_model'
        self.model = rztdl.dl.Model(self.model_name)
        self.operator_name = 'sub'
        self.input_layer = rztdl.dl.dl_layer.InputLayer('input_Layer', layer_nodes=10)

    def teardown(self):
        """
        | **@author:** Thebzeera V
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Thebzeera V
        |
        | Runs during class initialization
        """
        cls.session = tf.InteractiveSession()

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Thebzeera V
        |
        | Runs after class reference is removed / class test cases are completed
        """
        cls.session.close()

    def test_operator_name(self):
        """
        | **@author:** Thebzeera v
        |
        | Tests Operator Name Validation
        """
        false_names = ['sub 1', 'sub .', '%sub']
        for name in false_names:
            try:
                rztdl.dl.dl_operator(name)
                exit()
            except:
                assert True

    @raises(Exception)
    def test_validation(self):
        """
        | **@author:** Thebzeera v
        |
        | Test if sub dl_operator raises exception when trying to sub two different shapes of dl_layer
        """
        self.model.add_layer(self.input_layer)
        self.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer('fully_connected_layer',
                                                                   layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID,
                                                                   layer_nodes=15
                                                                   ))
        self.model.add_operator(rztdl.dl.dl_operator.SubOperator(name='sub1',
                                                                 operator_input=['input_Layer', 'fully_connected_layer'],
                                                                 operator_output='sub_op'))

    def test_fully_sub(self):
        """
        | **@author:** Thebzeera v
        |
        | Test Sub dl_operator on 2 Dimension
        """
        self.model.add_layer(self.input_layer)
        self.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer('fully_connected_layer',
                                                                   layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID,
                                                                   layer_nodes=10))
        self.model.add_operator(rztdl.dl.dl_operator.SubOperator(name='sub',
                                                                 operator_input=['fully_connected_layer', 'input_Layer'],
                                                                 operator_output='sub_op'))
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'sub')
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'sub_op')
        # Test the shape
        assert_equal(rztdl.RZTDL_DAG.get_layer(self.model_name, 'sub_op').get_shape().as_list(), [None, 10])

    def test_con_sub(self):
        """
        | **@author:** Thebzeera v
        |
        | Test Sub dl_operator on 4 Dimension
        """
        self.model.add_layer(self.input_layer)
        self.model.add_operator(rztdl.dl.dl_operator.ReshapeOperator(self.operator_name, operator_input='input_Layer',
                                                                     operator_output='reshape_out',
                                                                     shape=[-1, 1, 1, 1]))

        self.model.add_layer(rztdl.dl.dl_layer.ConvolutionLayer('convolution_layer',
                                                                layer_activation=rztdl.dl.constants.ACTIVATION.RELU,
                                                                filter_dimensions=[1, 1, 1, 1],
                                                                filter_strides=[1, 2, 3, 1],
                                                                filter_padding=rztdl.dl.constants.PADDING.SAME,
                                                                layer_input='reshape_out'))
        self.model.add_operator(rztdl.dl.dl_operator.SubOperator(name='sub1',
                                                                 operator_input=['convolution_layer',
                                                                              'reshape_out'],
                                                                 operator_output='sub_op'))
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'sub1')
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'sub_op')
        # Test the shape
        assert_equal(rztdl.RZTDL_DAG.get_layer(self.model_name, 'sub_op').get_shape().as_list(), [None, 1, 1, 1])

    def test_pool_layer_sub(self):
        """
        | **@author:** Thebzeera v
        |
        | Test Sub dl_operator on 4 Dimension
        """
        self.model.add_layer(self.input_layer)
        self.model.add_operator(rztdl.dl.dl_operator.ReshapeOperator(self.operator_name, operator_input='input_Layer',
                                                                     operator_output='reshape_out',
                                                                     shape=[-1, 2, 2, 1]))

        self.model.add_layer(rztdl.dl.dl_layer.PoolLayer('pool', pool_dimensions=[1, 4, 4, 1], pool_strides=[1, 1, 1, 1],
                                                         pool_padding=rztdl.dl.constants.PADDING.SAME,
                                                         pool_type=rztdl.dl.constants.POOL.MAX_POOL,
                                                         layer_input='reshape_out'))

        self.model.add_operator(rztdl.dl.dl_operator.SubOperator(name='sub2',
                                                                 operator_input=['pool',
                                                                              'reshape_out'],
                                                                 operator_output='sub_op'))
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'sub2')
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'sub_op')
        # Test the shape
        assert_equal(rztdl.RZTDL_DAG.get_layer(self.model_name, 'sub_op').get_shape().as_list(), [None, 2, 2, 1])
