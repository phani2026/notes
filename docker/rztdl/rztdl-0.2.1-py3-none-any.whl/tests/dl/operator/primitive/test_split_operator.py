# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import rztdl.dl
from nose.tools import *
import tensorflow as tf
from collections import OrderedDict
from nose import with_setup  # optional


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    print('********** Starting {} tests . . . **********'.format(__name__))


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    print('**********  {} tests completed successfully . . . **********'.format(__name__))


def my_setup_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Prathyush SP
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestSplitOerator:
    """
    | **@author:** Thebzeera V
    |
    | **Description:**
    |  Mul dl_operator module contains various utilities required to test using nose test cases
    | 1. split dl_operator on Input dl_layer
    | 2. split dl_operator on connected dl_layer
    | 3. split dl_operator on Convolution dl_layer
    | 4. split dl_operator on Pool dl_layer
    """

    def __init__(self):
        """
        | Initialize Test dl_operator
        """
        self.model_name = None
        self.model = None
        self.operator_name = None

    def setup(self):
        """
        | **@author:** Thebzeera V
        |
        | Runs before a new method is called
        """
        rztdl.RZTDL_DAG.dag = OrderedDict()
        tf.reset_default_graph()
        self.model_name = 'test_model'
        self.model = rztdl.dl.Model(self.model_name)
        self.operator_name = 'split_1'
        self.input_layer = rztdl.dl.dl_layer.InputLayer('input_Layer', layer_nodes=20)
        self.input_layer1 = rztdl.dl.dl_layer.InputLayer('input_Layer', layer_nodes=25)

    def teardown(self):
        """
        | **@author:** Thebzeera V
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Thebzeera V
        |
        | Runs during class initialization
        """
        cls.session = tf.InteractiveSession()

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Thebzeera V
        |
        | Runs after class reference is removed / class test cases are completed
        """
        cls.session.close()

    def test_operator_name(self):
        """
        | **@author:** Thebzeera v
        |
        | Tests Model Name Validation
        """
        false_names = ['split 1', 'split .', '%split']
        for name in false_names:
            try:
                rztdl.dl.dl_operator(name)
                exit()
            except:
                assert True

    def test_input_layer_split(self):
        """
        | **@author:** Thebzeera v
        |
        | Test split dl_operator on Input  dl_layer
        """

        self.model.add_layer(self.input_layer)
        obj = rztdl.dl.dl_operator.SplitOperator('split5', operator_input='input_Layer',
                                                 operator_output=['split1', 'split2'],
                                                 dimension=1)
        self.model.add_operator(obj)

        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'split5')

        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'split1')
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'split2')
        # Test shape by dimension 1
        assert_equal(rztdl.RZTDL_DAG.get_layer(self.model_name, 'split1').get_shape().as_list(), [None, 10])
        assert_equal(rztdl.RZTDL_DAG.get_layer(self.model_name, 'split2').get_shape().as_list(), [None, 10])
        # Test number of split
        assert_equal(len(obj.operator_output), 2)

    def test_fully_connected_layer_split(self):
        """
        | **@author:** Thebzeera v
        |
        | Test split dl_operator on Fully connected  dl_layer
        """
        self.model.add_layer(self.input_layer)
        self.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer('fully_connected_layer',
                                                                   layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID,
                                                                   layer_nodes=6))
        obj = rztdl.dl.dl_operator.SplitOperator('split3', operator_input='fully_connected_layer',
                                                 operator_output=['split1', 'split2'],
                                                 dimension=1)
        self.model.add_operator(obj)
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'split3')
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'split1')
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'split2')
        # Test dimension 1
        assert_equal(rztdl.RZTDL_DAG.get_layer(self.model_name, 'split1').get_shape().as_list(), [None, 3])
        assert_equal(rztdl.RZTDL_DAG.get_layer(self.model_name, 'split2').get_shape().as_list(), [None, 3])
        # Test number of split
        assert_equal(len(obj.operator_output), 2)

    def test_con_split(self):
        """
        | **@author:** Thebzeera v
        |
        | Test split dl_operator on Convolution  dl_layer
        """
        self.model.add_layer(self.input_layer1)
        self.model.add_layer(rztdl.dl.dl_layer.ConvolutionLayer('convolution_layer',
                                                                layer_activation=rztdl.dl.constants.ACTIVATION.RELU,
                                                                filter_dimensions=[1, 1, 1, 1],
                                                                filter_strides=[1, 2, 3, 1],
                                                                filter_padding=rztdl.dl.constants.PADDING.SAME,
                                                                layer_input='input_Layer'))
        obj = rztdl.dl.dl_operator.SplitOperator('split1', operator_input='convolution_layer',
                                                 operator_output=['split1', 'split2'],
                                                 dimension=2)

        self.model.add_operator(obj)
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'split1')

        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'split1')
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'split2')
        # Test dimension 2
        assert_equal(rztdl.RZTDL_DAG.get_layer(self.model_name, 'split1').get_shape().as_list(), [None, 3, 1, 1])
        assert_equal(rztdl.RZTDL_DAG.get_layer(self.model_name, 'split2').get_shape().as_list(), [None, 3, 1, 1])
        # Test number of split
        assert_equal(len(obj.operator_output), 2)

    def test_pool_layer_split(self):

        """
        | **@author:** Thebzeera v
        |
        | Test split dl_operator on Pool  dl_layer
        """
        self.model.add_layer(self.input_layer1)
        self.model.add_operator(rztdl.dl.dl_operator.ReshapeOperator(self.operator_name, operator_input='input_Layer',
                                                                     operator_output='reshape_out',
                                                                     shape=[-1, 4, 4, 1]))
        self.model.add_layer(rztdl.dl.dl_layer.PoolLayer('pool', pool_dimensions=[1, 4, 4, 1], pool_strides=[1, 2, 2, 1],
                                                         pool_padding=rztdl.dl.constants.PADDING.SAME,
                                                         pool_type=rztdl.dl.constants.POOL.MAX_POOL,
                                                         layer_input='reshape_out'))
        obj = rztdl.dl.dl_operator.SplitOperator("split", operator_input='pool',
                                                 operator_output=['split1'],
                                                 dimension=3)
        self.model.add_operator(obj)

        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'split')

        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'split1')
        # Test dimension 3
        assert_equal(rztdl.RZTDL_DAG.get_layer(self.model_name, 'split1').get_shape().as_list(), [None, 2, 2, 1])
        # Test number of split
        assert_equal(len(obj.operator_output), 1)

    def test_output_layer_split(self):
        """
        | **@author:** Thebzeera v
        |
        | Test split dl_operator on Fully  dl_layer
        """

        self.model.add_layer(self.input_layer)
        self.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer('fully_connected_layer',
                                                                   layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID,
                                                                   layer_nodes=6))
        self.model.add_layer(
            rztdl.dl.dl_layer.OutputLayer(name='output_name', layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID,
                                          layer_nodes=3, layer_input='fully_connected_layer'))
        obj = rztdl.dl.dl_operator.SplitOperator("split", operator_input='output_name',
                                                 operator_output=['split1'],
                                                 dimension=1)
        self.model.add_operator(obj)
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_DAG.get_layer(self.model_name, 'split1')
        # Test updated model architecture key is present or not
        rztdl.RZTDL_DAG.get_key_of_model_operator_architecture(self.model_name, 'split')
        # Test dimension 1
        assert_equal(rztdl.RZTDL_DAG.get_layer(self.model_name, 'split1').get_shape().as_list(), [None, 3])
        # Test number of split
        assert_equal(len(obj.operator_output), 1)

    @raises(Exception)
    def test_validate(self):
        """
        | **@author:** Thebzeera v
        |
        | Test the split dl_operator raises exception when passing dl_operator output as non string
        """
        self.model.add_layer(self.input_layer)
        self.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer('fully_connected_layer',
                                                                   layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID,
                                                                   layer_nodes=6))
        self.model.add_layer(
            rztdl.dl.dl_layer.OutputLayer(name='output_name', layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID,
                                          layer_nodes=3, layer_input='fully_connected_layer', layer_dropout=.2))
        rztdl.dl.dl_operator.SplitOperator(self.operator_name, operator_input='output_name',
                                           operator_output=[1,2,3,4],
                                           dimension=1)

    def test_reshape_validate(self):

        self.model.add_layer(self.input_layer1)
        self.model.add_operator(rztdl.dl.dl_operator.ReshapeOperator(self.operator_name, operator_input='input_Layer',
                                                                     operator_output='reshape_out',
                                                                     shape=[-1, 4,4,4]))
