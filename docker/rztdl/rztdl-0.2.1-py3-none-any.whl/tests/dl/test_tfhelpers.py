# -*- coding: utf-8 -*-
"""
| **@created on:** 30/03/17,
| **@author:** Vivek A Gupta,
| **@version:** v0.0.1
|
| **Description:**
| tfhelper Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
from nose.tools import *
from rztdl.dl.helpers import tfhelpers
from rztdl import RZTDL_DAG, RZTDL_CONFIG
from tensorboard.backend.event_processing import event_accumulator as ea
import time
import rztdl.dl
from rztdl.utils.file import read_csv, to_csv
import subprocess
from multiprocessing import Process
import multiprocessing
import os
import tensorflow as tf
import numpy as np
from rztdl.utils import string_constants as constants

multiprocessing.context._force_start_method('fork')

rztdl_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Setup - Called when this module is initialized - First Call
    """
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = "/tmp/rztdl_tfhelpers_test_cases/"
    print("*********Running TF Helpers Test Case . . .*********")


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Teardown - Called when this module is completed - Last Call
    """
    os.system("rm -rf " + RZTDL_CONFIG.CommonConfig.PATH_RZTDL)
    RZTDL_CONFIG.CommonConfig.PATH_RZTDL = rztdl_path
    print("*********TF Helpers Test Case completed successfully . . .*********")


class TestCost:
    """
    | **@author:** Vivek A Gupta
    |
    | Cost Class Test Cases
    | 1. Cross Entropy
    | 2. Mean Square Error
    | 3. Simple Cross Entropy
    | 4. Softmax Cross Entropy

    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        print("*********Running Cost Test Case . . .*********")
        RZTDL_DAG.initialize()
        tf.reset_default_graph()
        cls.placeholder1 = tf.placeholder(dtype=tf.float32, shape=[1, 1])
        cls.placeholder2 = tf.placeholder(dtype=tf.float32, shape=[1, 1])
        cls.init = tf.global_variables_initializer()
        cls.sess = tf.InteractiveSession()
        cls.sess.run(cls.init)
        cls.predicted = np.random.rand(1, 1)
        cls.output = np.random.rand(1, 1)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        cls.sess.close()
        print("*********Cost Test Case completed successfully. . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_cross_entropy(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests cross entropy function - Cross check with the correct formula.
        """
        cal_loss = tf.reduce_mean(((self.placeholder1 * tf.log(self.placeholder2)) + (
            (1 - self.placeholder1) * tf.log(1.0 - self.placeholder2))) * -1)

        loss = tfhelpers.Cost(self.placeholder1, self.placeholder2).cross_entropy()
        cost, cal_cost = self.sess.run([loss, cal_loss],
                                       feed_dict={self.placeholder1: self.output, self.placeholder2: self.predicted})
        assert_equal(cost, cal_cost)

    def test_mean_square_error(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests mean square error function - Cross check with the correct formula.
        """
        cal_loss = tf.reduce_mean(tf.square(self.placeholder1 - self.placeholder2))
        loss = tfhelpers.Cost(self.placeholder1, self.placeholder2).switch(constants.COST.MEAN_SQUARE_ERROR)
        cal_cost, cost = self.sess.run([cal_loss, loss],
                                       feed_dict={self.placeholder1: self.predicted, self.placeholder2: self.output})
        assert_equal(cost, cal_cost)

    def test_simple_cross_entropy(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests simple cross entropy function - Cross check with the correct formula.
        """
        cal_loss = tf.reduce_mean(-tf.reduce_sum(self.placeholder1 * tf.log(self.placeholder2), reduction_indices=1))

        loss = tfhelpers.Cost(self.placeholder1, self.placeholder2).simple_cross_entropy(reduction_indices=1)
        cost, cal_cost = self.sess.run([loss, cal_loss],
                                       feed_dict={self.placeholder1: self.output, self.placeholder2: self.predicted})
        assert_equal(cost, cal_cost)

    def test_softmax_cross_entropy(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests softmax cross entropy function - Cross check with the tensorflow function.
        """
        cal_loss = tf.reduce_mean(
            tf.nn.softmax_cross_entropy_with_logits(logits=self.placeholder2, labels=self.placeholder1))
        loss = tfhelpers.Cost(self.placeholder1, self.placeholder2).switch(constants.COST.SOFTMAX_CROSS_ENTROPY)
        cost, cal_cost = self.sess.run([loss, cal_loss],
                                       feed_dict={self.placeholder1: self.output, self.placeholder2: self.predicted})
        assert_equal(cost, cal_cost)


class TestInitialization:
    """
    | **@author:** Vivek A Gupta
    |
    | Initialization Class Test Cases
    | 1. Random Uniform Initialization
    | 2. Random Normal Initialization
    | 3. Zeros Initialization
    | 4. Ones Initialization
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        RZTDL_DAG.initialize()
        tf.reset_default_graph()
        cls.variable1 = tfhelpers.Initialization([1, 2], seed=2)
        cls.variable2 = tfhelpers.Initialization([1, 2], seed=2)
        cls.init = tf.global_variables_initializer()
        cls.sess = tf.InteractiveSession()
        cls.sess.run(cls.init)
        print("*********Running Initializer Test Case . . .*********")

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        cls.sess.close()
        print("*********Initializer Test Case completed successfully . . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_ones(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests ones function - Manually.
        """
        result = self.sess.run(self.variable1.ones())
        check1 = np.array([[1, 1]])
        assert_true(np.array_equal(check1, result))

    def test_zeros(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests zeros function - Manually.
        """
        result = self.sess.run(self.variable1.zeros())
        check1 = np.array([[0, 0]])
        assert_true(np.array_equal(check1, result))

    def test_random_uniform(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests random_uniform function - Check against tensorflow function.
        """
        result1, result2 = self.sess.run([self.variable1.random_uniform(), self.variable2.random_uniform()])
        assert_true(np.array_equal(result1, result2))

    def test_random_normal(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests random_normal function - Check against tensorflow function.
        """
        result1, result2 = self.sess.run([self.variable1.random_normal(), self.variable2.random_normal()])
        assert_true(np.array_equal(result1, result2))


class TestActivation:
    """
    | **@author:** Vivek A Gupta
    |
    | Activation Class Test Cases
    | 1. Sigmoid Activation
    | 2. Softmax Activation
    | 3. Tanh Activation
    | 4. Relu Activation
    | 5. None Activation
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        RZTDL_DAG.initialize()
        tf.reset_default_graph()
        cls.variable1 = tf.ones([1, 2])
        cls.init = tf.global_variables_initializer()
        cls.sess = tf.InteractiveSession()
        cls.sess.run(cls.init)
        print("*********Running Activation Test Case . . .*********")

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        cls.sess.close()
        print("*********Activation Test Case Completed successfully . . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_sigmoid(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests sigmoid function - Check against tensorflow function.
        """
        res = self.sess.run(tf.nn.sigmoid(self.variable1))
        ans = self.sess.run(tfhelpers.Activation(self.variable1).sigmoid())
        assert_true(np.array_equal(res, ans))

    def test_tanh(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests tanh function - Check against tensorflow function.
        """
        res = self.sess.run(tf.nn.tanh(self.variable1))
        ans = self.sess.run(tfhelpers.Activation(self.variable1).tanh())
        assert_true(np.array_equal(res, ans))

    def test_relu(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests relu function - Check against tensorflow function.
        """
        res = self.sess.run(tf.nn.relu(self.variable1))
        ans = self.sess.run(tfhelpers.Activation(self.variable1).relu())
        assert_true(np.array_equal(res, ans))

    def test_softmax(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests softmax function - Check against tensorflow function.
        """
        res = self.sess.run(tf.nn.softmax(self.variable1))
        ans = self.sess.run(tfhelpers.Activation(self.variable1).softmax())
        assert_true(np.array_equal(res, ans))

    def test_none(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests none function - Manually.
        """
        res = self.sess.run(tfhelpers.Activation(self.variable1).none())
        v1 = self.sess.run(self.variable1)
        assert_true(np.array_equal(v1, res))


class TestOptimization:
    """
    | **@author:** Vivek A Gupta
    |
    | Optimization Class Test Cases
    | 1. Adam Optimizer
    | 2. Adam Grad Optimizer
    | 3. Gradient Descent Optimizer
    | 4. Momentum Optimizer
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        print("*********Running Optimizer Test Case . . .*********")
        RZTDL_DAG.initialize()
        tf.reset_default_graph()
        cls.x = tf.placeholder(dtype='float', shape=[1, 1])
        cls.y = tf.placeholder(dtype='float', shape=[1, 1])
        cls.b = tf.Variable(tf.ones([1, 1]))
        cls.w = tf.Variable(tf.ones([1, 1]))
        cls.model = tf.add(tf.multiply(cls.x, cls.w), cls.b)
        cls.learning_rate = 0.01
        cls.cost = tf.reduce_sum(tf.pow(cls.model - cls.y, 2)) / (2 * 1)
        cls.input = [[3]]
        cls.output = [[5]]
        cls.sess = tf.InteractiveSession()

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        cls.sess.close()
        print("*********Optimizer Test Case completed successfully. . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a /new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_adam_optimizer(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests adam optimizer - Check against tensorflow function..
        """
        opt = tfhelpers.Optimizer(self.learning_rate, self.cost).switch(constants.OPTIMIZER.ADAM)
        init = tf.global_variables_initializer()
        self.sess.run(init)
        self.sess.run(opt, feed_dict={self.x: self.input, self.y: self.output})
        assert_equal(opt.name, 'Adam')

    def test_ada_gradient_optimizer(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests ada gradient optimizer - Check against tensorflow function.
        """
        opt = tfhelpers.Optimizer(self.learning_rate, self.cost).switch(constants.OPTIMIZER.ADA_GRADIENT)
        init = tf.global_variables_initializer()
        self.sess.run(init)
        self.sess.run(opt, feed_dict={self.x: self.input, self.y: self.output})
        assert_equal(opt.name, 'Adagrad')

    def test_gradient_descent_optimizer(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests adam gradient optimizer - Check against tensorflow function.
        """
        opt = tfhelpers.Optimizer(self.learning_rate, self.cost).switch(constants.OPTIMIZER.GRADIENT_DESCENT)
        init = tf.global_variables_initializer()
        self.sess.run(init)
        self.sess.run(opt, feed_dict={self.x: self.input, self.y: self.output})
        assert_equal(opt.name, 'GradientDescent')

    def test_momentum_optimizer(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests momentum optimizer - Check against tensorflow function.
        """
        opt = tfhelpers.Optimizer(self.learning_rate, self.cost, 1.0).switch(constants.OPTIMIZER.MOMENTUM)
        init = tf.global_variables_initializer()
        self.sess.run(init)
        self.sess.run(opt, feed_dict={self.x: self.input, self.y: self.output})
        assert_equal(opt.name, 'Momentum')

    def test_ftrl_optimizer(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests ftrl optimizer - Check against tensorflow function.
        """
        opt = tfhelpers.Optimizer(self.learning_rate, self.cost, 1.0).switch(constants.OPTIMIZER.FTRL)
        init = tf.global_variables_initializer()
        self.sess.run(init)
        self.sess.run(opt, feed_dict={self.x: self.input, self.y: self.output})
        assert_equal(opt.name, 'Ftrl')

    def test_proximal_ada_grad_optimizer(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests PROXIMAL_ADAGRAD optimizer - Check against tensorflow function.
        """
        opt = tfhelpers.Optimizer(self.learning_rate, self.cost, 1.0).switch(constants.OPTIMIZER.PROXIMAL_ADAGRAD)
        init = tf.global_variables_initializer()
        self.sess.run(init)
        self.sess.run(opt, feed_dict={self.x: self.input, self.y: self.output})
        assert_equal(opt.name, 'ProximalAdagrad')

    def test_proximal_gradient_descent_optimizer(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests PROXIMAL_GRADIENT_DESCENT optimizer - Check against tensorflow function.
        """
        opt = tfhelpers.Optimizer(self.learning_rate, self.cost, 1.0).switch(
            constants.OPTIMIZER.PROXIMAL_GRADIENT_DESCENT)
        init = tf.global_variables_initializer()
        self.sess.run(init)
        self.sess.run(opt, feed_dict={self.x: self.input, self.y: self.output})
        assert_equal(opt.name, 'ProximalGradientDescent')

    def test_ada_delta_optimizer(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests ADA_DELTA optimizer - Check against tensorflow function.
        """
        opt = tfhelpers.Optimizer(self.learning_rate, self.cost, 1.0).switch(constants.OPTIMIZER.ADA_DELTA)
        init = tf.global_variables_initializer()
        self.sess.run(init)
        self.sess.run(opt, feed_dict={self.x: self.input, self.y: self.output})
        assert_equal(opt.name, 'Adadelta')


class TestNormalizationLayer:
    """
    | **@author:** Vivek A Gupta
    |
    | NormalizationLayer Class Test Cases
    | 1. l2 norm
    | 2. lrn norm
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        print("*********Running Normalization Test Case . . .*********")
        RZTDL_DAG.initialize()
        tf.reset_default_graph()
        cls.x1 = tf.random_normal([1, 5], seed=12)
        cls.x2 = tf.random_normal([1, 2, 3, 4], seed=23)
        cls.init = tf.global_variables_initializer()
        cls.sess = tf.InteractiveSession()
        cls.sess.run(cls.init)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        cls.sess.close()
        print("*********Normalization Test Case completed successfully . . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a /new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_l2_norm(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests l2_norm function - Check against tensorflow function.
        """
        n1 = tfhelpers.NormalizationLayer(self.x1).l2_norm(
            norm_parameters={constants.PARAMETERS.NORM_DIM: 0, constants.PARAMETERS.NORM_EPSILON: 1})
        n2 = tf.nn.l2_normalize(self.x1, 0, 1)
        ans, res = self.sess.run([n1, n2])
        assert_true(np.array_equal(ans, res))

    def test_lrn_norm(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests lrn_norm function - Check against tensorflow function.
        """
        n1 = tfhelpers.NormalizationLayer(self.x2).lrn_norm(
            norm_parameters={constants.PARAMETERS.DEPTH_RADIUS: 1, constants.PARAMETERS.NORM_BIAS: 1,
                             constants.PARAMETERS.NORM_ALPHA: 1,
                             constants.PARAMETERS.NORM_BETA: 0.5})
        n2 = tf.nn.lrn(self.x2, 1, 1, 1, 0.5)
        ans, res = self.sess.run([n1, n2])
        assert_true(np.array_equal(ans, res))


class TestAccuracy:
    """
    | **@author:** Vivek A Gupta
    |
    | Accuracy Class Test Cases
    | 1. Simple accuracy
    | 2. Binary accuracy
    | 3. Softmax
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        print("*********Running Accuracy Test Case . . .*********")
        cls.pred = np.array([[1], [0], [1], [0]])
        cls.label = np.array([[1], [0], [0], [0]])
        cls.thresh = 0.5
        cls.acc_fun = tfhelpers.Accuracy(cls.pred, cls.label, cls.thresh)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        print("*********Accuracy Test Case completed successfully. . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a /new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_simple(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests simple function - Check if function is returning expected results.
        """
        x = self.acc_fun.simple()
        assert_equal(75.0, float(x['accuracy']))
        assert_equal(3.0, x['accurate_samples'])
        assert_equal(1.0, x['error_samples'])

    def test_binary(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests binary function - Check if function is returning expected results.
        """
        x = self.acc_fun.binary(1.0)
        assert_equal(50.0, float(x['accuracy']))
        assert_equal(1.0, x['accurate_samples'])
        assert_equal(1.0, x['error_samples'])

    def test_softmax(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests softmax function - Check if function is returning expected results.
        """
        pred = np.array([[1, 0], [2, 0], [0, 1], [0, 2]])
        label = np.array([[1, 0], [1, 0], [1, 0], [1, 0]])
        x = tfhelpers.Accuracy(pred, label).softmax()
        assert_equal(50.0, float(x['accuracy']))
        assert_equal(2.0, x['accurate_samples'])
        assert_equal(2.0, x['error_samples'])

    @raises(Exception)
    def test_length_simple(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests simple function - Check if an exception is thrown when the length of input and output do not match.
        """
        pred = [[2], [3]]
        label = [[2]]
        thresh = 0.5
        tfhelpers.Accuracy(pred, label, thresh).simple()

    @raises(Exception)
    def test_length_binary(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests binary function - Check if an exception is thrown when the length of input and output do not match.
        """
        pred = [[2], [3]]
        label = [[2]]
        thresh = 0.5
        tfhelpers.Accuracy(pred, label, thresh).binary()

    @raises(Exception)
    def test_length_softmax(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests softmax function - Check if an exception is thrown when the length of input and output do not match.
        """
        pred = [[1, 2]]
        label = [[1, 3], [2, 4]]
        thresh = 0.5
        tfhelpers.Accuracy(pred, label, thresh).softmax()


class TestTFTimeline:
    """
    | **@author**: Vivek A Gupta
    |
    | Timeline Class Test Cases
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        print("*********Running TFTimeline Test Cases . . .*********")
        cls.sess = tf.InteractiveSession()

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        cls.sess.close()
        print("*********TFTimeline Test Cases completed successfully . . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a /new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_run(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests run function - Check if the function is returning a json file.
        """
        x = tf.placeholder(dtype='float', shape=[1, 1])
        y = tf.placeholder(dtype='float', shape=[1, 1])

        b = tf.Variable(tf.ones([1, 1]))
        w = tf.Variable(tf.ones([1, 1]))

        model = tf.add(tf.multiply(x, w), b)

        learning_rate = 0.01
        cost = tf.reduce_sum(tf.pow(model - y, 2)) / (2 * 1)

        input = [[3]]
        output = [[5]]

        opt = tf.train.AdamOptimizer(learning_rate).minimize(cost)
        feed_dict = {x: input, y: output}

        tl_obj = tfhelpers.TFTimeline()

        init = tf.global_variables_initializer()

        self.sess.run(init)
        tl_json = tl_obj.run(self.sess, opt, feed_dict, True)

        fname = '/tmp/time1.json'
        with open(fname, 'w') as f:
            f.write(tl_json)

        assert os.path.isfile(fname)

        os.remove(fname)

    def test_get_run_options(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests get_run_options function - Check the return type of the function.
        """
        tl_obj = tfhelpers.TFTimeline()
        tl_obj_run_opt = tl_obj.get_run_options()
        assert_true(isinstance(tl_obj_run_opt, tf.RunOptions))

    def test_get_run_metadata(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests get_run_metadata function - Check the return type of the function.
        """
        tl_obj = tfhelpers.TFTimeline()
        tl_obj_meta = tl_obj.get_run_metadata()
        assert_true(isinstance(tl_obj_meta, tf.RunMetadata))

    def test_save(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests save function - Check if the json file is getting created.
        """
        x = tf.placeholder(dtype='float', shape=[1, 1])
        y = tf.placeholder(dtype='float', shape=[1, 1])

        b = tf.Variable(tf.ones([1, 1]))
        w = tf.Variable(tf.ones([1, 1]))

        model = tf.add(tf.multiply(x, w), b)

        learning_rate = 0.01
        cost = tf.reduce_sum(tf.pow(model - y, 2)) / (2 * 1)

        input = [[3]]
        output = [[5]]

        opt = tf.train.AdamOptimizer(learning_rate).minimize(cost)
        feed_dict = {x: input, y: output}

        tl_obj = tfhelpers.TFTimeline()

        init = tf.global_variables_initializer()

        self.sess.run(init)
        tl_obj.run(self.sess, opt, feed_dict, True)

        fname = '/tmp/time2.json'
        tl_obj.save(fname)

        assert os.path.isfile(fname)

        os.remove(fname)


class TestTFSummaries:
    """
    | **@author**: Vivek A Gupta
    |
    | TFSummaries Class Test Cases
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        print("*********Running TFSummaries Test Cases . . .*********")
        cls.a = tf.constant(2)
        cls.b = tf.constant(2)
        cls.path_rzt = '/tmp/rzt_test/test/'
        cls.path_tf = '/tmp/tf_test/test/'
        cls.sess = tf.InteractiveSession()

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        cls.sess.close()
        os.system("rm -rf " + '/'.join(cls.path_rzt.split('/')[0:-2]))
        os.system("rm -rf " + '/'.join(cls.path_tf.split('/')[0:-2]))
        print("*********TFSummaries Test Cases completed successfully . . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a /new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_aclose_file_writer(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests close_file_writer function - Check if summary can be added even after closing the file writer.
        """
        summ_obj = tfhelpers.TFSummaries()
        summ_obj.add_scalar_summary('a', self.a)
        merged_rzt = tfhelpers.TFSummaries.create_summary_op()
        summ_obj.create_file_writer('test_close', self.path_rzt, self.sess.graph)

        summary_rzt = self.sess.run(merged_rzt)
        summ_obj.add_summary('test_close', summary_rzt, 1)

        summ_obj.close_file_writer('test_close')

        time.sleep(2)

        summ_obj.add_scalar_summary('b', self.b)

        path_1 = self.path_rzt + str(os.listdir(self.path_rzt)[0])

        acc_rzt = ea.EventAccumulator(path_1)
        acc_rzt.Reload()

        os.system("rm -rf " + self.path_rzt)

        assert_equal(len(acc_rzt.Tags()['scalars']), 1)

    def test_create_summary_op(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests create_summary_op function - Check against tensorflow function.
        """
        c = tf.multiply(self.a, self.b)

        summ_obj = tfhelpers.TFSummaries()
        summ_obj.add_scalar_summary('b', self.b)
        summ_obj.add_scalar_summary('c', c)
        merged_rzt = tfhelpers.TFSummaries.create_summary_op()

        tf.summary.scalar('b', self.b)
        tf.summary.scalar('c', c)
        merged_tf = tf.summary.merge_all()

        summ_obj.create_file_writer('test_cre_sum', self.path_rzt, self.sess.graph)
        tf_writer = tf.summary.FileWriter(self.path_tf, self.sess.graph)

        summary_rzt, summary_tf = self.sess.run([merged_rzt, merged_tf])
        summ_obj.add_summary('test_cre_sum', summary_rzt, 1)
        tf_writer.add_summary(summary_tf, 1)

        path_1 = self.path_rzt + str(os.listdir(self.path_rzt)[0])
        path_2 = self.path_tf + str(os.listdir(self.path_tf)[0])

        summ_obj.close_file_writer('test_cre_sum')
        tf_writer.close()

        time.sleep(2)

        acc_rzt = ea.EventAccumulator(path_1)
        acc_rzt.Reload()

        acc_tf = ea.EventAccumulator(path_2)
        acc_tf.Reload()

        os.system("rm -rf " + self.path_rzt)
        os.system("rm -rf " + self.path_tf)

        assert_equal(acc_rzt.Scalars('b')[0][2], acc_tf.Scalars('b')[0][2])
        assert_equal(acc_rzt.Scalars('c')[0][2], acc_tf.Scalars('c')[0][2])

    def test_create_file_writer(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests create_file_writer function - Checks if file writer is creating a new file.
        """
        summ_obj = tfhelpers.TFSummaries()
        summ_obj.create_file_writer('test_cre_file', self.path_rzt, self.sess.graph)
        summ_obj.close_file_writer('test_cre_file')

        assert len(os.listdir(self.path_rzt)) > 0

        os.system("rm -rf " + self.path_rzt)

    def test_get_file_writer(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests get_file_writer function - Check the return type.
        """
        c = tf.multiply(self.a, self.b)

        path = '/tmp/test/get_file'

        self.sess.run(c)

        summ_obj = tfhelpers.TFSummaries()
        summ_obj.create_file_writer('test_get_file', path, self.sess.graph)
        summ_obj.close_file_writer('test_get_file')

        os.system("rm -rf " + '/'.join(path.split('/')[0:-1]))

        assert_true(isinstance(summ_obj.file_writers['test_get_file'], tf.summary.FileWriter))

    def test_run_metadata(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests run_metadata function - Compare length of run_metadata tag with tensorflow function.
        """
        c = tf.multiply(self.a, self.b)

        summ_obj = tfhelpers.TFSummaries()
        summ_obj.add_scalar_summary('c', c)
        merged_rzt = summ_obj.create_summary_op()

        tf.summary.scalar('c', c)
        merged_tf = tf.summary.merge_all()

        summ_obj.create_file_writer('tester', self.path_rzt, self.sess.graph)
        tf_writer = tf.summary.FileWriter(self.path_tf, self.sess.graph)

        run_options = tf.RunOptions(trace_level=tf.RunOptions.FULL_TRACE)
        run_metadata = tf.RunMetadata()

        summary_rzt, summary_tf = self.sess.run([merged_rzt, merged_tf], run_metadata=run_metadata, options=run_options)

        summ_obj.add_run_metadata('tester', run_metadata, 1)
        summ_obj.add_summary('tester', summary_rzt, 1)

        tf_writer.add_run_metadata(run_metadata, 'step%d' % 1)
        tf_writer.add_summary(summary_tf, 1)

        path_1 = self.path_rzt + str(os.listdir(self.path_rzt)[0])
        path_2 = self.path_tf + str(os.listdir(self.path_tf)[0])

        summ_obj.close_file_writer('tester')
        tf_writer.close()

        time.sleep(2)

        acc_rzt = ea.EventAccumulator(path_1)
        acc_rzt.Reload()

        acc_tf = ea.EventAccumulator(path_2)
        acc_tf.Reload()

        os.system("rm -rf " + self.path_rzt)
        os.system("rm -rf " + self.path_tf)

        assert_equal(len(acc_rzt.Tags()['run_metadata']), len(acc_tf.Tags()['run_metadata']))

    def test_add_scalar_summary(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests add_scalar_summary function - Compare scalar value with tensorflow function.
        """
        c = tf.multiply(self.a, self.b)

        summ_obj = tfhelpers.TFSummaries()
        summ_obj.add_scalar_summary('c', c)

        tf.summary.scalar('c', c)

        merged_rzt = summ_obj.create_summary_op()
        merged_tf = tf.summary.merge_all()

        summ_obj.create_file_writer('tester', self.path_rzt, self.sess.graph)
        tf_writer = tf.summary.FileWriter(self.path_tf, self.sess.graph)

        summary_rzt, summary_tf = self.sess.run([merged_rzt, merged_tf])

        summ_obj.add_summary('tester', summary_rzt, 1)
        tf_writer.add_summary(summary_tf, 1)

        summ_obj.close_file_writer('tester')
        tf_writer.close()

        time.sleep(2)

        path_1 = self.path_rzt + str(os.listdir(self.path_rzt)[0])
        path_2 = self.path_tf + str(os.listdir(self.path_tf)[0])

        acc_rzt = ea.EventAccumulator(path_1)
        acc_rzt.Reload()

        acc_tf = ea.EventAccumulator(path_2)
        acc_tf.Reload()

        assert_equal(acc_rzt.Scalars('c')[0][2], acc_tf.Scalars('c')[0][2])

        os.system("rm -rf " + self.path_tf)
        os.system("rm -rf " + self.path_rzt)

    def test_add_summary(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests add_summary function - Compare scalar values with tensorflow function.
        """
        c = tf.multiply(self.a, self.b)

        summ_obj = tfhelpers.TFSummaries()
        summ_obj.add_scalar_summary('b', self.b)
        summ_obj.add_scalar_summary('c', c)
        merged_rzt = tfhelpers.TFSummaries.create_summary_op()

        tf.summary.scalar('b', self.b)
        tf.summary.scalar('c', c)
        merged_tf = tf.summary.merge_all()

        summ_obj.create_file_writer('tester', self.path_rzt, self.sess.graph)
        tf_writer = tf.summary.FileWriter(self.path_tf, self.sess.graph)

        summary_rzt, summary_tf = self.sess.run([merged_rzt, merged_tf])
        summ_obj.add_summary('tester', summary_rzt, 1)
        tf_writer.add_summary(summary_tf, 1)

        path_1 = self.path_rzt + str(os.listdir(self.path_rzt)[0])
        path_2 = self.path_tf + str(os.listdir(self.path_tf)[0])

        summ_obj.close_file_writer('tester')
        tf_writer.close()

        time.sleep(2)

        acc_rzt = ea.EventAccumulator(path_1)
        acc_rzt.Reload()

        acc_tf = ea.EventAccumulator(path_2)
        acc_tf.Reload()

        os.system("rm -rf " + self.path_tf)
        os.system("rm -rf " + self.path_rzt)

        assert_equal(acc_rzt.Scalars('b')[0][2], acc_tf.Scalars('b')[0][2])
        assert_equal(acc_rzt.Scalars('c')[0][2], acc_tf.Scalars('c')[0][2])

    def test_create_variable_summaries(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests create_variable_summaries function - Check length of scalar tags and histogram value.
        """

        def create_summaries(tensor):
            with tf.name_scope('summaries'):
                mean = tf.reduce_mean(tensor)
                tf.summary.scalar('mean', mean)
                with tf.name_scope('stddev'):
                    # noinspection PyUnresolvedReferences
                    stddev = tf.sqrt(tf.reduce_mean(tf.square(tensor - mean)))
                tf.summary.scalar('stddev', stddev)
                tf.summary.scalar('max', tf.reduce_max(tensor))
                tf.summary.scalar('min', tf.reduce_min(tensor))
                tf.summary.histogram('histogram', tensor)

        a = tf.Variable(tf.random_normal([10]))
        init = tf.global_variables_initializer()

        summ_obj = tfhelpers.TFSummaries()
        summ_obj.create_variable_summaries(a)

        create_summaries(a)

        merged_rzt = summ_obj.create_summary_op()
        merged_tf = tf.summary.merge_all()

        self.sess.run(init)

        summ_obj.create_file_writer('tester', self.path_rzt, self.sess.graph)
        tf_writer = tf.summary.FileWriter(self.path_tf, self.sess.graph)

        summary_rzt, summary_tf = self.sess.run([merged_rzt, merged_tf])
        summ_obj.add_summary('tester', summary_rzt, 1)
        tf_writer.add_summary(summary_tf)

        path_1 = self.path_rzt + str(os.listdir(self.path_rzt)[0])
        path_2 = self.path_tf + str(os.listdir(self.path_tf)[0])

        summ_obj.close_file_writer('tester')
        tf_writer.close()

        time.sleep(2)

        acc_rzt = ea.EventAccumulator(path_1)
        acc_rzt.Reload()

        acc_tf = ea.EventAccumulator(path_2)
        acc_tf.Reload()

        os.system("rm -rf " + self.path_tf)
        os.system("rm -rf " + self.path_rzt)

        assert_equal(acc_rzt.Histograms('summaries/histogram')[0][-1], acc_tf.Histograms('summaries/histogram')[0][-1])
        assert_equal(len(acc_rzt.Tags()['scalars']), len(acc_tf.Tags()['scalars']))


class TestTensorboard:
    """
    | **@author**: Prathyush SP
    |
    | Tensorboard Class Test Cases
    """

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs during class initialization.
        """
        print("*********Running Tensorboard Test Cases . . .*********")
        data_path = '/'.join(str(__file__).split('/')[:-2]) + '/data/'
        train_data, train_label, valid_data, valid_label, test_data, test_label = read_csv(
            filename=data_path + '/sample_titanic.csv', split_ratio=[60, 20, 20], label_vector=False, randomize=True)
        model = rztdl.dl.Model('test_simple_ffn')

        model.add_layer(rztdl.dl.dl_layer.InputLayer(name='input_layer', layer_nodes=3))
        model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer(name='hidden_layer_1', layer_nodes=4,
                                                              layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID))
        model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer(name='hidden_layer_2', layer_nodes=2,
                                                              layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID))
        model.add_layer(rztdl.dl.dl_layer.OutputLayer(name='output_layer', layer_nodes=1,
                                                      layer_activation=rztdl.dl.constants.ACTIVATION.SIGMOID))

        model.close()
        cls.network = rztdl.dl.Network('test_nn_simple_ffn')

        # Training
        cls.network.train(epoch=1, learning_rate=0.01, model=model, cost=rztdl.dl.constants.COST.MEAN_SQUARE_ERROR,
                          optimizer=rztdl.dl.constants.OPTIMIZER.ADAM,
                          train_data={'input_layer': train_data, 'output_layer': train_label},
                          valid_data={'input_layer': valid_data, 'output_layer': valid_label},
                          test_data={'input_layer': test_data, 'output_layer': test_label}, display_step=1,
                          train_batches=1,
                          gini=True, print_json=False
                          )

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after class reference is removed / class test cases are completed.
        """
        print("*********Tensorboard Test Cases completed successfully . . .*********")

    def setup(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs before a /new method in the class is called.
        """
        pass

    def teardown(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Runs after each method is called.
        """
        pass

    def test_start_tensorboard(self):
        """
        | **@author:** Vivek A Gupta
        |
        | Tests start_tensorboard function - Check tensorboard is running in different ports.
        """

        def tens1():
            tb1 = tfhelpers.TensorBoard(self.network.name,
                                        '/tmp/rztdl_logs/' + self.network.name + '/' + self.network.timestamp + '/graphs/tf/')
            tb1.start_tensorboard()
            time.sleep(1)

        def tens2():
            tb2 = tfhelpers.TensorBoard(self.network.name,
                                        '/tmp/rztdl_logs/' + self.network.name + '/' + self.network.timestamp + '/graphs/tf/',
                                        6008)
            tb2.start_tensorboard()

        p1 = Process(target=tens1)
        p2 = Process(target=tens2)

        p1.start()
        p2.start()

        time.sleep(3)

        # Port - 1
        port1 = subprocess.Popen("netstat -tulpn | grep 6006 | awk \'{print $4}\' | cut -d \':\' -f2", shell=True,
                                 stdout=subprocess.PIPE)
        port1_id = str(port1.communicate()[0]).replace("b\'", "").replace("\\n\'", "")

        # Port - 2
        port2 = subprocess.Popen("netstat -tulpn | grep 6008 | awk \'{print $4}\' | cut -d \':\' -f2", shell=True,
                                 stdout=subprocess.PIPE)
        port2_id = str(port2.communicate()[0]).replace("b\'", "").replace("\\n\'", "")

        # Get process id of tensorboard processes.
        board1 = subprocess.Popen("lsof -i:6006 -t", shell=True, stdout=subprocess.PIPE)
        board1_pid = str(board1.communicate()[0]).replace("b\'", "").replace("\\n\'", "")

        board2 = subprocess.Popen("lsof -i:6008 -t", shell=True, stdout=subprocess.PIPE)
        board2_pid = str(board2.communicate()[0]).replace("b\'", "").replace("\\n\'", "")

        # Kill tensorboard processes.
        os.system("kill -9 " + str(board1_pid))
        os.system("kill -9 " + str(board2_pid))

        assert_true(port1_id, 6006)
        assert_true(port2_id, 6008)
