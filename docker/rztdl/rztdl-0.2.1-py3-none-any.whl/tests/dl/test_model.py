# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""
import rztdl
import rztdl.dl
from tensorflow import Tensor
from nose.tools import *
import tensorflow as tf
from collections import OrderedDict


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Setup - Called when this module is initialized - First Call
    """
    print("*********Running Model Test Case . . .*********")


def teardown_module():
    """
    | **@author:** Prathyush SP
    |
    | Module Teardown - Called when this module is completed - Last Call
    """
    print("*********Model Test Case completed successfully . . .*********")


class TestModel:
    """
    | **@author:** Prathyush SP
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | Initialize Test Model
        """
        self.model = None
        self.model_name = None

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method is called
        """
        rztdl.RZTDL_STORE.dag = OrderedDict()
        tf.reset_default_graph()
        self.model_name = 'test_model'
        self.model = rztdl.dl.Model(self.model_name)

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        cls.session = tf.InteractiveSession()
        print("*********Running Model Test Case . . .*********")

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        cls.session.close()
        print("*********Model Test Case completed successfully . . .*********")

    def test_model_name(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests Model Name Validation
        """
        false_names = ['model 1', 'model .', '%model']
        for name in false_names:
            try:
                rztdl.dl.Model(name)
                raise Exception('Invalid name validated . . .')
            except NameError:
                pass

    @raises(Exception)
    def test_add_layer(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Add dl_layer Functionality - Throw exception when duplicate name is added
        """
        # Test if the model raises exception when the dl_layer name is repeated
        self.model.add_component_output_as_tensor(rztdl.dl.dl_layer.InputLayer('layer1', 10))
        self.model.add_component_output_as_tensor(rztdl.dl.dl_layer.InputLayer('layer1', 10))

    def test_model_input_layer(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Model.add_layer() for Input Layer
        """
        layer_name = 'input_layer'
        input_layer = self.model.add_component_output_as_tensor(rztdl.dl.dl_layer.InputLayer(layer_name, layer_nodes=10))
        tensor = tf.placeholder(dtype=tf.float32, shape=[None, 10])
        # Test type
        assert type(input_layer) == type(tensor)
        # Test shape
        assert input_layer.get_shape().as_list() == tensor.get_shape().as_list()
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, layer_name)
        # Test RZTDL DAG Placeholder Insertion
        rztdl.RZTDL_STORE.get_placeholder(self.model_name, layer_name)
        # Test Collection
        assert len(tf.get_collection(input_layer.name)) == 1

    def test_model_fully_connected_layer(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Model.add_layer() for Fully Connected Layer
        """
        layer_name = 'hidden_layer'
        # Test if FC Layer raises exception when input dl_layer is not added
        try:
            self.model.add_component_output_as_tensor(rztdl.dl.dl_layer.FullyConnectedLayer(layer_name, layer_nodes=10))
        except:
            assert True

        self.model.add_component_output_as_tensor(rztdl.dl.dl_layer.InputLayer('input_layer', layer_nodes=10))
        hidden_layer = self.model.add_component_output_as_tensor(rztdl.dl.dl_layer.FullyConnectedLayer(layer_name,
                                                                                                       layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                                                       layer_nodes=5))

        # Test the instance of the output variable
        assert isinstance(hidden_layer, Tensor)
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, layer_name)
        # Test Collection
        assert len(tf.get_collection(hidden_layer.name)) == 1

    def test_model_output_connected_layer(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Model.add_layer() for Output Layer
        """
        layer_name = 'output_layer'
        # Test if Output Layer raises exception when input dl_layer is not added
        try:
            self.model.add_component_output_as_tensor(rztdl.dl.dl_layer.FullyConnectedLayer(layer_name, layer_nodes=10))
        except:
            assert True

        self.model.add_component_output_as_tensor(rztdl.dl.dl_layer.InputLayer('input_layer', layer_nodes=10))
        output_layer = self.model.add_component_output_as_tensor(rztdl.dl.dl_layer.OutputLayer(layer_name,
                                                                                               layer_activation=rztdl.dl.constants.ActivationType.SIGMOID,
                                                                                               layer_nodes=5))

        # Test the instance of the output variable
        assert isinstance(output_layer, Tensor)
        # Test RZTDL DAG Placeholder Insertion
        rztdl.RZTDL_STORE.get_placeholder(self.model_name, layer_name)
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, layer_name)
        # Test Collection
        assert len(tf.get_collection(output_layer.name)) == 1

    def test_model_convolution_layer(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Model.add_layer() for Convolution Layer
        """
        layer_name = 'convolution_layer'
        # Test if Output Layer raises exception when input dl_layer is not added
        try:
            self.model.add_component_output_as_tensor(rztdl.dl.dl_layer.FullyConnectedLayer(layer_name, layer_nodes=10))
        except:
            assert True

        self.model.add_component_output_as_tensor(rztdl.dl.dl_layer.InputLayer('input_layer', layer_nodes=25))
        convolution_layer = self.model.add_component_output_as_tensor(rztdl.dl.dl_layer.ConvolutionLayer(layer_name,
                                                                                                         layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                                                                         filter_dimensions=[1, 1, 1, 1],
                                                                                                         filter_strides=[1, 2, 2, 1],
                                                                                                         filter_padding=rztdl.dl.constants.PaddingType.SAME))

        # Test the instance of the output variable
        assert isinstance(convolution_layer, Tensor)
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, layer_name)
        # Test Collection
        assert len(tf.get_collection(convolution_layer.name)) == 1

    def test_model_pool_layer(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Model.add_layer() for Pool Layer
        """
        layer_name = 'pool_layer'
        # Test if Output Layer raises exception when input dl_layer is not added
        try:
            self.model.add_component_output_as_tensor(rztdl.dl.dl_layer.FullyConnectedLayer(layer_name, layer_nodes=10))
        except:
            assert True

        self.model.add_component_output_as_tensor(rztdl.dl.dl_layer.InputLayer('input_layer', layer_nodes=25))
        self.model.add_component_output_as_tensor(rztdl.dl.dl_layer.ConvolutionLayer('conv_layer',
                                                                                     layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                                                     filter_dimensions=[1, 1, 1, 1],
                                                                                     filter_strides=[1, 2, 2, 1],
                                                                                     filter_padding=rztdl.dl.constants.PaddingType.SAME))

        pool_layer = self.model.add_component_output_as_tensor(rztdl.dl.dl_layer.PoolLayer(layer_name, pool_dimensions=[1, 1, 1, 1],
                                                                                           pool_type=rztdl.dl.constants.PoolType.MAX_POOL,
                                                                                           pool_strides=[1, 2, 2, 1],
                                                                                           pool_padding=rztdl.dl.constants.PaddingType.SAME))

        # Test the instance of the output variable
        assert isinstance(pool_layer, Tensor)
        # Test RZTDL DAG Layer Insertion
        rztdl.RZTDL_STORE.get_component_output_as_tensor(self.model_name, layer_name)
        # Test Collection
        assert len(tf.get_collection(pool_layer.name)) == 1
