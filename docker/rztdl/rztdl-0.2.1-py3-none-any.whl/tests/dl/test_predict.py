# -*- coding: utf-8 -*-
"""
| **@created on:** 16/12/16,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import os
import numpy as np
import rztdl.dl
import rztdl.dl
import tensorflow as tf
from nose.tools import *
from rztdl import RZTDL_CONFIG
from rztdl.utils.file import read_csv
from rztdl.utils.string_constants import ModelMetaConstant


def setup_module():
    """
    | **@author:** Prathyush SP
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    RZTDL_CONFIG.update_dl_config_manager(
        config_file_path='/'.join(str(__file__).split('/')[:-2]) + '/rztdl_testing_config.json')


def my_teardown_function():
    """
    | **@author:** Prathyush SP
    |
    | Custom Teardown function
    """
    pass


class TestPrediction:
    """
    | **@author:** Umesh Kumar
    |
    | **Description:**
    | Prediction module contains various utilities required to test using nose testcases
    | 1. Model save path
    | 2. Predict the output
    | 3. Get weights
    | 4. Get bias
    | 5. Get placeholders
    | 6. Get dl_layer
    """

    @classmethod
    def setup_class(cls):
        """
           | **@author:** Umesh Kumar
           |
           | Runs when class is initialized.
           """
        print("*********Prediction Test Case started successfully . . .*********")
        cls.name = 'test_network'
        cls.data_path = '/'.join(str(__file__).split('/')[:-2]) + '/data/'
        cls.train_data, cls.train_label, _, _, cls.test_data, cls.test_label = read_csv(
            cls.data_path + "/sample_iris.csv",
            split_ratio=[60, 0, 40],

            randomize=True, output_label=[[4, 7]])
        # Load Multivariate Data
        cls.multivariate_train_data, cls.multivariate_train_label, cls.multivariate_valid_data, \
        cls.multivariate_valid_label, cls.multivariate_test_data, cls.multivariate_test_label = read_csv(
            cls.data_path + "/sample_iris.csv", split_ratio=[60, 20, 20],  randomize=True,
            output_label=[[4, 7]])
        # Create Multivariate Model
        cls.multivariate_model = rztdl.dl.Model("multivariate_model")
        cls.multivariate_model.add_layer(
            rztdl.dl.layer.InputLayer("input_layer", layer_nodes=len(cls.multivariate_train_data[0])))
        cls.multivariate_model.add_layer(rztdl.dl.layer.FullyConnectedLayer("hidden_layer", layer_nodes=10))
        cls.multivariate_model.add_layer(rztdl.dl.layer.OutputLayer(name="output_layer",
                                                                    layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                                                    layer_nodes=len(cls.multivariate_train_label[0]),
                                                                    layer_input="input_layer"))
        cls.multivariate_model.close()
        cls.network = rztdl.dl.Network("test_network")
        cls.network.train(epoch=1, learning_rate=0.01, model=cls.multivariate_model,
                          cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
                          optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
                          train_data={'input_layer': cls.multivariate_train_data,
                                      'output_layer': cls.multivariate_train_label},
                          valid_data={'input_layer': cls.multivariate_valid_data,
                                      'output_layer': cls.multivariate_valid_label},
                          test_data={'input_layer': cls.multivariate_test_data,
                                     'output_layer': cls.multivariate_test_label}, sess=None,
                          display_step=1, train_batch_size=1, regularisation=True,
                          regularisation_params=rztdl.dl.constants.REGULARISATION.regularisation(
                              regularisation_type=rztdl.dl.constants.REGULARISATION.L2_REGULARISATION,
                              beta=0.01))
        cls.predict = rztdl.dl.Prediction(network_name=cls.name)
        cls.metadata = cls.predict.metadata
        cls.sess = cls.predict.session

    @classmethod
    def teardown_class(cls):
        """
           | **@author:** Umesh Kumar
           |
           | Runs when class is completed.
           """
        os.system("rm -rf " + RZTDL_CONFIG.CommonConfig.PATH_RZTDL)
        os.system("rm -rf /tmp/rzt_predict/")
        print("*********Prediction Test Case completed successfully . . .*********")

    @staticmethod
    def setup():
        """
           | **@author:** Umesh Kumar
           |
           | Runs before each method is called
           """
        pass

    @staticmethod
    def teardown():
        """
           | **@author:** Umesh Kumar
           |
           | Runs after each method is called
           """
        pass

    def test_get_predict_save_path(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test Predict Save path functionality - Returns save_path where the model is saved.
        """
        assert_equal(self.predict.get_predict_save_path(),
                     RZTDL_CONFIG.CommonConfig.PATH_RZTDL + '/' + self.name + '/' + self.metadata['timestamp'] + '/')

    def test_predict(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test predict functionality in Prediction class - Returns predicted output of the given data
        """
        result = self.predict.predict(layer_name='output_layer', data={'input_layer': self.test_data})
        assert_equal(len(result[0]), 4)
        assert_equal(len(result[0][0]), 3)

    def test_prediction_loading_from_different_path(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test predict functionality loading the model from different path
        """
        model = rztdl.dl.Model("predict_model")
        model.add_layer(
            rztdl.dl.layer.InputLayer("input_layer", layer_nodes=len(self.train_data[0])))
        model.add_layer(rztdl.dl.layer.OutputLayer(name="output_layer",
                                                   layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                                   layer_nodes=len(self.train_label[0]),
                                                   layer_input="input_layer"))
        model.close()
        predict_network = rztdl.dl.Network("test_predict_network")
        predict_network.train(epoch=1, learning_rate=0.01, model=model,
                              cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
                              optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
                              train_data={'input_layer': self.train_data,
                                          'output_layer': self.train_label},
                              test_data={'input_layer': self.test_data,
                                         'output_layer': self.test_label},
                              display_step=1, train_batch_size=1, save_path="/tmp/rzt_predict/")
        prediction = rztdl.dl.Prediction('test_predict_network', model_save_path="/tmp/rzt_predict/")
        prediction.predict(layer_name='output_layer', data={'input_layer': self.train_data})

    def test_prediction_loading_from_persistence_training(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test predict functionality loading the model from persistence training
        """
        network = rztdl.dl.Network("test_predict_network")
        network.persist_training(epoch=1, learning_rate=0.01,
                                 train_data={'input_layer': self.train_data,
                                             'output_layer': self.train_label},
                                 test_data={'input_layer': self.test_data,
                                            'output_layer': self.test_label},
                                 display_step=1, load_path="/tmp/rzt_predict/", save_path="/tmp/rzt_predict/")
        prediction = rztdl.dl.Prediction('test_predict_network', model_save_path="/tmp/rzt_predict/")
        prediction.predict(layer_name='output_layer', data={'input_layer': self.train_data})

    def test_get_weights(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test get_weights functionality - Returns weights of the given dl_layer
        """
        # Get weights of single dl_layer
        weights = self.predict.get_weights(layer_name="hidden_layer")
        pred_weights = self.sess.run(tf.get_collection(self.metadata[ModelMetaConstant.WEIGHTS]["hidden_layer"])[0])
        np.testing.assert_equal(pred_weights, weights)

        # Get weights of more layers
        weights = self.predict.get_weights(layer_name=["hidden_layer", "output_layer"])
        output_weights = self.sess.run(tf.get_collection(self.metadata[ModelMetaConstant.WEIGHTS]["output_layer"])[0])
        np.testing.assert_equal(pred_weights, weights["hidden_layer"])
        np.testing.assert_equal(output_weights, weights["output_layer"])

    def test_get_set_weights(self):
        """
        | **@author:** Prathyush SP
        |
        | Test set_weights functionality - Sets weight of a given dl_layer
        """
        # Set weights
        weights = self.predict.get_weights(layer_name="hidden_layer")
        self.predict.set_weights(layer_name='hidden_layer', layer_weights=np.ones(weights.shape))
        np.testing.assert_equal(
            self.sess.run(tf.get_collection(self.metadata[ModelMetaConstant.WEIGHTS]["hidden_layer"])[0]),
            np.ones(weights.shape))

    def test_get_bias(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test get_bias functionality - Returns bias of the given dl_layer
        """
        # Get bias of single dl_layer
        bias = self.predict.get_bias(layer_name="hidden_layer")
        pred_bias = self.sess.run(tf.get_collection(self.metadata[ModelMetaConstant.BIAS]["hidden_layer"])[0])
        np.testing.assert_equal(pred_bias, bias)

        # Get bias of more layers
        bias = self.predict.get_bias(layer_name=["hidden_layer", "output_layer"])
        output_bias = self.sess.run(tf.get_collection(self.metadata[ModelMetaConstant.BIAS]["output_layer"])[0])
        np.testing.assert_equal(pred_bias, bias["hidden_layer"])
        np.testing.assert_equal(output_bias, bias["output_layer"])

    def test_get_set_bias(self):
        """
        | **@author:** Prathyush SP
        |
        | Test set_bias functionality - Sets bias of a given dl_layer
        """
        # Set Bias
        bias = self.predict.get_bias(layer_name="hidden_layer")
        self.predict.set_bias(layer_name='hidden_layer', layer_bias=np.ones(bias.shape))
        np.testing.assert_equal(
            self.sess.run(tf.get_collection(self.metadata[ModelMetaConstant.BIAS]["hidden_layer"])[0]),
            np.ones(bias.shape))

    def test_get_placeholders(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test get_placeholders functionality - Returns placeholders of the given key
        """
        for placeholder in self.metadata[ModelMetaConstant.PREDICTION_PLACEHOLDERS]:
            pred_placeholders = self.predict._get_placeholder(placeholder_name=placeholder)
            placeholders = tf.get_collection(self.metadata[ModelMetaConstant.PREDICTION_PLACEHOLDERS][placeholder])[0]
            assert_equal(pred_placeholders, placeholders)

    def test_get_layer(self):
        """
        | **@author:** Umesh Kumar
        |
        | Test get_layer functionality - Returns dl_layer output of the given dl_layer
        """
        # Get single dl_layer
        layer = self.predict._get_layer(layer_name="hidden_layer")
        pred_layers = tf.get_collection(self.metadata[ModelMetaConstant.LAYERS]["hidden_layer"])[0]
        assert_equal(pred_layers, layer)

        # Get more layers
        layers = self.predict._get_layer(layer_name=["hidden_layer", "output_layer"])
        output_layer = tf.get_collection(self.metadata[ModelMetaConstant.LAYERS]["output_layer"])[0]
        assert_equal(output_layer, layers["output_layer"])
        assert_equal(pred_layers, layers["hidden_layer"])
