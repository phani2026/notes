# -*- coding: utf-8 -*-
"""
| **@created on:** 5/31/18,
| **@author:** Himaprasoon PT,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** 
|
..todo::

"""

from nose import with_setup  # optional
from nose.tools import *

import rztdl.utils.string_constants as constants
from rztdl.blueprint import BluePrintProperties


def setup_module():
    """
    | **@author:** Himaprasoon PT
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    pass


def teardown_module():
    """
    | **@author:** Himaprasoon PT
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    pass


def my_setup_function():
    """
    | **@author:** Himaprasoon PT
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Himaprasoon PT
    |
    | Custom Teardown function
    """
    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Himaprasoon PT
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestBluePrintProperties:
    """
    | **@author:** Himaprasoon PT
    |
    | BluePrintProperties Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        pass

    def setup(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Runs before a new method in the class is called
        """
        pass

    def teardown(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Himaprasoon PT
        |
        | Runs during class initialization
        """
        pass

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Himaprasoon PT
        |
        | Runs after class reference is removed / class test cases are completed
        """
        pass

    def test_blueprint_properties_without_params(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Tests Sample Method
        """
        try:
            BluePrintProperties(data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                                status=constants.STATUS.ACTIVE)
            assert False
        except TypeError:
            assert True

        try:
            BluePrintProperties(name="sample_name")
            assert False
        except TypeError:
            assert True

        try:
            BluePrintProperties(name="sample_name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE)
            assert False
        except TypeError:
            assert True

        pass

    def test_complex_blueprint_properties(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Tests Sample Method
        """
        try:
            BluePrintProperties(name="sample_name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                                status=constants.STATUS.ACTIVE)
            assert False
        except KeyError:
            assert True

        try:
            BluePrintProperties(name="sample_name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                                status=constants.STATUS.ACTIVE, properties="")
            assert False
        except TypeError:
            assert True

        bp_param = BluePrintProperties("k", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                       status=constants.STATUS.ACTIVE)
        BluePrintProperties(name="sample_name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                            status=constants.STATUS.ACTIVE, properties=[bp_param])
        pass

    def test_list_blueprint_properties(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Tests Sample Method
        """
        try:
            BluePrintProperties(name="sample_name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                                status=constants.STATUS.ACTIVE, possible_values="A")
            assert False
        except KeyError:
            assert True

        try:
            BluePrintProperties(name="sample_name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                                status=constants.STATUS.ACTIVE, class_name="A")
            assert False
        except KeyError:
            assert True

    def test_list_blueprint_properties_json(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Tests Sample Method
        """
        bp1 = BluePrintProperties(name="sample_name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.LIST,
                                  status=constants.STATUS.ACTIVE, possible_values="1", class_name="A")
        bp_json = bp1.json()
        assert "possible_values" in bp_json.keys()
        assert "class_name" in bp_json.keys()
        assert "properties" not in bp_json.keys()

    def test_complex_blueprint_properties_json(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Tests Sample Method
        """
        bp_param = BluePrintProperties("k", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                       status=constants.STATUS.ACTIVE)
        bp1 = BluePrintProperties(name="sample_name", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.COMPLEX,
                                  status=constants.STATUS.ACTIVE, properties=[bp_param])
        bp_json = bp1.json()
        assert "properties" in bp_json.keys()
        assert "class_name" not in bp_json.keys()
        assert "possible_values" not in bp_json.keys()

    def test_normal_blueprint_properties_json(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Tests Sample Method
        """
        bp1 = BluePrintProperties("k", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                  status=constants.STATUS.ACTIVE)
        bp_json = bp1.json()
        assert "properties" not in bp_json.keys()
        assert "class_name" not in bp_json.keys()
        assert "possible_values" not in bp_json.keys()

        try:
            BluePrintProperties("k", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.INTEGER,
                                status=constants.STATUS.ACTIVE, possible_values="f")
            assert False
        except KeyError:
            assert True

        try:
            BluePrintProperties("k", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                                status=constants.STATUS.ACTIVE, class_name="f")
            assert False
        except KeyError:
            assert True

        try:
            BluePrintProperties("k", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                                status=constants.STATUS.ACTIVE, properties=[bp1])
            assert False
        except KeyError:
            assert True

    @raises(Exception)
    def test_sample_method_with_exception(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Tests sample.py method which throws exception
        """
        raise Exception('Raise Exception')
        pass
