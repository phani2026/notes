# -*- coding: utf-8 -*-
"""
| **@created on:** 5/31/18,
| **@author:** Himaprasoon PT,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** 
|
..todo::

"""

import rztdl.utils.string_constants as constants
from rztdl.blueprint import Blueprint
from rztdl.dl.components.dl_layer import FullyConnectedLayer


def setup_module():
    """
    | **@author:** Himaprasoon PT
    |
    | DL Module Setup - Called when this module is initialized - First Call
    """
    pass


def teardown_module():
    """
    | **@author:** Himaprasoon PT
    |
    | DL Module Teardown - Called when this module is completed - Last Call
    """
    pass


def my_setup_function():
    """
    | **@author:** Himaprasoon PT
    |
    | Custom Setup function
    """
    pass


def my_teardown_function():
    """
    | **@author:** Himaprasoon PT
    |
    | Custom Teardown function
    """
    pass


class TestBluePrint:
    """
    | **@author:** Himaprasoon PT
    |
    | BluePrintProperties Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        pass

    def setup(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Runs before a new method in the class is called
        """
        pass

    def teardown(self):
        """
        | **@author:** Himaprasoon PT
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Himaprasoon PT
        |
        | Runs during class initialization
        """
        pass

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Himaprasoon PT
        |
        | Runs after class reference is removed / class test cases are completed
        """
        pass

    def test_blueprint_add_output_component(self):
        bp = Blueprint(FullyConnectedLayer, version="0.0.1", status=constants.STATUS.ACTIVE)
        assert bp.class_name == FullyConnectedLayer.__module__ + "." + FullyConnectedLayer.__qualname__
        bp.add_inputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        bp.add_parameter(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                         status=constants.STATUS.ACTIVE, optional=False)
        bp.add_outputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                       status=constants.STATUS.ACTIVE, optional=False)

    def test_blueprint_add_output_non_component(self):
        bp = Blueprint(constants.ActivationType, version="0.0.1", status=constants.STATUS.ACTIVE)
        assert bp.class_name == constants.ActivationType.__module__

        bp.add_inputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                      status=constants.STATUS.ACTIVE, optional=False)
        bp.add_outputs(name="component_input", data_type=constants.BLUEPRINT_PARAMETERS.DataTypeOptions.NONE,
                       status=constants.STATUS.ACTIVE, optional=False)
