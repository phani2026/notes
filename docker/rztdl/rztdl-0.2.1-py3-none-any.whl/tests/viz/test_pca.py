# -*- coding: utf-8 -*-
"""
| **@created on:** 16/05/17,
| **@author:** Thebzeera V,
| **@version:** v0.0.1
|
| **Description:**
| PCA Test Class
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import matplotlib.pyplot as plt
from rztdl.utils.file import read_csv
from nose.tools import *
from rztdl.viz import pca
import os.path
from nose import with_setup  # optional
from sklearn.decomposition import PCA
import numpy as np


def setup_module():
    """
    | **@author:** Thebzeera V

    |
    |  Module Setup - Called when this module is initialized - First Call
    """


def teardown_module():
    """
    | **@author:** Thebzeera V
    |
    |  Module Teardown - Called when this module is completed - Last Call
    """


def my_setup_function():
    """
    | **@author:** Thebzeera V
    |
    | Custom Setup function
    """


def my_teardown_function():
    """
    | **@author:** Thebzeera V
    |
    | Custom Teardown function
    """

    pass


@with_setup(my_setup_function, my_teardown_function)
def test_simple():
    """
    | **@author:** Thebzeera V
    |
    | Test function utilizing custom setup and teardown
    """
    pass


class TestPca:
    """
    | **@author:** Thebzeera V
    |
    | test pca class

    """

    def __init__(self):
        pass

    def setup(self):
        """
        | **@author:** Thebzeera V
        |
        | Runs before a new method is called
        """

    def teardown(self):
        """
        | **@author:** Thebzeera V
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Thebzeera V
        |
        | Runs during class initialization
        """
        print("*********Running PCA Test Cases . . .*********")
        cls.n_component = 2
        cls.save_path = os.getcwd() + '/pca_image.png'
        cls.data_path = '/'.join(str(__file__).split('/')[:-2]) + '/data/'
        cls.data, cls.label, _, _, _, _ = read_csv(cls.data_path + 'sum.csv', split_ratio=[100, 0, 0],
                                                   output_label=True, randomize=True)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Thebzeera V
        |
        | Runs after class reference is removed / class test cases are completed
        """
        print("*********PCA Test Case completed successfully . . .*********")

    def test_plot(self):
        """
        | **@author:** Thebzeera V
        |
        | Test PCA Plot
        :return:
        """
        obj_pca = pca.Pca(n_component=self.n_component, data=np.array(self.data), label=np.array(self.label))
        obj_pca.plot(save_path=self.save_path, show=False)

        # Testing whether the path is present or not
        assert_equal(os.path.exists(self.save_path), True)
        os.remove(self.save_path)
