import rztdl
import rztdl.dl
import os
from nose.tools import *
import tensorflow as tf
from collections import OrderedDict
import rztdl.utils.dl_exception
from rztdl.meta import model_meta_parser


def setup_module():
    """
    | **@author:** Thebzeera V
    |
    | Module Setup - Called when this module is initialized - First Call
    """
    print("*********model meta parser Test Case . . .*********")


def teardown_module():
    """
    | **@author:** Thebzeera V
    |
    | Module Teardown - Called when this module is completed - Last Call
    """
    print("*********model meta parser Test Case completed successfully . . .*********")


def my_setup_function():
    """
    | **@author:** Thebzeera V
    |
    | Custom Setup function
    """


def my_teardown_function():
    """
    | **@author:** Thebzeera V
    |
    | Custom Teardown function
    """

    pass


class TestModelMetaAnalysis:
    """
    | **@author:** Thebzeera V
    |
    | **Description:**
    |  model meta analysis module contains various utilities required to test using nose test cases
    | 1. get meta data
    | 2. get run
    | 3. get best run cost
    | 4. get best run gini
    | 5. get best run accuracy
    | 5. get least run cost
    | 5. get least run gini
    | 5. get least run accuracy
    | 5. get average run
    """

    def __init__(self):
        """
        | Initialize Test dl_operator name
        """
        pass

    def setup(self):
        """
        | **@author:** Thebzeera V
        |
        | Runs before a new method is called
        """
        rztdl.RZTDL_STORE.dag = OrderedDict()
        tf.reset_default_graph()

    def teardown(self):
        """
        | **@author:** Thebzeera V
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Thebzeera V
        |
        | Runs during class initialization
        """
        cls.network_name = "data"
        cls.session = tf.InteractiveSession()
        cls.obj = model_meta_parser.ModelMetaAnalysis(cls.network_name)
        cls.cwd = os.getcwd()
        cls.obj.save_path = '/'.join(str(__file__).split('/')[:-2]) + '/'
        cls.obj.network_name = cls.network_name
        cls.keys, cls.cost, cls.accuracy, cls.gini = cls.obj.get_meta_data()
        cls.keys = cls.obj.metadata.keys()

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Thebzeera V
        |
        | Runs after class reference is removed / class test cases are completed
        """
        cls.session.close()

    def test_get_meta_data(self):
        """
        | **@author:** Thebzeera v
        |
        | Test get meta data
        :return:
        """
        assert_equal(os.path.exists(self.obj.save_path + self.network_name), True)
        cost_value = [
            self.obj.metadata[k][rztdl.ModelMetaConstant.TEST_META][rztdl.ModelMetaConstant.TEST_META_OPTIONS.TEST_COST]
            for k in
            self.keys]

        accuracy_value = [self.obj.metadata[k][
                              rztdl.ModelMetaConstant.TEST_META][
                              rztdl.ModelMetaConstant.TEST_META_OPTIONS.TEST_ACCURACY] for
                          k in self.keys]

        gini_value = [self.obj.metadata[k][
                          rztdl.ModelMetaConstant.TEST_META][rztdl.ModelMetaConstant.TEST_META_OPTIONS.TEST_GINI] for k
                      in
                      self.keys]

        assert_equal(cost_value, [7.3238844871521, 21.919965744018555, 12.541357040405273])
        assert_equal(accuracy_value, [35.0, 36.36, 33.18])
        assert_equal(gini_value, [-0.08900190718372536, -0.07116071428571424, -0.26372192712701525])

    def test_get_run(self):
        """
        | **@author:** Thebzeera v
        |
        | Test get run
        :return:
        """
        run_id = 0
        meta = self.obj.get_run(run_id)
        meta_data = self.obj.metadata
        assert_equal(meta, meta_data['0'])

    def test_get_best_run_cost(self):
        """
        | **@author:** Thebzeera v
        |
        | Test get best run cost
        :return:
        """
        learning = self.obj.get_best_run("cost").learning_rate
        cost = self.obj.get_best_run("cost").cost
        model_name = self.obj.get_best_run("cost").model_name
        accuracy = self.obj.get_best_run("cost").accuracy
        gini = self.obj.get_best_run("cost").gini
        test_batches = self.obj.get_best_run("cost").test_batches
        test_batche_size = self.obj.get_best_run("cost").test_batch_size
        train_batch = self.obj.get_best_run("cost").train_batches

        assert_equal(learning, 0.01)
        assert_equal(cost, 7.3238844871521)
        assert_equal(train_batch, 1)
        assert_equal(model_name, 'titanic')
        assert_equal(test_batche_size, 440)
        assert_equal(train_batch, 1)
        assert_equal(accuracy, 35.0)
        assert_equal(gini, -0.08900190718372536)
        assert_equal(test_batches, 1)

    def test_best_run_accuracy(self):
        """
        | **@author:** Thebzeera v
        |
        | Test get best run accuracy
        :return:
        """
        cost = self.obj.get_best_run("accuracy").cost
        model_name = self.obj.get_best_run("accuracy").model_name
        accuracy = self.obj.get_best_run("accuracy").accuracy
        gini = self.obj.get_best_run("accuracy").gini
        test_batches = self.obj.get_best_run("accuracy").test_batches
        test_batche_size = self.obj.get_best_run("accuracy").test_batch_size
        train_batch = self.obj.get_best_run("accuracy").train_batches
        train_batch_size = self.obj.get_best_run("accuracy").train_batch_size
        valid_batch_size = self.obj.get_best_run("accuracy").valid_batch_size
        valid_batches = self.obj.get_best_run("accuracy").valid_batches

        assert_equal(cost, 21.919965744018555)
        assert_equal(accuracy, 36.36)
        assert_equal(valid_batches, 1)
        assert_equal(test_batches, 1)
        assert_equal(valid_batch_size, 440)
        assert_equal(train_batch_size, 1540)
        assert_equal(train_batch, 1)
        assert_equal(model_name, 'titanic')
        assert_equal(test_batche_size, 440)
        assert_equal(gini, -0.07116071428571424)

    def test_best_run_gini(self):
        """
        | **@author:** Thebzeera v
        |
        | Test get best run gini
        :return:
        """
        cost = self.obj.get_best_run("gini").cost
        model_name = self.obj.get_best_run("gini").model_name
        accuracy = self.obj.get_best_run("gini").accuracy
        gini = self.obj.get_best_run("gini").gini
        test_batches = self.obj.get_best_run("gini").test_batches
        test_batche_size = self.obj.get_best_run("gini").test_batch_size
        train_batch = self.obj.get_best_run("gini").train_batches
        train_batch_size = self.obj.get_best_run("gini").train_batch_size
        valid_batch_size = self.obj.get_best_run("gini").valid_batch_size
        valid_batches = self.obj.get_best_run("gini").valid_batches

        assert_equal(gini, -0.07116071428571424)
        assert_equal(cost, 21.919965744018555)
        assert_equal(accuracy, 36.36)
        assert_equal(valid_batches, 1)
        assert_equal(test_batches, 1)
        assert_equal(valid_batch_size, 440)
        assert_equal(train_batch_size, 1540)
        assert_equal(train_batch, 1)
        assert_equal(model_name, 'titanic')
        assert_equal(test_batche_size, 440)

    def test_get_average_run(self):
        accuracy = self.obj.get_average_run("accuracy")
        gini = self.obj.get_average_run("gini")
        cost = self.obj.get_average_run("cost")
        assert_equal(cost, 13.928402423858643)
        assert_equal(accuracy, 34.846666666666664)
        assert_equal(gini, -0.14129484953215163)

    def test_get_least_run_gini(self):
        """
        | **@author:** Thebzeera v
        |
        | Test get least run gini
        :return:
        """
        cost = self.obj.get_least_run("gini").cost
        model_name = self.obj.get_least_run("gini").model_name
        accuracy = self.obj.get_least_run("gini").accuracy
        gini = self.obj.get_least_run("gini").gini
        test_batches = self.obj.get_least_run("gini").test_batches
        test_batche_size = self.obj.get_least_run("gini").test_batch_size
        train_batch = self.obj.get_least_run("gini").train_batches
        train_batch_size = self.obj.get_least_run("gini").train_batch_size
        valid_batch_size = self.obj.get_least_run("gini").valid_batch_size
        valid_batches = self.obj.get_least_run("gini").valid_batches

        assert_equal(gini, -0.26372192712701525)
        assert_equal(cost, 12.541357040405273)
        assert_equal(accuracy, 33.18)
        assert_equal(test_batches, 1)
        assert_equal(valid_batch_size, 440)
        assert_equal(train_batch_size, 1540)
        assert_equal(train_batch, 1)
        assert_equal(model_name, 'titanic')
        assert_equal(test_batche_size, 440)
        assert_equal(valid_batches, 1)

    def test_get_least_run_cost(self):
        """
        | **@author:** Thebzeera v
        |
        | Test get least run cost
        :return:
        """
        gini = self.obj.get_least_run("cost").gini
        model_name = self.obj.get_least_run("cost").model_name
        accuracy = self.obj.get_least_run("cost").accuracy
        cost = self.obj.get_least_run("cost").cost
        test_batches = self.obj.get_least_run("cost").test_batches
        test_batche_size = self.obj.get_least_run("cost").test_batch_size
        train_batch = self.obj.get_least_run("cost").train_batches
        train_batch_size = self.obj.get_least_run("cost").train_batch_size
        valid_batch_size = self.obj.get_least_run("cost").valid_batch_size
        valid_batches = self.obj.get_least_run("cost").valid_batches

        assert_equal(gini, -0.07116071428571424)
        assert_equal(cost, 21.919965744018555)
        assert_equal(accuracy, 36.36)
        assert_equal(test_batches, 1)
        assert_equal(valid_batch_size, 440)
        assert_equal(train_batch_size, 1540)
        assert_equal(model_name, 'titanic')
        assert_equal(valid_batches, 1)
        assert_equal(test_batche_size, 440)
        assert_equal(train_batch, 1)

    def test_get_least_run_accuracy(self):
        """
        | **@author:** Thebzeera v
        |
        | Test get least run accuracy
        :return:
        """
        learning = self.obj.get_least_run("accuracy").learning_rate
        cost = self.obj.get_least_run("accuracy").cost
        gini = self.obj.get_least_run("accuracy").gini
        model_name = self.obj.get_least_run("accuracy").model_name
        accuracy = self.obj.get_least_run("accuracy").accuracy
        test_batches = self.obj.get_least_run("accuracy").test_batches
        test_batche_size = self.obj.get_least_run("accuracy").test_batch_size
        train_batch = self.obj.get_least_run("accuracy").train_batches
        train_batch_size = self.obj.get_least_run("accuracy").train_batch_size
        valid_batch_size = self.obj.get_least_run("accuracy").valid_batch_size
        valid_batches = self.obj.get_least_run("accuracy").valid_batches

        assert_equal(learning, 0.01)
        assert_equal(gini, -0.26372192712701525)
        assert_equal(cost, 12.541357040405273)
        assert_equal(accuracy, 33.18)
        assert_equal(valid_batches, 1)
        assert_equal(test_batches, 1)
        assert_equal(valid_batch_size, 440)
        assert_equal(train_batch_size, 1540)
        assert_equal(train_batch, 1)
        assert_equal(model_name, 'titanic')
        assert_equal(test_batche_size, 440)
