# -*- coding: utf-8 -*-
"""
| **@created on:** 25/04/17,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import rztdl.dl
from nose.tools import *
from rztdl.utils.file import read_csv


class TestMnistPersistTrainModel:
    """
    | **@author:** Prathyush SP
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        pass

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method in the class is called
        """
        pass

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        print("*********Running MNIST Persist Train Test Cases . . .*********")
        cls.data_path = '/'.join(str(__file__).split('/')[:-2]) + '/data/'
        cls.train_data, cls.train_label, cls.valid_data, cls.valid_label, cls.test_data, cls.test_label = read_csv(
            cls.data_path + '/sample_mnist.csv',
            split_ratio=[60, 20, 20],
            output_label=[[785, 794]],
            normalize=False,
            randomize=True)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        del cls
        print("*********MNIST Persist Train Test Cases completed successfully. . .*********")

    def test_persist_train(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests Sample Method
        """
        network = rztdl.dl.Network('test_mnist_train')
        network.persist_training(epoch=1, learning_rate=0.01,
                                 train_data={'input_layer': self.train_data, 'output_layer': self.train_label},
                                 valid_data={'input_layer': self.valid_data, 'output_layer': self.valid_label},
                                 test_data={'input_layer': self.test_data, 'output_layer': self.test_label},
                                 display_step=1)
        pass

    @raises(FileExistsError)
    def test_persist_train_exception(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests sample method which throws exception
        """
        import os
        from rztdl import RZTDL_CONFIG
        network_path = RZTDL_CONFIG.CommonConfig.PATH_RZTDL+'/test_mnist_train'
        os.system('rm -rf '+ network_path)
        network = rztdl.dl.Network('test_mnist_train')
        network.persist_training(epoch=1, learning_rate=0.01,
                                 train_data={'input_layer': self.train_data, 'output_layer': self.train_label},
                                 valid_data={'input_layer': self.valid_data, 'output_layer': self.valid_label},
                                 test_data={'input_layer': self.test_data, 'output_layer': self.test_label},
                                 display_step=1)
