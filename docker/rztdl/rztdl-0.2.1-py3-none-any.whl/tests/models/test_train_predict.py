# -*- coding: utf-8 -*-
"""
| **@created on:** 25/04/17,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import rztdl.dl
from rztdl.utils.file import read_csv
from rztdl import RZTDL_STORE
import tensorflow as tf


class TestMnistTrain:
    """
    | **@author:** Prathyush SP
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        pass

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method in the class is called
        """
        pass

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        print("*********Running MNIST Train Test Case . . .*********")
        RZTDL_STORE.initialize()
        tf.reset_default_graph()
        cls.data_path = '/'.join(str(__file__).split('/')[:-2]) + '/data/'
        cls.train_data, cls.train_label, cls.valid_data, cls.valid_label, cls.test_data, cls.test_label = read_csv(
            cls.data_path + '/sample_mnist.csv',
            split_ratio=[60, 20, 20],
            output_label=[[785, 794]],
            normalize=False,
            randomize=True)
        cls.model = rztdl.dl.Model('cnn')
        cls.model.add_layer(rztdl.dl.dl_layer.InputLayer("input_layer", layer_nodes=len(cls.train_data[0])))
        cls.model.add_layer(rztdl.dl.dl_layer.ConvolutionLayer('con1', layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                               filter_dimensions=[5, 5, 1, 32],
                                                               filter_strides=[1, 1, 1, 1],
                                                               filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                               layer_filter=rztdl.dl.constants.InitializerType.random_normal(
                                                                std_dev=1.0,
                                                                mean=1.0,
                                                                seed=0),
                                                               layer_bias=rztdl.dl.constants.InitializerType.random_uniform(
                                                                min_val=0.0,
                                                                max_val=1.0,
                                                                seed=0),
                                                               norm_type=rztdl.dl.constants.NormalizationType.LRN_NORM,
                                                               norm_parameters=rztdl.dl.constants.NormalizationType.lrn_norm(
                                                                depth_radius=1,
                                                                bias=1,
                                                                alpha=1,
                                                                beta=0.5)
                                                               ))
        cls.model.add_layer(rztdl.dl.dl_layer.PoolLayer('pool1', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                                        pool_padding=rztdl.dl.constants.PaddingType.SAME,
                                                        pool_type=rztdl.dl.constants.PoolType.MAX_POOL,
                                                        layer_input='cnn.con1'))
        cls.model.add_layer(rztdl.dl.dl_layer.ConvolutionLayer('con2', layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                               filter_dimensions=[5, 5, 32, 64],
                                                               filter_strides=[1, 1, 1, 1],
                                                               filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                               layer_filter=rztdl.dl.constants.InitializerType.random_normal(
                                                                std_dev=1.0,
                                                                mean=1.0,
                                                                seed=0),
                                                               layer_bias=rztdl.dl.constants.InitializerType.random_uniform(
                                                                min_val=0.0,
                                                                max_val=1.0,
                                                                seed=0),
                                                               norm_type=rztdl.dl.constants.NormalizationType.L2_NORM,
                                                               norm_parameters=rztdl.dl.constants.NormalizationType.l2_norm(
                                                                dim=1,
                                                                epsilon=1e-10)
                                                               ))
        cls.model.add_layer(rztdl.dl.dl_layer.PoolLayer('pool2', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                                        pool_padding=rztdl.dl.constants.PaddingType.SAME,
                                                        pool_type=rztdl.dl.constants.PoolType.MAX_POOL))
        cls.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer(name="hidden_layer_1",
                                                                  layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                                  layer_nodes=10, layer_input='cnn.pool2',
                                                                  norm_type=rztdl.dl.constants.NormalizationType.L2_NORM,
                                                                  norm_parameters=rztdl.dl.constants.NormalizationType.l2_norm(
                                                                   dim=0,
                                                                   epsilon=1e-12)))
        cls.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer(name="hidden_layer_2",
                                                                  layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                                  layer_nodes=10, layer_input='cnn.hidden_layer_1'))
        cls.model.add_operator(
            rztdl.dl.dl_operator.AddOperator(name="add_operator", operator_input=["hidden_layer_1", "hidden_layer_2"],
                                             operator_output="add_op_out"))
        cls.model.add_layer(rztdl.dl.dl_layer.OutputLayer(name="output_layer",
                                                          layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                                          layer_nodes=len(cls.train_label[0]),
                                                          layer_input='hidden_layer_2'))
        cls.model.close()

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        del cls
        print("*********MNIST Train Test Case completed successfully. . .*********")

    def test_train(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Train Method
        """
        network = rztdl.dl.Network('test_mnist_train')
        network.train(epoch=1, learning_rate=0.01, model=self.model, cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
                      optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
                      train_data={'input_layer': self.train_data, 'output_layer': self.train_label},
                      valid_data={'input_layer': self.valid_data, 'output_layer': self.valid_label},
                      test_data={'input_layer': self.test_data, 'output_layer': self.test_label},
                      display_step=1)

    def test_predict(self):
        """
        | **@author:** Prathyush SP
        |
        | Test Predict Method
        """
        RZTDL_STORE.initialize()
        tf.reset_default_graph()
        pr = rztdl.dl.Prediction(network_name='test_mnist_train')
        pr.predict(layer_name='output_layer', data={'input_layer': self.test_data})
        for layer in ['con1', 'con2', 'hidden_layer_1', 'hidden_layer_2', 'output_layer']:
            pr.get_weights(layer_name=layer)
            pr.get_bias(layer_name=layer)
