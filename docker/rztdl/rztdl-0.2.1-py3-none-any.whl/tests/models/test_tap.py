# -*- coding: utf-8 -*-
"""
| **@created on:** 25/04/17,
| **@author:** Prathyush SP,
| **@version:** v0.0.1
|
| **Description:**
| DL Module Tests
| **Sphinx Documentation Status:** Complete
|
..todo::

"""

import rztdl.dl
from rztdl.dl import Tensor
import importlib
from nose.tools import *
import nose
import tensorflow as tf
from collections import OrderedDict
from nose import with_setup  # optional
from rztdl.utils.file import read_csv, read_network
from rztdl import RZTDL_STORE


class TestModel:
    """
    | **@author:** Prathyush SP
    |
    | Model Module Test Cases
    """

    def __init__(self):
        """
        | One time class Initialization
        """
        pass

    def setup(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs before a new method in the class is called
        """
        pass

    def teardown(self):
        """
        | **@author:** Prathyush SP
        |
        | Runs after each method is called
        """
        pass

    @classmethod
    def setup_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs during class initialization
        """
        print("*********Running MNIST Tap Test Case . . .*********")
        RZTDL_STORE.initialize()
        cls.data_path = '/'.join(str(__file__).split('/')[:-2]) + '/data/'
        cls.train_data, cls.train_label, cls.valid_data, cls.valid_label, cls.test_data, cls.test_label = read_csv(
            cls.data_path + '/sample_mnist.csv',
            split_ratio=[60, 20, 20],
            output_label=[[785, 794]],
            normalize=False,
            randomize=True)

        cls.model = rztdl.dl.Model('cnn')
        cls.model.add_layer(rztdl.dl.dl_layer.InputLayer("input_layer", layer_nodes=len(cls.train_data[0])))
        cls.model.add_layer(rztdl.dl.dl_layer.ConvolutionLayer('con1', layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                               filter_dimensions=[5, 5, 1, 32],
                                                               filter_strides=[1, 1, 1, 1],
                                                               filter_padding=rztdl.dl.constants.PaddingType.SAME,
                                                               layer_filter=rztdl.dl.constants.InitializerType.random_normal(
                                                                std_dev=1.0,
                                                                mean=1.0,
                                                                seed=0),
                                                               layer_bias=rztdl.dl.constants.InitializerType.random_uniform(
                                                                min_val=0.0,
                                                                max_val=1.0,
                                                                seed=0),
                                                               norm_type=rztdl.dl.constants.NormalizationType.LRN_NORM,
                                                               norm_parameters=rztdl.dl.constants.NormalizationType.lrn_norm(
                                                                depth_radius=1,
                                                                bias=1,
                                                                alpha=1,
                                                                beta=0.5)
                                                               ))
        cls.model.add_layer(rztdl.dl.dl_layer.PoolLayer('pool1', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                                        pool_padding=rztdl.dl.constants.PaddingType.SAME,
                                                        pool_type=rztdl.dl.constants.PoolType.MAX_POOL,
                                                        layer_input='con1'))
        cls.model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer(name="hidden_layer_1",
                                                                  layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                                  layer_nodes=10, layer_input='pool1',
                                                                  norm_type=rztdl.dl.constants.NormalizationType.L2_NORM,
                                                                  norm_parameters=rztdl.dl.constants.NormalizationType.l2_norm(
                                                                   dim=0,
                                                                   epsilon=1e-12)))
        cls.model.add_layer(rztdl.dl.dl_layer.OutputLayer(name="output_layer",
                                                          layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                                          layer_nodes=len(cls.train_label[0])))
        cls.model.close()
        cls.network = rztdl.dl.Network('test_mnist')
        cls.network.train(epoch=1, learning_rate=0.001, model=cls.model,
                          cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
                          optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
                          train_data={'input_layer': cls.train_data, 'output_layer': cls.train_label},
                          valid_data={'input_layer': cls.valid_data, 'output_layer': cls.valid_label},
                          test_data={'input_layer': cls.test_data, 'output_layer': cls.test_label},
                          display_step=1)

    @classmethod
    def teardown_class(cls):
        """
        | **@author:** Prathyush SP
        |
        | Runs after class reference is removed / class test cases are completed
        """
        pass

    def test_tap(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests Sample Method
        """
        conv2_train_data_tap, conv2_valid_data_tap, conv2_test_data_tap = \
            read_network(network_name='test_mnist.con1',
                         layer_data={
                             'input_layer': self.train_data + self.test_data + self.valid_data,
                             'output_layer': self.train_label + self.test_label + self.valid_label},
                         split_ratio=[60, 20, 20],
                         output_label=False)
        hidden_layer_2_train_data_tap, hidden_layer_2_valid_data_tap, hidden_layer_2_test_data_tap = read_network(
            network_name='test_mnist.hidden_layer_1',
            layer_data={'input_layer': self.train_data + self.test_data + self.valid_data,
                        'output_layer': self.train_label + self.test_label + self.valid_label},
            split_ratio=[60, 20, 20], output_label=False)

        model = rztdl.dl.Model('ffn')
        model.add_layer(rztdl.dl.dl_layer.InputLayer("input_layer", layer_nodes=len(self.train_data[0])))
        model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer(name="hidden_layer_1",
                                                              layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                              layer_nodes=10,
                                                              norm_type=rztdl.dl.constants.NormalizationType.L2_NORM,
                                                              norm_parameters=rztdl.dl.constants.NormalizationType.l2_norm(
                                                               dim=0,
                                                               epsilon=1e-12)))
        # Convolution 2 Tapping
        model.add_layer(rztdl.dl.dl_layer.InputLayer("conv2_tap", layer_shape=[None, 28, 28, 32]))
        model.add_layer(rztdl.dl.dl_layer.PoolLayer('pool2', pool_dimensions=[1, 2, 2, 1], pool_strides=[1, 2, 2, 1],
                                                    pool_padding=rztdl.dl.constants.PaddingType.SAME,
                                                    pool_type=rztdl.dl.constants.PoolType.MAX_POOL, layer_input='conv2_tap'))
        model.add_layer(rztdl.dl.dl_layer.FullyConnectedLayer(name="hidden_layer_2",
                                                              layer_activation=rztdl.dl.constants.ActivationType.RELU,
                                                              layer_nodes=10))

        # Hidden Layer 2 Tapping
        model.add_layer(rztdl.dl.dl_layer.InputLayer("hidden_layer_2_tap", layer_nodes=10))
        model.add_operator(
            rztdl.dl.dl_operator.ConcatOperator(name='concat_tap',
                                                operator_input=['hidden_layer_1', 'hidden_layer_2', 'hidden_layer_2_tap'],
                                                operator_output='concat_out', dimension=1))
        model.add_layer(rztdl.dl.dl_layer.OutputLayer(name="output_layer",
                                                      layer_activation=rztdl.dl.constants.ActivationType.IDENTITY,
                                                      layer_nodes=10, layer_input='concat_out'))
        model.close()
        network = rztdl.dl.Network('test_mnist_tap')
        network.train(epoch=1, learning_rate=0.001, model=model, cost=rztdl.dl.constants.CostType.SOFTMAX_CROSS_ENTROPY,
                      optimizer=rztdl.dl.constants.OptimizerTypes.ADAM,
                      train_data={'input_layer': self.train_data, 'output_layer': self.train_label,
                                  'conv2_tap': conv2_train_data_tap,
                                  'hidden_layer_2_tap': hidden_layer_2_train_data_tap},
                      valid_data={'input_layer': self.valid_data, 'output_layer': self.valid_label,
                                  'conv2_tap': conv2_valid_data_tap,
                                  'hidden_layer_2_tap': hidden_layer_2_valid_data_tap},
                      test_data={'input_layer': self.test_data, 'output_layer': self.test_label,
                                 'conv2_tap': conv2_test_data_tap,
                                 'hidden_layer_2_tap': hidden_layer_2_test_data_tap},
                      display_step=1)

    @raises(Exception)
    def test_sample_method_with_exception(self):
        """
        | **@author:** Prathyush SP
        |
        | Tests sample method which throws exception
        """
        raise Exception('Raise Exception')
        pass
